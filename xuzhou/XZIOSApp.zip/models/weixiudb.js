﻿﻿
var WEIXIUDB = new Object();

//作业任务(父工单)
WEIXIUDB.OPPlan = [
    "PWONum DEFAULT ''",
    "PlanFetchDate DEFAULT ''",
    "LineNum DEFAULT ''",
    "LineName DEFAULT ''",
    "OPName DEFAULT ''",
    "OPDate DEFAULT ''",
    "OPCode DEFAULT ''",
    "OPOrgNum DEFAULT ''",
    "OPOrgName DEFAULT ''",
    "UnitOrgNum DEFAULT ''",
    "UnitOrgName DEFAULT ''",
    "OPStartTime DEFAULT ''",
    "OPFinishTime DEFAULT ''",
    "OPContent DEFAULT ''",
    "PlanNote DEFAULT ''",
    "WorkStatus DEFAULT '1'",
    "OperateStatus DEFAULT '1'",
    "WOType DEFAULT ''",
    "IsOutOrder DEFAULT '0'",
    "OutOrderIsConfirm DEFAULT '0'",
    "OutOrderCheck DEFAULT '0'",
    "ResponseTime DEFAULT ''",
    "ResponseUserCode DEFAULT ''",
    "ResponseUserName DEFAULT ''",
    "RepairTime DEFAULT ''",
    "RepairUserCode DEFAULT ''",
    "RepairUserName DEFAULT ''",
    "DeviceLocationNum DEFAULT ''",
    "DeviceTypeNum DEFAULT ''",
];


//作业人员
WEIXIUDB.OPUsers = [
    "PWONum DEFAULT ''",
    "UserNum DEFAULT ''",
    "UserName DEFAULT ''",
    "UserCode DEFAULT ''",
    "LoginTime DEFAULT ''",
    "isAdd DEFAULT '0'"];

//工单
WEIXIUDB.OPOrders = [
    "PWONum DEFAULT ''",
    "WONum DEFAULT ''",
    "WOType DEFAULT ''",
    "DeviceNum DEFAULT ''",
    "DeviceName DEFAULT ''",
    "DeviceTypeNum DEFAULT ''",
    "DeviceTypeName DEFAULT ''",
    "JobPlanNum DEFAULT ''",
    "DeviceLocation DEFAULT ''",
    "DeviceLocationNum DEFAULT ''",
    "DeviceOfAreaNum DEFAULT ''",
    "RecSrc DEFAULT ''",
    "RecWay DEFAULT 'p'",
    "RecTime DEFAULT ''",
    "SelfFormIsFinished DEFAULT '0'",
    "SelfFormFinishTime DEFAULT ''",
    "SelfFormUserCode DEFAULT ''",
    "SelfFormUserName DEFAULT ''",
    "MutFormIsFinished  DEFAULT '0'",
    "MutFormUserCode DEFAULT ''",
    "MutFormUserName DEFAULT ''",
    "MutFormFinishTime DEFAULT ''",
    "DeviceNote DEFAULT ''",
    "OrderDesc DEFAULT ''",
    "RelatedAttNum DEFAULT ''",
    "TagCode DEFAULT ''",
    "AssetTagCode DEFAULT ''",
    "IsAllowedBatchSubmit DEFAULT ''",
    "HasFollowUpWork DEFAULT '0'",
    "IsOtherCheck DEFAULT '0'",
    "IsConfirm DEFAULT '0'",
    "ConfirmUserCode DEFAULT ''",
    "ConfirmTime DEFAULT ''",
    "SpecialtyNum DEFAULT ''",
    "SpecialtyName DEFAULT ''",
    "LineNum  DEFAULT ''",
    "LineName  DEFAULT ''",
    "IsDone DEFAULT '0'",
    "FailDate DEFAULT ''",
    "ActStart DEFAULT ''",
    "ActFinish DEFAULT ''",
    "IsRemove DEFAULT '0'",
    "RemoveUserCode DEFAULT ''",
    "RemoveUserName DEFAULT ''",
    "RemoveFinishTime DEFAULT ''",
    "IsNeedReqrev DEFAULT ''",
    "SubSystemID DEFAULT ''",
    "SubSystemNum DEFAULT ''",
    "SubSystemName DEFAULT ''",
    "LocationNum DEFAULT ''",
    "LocationName DEFAULT ''",
    "RepairContent DEFAULT ''",
    "TechnologyState DEFAULT ''",
    "IsUse DEFAULT ''",
    "FaultLevel DEFAULT ''",
    "EffectScope DEFAULT ''",
    "FaultRecTime DEFAULT ''",
    "PresentDate DEFAULT ''",
    "TempRepTime DEFAULT ''",
    "FaultCodeNum DEFAULT ''",
    "FaultPhenomenonNum DEFAULT ''",
    "FaultReasonNum DEFAULT ''",
    "FaultSolutionNum DEFAULT ''",
    "ResponseTime DEFAULT ''",
    "ReqPhoto DEFAULT ''",
    "CancelFlag DEFAULT '0'",//取消填报标识，lsw 2017年12月8日
    "CancelReason DEFAULT ''",//取消填报原因，lsw 2017年12月8日
    "CancelMemo DEFAULT ''",//取消填报备注，lsw 2017年12月8日
    //-----------------故障的数据
    "RecUserName DEFAULT ''",//故障处理人
    // "FaultRecTime DEFAULT ''",//处理时间
    "FaultDesc DEFAULT ''",//故障描述
    // "ResponseTime DEFAULT ''",//响应时间
    "FaultReportUserName DEFAULT ''",//故障提报人
    "FaultReportUserNum DEFAULT ''",//故障提报人编号
    "FaultRepMobilePhone DEFAULT ''",//提报人电话
    "FaultLocation DEFAULT ''",//故障地点
    "FaultJournalTime DEFAULT ''",//故障提报时间
    "FaultTime DEFAULT ''",//故障发生时间
    "OperationTimeFault DEFAULT '0'",//是否运营期故障
    "RequestCompletionTime DEFAULT ''",//要求完成时间
    "JobHeadUserName DEFAULT ''",//作业负责人
    "JobHeadUserID DEFAULT ''",//作业负责人
    "IsApplySGPlan  DEFAULT '0'",//是否申报施工计划
    "IsEquipmentFailure  DEFAULT '0'",//是否属设备故障
    "FaultCriminalTime DEFAULT ''",//故障接报时间
    "LocationID DEFAULT ''",//位置
    "LocationCode DEFAULT ''",
    "TrainBody DEFAULT ''",//车体
    "TrainNumber DEFAULT ''",//车次
    // "SubSystemID DEFAULT ''",
    // "LocationName DEFAULT ''",
    // "DeviceTypeNum DEFAULT ''",//设备类型
    // "DeviceTypeName DEFAULT ''",
    "ContractName DEFAULT ''",//合同名称
    "Supplier DEFAULT ''",//供应商
    "ContractCode DEFAULT ''",//合同号
    "SupplierTel DEFAULT ''",//联系方式

    "FormerEquipment  DEFAULT ''",
    "FormerEquipmentLocation  DEFAULT ''",
    "NewEquipment  DEFAULT ''",
    "NewEquipmentLocation  DEFAULT ''",
    "Station  DEFAULT ''",//提报车站
    "FormerEquipmentName  DEFAULT ''",//原对调设备
    "FormerEquipmentLocationName  DEFAULT ''",//原对调设备位置
    "NewEquipmentName  DEFAULT ''",//新对调设备
    "NewEquipmentLocationName  DEFAULT ''",//新对调设备位置
    "IsOutSource  DEFAULT '0'",//是否委外
    "FaultClassify DEFAULT ''",//故障分级

    "FaultCategory DEFAULT ''",//影响类别
    "RefinePptions DEFAULT ''",//细化选项
    "IsRepair DEFAULT ''",//是否启动抢修
    "ActualFaultTime DEFAULT ''",//故障实际发生时间
    "ActualEndTime DEFAULT ''",//临时修复时间
    "FaultCompleteTime DEFAULT ''",//完全修复时间
    "EquipmentStopStartTime DEFAULT ''",//设备停机开始时间
    "EquipmentStopEndTime DEFAULT ''",//设备停机结束时间
    "FaultDescription DEFAULT ''",//故障现象
    "FaultReason DEFAULT ''",//故障原因
    "FaultMemo DEFAULT ''"//故障措施
    // "OrderDesc DEFAULT ''",//备注

    
];

//计划区域标签 todo
WEIXIUDB.OPAreasTags = [
    "PWONum DEFAULT ''",
    "TagCode DEFAULT ''",
    "AreaID DEFAULT ''",
    "AreaName DEFAULT ''",
    "CoordX DEFAULT ''",
    "CoordY DEFAULT ''",
    "IsScan DEFAULT '0'"];

//设备工序
WEIXIUDB.OrderProcedure = [
    "PWONum DEFAULT ''",
    "WONum DEFAULT ''",
    "ProcedureNum DEFAULT ''",
    "JobTaskNum DEFAULT ''",
    "ProcedureGroup DEFAULT ''",
    "ProcedureDesc DEFAULT ''",
    "SortNum DEFAULT 0",
    "IsKeyTask DEFAULT ''",
    "TechStandard DEFAULT ''",
    "FormWay DEFAULT ''",
    "OptionsValue DEFAULT ''",
    "OptRequireGoTo DEFAULT ''",
    "PointNum DEFAULT ''",
    "PointName DEFAULT ''",
    "HasMultPoint DEFAULT ''",
    "MaxValue DEFAULT ''",
    "MinValue DEFAULT ''",
    "UppLayerProcedureNum DEFAULT ''",
    "HasChildProcedure DEFAULT ''",
    "ResultValue DEFAULT ''",
    "SelfFormTime DEFAULT ''",
    "SelfFormUserName DEFAULT ''",
    "SelfFormUserCode DEFAULT ''",
    "MutFormTime DEFAULT ''",
    "IsMutCheck DEFAULT '0'",
    "MutFormUserCode DEFAULT ''",
    "MutFormUserName DEFAULT ''",
    "RelatedAttNum DEFAULT ''",
    "PredecessorTasks DEFAULT ''",
    "IsPhotoGraph DEFAULT '0'"
];

//作业工具
WEIXIUDB.OPTools = [
    "PWONum DEFAULT ''",
    "OPToolNum DEFAULT ''",
    "OPToolName DEFAULT ''",
    "OPToolUnit DEFAULT ''",
    "OPToolCount DEFAULT ''",
    "BeforePlanRegTime DEFAULT ''",
    "BeforePlanRegCount DEFAULT ''",
    "FinishChkTime DEFAULT ''",
    "FinishChkCount DEFAULT ''",
    "IsNewAdded DEFAULT '0'",
    "RelatedAttNum DEFAULT ''"];

//物料
WEIXIUDB.OPMaterial = [
    "PWONum DEFAULT ''",
    "WONum DEFAULT ''",
    "OPMateriaID DEFAULT ''",
    "OPMaterialNum DEFAULT ''",
    "OPMaterialName DEFAULT ''",
    "OPMaterialUnit DEFAULT ''",
    "OPMaterialCount DEFAULT ''",
    "BeforePlanRegTime DEFAULT ''",
    "BeforePlanRegCount DEFAULT ''",
    "FinishChkTime DEFAULT ''",
    "FinishChkCount DEFAULT ''",
    "IsOut DEFAULT '0'"];

//标签读取记录
WEIXIUDB.TagRecords = [
    "PWONum DEFAULT ''",
    "TagCode DEFAULT ''",
    "ScanTime DEFAULT ''",
    "TagType DEFAULT ''",
    "EnterOrExit DEFAULT ''"];

//故障信息(林胜旺新增)
WEIXIUDB.FaultsOrder = [
    "PWONum DEFAULT ''",//父工单号
    "WONum DEFAULT ''",//工单号
    "WOType DEFAULT ''",//故障类型CM
    "SpecialtyNum DEFAULT ''",//专业
    "SpecialtyName DEFAULT ''",
    "LineNum DEFAULT ''",//线路
    "LineName DEFAULT ''",
    "DeviceNum DEFAULT ''",//设备
    "DeviceName DEFAULT ''",
    "SubSystemID DEFAULT ''",
    "SubSystemNum DEFAULT ''",//子系统
    "SubSystemName DEFAULT ''",
    "RecUserName DEFAULT ''",//故障处理人
    "RecUserNum DEFAULT ''",//故障处理人
    "FaultRecTime DEFAULT ''",//处理时间
    "FaultDesc DEFAULT ''",//故障描述
    "ResponseTime DEFAULT ''",//响应时间
    "FaultReportUserName DEFAULT ''",//故障提报人
    "FaultReportUserNum DEFAULT ''",//故障提报人编号
    "FaultRepMobilePhone DEFAULT ''",//提报人电话
    "FaultLocation DEFAULT ''",//故障地点
    "AppCode DEFAULT '18'",
    "FaultJournalTime DEFAULT ''",//故障提报时间
    "FaultTime DEFAULT ''",//故障发生时间
    "OperationTimeFault DEFAULT '0'",//是否运营期故障
    "RequestCompletionTime DEFAULT ''",//要求完成时间
    "JobHeadUserName DEFAULT ''",//作业负责人
    "JobHeadUserID DEFAULT ''",//作业负责人
    "IsApplySGPlan  DEFAULT '0'",//是否申报施工计划
    "IsEquipmentFailure  DEFAULT '0'",//是否属设备故障
    "FaultCriminalTime DEFAULT ''",//故障接报时间
    "LocationID DEFAULT ''",//位置
    "LocationCode DEFAULT ''",
    "LocationName DEFAULT ''",
    "DeviceTypeNum DEFAULT ''",//设备类型
    "DeviceTypeName DEFAULT ''",
    "IsOutSource  DEFAULT '0'",//是否委外
    "FaultClassify DEFAULT ''",//故障分级
    "FaultCategory DEFAULT ''",//影响类别
    "RefinePptions DEFAULT ''",//细化选项
    "IsRepair DEFAULT ''",//是否启动抢修
    "ActualFaultTime DEFAULT ''",//故障实际发生时间
    "ActualEndTime DEFAULT ''",//临时修复时间
    "FaultCompleteTime DEFAULT ''",//完全修复时间
    "EquipmentStopStartTime DEFAULT ''",//设备停机开始时间
    "EquipmentStopEndTime DEFAULT ''",//设备停机结束时间
    "FaultDescription DEFAULT ''",//故障现象
    "FaultReason DEFAULT ''",//故障原因
    "FaultMemo DEFAULT ''",//故障措施
    "OrderDesc DEFAULT ''",//备注
    "DownLoadUserCode DEFAULT ''",//下载人
    "selfFormIsFinished DEFAULT ''",//已完成
    "TrainBody DEFAULT ''",//车体
    "TrainNumber DEFAULT ''",//车次
    "ContractName DEFAULT ''",//合同名称
    "Supplier DEFAULT ''",//供应商
    "ContractCode DEFAULT ''",//合同号
    "SupplierTel DEFAULT ''",//联系方式

    "FormerEquipment  DEFAULT ''",
    "FormerEquipmentLocation  DEFAULT ''",
    "NewEquipment  DEFAULT ''",
    "NewEquipmentLocation  DEFAULT ''",
    "Station  DEFAULT ''",//提报车站
    "FormerEquipmentName  DEFAULT ''",//原对调设备
    "FormerEquipmentLocationName  DEFAULT ''",//原对调设备位置
    "NewEquipmentName  DEFAULT ''",//新对调设备
    "NewEquipmentLocationName  DEFAULT ''"//新对调设备位置
  
];

//附件
WEIXIUDB.AttFile = [
    "PWONum DEFAULT ''",
    "AttNum DEFAULT ''",
    "AttType DEFAULT ''",
    "ObjectType DEFAULT ''",
    "ObjectID DEFAULT ''",
    "AttDesc DEFAULT ''",
    "AttPath DEFAULT ''",
    "IsUpLoad DEFAULT '1'"
];

//线路
WEIXIUDB.Line = [
    "LineID DEFAULT ''",
    "LineNum DEFAULT ''",
    "LineName DEFAULT ''"];

//用户信息
WEIXIUDB.User = [
    "UserNum DEFAULT ''",
    "UserName DEFAULT ''",
    "UserCode DEFAULT ''",
    "Password DEFAULT ''",
    "LineNum DEFAULT ''",
    "LineName DEFAULT ''",
    "OrgNum DEFAULT ''",
    "OrgName DEFAULT ''",
    "UnitOrgNum DEFAULT ''",
    "UnitName DEFAULT ''",
    "SpecialtyNum DEFAULT ''",
    "SpecialtyName DEFAULT ''",
    "IsOutSourceUser DEFAULT '0'",
    "RecordStatus DEFAULT ''",//活动
    "MobilePhone DEFAULT ''"//电话号码

];

//设备基础数据
WEIXIUDB.Device = [
  "rownum DEFAULT ''",
    "DeviceNum DEFAULT ''",
    "DeviceName DEFAULT ''",
    "DeviceTypeNum DEFAULT ''",
    "DeviceTypeName DEFAULT ''",
    "SpecialtyNum DEFAULT ''",
    "SpecialtyName DEFAULT ''",
    "LineNum DEFAULT ''",
    "LineName DEFAULT ''",
    "AreaNum DEFAULT ''",
    "AreaName  DEFAULT ''",
    "LocationNum  DEFAULT ''",
    "LocationName  DEFAULT ''",
    "FaultCodeNum  DEFAULT ''",
    "TagCode  DEFAULT ''",
    "RecordStatus  DEFAULT ''"
    


];

//故障类型
WEIXIUDB.FaultClass = [
    "FaultClassCode DEFAULT ''",
    "FaultClassName DEFAULT ''"];

//故障现象
WEIXIUDB.FaultPhenomenon = [
    "FaultPhenomenonNum DEFAULT ''",
    "FaultPhenomenonName DEFAULT ''",
    "FaultCodeNum DEFAULT ''"];

//故障原因
WEIXIUDB.FaultReason = [
    "FaultReasonNum DEFAULT ''",
    "FaultReasonName DEFAULT ''",
    "FaultPhenomenonNum DEFAULT ''"];

//故障解决方式
WEIXIUDB.FaultSolution = [
    "FaultSolutionNum DEFAULT ''",
    "FaultSolutionName DEFAULT ''",
    "FaultReasonNum DEFAULT ''"];

//专业
WEIXIUDB.Specialty = [
    "SpecialtyNum DEFAULT ''",
    "SpecialtyName DEFAULT ''"];
//专业-子系统
WEIXIUDB.SubSystem = [
    "SubSystemID DEFAULT ''",
    "SubSystemNum DEFAULT ''",
    "SubSystemName DEFAULT ''",
    "SpecialtyNum DEFAULT ''"];


//作业区域
WEIXIUDB.Area = [
    "AreaNum DEFAULT ''",
    "AreaName DEFAULT ''",
    "LineNum DEFAULT ''",
    "TagCode DEFAULT ''",
    "SortOrder DEFAULT ''"];

//位置
WEIXIUDB.Location = [
    "rownum DEFAULT ''",
    "LocationID DEFAULT ''",
    "LocationNum DEFAULT ''",
    "LocationName DEFAULT ''",
    "TagCode DEFAULT ''",
    "ParentLocationNum DEFAULT ''",
    "AreaNum DEFAULT ''",
    "RecordStatus DEFAULT ''",
    "SpecialtyNum DEFAULT ''",
    "CoordX DEFAULT '0'",
    "CoordY DEFAULT '0'"];
//站点
WEIXIUDB.ALNDomain = [
    "ALNDomainID DEFAULT ''",
    "VALUE DEFAULT ''",
    "LineNum DEFAULT ''"];

//测点数据
WEIXIUDB.MeasurePoint = [
    "PointNum DEFAULT ''",
    "Description DEFAULT ''",
    "MeasureUnitID DEFAULT ''",
    "Location DEFAULT ''",
    "AssetNum DEFAULT ''",
    "UpperWarning DEFAULT ''",
    "LowerWarning DEFAULT ''"];

//测量结果数据
WEIXIUDB.Measurement = [
    "WONum DEFAULT ''",
    "PointNum  DEFAULT ''",
    "MeasurementValue  DEFAULT ''",
    "MeasurementType DEFAULT ''",
    "MeasureDate DEFAULT ''"
];

//物料基础数据
WEIXIUDB.Material = [
    "ItemNum DEFAULT ''",
    "Description DEFAULT ''",
    "ItemUnit  DEFAULT ''"
];
//工具基础数据
WEIXIUDB.Tool = [
    "OPToolNum DEFAULT ''",
    "OPToolName DEFAULT ''",
    "OPToolUnit DEFAULT ''"
];

//委外物料基础数据
WEIXIUDB.OutMaterial = [
    "ItemNum DEFAULT ''",
    "Description  DEFAULT ''",
    "ItemUnit DEFAULT ''"
];


//安全交底主表
WEIXIUDB.OPSafetyMain = [
    "PWONum DEFAULT ''",
    "IsTakeover DEFAULT ''",
    "IsConfirm DEFAULT ''",
    "ConfirmTime DEFAULT ''",
    "SafetyMainNum DEFAULT ''"
];

//安全交底细项
WEIXIUDB.OPSafety = [
    "PWONum DEFAULT ''",
    "OPSafetyNum DEFAULT ''",
    "OPSafetyDesc DEFAULT ''",
    "OPSafetyClass DEFAULT ''",
    "OPsafetySec DEFAULT ''",
    "IsConfirm DEFAULT '0'",
    "SafetyMainNum DEFAULT ''"
];

//取消工单
WEIXIUDB.CancelReason = [
    "CancelNum DEFAULT ''",
    "CancelName DEFAULT ''"
];
