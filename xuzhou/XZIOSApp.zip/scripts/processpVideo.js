﻿var ProcesspVideo = function () {
    this.PageParam = null;

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });

    })(this);
    this.VideoBox = null;
};

ProcesspVideo.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSave").click(function () {
            _self.funSaveProcess();
        });
    },
    funInitPageHeader: function () {
        var _self = this;
        var orderObj = new Object();
        orderObj.WONum = _self.PageParam["WONum"];
        SqlHelper.funGetData("OPOrders", function (rowsOrder) {
            var rowsOrderlen = rowsOrder.length;
            if (rowsOrderlen > 0) {
                $("#pageTitle").text(rowsOrder[0]["DeviceLocation"]);
            }
            ;
        }, orderObj);
    },

    funInitVideoBox: function (containerId) {
        var _self = this;
        if (_self.PhotoBox == null) {
            var param = new Object();
            param.ObjectType = "UDWOTASK";
            param.ObjectID = _self.PageParam["UppLayerProcedureNum"];
            param.ContainerId = containerId;
            _self.VideoBox = new PhotoBox(param);
        }
        _self.PhotoBox.initBox(_self.VideoBox);
    },

    funSaveProcess: function () {
        var _self = this;
        var procedureNum = _self.PageParam["UppLayerProcedureNum"];
        var resultValue = _self.PageParam["ResultValue"];

        var sqlParam = new Object();
        sqlParam.ResultValue = resultValue;
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                sqlParam.SelfFormUserName = res;
            }
        });
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                sqlParam.SelfFormUserCode = res;
            }
        });
        sqlParam.SelfFormTime = Common.funGetNowDate();
        sqlParam.WhereParam = new Object();
        sqlParam.WhereParam.ProcedureNum = procedureNum;
        SqlHelper.funUpdateData("OrderProcedure", [sqlParam], function () {
            Common.funGoBack();
        });
    },
    funBackRefresh: function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var pageName = retParam["pageName"];
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("processpAudio.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funInitVideoBox("vboxList");
            _self.funInitPageHeader();
        }, 100);
    }
};
