﻿﻿var Choice = function () {
    this.PWONumList = new Array();
};

Choice.prototype = {
    funInitEvent: function () {
        var _self = this;
        $("#imback").click(function () {
            Common.funGoBack();
        });
        // $("#btnStartWork").click(function () {
        //     _self.funStartWork();
        // });
        $("#btnDel").click(function () {
            //测试用删除全部工单数据
            //_self.funDelPaln(pWoNum);
            var _self = this;
            var chkObj = _self.funGetChkList();
            var planList = chkObj.PlanList;
            var faultList = chkObj.FaultList;
            var chkListCount = planList.length + faultList.length;
            if (chkListCount > 0) {
                app.confirm("确认要删除所选作业?", function (index) {
                    if (index == 2) {
                        app.progress.start("删除提示", "正在处理中...");
                        //_self.funDelWK(planList, faultList, true, []);
                    }
                }, "删除作业确认", "取消,确定");
            }

            //app.progress.start("提示", "数据正在处理...");
            //var sqlList = new Array();
            //sqlList.push("delete from OPPlan");
            //sqlList.push("delete from OPOrders");
            //sqlList.push("delete from FaultsOrder");
            //sqlList.push("delete from OPTools");
            //sqlList.push("delete from OPMaterial");
            //sqlList.push("delete from OPPlan");
            //var db = app.database.open(Common.WEIXIUDB);
            //db.transaction(function (tx) {
            //    for (var j = 0; j < sqlList.length; j++) {
            //        tx.executeSql(sqlList[j]);
            //    }
            //}, function (error) {
            //    app.alert(error, function () {
            //        app.progress.stop();
            //    });
            //}, function () {
            //    app.progress.stop();
            //    app.alert("删除成功！");
            //    _self.funInitPlanData("planList");
               
            //});
        });
        $("#btnLogOut").click(function () {
            Common.funLoadMain();
        });


        $("#btnSearch").click(function () {
            var oPCode = $("#txtOPCode").val();
            choice.funInitPlanData("planList","",oPCode);
        });

        var funCode = function (res) {
            if (res) {
                switch (res["TagType"]) {
                    case "L"://设备的位置标签
                        _self.funChoicePlan("L"+res["TagCode"]);
                        break;
                    default:
                        _self.funChoicePlan(res["TagCode"]);
                        app.alert("非设备标签[" + res["TagType"] + res["TagCode"] + "]！");
                        break;
                }
            } else {
                navigator.notification.vibrate(2000);
                app.alert("未知标签！");
            }
        };

        $("#btnBarCode").click(function () {
            Common.getBarcode(function (res) {
                funCode(res);
            }, function () {
                navigator.notification.vibrate(2000);
                app.alert("app扫描二维码，无法获取数据！");
            });
        });

        app.setting.get("bluetooth_key", "", function (rest) {
            if (rest) {
                setInterval(function () {
                    app.getGlobalVariable("bluetoothIsConnected", function (isCon) {
                        if (isCon == "F") {   //F ==失
                            app.bluetooth.connect(rest);
                        } else if (isCon == "S") { //成功
                            var res = window.bluetoothValue;
                            if (res) {
                                window.bluetoothValue = "";
                                var convertCode = Common.funConvertCode(res);
                                funCode(convertCode);
                            }
                        } else if (isCon == "H") { //正在连接请等待

                        }
                    });
                }, 1000);
            }
        });
    },

    funInitUiData: function () {
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                $("#username").html(res);
            }
        });

        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                $("#usercode").html("（" + res + "）");
            }
        });
    },
    funInitPlanData: function (containerId,userCode,planCode) {
        if(planCode == null){
            planCode = "";
        }
        if(userCode == null){
            userCode = "";
        }
        var _self = this;
        _self.PWONumList.length = 0;
        var db = app.database.open(Common.WEIXIUDB);
        var sqlText = "SELECT *,( select count(c.PWONum) from OPOrders c where RecWay='s' and c.PWONum=PWONum ) as ScanNum ,( select count(o.PWONum) as scanNum from OPOrders o where o.PWONum=PWONum ) as OrderNum  FROM OPPlan WHERE PWONum LIKE '%" + planCode + "%' or OPName like '%" + planCode + "%' ORDER BY WOType ASC,OPDate ASC,WorkStatus ASC ";

        var sqlByUser = "SELECT PWONum FROM OPOrders WHERE SelfFormUserCode LIKE '%"+userCode+"%'";

        var opRows;
        var rows = new Array();
        var userRows;

        db.transaction(function (tx) {
                tx.executeSql(sqlText, [], function (tx1, results) {
                    opRows = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlByUser, [], function (tx1, results) {
                    userRows = Common.funConvertRowsJson(results);
                });
            }, function (error) {
                app.alert(error);
            }, function () {
            for(var k = 0;k<opRows.length;k++){
                for(var j = 0;j<userRows.length;j++){
                    if(opRows[k]["PWONum"] == userRows[j]["PWONum"]){
                        rows.push(opRows[k]);
                    }
                }
            }
            var lihtml = "";
            if (rows.length == 0) {
                lihtml += '<li>';
                lihtml += '<div data-role="BTButton" mouseup="false" mousedown="false" data-status="1">';
                lihtml += '<span class="btn-text">暂无待办工单</span>';
                lihtml += '</div>';
                lihtml += '</li>';


            } else {
                var funGetWkStatus = function (workStatus) {
                    var wkStatusText = "";
                    switch (workStatus) {
                        case "1":
                            wkStatusText = "【未开始】";
                            break;
                        case "2":
                            wkStatusText = "【进行中】";
                            break;
                        case "3":
                            wkStatusText = "【已完成未上传】";
                            break;
                        case "4":
                            wkStatusText = "【已发送到电脑】";
                            break;
                        default:
                            wkStatusText = "【N/A】";
                            break;
                    }
                    return wkStatusText;
                };


                var funGetOpStatus = function (operateStatus) {
                    var opStatusText = "";
                    switch (operateStatus) {
                        case "1":
                            opStatusText = "class='BTCheck_OFF'";
                            break;
                        case "2":
                            opStatusText = "class='BTCheck_ON'";
                            break;
                        default:
                            opStatusText = "class='BTCheck_OFF'";
                            break;
                    }
                    return opStatusText;
                };

                var leng = rows.length;

                for (var i = 0; i < leng; i++) {
                    var row = rows[i];
                    _self.PWONumList.push(row["PWONum"]);
                    var responseTime = row["ResponseTime"];
                    var repairTime = row["RepairTime"];
                    var pWoNum = row["PWONum"];
                    var wOType = row["WOType"];
                    var oPcode = row["OPCode"] ? "(" + row["OPCode"] + ")" : "";
                    var responeUser = row["ResponseUserName"] ? "(响应人：" + row["ResponseUserName"] + ")" : "";
                    var outOrderCheck = row["OutOrderCheck"];
                    var outOrderIsConfirm = row["OutOrderIsConfirm"];
                    var scanNum = row["ScanNum"] || 0;
                    var orderNum = row["OrderNum"] || 0;

                    lihtml += '<li>';
                    lihtml += '<div data-role="BTButton" >';
                    lihtml += '<span class="btn-text">';
                    lihtml += '<div class="row-box">';
                    lihtml += '<div class="span1">';
                    if (wOType == "CM" || wOType == "CBM") {
                        lihtml += '<div id=' + row["PWONum"] + '  _WorkStatus=' + row["WorkStatus"] + ' value=' + row["PWONum"] + funGetOpStatus(row["OperateStatus"]) + ' data-inline="false">' + "<b><font style='color: red;font-size: 35px'>! </font></b>" + row["PWONum"] + "_" + row["OPName"] + oPcode + responeUser + funGetWkStatus(row["WorkStatus"]) + '</div>';
                    } else {
                        lihtml += '<div id=' + row["PWONum"] + '  _WorkStatus=' + row["WorkStatus"] + ' value=' + row["PWONum"] + funGetOpStatus(row["OperateStatus"]) + ' data-inline="false">' + row["PWONum"] + "_" + row["OPName"] + oPcode + funGetWkStatus(row["WorkStatus"]) + '</div>';
                    }
                    if (outOrderCheck == "1" && outOrderIsConfirm == "0") {
                        lihtml += '<div id="orderconfirm_' + pWoNum + '" PWONum="' + pWoNum + '"  class="moreFill" align="right">确认</div>';
                    }
                    lihtml += '</div>';
                    if (wOType == "CM") {
                        if (repairTime == "") {
                            lihtml += '<div id="start_' + pWoNum + '" PWONum="' + pWoNum + '"   data-inline="true"  data-status="1" align="right" class="btnStyleMini"><span class="">填报</span></div>';
                            lihtml += '<div id="eorRpt_' + pWoNum + '" PWONum="' + pWoNum + '" activity="ErrorReport"   data-inline="true" data-status="1" align="right" class="btnStyleMini" style="margin-left: 10px"><span class="">误报</span></div>';
                            lihtml += '<div id="Del_' + pWoNum + '" PWONum="' + pWoNum + '"data-inline="true" data-status="1" align="right" class="btnStyleMini " style="margin-left: 10px"><span class="">删除</span></div>';
                        } else {
                            lihtml += '<div id="start_' + pWoNum + '" PWONum="' + pWoNum + '"  data-inline="true"  data-status="1" align="right" class="btnStyleMini "><span class="">填报</span></div>';
                            lihtml += '<div id="Del_' + pWoNum + '" PWONum="' + pWoNum + '" data-inline="true" data-status="1" align="right" class="btnStyleMini " style="margin-left: 10px"><span class="">删除</span></div>';
                        }
                    } else {
                        lihtml += '<div id="start_' + pWoNum + '" PWONum="' + pWoNum + '"   data-inline="true"  data-status="1" align="right" class="btnStyleMini"><span class="">填报</span></div>';
                        lihtml += '<div id="Del_' + pWoNum + '" PWONum="' + pWoNum + '"data-inline="true" data-status="1" align="right" class="btnStyleMini " style="margin-left: 10px"><span class="">删除</span></div>';
                    }
                    lihtml += '</div>';
                    lihtml += '</span>';
                    lihtml += '</div>';
                    lihtml += '</li>';
                }
            }
            var cnt = document.getElementById(containerId);
            if (cnt) {
                cnt.innerHTML = lihtml;
                ui.init();
                _self.funBindEvent(rows);
            }
        });
    },
    funStartWork: function (PWONum,OPDesc) {
        var _self = this;
        var sqlparam = new Object();
        var sqlTextList = new Array();
        var startWkList = new Array();

        sqlparam.WhereParam = new Object();
        sqlparam.WhereParam.PWONum = PWONum;
        sqlparam.OperateStatus = "2";
        var sqlText = SqlTextHelper.funUpdateDataText("OPPlan", sqlparam);
        sqlTextList.push(sqlText);

        var specialtyNum = "";
        app.getGlobalVariable("SpecialtyNum", function (resVal) {
            if (resVal) {
                specialtyNum = resVal;
            }
        });

        var wk = new Object();
        wk.PWONum = PWONum;
        wk.OPDesc = OPDesc;
        startWkList.push(wk);

        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(db, sqlTextList, function () {
            app.setGlobalVariable("CurrentPWONum", PWONum);
            app.setGlobalVariable("startWkList", JSON.stringify(startWkList));
            if (specialtyNum == "gzw") {
                Common.funLoad("eqlist.html");
            } else {
                Common.funLoad("tool.html");
            }
        });

    },
    funStartFail:function (PWONum) {
        var specialtyNum = "";
        app.getGlobalVariable("SpecialtyNum", function (resVal) {
            if (resVal) {
                specialtyNum = resVal;
            }
        });
        var sqlTextList = new Array();
        var startWkList = new Array();
        var startWk = {
            "PWONum":PWONum
        };
        startWkList.push(startWk);
        var sqlparam = new Object();
        sqlparam.WhereParam = new Object();
        sqlparam.WhereParam.PWONum = PWONum;
        sqlparam.OperateStatus = "2";
        var sqlText = SqlTextHelper.funUpdateDataText("OPPlan", sqlparam);
        sqlTextList.push(sqlText);
        if (specialtyNum == "afc" || specialtyNum == "acs") {
            app.alert("请先响应后填报");
        } else {
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeNonQuery(db, sqlTextList, function () {
                app.setGlobalVariable("CurrentPWONum", PWONum);
                app.setGlobalVariable("startWkList", JSON.stringify(startWkList));
                Common.funLoad("tool.html");
            });
        }

    },
    funBindEvent: function (rows) {
        var _self = this;
        var rowlen = rows.length;
        for (var i = 0; i < rowlen; i++) {
            var item = rows[i];
            var wOType = item["WOType"];
            var isOutOrder = item["IsOutOrder"];
            var pWoNum = item["PWONum"];
            $("#Del_" + pWoNum).click(function () {
                var ctr = $(this);
                app.confirm("确认删除该工单?", function (index) {
                    if (index == 2) {
                        var pwoNum = ctr.attr("PWONum");
                        _self.funDelPaln(pwoNum);
                    }
                }, "删除工单确认", "取消,确定");
            });
            if (wOType == "CM") {
                var responseTime = item["ResponseTime"];
                var repairTime = item["RepairTime"];
                if (responseTime == "" || repairTime == "") {
                    $("#act_" + pWoNum).click(function () {
                        var ctr = $(this);
                        var pwoNum = ctr.attr("PWONum");
                        var activity = ctr.attr("activity");
                        var msg = "";
                        var title = "";
                        if (activity == "ResponseTime") {
                            msg = "确认响应该工单";
                            title = "响应工单确认";
                        } else {
                            msg = "确认修复完成该工单";
                            title = "修复完成工单确认";
                        }
                        app.confirm(msg, function (index) {
                            if (index == 2) {
                                _self.funFaultReply(pwoNum, activity);
                            }
                        }, title, "取消,确定");
                    });
                }

                $("#eorRpt_" + pWoNum).click(function () {
                    var ctr = $(this);
                    app.confirm("确认该工单为误报工单?", function (index) {
                        if (index == 2) {
                            var pwoNum = ctr.attr("PWONum");
                            var activity = ctr.attr("activity");
                            _self.funFaultReply(pwoNum, activity);
                        }
                    }, "误报工单确认", "取消,确定");
                });

               

                $("#start_" + pWoNum).click(function () {
                    var ctr = $(this);
                    var pwoNum = ctr.attr("PWONum");
                    _self.funStartFail(pwoNum);

                });

            } else {
                $("#start_" + pWoNum).click(function () {
                    var ctr = $(this);
                    var pwoNum = ctr.attr("PWONum");
                    _self.funStartWork(pwoNum);
                });
            }


            if (isOutOrder == "1") {
                $("#orderconfirm_" + pWoNum).click(function () {
                    var ctr = $(this);
                    var pwonum = ctr.attr("PWONum");
                    var sqlPlanText = "update OPPlan set OutOrderIsConfirm='1' where PWONum='" + pwonum + "'";

                    var userCode = "";
                    var cfirmTime = Common.funGetNowDate();
                    app.getGlobalVariable("UserCode", function (res) {
                        if (res) {
                            userCode = res;
                        }
                    });
                    var sqlOrderText = "update OPOrders set IsConfirm='1' ,ConfirmUserCode='" + userCode + "',ConfirmTime='" + cfirmTime + "' where PWONum='" + pwonum + "'";

                    var db = app.database.open(Common.WEIXIUDB);
                    app.database.executeNonQuery(db, [sqlPlanText, sqlOrderText], function () {
                        ctr.remove();
                    });
                });

            }
        }
    },
    funFaultReplyNew: function (pWoNum, activity) {
        var _self = this;
        var actTime = Common.funGetNowDate();
        if (activity == "ErrorReport") {
            _self.funDelPaln(pWoNum);
        } else {
            var usercode = "";
            app.getGlobalVariable("UserCode", function (resVal) {
                if (resVal) {
                    usercode = resVal;
                }
            });
            var sqlText = "";
            switch (activity) {
                case "ResponseTime":
                    sqlText = "update OPPlan set ResponseTime='" + actTime + "' ,ResponseUserCode='" + usercode + "' where PWONum='" + pWoNum + "'";
                    break;
                case "RepairTime":
                    sqlText = "update OPPlan set RepairTime='" + actTime + "' ,RepairUserCode='" + usercode + "' where PWONum='" + pWoNum + "'";
                    break;
            }
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeNonQuery(db, sqlText, function () {
                var ctr = $("#act_" + pWoNum);
                if (activity == "RepairTime") {
                    $("#eorRpt_" + pWoNum).remove();
                    ctr.remove();
                } else {
                    ctr.remove();
                }
            });
        }
    },

    funFaultReply: function (pWoNum, activity) {
        var _self = this;
        var requestParam = new Object();
        var actTime = Common.funGetNowDate();
        var replyItem = new Object();
        replyItem.PWONum = pWoNum;
        replyItem.ActivityType = activity;
        replyItem.ActivityTime = actTime;
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                replyItem.UserCode = res;
            }
        });
        requestParam.orgin = "stream";
        requestParam.AuthBlock = new Object();
        requestParam.AuthBlock.RequestTime = actTime;
        requestParam.AuthBlock.ClientNumber = device.uuid;
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                requestParam.AuthBlock.UserCode = res;
                replyItem.UserCode = res;
            }
        });
        app.getGlobalVariable("Password", function (res) {
            if (res) {
                requestParam.AuthBlock.Password = res;
            }
        });
        requestParam.CallMethod = "Misc_FaultWOReply";
        requestParam.PayLoad = replyItem;
        app.progress.start("提示", "数据正在处理...");
        app.ajax({
            "url": MobileConfig.FaultWOReply, "data": requestParam,
            "contentType": "application/json",
            "method": "POST", "async": false,
            "success": function (res) {
                app.progress.stop();
                var responseData = JSON.parse(res.returnValue);
                if (responseData.ResStatus == true) {
                    if (activity == "ErrorReport") {
                        _self.funDelPaln(pWoNum);
                    } else {
                        var usercode = "";
                        app.getGlobalVariable("UserCode", function (resVal) {
                            if (resVal) {
                                usercode = resVal;
                            }
                        });
                        var sqlText = "";
                        switch (activity) {
                            case "ResponseTime":
                                sqlText = "update OPPlan set ResponseTime='" + actTime + "' ,ResponseUserCode='" + usercode + "' where PWONum='" + pWoNum + "'";
                                break;
                            case "RepairTime":
                                sqlText = "update OPPlan set RepairTime='" + actTime + "' ,RepairUserCode='" + usercode + "' where PWONum='" + pWoNum + "'";
                                break;
                        }
                        var db = app.database.open(Common.WEIXIUDB);
                        app.database.executeNonQuery(db, sqlText, function () {
                            var ctr = $("#act_" + pWoNum);
                            if (activity == "RepairTime") {
                                $("#eorRpt_" + pWoNum).remove();
                                ctr.remove();
                            } else {
                                ctr.remove();
                            }
                            _self.funInitPlanData("planList");
                        });
                    }
                } else {
                    app.alert(responseData.ResMsg);
                }
            }
        });
    },

    funDelPaln: function (pwoNum) {
        var _self = this;
        var delTagRecordsText = "delete from TagRecords where PWONum='" + pwoNum + "' ";
        var delOPMaterialText = "delete from OPMaterial where PWONum='" + pwoNum + "' ";
        var delOPToolsText = "delete from OPTools where PWONum='" + pwoNum + "' ";
        var delOPAreasTagsText = "delete from OPAreasTags where PWONum='" + pwoNum + "' ";
        var delAttFileText = "delete from AttFile where PWONum='" + pwoNum + "' ";
        var delFaultsOrderText = "delete from FaultsOrder where PWONum='" + pwoNum + "' ";
        var delOrderProcedureText = "delete from OrderProcedure where PWONum='" + pwoNum + "' ";
        var delOPOrdersText = "delete from OPOrders where PWONum='" + pwoNum + "' ";
        var delOPPlanText = "delete from OPPlan where PWONum='" + pwoNum + "' ";
        var delOPSafetyText = "delete from OPSafety where PWONum='" + pwoNum + "' ";
        var delOPSafetyMainText = "delete from OPSafetyMain where PWONum='" + pwoNum + "' ";

        var selAttFileText = "select AttPath  from AttFile where PWONum='" + pwoNum + "' ";

        var attRows = new Array();
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            tx.executeSql(selAttFileText, [], function (tx1, results) {
                attRows = Common.funConvertRowsJson(results);
            });
            tx.executeSql(delTagRecordsText);
            tx.executeSql(delOPMaterialText);
            tx.executeSql(delOPToolsText);
            tx.executeSql(delOPAreasTagsText);
            tx.executeSql(delAttFileText);
            tx.executeSql(delOrderProcedureText);
            tx.executeSql(delFaultsOrderText);
            tx.executeSql(delOPOrdersText);
            tx.executeSql(delOPSafetyText);
            tx.executeSql(delOPSafetyMainText);
            tx.executeSql(delOPPlanText);

        }, function (error) {
            app.alert(error);
        }, function () {
            var attlen = attRows.length;
            if (attRows > 0) {
                for (var j = 0; j < attlen; j++) {
                    var path = attRows[j];
                    if (path) {
                        window.resolveLocalFileSystemURI(path, function (fileEntry) {
                            fileEntry.remove();
                        }, null);
                    }
                }
            }
            _self.funInitPlanData("planList");
        });
    },
    funDelWK: function (planList, faultList, isDelAttFile, attFileList) {
        var _self = this;
        var sqlList = new Array();
        var planLeng = planList.length;
        for (var i = 0; i < planLeng; i++) {
            var pwoNum = planList[i];
            sqlList.push("delete from TagRecords where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPMaterial where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPTools where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPAreasTags where PWONum='" + pwoNum + "'");
            if (isDelAttFile) {
                sqlList.push("delete from AttFile where PWONum='" + pwoNum + "'");
            }
            sqlList.push("delete from OrderProcedure where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPOrders where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPPlan where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPSafety where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPSafetyMain where PWONum='" + pwoNum + "'");
        }

        var faultLeng = faultList.length;
        for (var k = 0; k < faultLeng; k++) {
            var faultNum = faultList[k];
            sqlList.push("delete from TagRecords where PWONum='" + faultNum + "'");
            sqlList.push("delete from OPMaterial where PWONum='" + faultNum + "'");
            sqlList.push("delete from OPTools where PWONum='" + faultNum + "'");
            sqlList.push("delete from OPAreasTags where PWONum='" + faultNum + "'");
            if (isDelAttFile) {
                sqlList.push("DELETE FROM AttFile where ObjectID='" + faultNum + "'");
            }
            sqlList.push("DELETE FROM FaultsOrder where WONum='" + faultNum + "'");
            sqlList.push("delete from OPOrders where PWONum='" + faultNum + "'");
            sqlList.push("delete from OPPlan where PWONum='" + faultNum + "'");
            sqlList.push("delete FROM Measurement where WONum='" + faultNum + "'");
            sqlList.push("delete from OPSafety where PWONum='" + faultNum + "'");
            sqlList.push("delete from OPSafetyMain where PWONum='" + faultNum + "'");
        }

        var attLeng = attFileList.length;
        for (var g = 0; g < attLeng; g++) {
            var attNum = attFileList[g];
            sqlList.push("DELETE FROM AttFile where AttNum='" + attNum + "'");
        }

        var sqlCount = sqlList.length;
        if (sqlCount > 0) {
            var db = app.database.open(Common.WEIXIUDB);
            db.transaction(function (tx) {
                for (var j = 0; j < sqlCount; j++) {
                    tx.executeSql(sqlList[j]);
                }
            }, function (error) {
                app.alert(error, function () {
                    app.progress.stop();
                });
            }, function () {
                app.progress.stop();
                _self.funInitPlanData("planList");
            });
        } else {
            app.progress.stop();
        }
    },

    funChoicePlan: function (tagCode) {
        var _self = this;
        var pwoNumList = _self.PWONumList;
        var pwoNumlen = pwoNumList.length;
        if (tagCode && pwoNumlen > 0) {
            var tagCodeArr = tagCode.split(";");
            var tagWhereCondition = new Array();
            for (var tagi = 0; tagi < tagCodeArr.length; tagi++) {
                tagWhereCondition.push(" DeviceNum like '%" + tagCodeArr[tagi] + "%' ");
                tagWhereCondition.push(" DeviceLocationNum like '%" + tagCodeArr[tagi] + "%' ");
            }

            for (var i = 0; i < pwoNumlen; i++) {
                var pwoNum = pwoNumList[i];
                var chkBox = $("#" + pwoNum);
                var result = chkBox.btcheck("val");
                if (result != null && result.value != "") {
                    chkBox.removeClass("BTCheck_ON").addClass("BTCheck_OFF");
                }
            }

            var sqlText = "SELECT DISTINCT PWONum FROM OPOrders WHERE (" + tagWhereCondition.join(" OR ") + " )";
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeQuery(db, sqlText, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowlen = rows.length;
                if (rowlen > 0) {
                    for (var j = 0; j < rowlen; j++) {
                        var chkedBox = $("#" + rows[j]["PWONum"]);
                        var rets = chkBox.btcheck("val");
                        if (rets == null) {
                            chkedBox.removeClass("BTCheck_OFF").addClass("BTCheck_ON");
                        }
                    }
                }
            });

        }
    },
    funBackRefresh: function () {
        var _self = this;
        _self.funInitPlanData("planList");
    }
};
