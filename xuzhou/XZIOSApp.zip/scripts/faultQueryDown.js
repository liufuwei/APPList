﻿var FaultQueryDown = function () {

    this.Lines = new Array();
    this.Specialtys = new Array();
  

};

FaultQueryDown.prototype = {
    funInitEvent:function () {
        var _self = this;

        $("#LineList").click(function () {
            var lines = _self.Lines;
            if (lines.length > 0) {
                var lineCtr = $("#LineList");
                        var defkey = "";
                        app.wheelSelect.oneSelect(lines,
                            function (res) {
                        var key = res["key"];
                        var value = res["value"];
                        lineCtr.text(value);
                        lineCtr.attr("key", key);
                        downWork.funLoadStationData(key, downWork);
                    }, defkey, "请选择线路");
            } else {
                app.alert("暂无线路基础数据");
            }
        });
        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#SpecialtyList").click(function () {
            var specialtys = _self.Specialtys;
            if (specialtys.length > 0) {
                var specialtyCtr = $("#SpecialtyList");
                var defkey = "";
                app.wheelSelect.oneSelect(specialtys,
                    function (res) {
                        var key = res["key"];
                        var value = res["value"];
                        specialtyCtr.text(value);
                        specialtyCtr.attr("key", key);

                    }, defkey, "请选择专业");
            } else {
                app.alert("暂无专业基础数据");
            }
        });


        $("#btnDownFault").click(function () {
            _self.funDownFault();
        });

    },

    funInitUiData: function () {
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                $("#username").html(res);
            }
        });

        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                $("#usercode").html("（" + res + "）");
            }
        });
    },

    funInitData: function () {
        var _self = this;
        var userCode = "";
        app.getGlobalVariable("UserCode", function (res) { if (res) { userCode = res; } });
        if (userCode) {
            var db = app.database.open(Common.WEIXIUDB);
            var userRows = new Array();
            db.transaction(function (tx) {
                tx.executeSql("SELECT LineNum as 'key' ,LineName as value from Line", [], function (tx1, results) { _self.Lines = Common.funConvertRowsJson(results); });
                tx.executeSql("SELECT SpecialtyNum as 'key',SpecialtyName as value  from Specialty", [], function (tx1, results) { _self.Specialtys = Common.funConvertRowsJson(results); });
                tx.executeSql("SELECT * FROM User WHERE UserCode='" + userCode + "'", [], function (tx1, results) { userRows = Common.funConvertRowsJson(results); });
            }, function (error) { app.alert(error); }, function () {
                if (userRows.length != 0) {
                    var row = userRows[0];
                    var specialtyNum = row["SpecialtyNum"];
                    var specialtyName = row["SpecialtyName"];
                    if (specialtyNum && specialtyName) {
                        var specialtyCtr = $("#SpecialtyList");
                        specialtyCtr.text(specialtyName);
                        specialtyCtr.attr("key", specialtyNum);
                    }
                    var lineNum = row["LineNum"];
                    var lineName = "";
                    var linelen = _self.Lines.length;
                    for (var i = 0; i < linelen; i++) {
                        var line = _self.Lines[i];
                        if (line["key"] == lineNum) {
                            lineName = line["value"];
                            break;
                        }
                    }
                    if (lineNum && lineName) {
                        var lineCtr = $("#LineList");
                        lineCtr.text(lineName);
                        lineCtr.attr("key", lineNum);
                    }
                }
            });
        }
    },

    funDownFault: function () {

        var _self = this;

        var funDownFaultWk = function (filePath) {
            setTimeout(function () {
                var paramObj = new Object();
                paramObj.filepath = filePath;
                var param = new Object();
                param.PayLoad = paramObj;
                app.ajax({
                    "url": MobileConfig.GetDownWkStatusUrl,
                    "data": param,
                    "contentType": "application/json",
                    "method": "POST",
                    "async": true,
                    "success": function (res) {
                        var statusObj = JSON.parse(res.returnValue);
                        var status = statusObj.status;
                        if (status == "H") {
                            funDownFaultWk(filePath);
                        } else if (status == "F") {
                            app.alert("调用失败", function () {
                                app.progress.stop();
                            });
                        } else if (status == "S") {
                            var acthSavePath = "";
                            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fileSystem) {
                                fileSystem.root.getDirectory("LimisFaultQueryFile", { create: true, exclusive: false },
                                    function (fileEntry) {
                                        acthSavePath = fileEntry.fullPath;
                                    }, function () {
                                        app.alert("创建目录失败", function () { app.progress.stop(); });
                                    });
                            });
                            if (acthSavePath) {
                                var localFilePath = acthSavePath + "/FaultOrderList.txt";
                                localStorage.setItem("FaultOrderPath", localFilePath);

                                var fileTransfer = new FileTransfer();
                                var fileUri = encodeURI(filePath);
                                fileTransfer.download(fileUri, localFilePath, function (entry) {
                                    app.file.readAsString(localFilePath, function (res) {
                                        var planOrder = JSON.parse(res);
                                        if (planOrder.ResStatus == true) {
                                            var cmCount = planOrder.PayLoad.CMList.length;
                                            app.progress.stop();
                                            app.alert("下载了[" + cmCount + "]故障数据", function () {
                                                Common.funGoBack();
                                            });
                                        } else {
                                            app.progress.stop();
                                            app.alert(planOrder.ResMsg);
                                        }
                                    }, function (res) {
                                        app.alert(res, function () { app.progress.stop(); });
                                    });
                                }, function (error) {
                                    app.alert("下载故障查询数据失败", function () { app.progress.stop(); });
                                });
                            }
                        }
                    }
                });
            }, 2000);
        };

        var networkState = navigator.network.connection.type;
        if (networkState == Connection.NONE) { //未连接
            app.alert("当前没有可用的网络");
        } else {
            app.progress.start("下载提示", "正在处理中...");
            var reqPayLoad = _self.funGetRequsetParam();
            var requestParam = new Object();
            requestParam.orgin = "stream";
            requestParam.CallMethod = "Biz_CmDownLoad";
            requestParam.AuthBlock = new Object();
            requestParam.AuthBlock.ClientNumber = device.uuid;
            requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
            app.getGlobalVariable("UserCode", function (res) { if (res) { requestParam.AuthBlock.UserCode = res; } });
            app.getGlobalVariable("Password", function (res) { if (res) { requestParam.AuthBlock.Password = res; } });
            requestParam.PayLoad = reqPayLoad;
            app.ajax({
                "url": MobileConfig.CmDownLoad, "data": requestParam,
                "contentType": "application/json",
                "method": "POST", "async": true,
                "success": function (res) {
                    var planOrder = JSON.parse(res.returnValue);
                    if (planOrder.ResStatus == true) {
                        var resData = planOrder.PayLoad;
                        var filePath = resData.filepath;
                        if (filePath) {
                            funDownFaultWk(filePath);
                        }
                    } else {
                        app.alert(planOrder.ResMsg, function () {
                            app.progress.stop();
                        });
                    }
                }
            });

        }
    },

    funGetRequsetParam: function () {
        var requestParam = new Object();

        var lineNum = $("#LineList").attr("key") || "NA";
        if (lineNum != "NA") {
            requestParam.LineNum = lineNum;
        }

        var specNum = $("#SpecialtyList").attr("key") || "NA";
        if (specNum != "NA") {
            requestParam.SpecNum = specNum;
        }

        var statusArr = new Array();
        if ($("#Status_0").hasClass("BTCheck_ON")) {
            statusArr.push("等待批准");
        }
        if ($("#Status_1").hasClass("BTCheck_ON")) {
            statusArr.push("已批准");
        }
        if ($("#Status_2").hasClass("BTCheck_ON")) {
            statusArr.push("取消");
        }
        if ($("#Status_3").hasClass("BTCheck_ON")) {
            statusArr.push("等待物料");
        }
        if ($("#Status_4").hasClass("BTCheck_ON")) {
            statusArr.push("完成");
        }
        if ($("#Status_5").hasClass("BTCheck_ON")) {
            statusArr.push("关闭");
        }
        requestParam.Status = statusArr.join(";");

        var wonum = $("#txtWonum").val().trim();
        if (wonum != "") {
            requestParam.Wonum = wonum;
        }

        var description = $("#txtDescription").val().trim();
        if (description != "") {
            requestParam.Description = description;
        }

        var beginTime = $("#txtBeginTime").btselect("val").value;
        if (beginTime) {
            requestParam.BeginTime = beginTime;
        }

        var endTime = $("#txtEndTime").btselect("val").value;
        if (endTime) {
            requestParam.EndTime = endTime;
        }
        return requestParam;
    },
    funBackRefresh : function () {
        this.funInitData();
    }
};