﻿var MeasurePoint = function () {
    this.PageParam = null;

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);

    this.MeasurementDic = new Dictionary();
};

MeasurePoint.prototype = {
    funInitEvent:function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            var param = new Object();
            param.WONum = _self.PageParam["WONum"];
            Common.funGoBack(param,"measurePoint.html");
        }, false);
        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSaveProcess").click(function () {
            _self.funSaveMeasurePoint();
        });
    },
    funInitMeasurePointData: function (containerId) {
        var _self = this;
        var wONum = _self.PageParam["WONum"];
        var deviceNum = _self.PageParam["DeviceNum"];
        var sql = "SELECT a.*,b.WONum,b.MeasurementValue,b.MeasurementType from MeasurePoint a LEFT JOIN Measurement b ON a.PointNum=b.PointNum and  b.WONum='" + wONum + "' INNER JOIN Device c on c.LocationNum=a.Location where c.DeviceNum='" + deviceNum + "' ORDER BY a.PointNum asc";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sql, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowslen = rows.length;

            var funCacheData = function (rowItem) {
                var pointNum = rowItem["PointNum"];
                var cacheItem = _self.MeasurementDic.Item(pointNum);
                if (cacheItem == null) {
                    cacheItem = new Object();
                    cacheItem.PointNum = rowItem["PointNum"];
                    cacheItem.Description = rowItem["Description"];
                    cacheItem.MeasureUnitID = rowItem["MeasureUnitID"];
                    cacheItem.Location = rowItem["Location"];
                    cacheItem.AssetNum = rowItem["AssetNum"];
                    cacheItem.UpperWarning = rowItem["UpperWarning"];
                    cacheItem.LowerWarning = rowItem["LowerWarning"];
                    _self.MeasurementDic.Add(pointNum, cacheItem);
                }
                var measurementType = rowItem["MeasurementType"];
                switch (measurementType) {
                    case "修前":
                        cacheItem.AgoVal = rowItem["MeasurementValue"];
                        break;
                    case "修后":
                        cacheItem.AfterVal = rowItem["MeasurementValue"];
                        break;
                }
            };
            for (var i = 0; i < rowslen; i++) {
                var row = rows[i];
                funCacheData(row);
            }
            _self.funDrawList(containerId);

        });
    },

    funDrawList: function (containerId) {
        var _self = this;
        var measurementDic = _self.MeasurementDic; //
        var measurementVals = measurementDic.Values();
        var measurementLen = measurementVals.length;

        var liHtml = "";
        for (var i = 0; i < measurementLen; i++) {
            var item = measurementVals[i];
            var pointNum = item["PointNum"];
            var description = item["Description"];
            var measureUnitId = item["MeasureUnitID"];
            var upperWarning = item["UpperWarning"];
            var lowerWarning = item["LowerWarning"];
            var agoVal = item["AgoVal"] || "";
            var afterVal = item["AfterVal"] || "";
            var desc = "";
            liHtml += ' <ul class="list-view list-view-head list-check" data-corner="all">';
            liHtml += '<li>';
            liHtml += '<div data-role="BTButton" mousedown="false" data-status="1">';
            liHtml += '<span class="btn-text">';
            if (description) {
                liHtml += description;
            }
            if (lowerWarning) {
                desc += " 下限值:" + lowerWarning;
            }
            if (upperWarning) {
                desc += " 上限值:" + upperWarning;
            }
            if (measureUnitId) {
                desc += " 单位:" + measureUnitId;
            }
            if (desc) {
                liHtml += '(' + desc + ')';
            }
            desc = "";
            liHtml += '</span>';
            liHtml += '</div>';
            liHtml += '</li>';
            liHtml += '<li>';
            liHtml += '<div data-role="BTButton" mousedown="false" mouseup="false">';
            liHtml += '<div class="row-box">';
            if (agoVal) {
                liHtml += '修前:<input  class="singInput" style="width: 150px" type="number" id="ago' + pointNum + '"  value=' + agoVal + '  />';
            } else {
                liHtml += '修前:<input class="singInput" style="width: 150px" type="number" id="ago' + pointNum + '"  />';
            }
            if (afterVal) {
                liHtml += '修后:<input class="singInput" style="width:150px" type="number" id="after' + pointNum + '"  value=' + afterVal + '  />';
            } else {
                liHtml += '修后:<input class="singInput" style="width:150px" type="number" id="after' + pointNum + '"  />';
            }
            liHtml += '<div id="err' + pointNum + '" class="inputEro"></div>';
            liHtml += '</div>';
            liHtml += '</div>';
            liHtml += '</li>';
            liHtml += '</ul>';
        }
        var cnt = document.getElementById(containerId);
        if (cnt) {
            if (liHtml) {
                cnt.innerHTML = liHtml;
                ui.init();
            } else {
                liHtml = '<ul class="list-view list-view-head list-liStyle" data-corner="all">';
                liHtml += '<li>';
                liHtml += '<div class="row-fluid">';
                liHtml += '<div align="center">***暂无数据***</div>';
                liHtml += '</div>';
                liHtml += '</li>';
                liHtml += '</ul>';
                cnt.innerHTML = liHtml;
            }
        }
    },

    funVerificationData: function (warningVal, fillVal, verifyType) {
        var isPass = true;
        if (warningVal && fillVal) {
            switch (verifyType) {
                case "UpperWarning":
                    {
                        if ((warningVal - 0) < (fillVal - 0)) {
                            isPass = false;

                        }
                    }
                    break;
                case "LowerWarning":
                    {
                        if ((warningVal - 0) > (fillVal - 0)) {
                            isPass = false;
                        }
                    }
                    break;
            }
        }
        return isPass;
    },

    funSaveMeasurePoint: function () {
        var _self = this;
        var measurementDic = _self.MeasurementDic;
        var measurementVals = measurementDic.Values();
        var measurementLen = measurementVals.length;
        var wONum = _self.PageParam["WONum"];
        var sqlList = new Array();
        if (measurementLen > 0) {
            var delSql = 'DELETE FROM Measurement where WONum="' + wONum + '"';
            sqlList.push(delSql);
            var dateDate = Common.funGetNowDate();
            var isAllPass = true;
            for (var i = 0; i < measurementLen; i++) {
                var item = measurementVals[i];
                var pointNum = item["PointNum"];
                var upperWarning = item["UpperWarning"];
                var lowerWarning = item["LowerWarning"];
                var agoVal = $("#ago" + pointNum).val();
                var afterVal = $("#after" + pointNum).val();
                var isPass = true;
                if (agoVal) {
                    isPass = _self.funVerificationData(upperWarning, agoVal, "UpperWarning");
                    if (isPass == true) {
                        isPass = _self.funVerificationData(lowerWarning, agoVal, "LowerWarning");
                    }
                    var insertAgoSql = 'insert into Measurement(WONum,PointNum,MeasurementValue,MeasurementType,MeasureDate) VALUES ("' + wONum + '","' + pointNum + '","' + agoVal + '","修前","' + dateDate + '")';
                    sqlList.push(insertAgoSql);
                }
                if (afterVal) {
                    if (isPass == true) {
                        isPass = _self.funVerificationData(upperWarning, afterVal, "UpperWarning");
                    }
                    if (isPass == true) {
                        isPass = _self.funVerificationData(lowerWarning, afterVal, "LowerWarning");
                    }
                    var insertAfterSql = 'insert into Measurement(WONum,PointNum,MeasurementValue,MeasurementType,MeasureDate) VALUES ("' + wONum + '","' + pointNum + '","' + afterVal + '","修后","' + dateDate + '")';
                    sqlList.push(insertAfterSql);
                }
                if (isPass == false) {
                    isAllPass = false;
                    $("#err" + pointNum).text("数据超限");
                } else {
                    $("#err" + pointNum).text("");
                }
            }
        }
        var param = new Object();
        param.WONum = wONum;
        if (sqlList.length > 1) {
            var dbName = app.database.open(Common.WEIXIUDB);
            if (isAllPass == false) {
                app.confirm("填报的数据有超限,是否继续保存", function (index) {
                    if (index == 2) {
                        app.database.executeNonQuery(dbName, sqlList, function () {
                            Common.funGoBack(param,"measurePoint.html");
                        });
                    }
                }, "提示", "取消,确定");
            } else {
                app.database.executeNonQuery(dbName, sqlList, function () {
                    Common.funGoBack(param,"measurePoint.html");
                });
            }
        } else {
            Common.funGoBack(param,"measurePoint.html");
        }
    },
    funBackRefresh : function () {
        this.funInitMeasurePointData("divMeasurePointlist");
    }
};
