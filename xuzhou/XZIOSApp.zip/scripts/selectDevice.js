﻿var SelDevice = function () {
    this.PageParam = null;
    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);
};

SelDevice.prototype = {
    funInitEvent: function ()
    {
        var _self = this;
        document.addEventListener("backbutton", function () {

            var faultObj = _self.PageParam;
            faultObj.manualSelect = "0"; //手选页面传回一个“1”回去上一个填报故障信息页面
            Common.funGoBack(faultObj, "selectDevice.html");
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSelectDevice").click(function () {
            _self.funSelectDevice("txtDeviceName", "devicelist");
        });
    },

    funSelectDevice: function (inputCntId, containerId)
    {
        var _self = this;
        var inputCtr = $("#" + inputCntId);
        var deviceName = inputCtr.val().trim();
        if (deviceName) {
            var sql = 'select * from Device where DeviceName like "%' + deviceName + '%" or DeviceNum like "%' + deviceName + '%"';
            var db = app.database.open(Common.WEIXIUBASEDB);
            app.database.executeQuery(db, sql, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowlen = rows.length;
                var liHtml = "";
                if (rowlen > 0) {
                    inputCtr.val("");
                    for (var i = 0; i < rowlen; i++)
                    {
                        var row = rows[i];
                        var dicNum = row.DeviceNum;
                        var dicName = row.DeviceName;
                        var typeNum = row.DeviceTypeNum;
                        var typeName = row.DeviceTypeName;
                        var locationName = row.LocationName;
                        liHtml += '<li  id="li' + dicNum + '"  DeviceNum="' + dicNum + '"  DeviceName="' + dicName + '"  DeviceTypeNum="' + typeNum + '"  DeviceTypeName="' + typeName + '"  LocationName="' + locationName + '">';
                        liHtml += '<div class="row-fluid">';
                        liHtml += '<div class="span6">' + dicNum + '<br/>' + dicName + '</div>';
                        liHtml += '<div class="span5">' + locationName + '</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                    }
                }
                var cnt = document.getElementById(containerId);
                if (cnt) {
                    var childItems = cnt.children;
                    var childlen = childItems.length;
                    for (var j = 1; j < childlen; j++)
                    {
                        cnt.removeChild(childItems[1]);
                    }
                    if (liHtml)
                    {
                        cnt.innerHTML += liHtml;
                        _self.funBindEvent(rows);
                    } else {
                        liHtml += '<li>';
                        liHtml += '<div class="row-fluid">';
                        liHtml += '<div class="span10" align="center">***暂无数据***</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                        cnt.innerHTML += liHtml;
                    }
                }
            });
        } else {
            app.alert("请输入设备名称");
        }
    },

    funBindEvent: function (rows)
    {
        var _self = this;
        var rowlen = rows.length;
        for (var i = 0; i < rowlen; i++) {
            var item = rows[i];
            var deviceNum = item["DeviceNum"];
            $("#li" + deviceNum).click(function () {
                var ctr = $(this);
                var dicNum = ctr.attr("DeviceNum");
                var dicName = ctr.attr("DeviceName");
                var typeNum = ctr.attr("DeviceTypeNum");
                var typeName = ctr.attr("DeviceTypeName");
                var LocationName = ctr.attr("LocationName");

                
                var faultObj = _self.PageParam;
                faultObj.pageData.DeviceNum = dicNum;
                faultObj.pageData.DeviceName = dicName;
                faultObj.pageData.DeviceTypeNum = typeNum;
                faultObj.pageData.DeviceTypeName = typeName;

                faultObj.pageData.LocationName = LocationName;

                // faultObj.pageData.RecordWay = "p"; //p-选择 s-扫描
                // faultObj.pageData.RecordTime = Common.funGetNowDate();
                faultObj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面

                Common.funGoBack(faultObj, "selectDevice.html");
            });
        }
    }
};
