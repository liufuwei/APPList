﻿var OutCheck = function () {

    this.StartWkList = new Array();

    (function (_this) {
        app.getGlobalVariable("startWkList", function (res) {
            if (res) {
                _this.StartWkList = JSON.parse(res);
            }
        });
    })(this);

    this.OPToolsList = new Array();

    this.NewToolsList = new Array();

};

OutCheck.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);


        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSave").click(function () {
            _self.funSave();
        });

        $("#btnSkip").click(function () {
            Common.funLoad("consumeMaterial.html");
        });

        $("#btnAddTool").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM Tool";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if(rows && rows[0]["count(*)"]>0){
                    var pageParam = new Object();
                    pageParam.GoPageName = "outCheck";
                    Common.funLoad("addTool.html", pageParam);
                } else {
                    app.alert("暂无工具数据，请在主界面更新基础数据--工具");
                }
            });
        });

    },
    funGetSaveToolSql: function () {
        var _self = this;
        var opToolLength = _self.OPToolsList.length;
        var newToolsLeng = _self.NewToolsList.length;
        var wkLeng = _self.StartWkList.length;
        var finishChkTime = Common.funGetNowDate();
        var paraSqlList = new Array();
        if (opToolLength > 0 || newToolsLeng > 0) {

            var sqlWhere = "";
            var leng = _self.StartWkList.length;
            for (var m = 0; m < leng; m++) {
                if ((m + 1) == leng) {
                    sqlWhere += " PWONum='" + _self.StartWkList[m].PWONum + "' ";
                } else {
                    sqlWhere += " PWONum='" + _self.StartWkList[m].PWONum + "' or";
                }
            }
            var delSql = "Delete FROM OPTools WHERE " + sqlWhere;
            paraSqlList.push(delSql);

            var paramEntityList = new Array();
            for (var i = 0; i < opToolLength; i++) {
                for (var k = 0; k < wkLeng; k++) {
                    var planTool = new Object();
                    planTool.PWONum = _self.StartWkList[k]["PWONum"];
                    planTool.OPToolNum = _self.OPToolsList[i]["OPToolNum"];
                    planTool.OPToolName = _self.OPToolsList[i]["OPToolName"];
                    planTool.OPToolUnit = _self.OPToolsList[i]["OPToolUnit"];
                    planTool.BeforePlanRegTime = _self.OPToolsList[i]["BeforePlanRegTime"];
                    planTool.BeforePlanRegCount = _self.OPToolsList[i]["BeforePlanRegCount"];
                    planTool.IsNewAdded = _self.OPToolsList[i]["IsNewAdded"];
                    planTool.FinishChkTime = finishChkTime;
                    //By Liwch 由于工具ID可能包含小数点，因此将小数点改为下划线‘_’
                    planTool.OPToolCount = parseInt($("#txtOPToolNum" + (planTool.OPToolNum + "").replace(".", "_")).val()) || "0";
                    paramEntityList.push(planTool);
                }
            }

            for (var j = 0; j < newToolsLeng; j++) {
                for (var l = 0; l < wkLeng; l++) {
                    var newTool = _self.NewToolsList[j];
                    var oPToolNum = newTool["OPToolNum"];
                    var newToolItem = new Object();
                    newToolItem.PWONum = _self.StartWkList[l]["PWONum"];
                    newToolItem.OPToolNum = oPToolNum;
                    newToolItem.OPToolName = newTool["OPToolName"];
                    newToolItem.OPToolUnit = newTool["OPToolUnit"];
                    newToolItem.BeforePlanRegTime = "";
                    newToolItem.BeforePlanRegCount = "";
                    newToolItem.IsNewAdded = 1;
                    newToolItem.FinishChkTime = finishChkTime;
                    newToolItem.OPToolCount = parseInt($("#txtOPToolNum" + oPToolNum).val()) || "0";
                    paramEntityList.push(newToolItem);
                }
            }
            var inertText = SqlTextHelper.funGetInsertText("OPTools", paramEntityList);
            paramEntityList = null;
            paraSqlList = paraSqlList.concat(inertText);
        }
        return paraSqlList;
    },

    funInitToolData: function (containerId) {
        var _self = this;
        var sqlWhere = "";
        var leng = _self.StartWkList.length;
        for (var k = 0; k < leng; k++) {
            if ((k + 1) == leng) {
                sqlWhere += " PWONum='" + _self.StartWkList[k].PWONum + "' ";
            } else {
                sqlWhere += " PWONum='" + _self.StartWkList[k].PWONum + "' or";
            }
        }
        if (leng > 0) {
            var sql = "SELECT " +
                " OPToolNum,max(OPToolName) as OPToolName,max(OPToolUnit) as OPToolUnit,max(OPToolCount) as OPToolCount,max(OPToolUnit) as OPToolUnit,max(BeforePlanRegTime) as BeforePlanRegTime,max(BeforePlanRegCount) as BeforePlanRegCount,max(FinishChkTime) as FinishChkTime, max(FinishChkCount) as FinishChkCount,max(IsNewAdded) as IsNewAdded,max(RelatedAttNum) as RelatedAttNum" +
                " FROM  OPTools  " +
                " WHERE " + sqlWhere +
                " group by OPToolNum";
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeQuery(db, sql, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if (rows.length > 0) {
                    _self.OPToolsList = rows;
                    var liHtml = "";
                    var rowsLeng = rows.length;
                    for (var i = 0; i < rowsLeng; i++) {
                        var row = rows[i];
                        var toolCount = row["OPToolCount"] || row["FinishChkCount"] || row["BeforePlanRegCount"];
                        var toolName = row["OPToolName"];
                        //By Liwch 由于工具ID可能包含小数点，因此将小数点改为下划线‘_’
                        var oPToolNum = (row["OPToolNum"] + "").replace(".", "_");

                        var cntId = "txtOPToolNum" + oPToolNum;
                        var oPToolUnit = row["OPToolUnit"];
                        liHtml += '<li class="delcss">';
                        liHtml += '<div class="row-fluid">';
                        if (oPToolUnit) {
                            liHtml += '<div class="span5">' + toolName + '[' + oPToolUnit + ']</div>';
                        } else {
                            liHtml += '<div class="span5">' + toolName + '</div>';
                        }

                        liHtml += '<div class="span2" align="center"><input id="' + cntId + '" type="number" value="' + toolCount + '" class="toolNum"/></div>';
                        liHtml += '<div  align="center">';
                        liHtml += '  <a CntId="' + cntId + '" id="btnAdd' + oPToolNum + '" href="javascript:void(0)" class="addN"></a>';
                        liHtml += '  <a CntId="' + cntId + '" id="btnMinus' + oPToolNum + '" href="javascript:void(0)" class="minusN"></a>';
                        liHtml += '  <a CntId="' + cntId + '" PWONum="' + sqlWhere + '" id="Del' + oPToolNum + '" href="javascript:void(0)" class="delN"></a>';
                        liHtml += '</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                    }
                    if (liHtml) {
                        var cnt = document.getElementById(containerId);
                        if (cnt) {
                            cnt.innerHTML += liHtml;
                            _self.funBindToolEvent();
                        }
                    }
                } else {
                    _self.funToolNoDataMsg(containerId);
                }
            });
        }
    },

    funBindToolEvent: function () {
        var _self = this;
        var toolsList = _self.OPToolsList;
        var toolslen = toolsList.length;
        for (var i = 0; i < toolslen; i++) {
            var item = toolsList[i];
            //By Liwch 由于工具ID可能包含小数点，因此将小数点改为下划线‘_’
            var oPToolNum = (item["OPToolNum"] + "").replace(".", "_");

            $("#btnAdd" + oPToolNum).click(function () {
                var ctr = $(this);
                var ctrId = ctr.attr("CntId");
                _self.funUpCount(ctrId);
            });

            $("#btnMinus" + oPToolNum).click(function () {
                var ctr = $(this);
                var ctrId = ctr.attr("CntId");
                _self.funDownCount(ctrId);
            });
            $("#Del" + oPToolNum).click(function () {
                var ctr = $(this);
                var PWONum = ctr.attr("PWONum");
                app.confirm("确认删除该工具?", function (index) {
                    if (index == 2) {
                        _self.funDelOPTools(oPToolNum, PWONum);
                    }
                }, "删除工具确认", "取消,确定");
               
            });

        }
    },
    funDelOPTools: function (oPToolNum, pwoNum) {
        var _self = this;
        var delOPToolsText = "delete from OPTools WHERE OPToolNum='" + oPToolNum + "' and  " + pwoNum + " ";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(db, delOPToolsText, function () {
            _self.funBackRefresh();
        });
    },

    funUpCount: function (cntId) {
        if (cntId) {
            var cnt = $("#" + cntId);
            var count = parseInt(cnt.val()) || 0;
            count += 1;
            if (count < 0) {
                count = 0;
            }
            cnt.val(count);
            cnt.attr("value", count);
        }
    },

    funDownCount: function (cntId) {
        if (cntId) {
            var cnt = $("#" + cntId);
            var count = parseInt(cnt.val()) || 0;
            count -= 1;
            if (count < 0) {
                count = 0;
            }
            cnt.val(count);
            cnt.attr("value", count);
        }
    },


    funSave: function () {
        var _self = this;
        var sqlList = new Array();
        var toolSqlList = _self.funGetSaveToolSql();
        if (toolSqlList.length > 0) {
            sqlList = sqlList.concat(toolSqlList);
        }
        if (sqlList.length > 0) {
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeNonQuery(db, sqlList, function () {
                Common.funLoad("consumeMaterial.html");
            });
        } else {
            Common.funLoad("consumeMaterial.html");
        }
    },


    funToolNoDataMsg: function (containerId) {
        var _self = this;
        var total = _self.OPToolsList.length + _self.NewToolsList.length;
        if (total > 0) {
            var cntDataMsg = $("#liToolDataMsg");
            if (cntDataMsg) {
                $("#liToolDataMsg").remove();
            }
        } else {
            var cnt = document.getElementById(containerId);
            if (cnt) {
                var liHtml = "";
                liHtml = ' <li id="liToolDataMsg" >';
                liHtml += '<div class="row-fluid">';
                liHtml += '<div align="center">***暂无数据***</div>';
                liHtml += '</div>';
                liHtml += '</li>';
                cnt.innerHTML += liHtml;
            }
        }
    },

    funBackRefresh: function () {
        app.refresh();
        this.funInitToolData("toollist");
    }
};

