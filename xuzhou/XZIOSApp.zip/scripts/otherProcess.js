﻿var OtherProcess = function () {

    this.PageParam = null;

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });

    })(this);

    this.PhotoBox = null;

    this.VideoBox = null;

    this.AudioBox = null;

    this.UserInfo = new Object();
};

OtherProcess.prototype = {
    funInitEvent:function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSaveProcess").click(function () {
            _self.funSaveOrderData("txtDeviceNote");
        });


        $("#btnFaultReport").click(function () {
            var faultObj = new Object();
            faultObj.RelationWONum = _self.PageParam["WONum"];
            Common.funLoad("faultReport.html", faultObj);

        });
    },
    funInitUi: function () {
        var _self = this;
        var pageTitle = _self.PageParam["PageHeader"];
        if (pageTitle) {
            $("#pageTitle").text(pageTitle);
        }
    },
    

    funInitOrderData: function (orderName) {
        var _self = this;
        var OPOrdersParams = new Object();
        OPOrdersParams.WONum = _self.PageParam["WONum"];
        //OPOrdersParams.PWONum = _self.PageParam["PWONum"];
        SqlHelper.funGetData("OPOrders", function (rows) {
            if (rows.length > 0) {
                $("#txtDeviceNote").val(rows[0]["DeviceNote"]);
                $("#txtOrderDesc").text(rows[0]["OrderDesc"]);  //邱嘉楠新增
                //获取后续跟进
                var yesOrNo = rows[0]["HasFollowUpWork"];
                if (yesOrNo == "1") {
                }
                else {
                    $("#radioBtnNo").btradio("val", "0");
                }
            }
        }, OPOrdersParams);
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                _self.UserInfo.UserName = res;
            }
        });
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                _self.UserInfo.UserCode = res;
            }
        });
    },

    funSaveOrderData: function (deviceNoteId) {
        var _self = this;
        var OPOrdersParamsList = new Array();
        var OPOrdersParams = new Object();
        OPOrdersParams.DeviceNote = $("#" + deviceNoteId).val();
        //是否后续跟进
        if ($("#radioBtnYes").hasClass("BTCheck_ON")) {
            OPOrdersParams.HasFollowUpWork = "1";
        }
        else { OPOrdersParams.HasFollowUpWork = "0"; }
        OPOrdersParams.SelfFormIsFinished = "1";
        OPOrdersParams.SelfFormFinishTime = Common.funGetNowDate();
        OPOrdersParams.SelfFormUserCode = _self.UserInfo.UserCode;
        OPOrdersParams.SelfFormUserName = _self.UserInfo.UserName;
        OPOrdersParams.WhereParam = new Object();
        OPOrdersParams.WhereParam.WONum = _self.PageParam["WONum"];
        OPOrdersParamsList.push(OPOrdersParams);
        SqlHelper.funUpdateData("OPOrders", OPOrdersParamsList, function () {
            app.alert("保存成功", function () { Common.funGoBack(); });
            //app.back();
            //Common.funGoBack();
        });
    },

    funInitPhotoBox: function (containerId) {
        var _self = this;
        if (_self.PhotoBox == null) {
            var param = new Object();
            //拍照的类型，ObjectType为:A,B,C,D 其中：A,工单、B,工序、C,工具、D.故障
            param.ObjectType = "WORKORDER";
            //赋值主键：工单编号
            var WONum = _self.PageParam["WONum"];
            param.ObjectID = WONum;
            param.ContainerId = containerId;
            param.PWONum = _self.PageParam["PWONum"];
            _self.PhotoBox = new PhotoBox(param);

        }
        _self.PhotoBox.initBox(_self.PhotoBox);
    },

    funInitVideoBox: function (containerId) {
        var _self = this;
        if (_self.VideoBox == null) {
            var param = new Object();
            //拍照的类型，ObjectType为:A,B,C,D 其中：A,工单、B,工序、C,工具、D.故障
            param.ObjectType = "WORKORDER";
            //赋值主键：工单编号
            var WONum = _self.PageParam["WONum"];
            param.ObjectID = WONum;

            param.ContainerId = containerId;
            param.PWONum = _self.PageParam["PWONum"];

            _self.VideoBox = new VideoBox(param);
        }
        _self.VideoBox.initBox(_self.VideoBox);
    },
    
    funInitAudioBox: function (containerId) {
        var _self = this;
        if (_self.Audio == null) {
            var param = new Object();
            param.ObjectType = "WORKORDER";
            var WONum = _self.PageParam["WONum"];
            param.ObjectID = WONum;
            
            param.ContainerId = containerId;
            param.PWONum = _self.PageParam["PWONum"];
            
            _self.AudioBox = new AudioBox(param);
        }
        _self.AudioBox.initBox(_self.AudioBox);
    },
    funBackRefresh: function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var pageName = retParam["pageName"];
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funInitOrderData("lblOpOrder");
            _self.funInitPhotoBox("pboxList");
            _self.funInitVideoBox("vboxList");
            _self.funInitAudioBox("aboxList");
        }, 100);
    }
    
};
