﻿var SelLocation = function () {
    this.PageParam = null;
    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);
};

SelLocation.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            var faultObj = _self.PageParam;
            faultObj.manualSelect = "0"; //手选页面传回一个“1”回去上一个填报故障信息页面
            Common.funGoBack(faultObj, "selectLocation.html");
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSelectLocation").click(function () {
            _self.funSelectLocation("txtLocationName", "locationlist");
        });
    },

    funSelectLocation: function (inputCntId, containerId) {
        var _self = this;
        var inputCtr = $("#" + inputCntId);
        var locationName = inputCtr.val().trim();
        if (locationName) {
            var sql = 'select * from Location where LocationName like "%' + locationName + '%" or LocationNum like "%' + locationName + '%"';
            var db = app.database.open(Common.WEIXIUBASEDB);
            app.database.executeQuery(db, sql, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowlen = rows.length;
                var liHtml = "";
                if (rowlen > 0) {
                    inputCtr.val("");
                    for (var i = 0; i < rowlen; i++) {
                        var row = rows[i];
                        var locationNum = row.LocationNum;
                        var locationName = row.LocationName;
                        var locationID = row.LocationID;
                        var parentNum = row.ParentLocationNum;
                        liHtml += '<li  id="li' + locationNum + '"  LocationNum="' + locationNum + '"  LocationName="' + locationName + '"  LocationID="' + locationID + '">';
                        liHtml += '<div class="row-fluid">';
                        liHtml += '<div class="span6">' + locationNum + '<br/>' + locationName + '</div>';
                        liHtml += '<div class="span5">' + parentNum + '</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                    }
                }
                var cnt = document.getElementById(containerId);
                if (cnt) {
                    var childItems = cnt.children;
                    var childlen = childItems.length;
                    for (var j = 1; j < childlen; j++) {
                        cnt.removeChild(childItems[1]);
                    }
                    if (liHtml) {
                        cnt.innerHTML += liHtml;
                        _self.funBindEvent(rows);
                    } else {
                        liHtml += '<li>';
                        liHtml += '<div class="row-fluid">';
                        liHtml += '<div class="span10" align="center">***暂无数据***</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                        cnt.innerHTML += liHtml;
                    }
                }
            });
        } else {
            app.alert("请输入位置名称或编号");
        }
    },

    funBindEvent: function (rows) {
        var _self = this;
        var rowlen = rows.length;
        for (var i = 0; i < rowlen; i++) {
            var item = rows[i];
            var locationNum = item["LocationNum"];
            $("#li" + locationNum).click(function () {
                var ctr = $(this);
                var locationNum = ctr.attr("LocationNum");
                var locationName = ctr.attr("LocationName");
                var locationID = ctr.attr("LocationID");
                var faultObj = _self.PageParam;
                faultObj.pageData.LocationCode = locationNum;
                faultObj.pageData.LocationName = locationName;
                faultObj.pageData.LocationID = locationID;

                Common.funGoBack(faultObj, "selectLocation.html");
            });
        }
    }
};
