﻿
var Fault = function () {
    this.PageParam = new Object();

    this.PhotoBox = null;

    this.VideoBox = null;

    this.AudioBox = null;

    this.defaultFaultObj = new Object();//临时参数

    this.FaultMaterial = null;

    this.IsEdit = false;

    this.CurrentUserInfo = new Object();//当前用户

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                if (result.WONum) {
                    _this.PageParam.WONum = result.WONum;

                }
            }
        });
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                _this.CurrentUserInfo.UserCode = res;
            }
        });
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                _this.CurrentUserInfo.UserName = res;
                _this.defaultFaultObj.RecUserName = res;
            }
        });

    })(this);

};

Fault.prototype = {
    funInitEvent: function () {
        var _self = this;

        document.addEventListener("backbutton", function () {
            var tempFaultWoNum = "";
            app.getGlobalVariable("TempFaultWoNum", function (res) {
                if (res) {
                    tempFaultWoNum = res;
                }
            });
            app.setGlobalVariable("TempFaultWoNum", "");
            app.setGlobalVariable(tempFaultWoNum, "");
            //                    Common.funGoBack();
            app.back();
        }, false);

        $("#imback").click(function () {
            var tempFaultWoNum = "";
            app.getGlobalVariable("TempFaultWoNum", function (res) {
                if (res) {
                    tempFaultWoNum = res;
                }
            });
            app.setGlobalVariable("TempFaultWoNum", "");
            app.setGlobalVariable(tempFaultWoNum, "");
            //                    Common.funGoBack();
            app.back();
        });
        //点击保存按钮触发的方法
        $("#btnSaveFault").click(function () {
            _self.funSaveFault();
        });


        $("#DeviceName").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM Device";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if (rows && rows[0]["count(*)"] > 0) {
                    var Obj = new Object();
                    Obj.pageData = _self.funGetPageData();
                    Obj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面
                    Common.funLoad("selectDevice.html", Obj);
                } else {
                    app.alert("暂无设备数据，请在主界面更新基础数据--设备");
                }
            });
        });
        $("#LocationName").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM Location";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if (rows && rows[0]["count(*)"] > 0) {
                    var Obj = new Object();
                    Obj.pageData = _self.funGetPageData();
                    Obj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面
                    Common.funLoad("selectLocation.html", Obj);
                } else {
                    app.alert("暂无位置数据，请在主界面更新基础数据--位置");
                }
            });
        });
        $("#selectArea").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM ALNDomain";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if (rows && rows[0]["count(*)"] > 0) {
                    var Obj = new Object();
                    Obj.pageData = _self.funGetPageData();
                    Obj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面
                    Common.funLoad("selectALNDomain.html", Obj);
                } else {
                    app.alert("暂无地点数据，请在主界面更新基础数据--其他");
                }
            });
        });
        // $("#btnManualSelect").click(function () {
        //     //插入模拟数据
        //     var device = {
        //         "PWONum ": "WO-20180801-0018",
        //         "WONum ": _self.PageParam.WONum,
        //         "WOType ": "CM"
        //     };
        //     var inertFaultsText = SqlTextHelper.funGetInsertText("OPOrders", [device]);
        //     var db = app.database.open(Common.WEIXIUDB);
        //     app.database.executeNonQuery(db, inertFaultsText, function () {
        //         alert("success")
        //     }, function () {
        //         alert("fail")
        //     });
        // });
    },

    /**
     * 通过工单号查询故障数据
     */
    funInitPageParam: function () {
        var _self = this;
        ///<summary>页面参数统一入口，初始化页面带来的参数</summary>

        if (_self.PageParam) {
            _self.defaultFaultObj.WONum = _self.PageParam["WONum"];//计划修的故障工单号
        }
        var faultsOrderParam = new Object();
        faultsOrderParam.WONum = _self.defaultFaultObj.WONum ? _self.defaultFaultObj.WONum : "";
        if (faultsOrderParam.WONum != "") {
            SqlHelper.funGetData("FaultsOrder", function (rows) { //查询数据库获取数据
                if (rows && rows.length > 0) {
                    _self.defaultFaultObj = rows[0];
                    _self.funInitPageData();
                } else {
                    Common.funGoBack();
                    app.alert("故障工单数据有误请重新下载")
                }
            }, faultsOrderParam, SqlHelper.WEIXIUDB);
        } else {
            _self.funInitPageData();
        }

    },

    funInitPageData: function () {
        var _self = this;
        ///<summary>页面数据初始化</summary>
        SqlHelper.funGetData("User", function (rowsUser) {
            if (rowsUser && rowsUser.length > 0) {
                _self.CurrentUserInfo = rowsUser[0];
                var userNum = rowsUser[0].UserNum;
                _self.defaultFaultObj.RecUserNum = rowsUser[0].UserCode;
                // _self.defaultFaultObj.UserCode = rowsUser[0].UserCode;
                if (rowsUser[0].MobilePhone) {
                    _self.CurrentUserInfo.MobilePhone = rowsUser[0].MobilePhone;
                }
                //获取当前用户信息后再执行
                if (!_self.defaultFaultObj["WONum"]) {

                    //新建工单编号格式为："-" + 员工号 + 时间戳new Date().getTime()    --注意，格式为全数字
                    var WONum = "-" + userNum + new Date().getTime();
                    _self.defaultFaultObj.WONum = WONum;
                    //故障实际发生时间，如果是新增则取当前
                    // _self.defaultFaultObj.FailDate = Common.funGetNowDate();
                }
                _self.funBindPageData();
            }
        }, _self.CurrentUserInfo, SqlHelper.WEIXIUDB);
    },

    funBindPageData: function () {
        var _self = this;
        ///<summary>绑定页面数据</summary>

        //初始化拍照控件
        _self.funInitPhotoBox("pboxList");
        //初始化录像控件
        _self.funInitVideoBox("vboxList");
        //录音
        _self.funInitAudioBox("aboxList");

        //记录人员姓名
        $("#FaultReportUserName").val(_self.defaultFaultObj.FaultReportUserName || _self.CurrentUserInfo.UserName);
        $("#FaultRepMobilePhone").val(_self.defaultFaultObj.FaultRepMobilePhone || _self.CurrentUserInfo.MobilePhone || "");
        $("#FaultDesc").val(_self.defaultFaultObj.FaultDesc || "");
        $("#FaultLocation").val(_self.defaultFaultObj.FaultLocation || "");
        $("#AppCode").val(_self.defaultFaultObj.AppCode || "23");
        if (_self.defaultFaultObj["OperationTimeFault"] == "1") {
            $("#radioBtnOperationTimeFaultYes").btradio("val", "0");
        } else {
            $("#radioBtnOperationTimeFaultNo").btradio("val", "0");
        }


        //故障发生时间
        var ActualFaultTime = _self.defaultFaultObj["ActualFaultTime"] ? _self.defaultFaultObj["ActualFaultTime"] : Common.funGetNowDate();

        _self.funSetDatepicker("FaultDate", "FaultTime", ActualFaultTime);
        //故障提报时间
        var FaultJournalTime = _self.defaultFaultObj["FaultJournalTime"] ? _self.defaultFaultObj["FaultJournalTime"] : Common.funGetNowDate();
        _self.funSetDatepicker("FaultJournalDate", "FaultJournalTime", FaultJournalTime);


        _self.funGetLineInfo("LineList");
        _self.funGetSpecialtyInfo("SpecialtyList");

    },
    funSetTempFaultWoNum: function () {
        ///<summary>创建故障工单编号</summary>
        app.getGlobalVariable("TempFaultWoNum", function (res) {
            if (!res) {
                app.setGlobalVariable("TempFaultWoNum", Common.funGetPkId());
            }
        });
    },


    funInitPhotoBox: function (containerId) {
        var _self = this;
        if (_self.PhotoBox == null) {
            var param = new Object();
            //拍照的类型，ObjectType为:A,B,C,D 其中：A,工单、B,工序、C,工具、D.故障
            param.ObjectType = "WORKORDER";
            //赋值主键：工单编号
            var WONum = _self.defaultFaultObj["WONum"] || "";//$("#WONumText").val();
            var PWONum = _self.defaultFaultObj["PWONum"] || "";// $("#PWONumText").val();   //2013/12/4 邱嘉楠新增
            param.ObjectID = WONum;
            param.ContainerId = containerId;
            param.PWONum = PWONum;
            param.OrderType = _self.defaultFaultObj["OrderType"];

            if (_self.PageParam) {
                var imgInfos = _self.PageParam["ImgInfos"] || [];
                param.InitAttList = imgInfos;
            }


            _self.PhotoBox = new PhotoBox(param);
            _self.PhotoBox.initBox(_self.PhotoBox);
        }

    },

    funInitVideoBox: function (containerId) {
        var _self = this;
        if (_self.VideoBox == null) {
            var param = new Object();
            //拍照的类型，ObjectType为:A,B,C,D 其中：A,工单、B,工序、C,工具、D.故障
            param.ObjectType = "WORKORDER";
            //赋值主键：工单编号
            var WONum = _self.defaultFaultObj["WONum"] || "";//$("#WONumText").val();
            var PWONum = _self.defaultFaultObj["PWONum"] || "";// $("#PWONumText").val();   //2013/12/4 邱嘉楠新增
            param.ObjectID = WONum;
            param.ContainerId = containerId;
            param.PWONum = PWONum;
            if (_self.PageParam) {
                var videoInfos = _self.PageParam["VideoInfos"] || [];
                param.InitAttList = videoInfos;
            }

            _self.VideoBox = new VideoBox(param);
            _self.VideoBox.initBox(_self.VideoBox);


        }
    },

    funInitAudioBox: function (containerId) {
        var _self = this;
        if (_self.AudioBox == null) {
            var param = new Object();
            param.ObjectType = "WORKORDER";
            var WONum = _self.defaultFaultObj["WONum"] || "";//$("#WONumText").val();
            var PWONum = _self.defaultFaultObj["PWONum"] || "";// $("#PWONumText").val();   //2013/12/4 邱嘉楠新增
            param.ObjectID = WONum;
            param.ContainerId = containerId;
            param.PWONum = PWONum;
            if (_self.PageParam) {
                var audioInfos = _self.PageParam["AudioInfos"] || [];
                param.InitAttList = audioInfos;
            }
            _self.AudioBox = new AudioBox(param);
            _self.AudioBox.initBox(_self.AudioBox);

        }

    },


    funSaveFault: function () {
        var _self = this;
        //确认是否必填已经填写完毕
        var msg = _self.funCheckRequired();

        if (msg !== "") {
            app.alert(msg);
            return;
        }
        var faultObj = _self.funGetPageData();
        var sqlList = new Array();



        var delFaultSql = "Delete FROM FaultsOrder WHERE WONum='" + faultObj.WONum + "'";
        sqlList.push(delFaultSql);

        var inertFaultsText = SqlTextHelper.funGetInsertText("FaultsOrder", [faultObj]);
      
        sqlList = sqlList.concat(inertFaultsText);

        if (faultObj.WONum.substr(0, 1) != "-") {

            //p-选择 s-扫描 暂时没有扫描的数据都是p
            var updOrdersText = "UPDATE OPOrders set SelfFormIsFinished = '1',SelfFormUserName='" + faultObj.RecUserName + "',SelfFormFinishTime='" + faultObj.FaultRecTime + "',SelfFormUserCode ='" + _self.CurrentUserInfo.UserCode + "',RecWay ='p',RecTime='" + faultObj.RecordTime + "' where WONum='" + faultObj.WONum + "'";
            sqlList.push(updOrdersText);
        }

        var db = app.database.open(Common.WEIXIUDB);

        app.database.executeNonQuery(db, sqlList, function () {

            app.alert("保存成功", function () {
                var tempFaultWoNum = "";
                app.getGlobalVariable("TempFaultWoNum", function (res) {
                    if (res) {
                        tempFaultWoNum = res;
                    }
                });
                app.setGlobalVariable("TempFaultWoNum", "");
                app.setGlobalVariable(tempFaultWoNum, "");
                Common.funGoBack();
            });
        });
    },
    funCheckRequired: function () {
        var _self = this;
        var msg = "";
        if ($("#LineList").btselect("val").value === "请选择" || $("#LineList").btselect("val").value === "") {
            msg = "请选择线路"
        }
        else if ($("#FaultDesc").val() === "") {
            msg = "请填写故障描述"
        }
        else if ($("#FaultLocation").val() === "") {
            msg = "请选择故障地点"
        }
        else if (_self.funGetDatepicker("FaultDate", "FaultTime") === "") {
            msg = "请选择故障发生时间"
        }
        return msg;
    },

    funGetPageData: function () {
        var _self = this;
        var faultObject = _self.defaultFaultObj;

        //故障描述
        faultObject.FaultDesc = $("#FaultDesc").val();
        //故障地点
        faultObject.FaultLocation = $("#FaultLocation").val();

        faultObject.AppCode = $("#AppCode").val();

        //提报人信息
        faultObject.FaultReportUserName = _self.CurrentUserInfo.UserName;
        faultObject.FaultReportUserNum = _self.CurrentUserInfo.UserCode;
        faultObject.FaultRepMobilePhone = _self.CurrentUserInfo.MobilePhone;


        //故障提报时间
        faultObject.FaultJournalTime = _self.funGetDatepicker("FaultJournalDate", "FaultJournalTime");
        //故障发生时间
        faultObject.FaultTime = _self.funGetDatepicker("FaultDate", "FaultTime");
        //是否运营期故障
        faultObject.OperationTimeFault = $("#radioBtnOperationTimeFaultYes").hasClass("BTCheck_ON") ? "1" : "0";
        //线路
        faultObject.LineNum = $("#LineList").btselect("val").value;
        faultObject.LineName = ($("#LineList").btselect("val").label === "请选择") ? "" : $("#LineList").btselect("val").label;
        //专业
        // faultObject.SpecialtyList = ($("#SpecialtyList").btselect("val").value === "请选择") ? "": $("#SpecialtyList").btselect("val").value ;




        return faultObject;

    },

    funEditMeasurement: function () {
        var _self = this;
        var deviceNum = $("#deviceList").btselect("val").value;
        if ((deviceNum == "请选择") || deviceNum == "") {
            app.alert("请先选择故障设备");
        } else {
            _self.funSaveFault("measurePoint");
        }
    },


    funSetDatepicker: function (dateId, timeId, date) {
        ///<summary>设置日期</summary>
        ///<param name="dateId">日期主键</param>
        ///<param name="timeId">时间主键</param>
        ///<param name="date">日期，为空则清除</param>
        if (!date || date == "") {
            $("#" + dateId).attr("value", "");
            $("#" + dateId + " span")[0].innerHTML = "日期";
            $("#" + timeId).attr("value", "");
            $("#" + timeId + " span")[0].innerHTML = "时间";
            return;
        }
        var dates = date.split(" ");
        $("#" + dateId).attr("value", dates[0].replace(/\//g, "-"));
        $("#" + dateId + " span")[0].innerHTML = dates[0].replace(/\//g, "-");
        var timeValue = dates[1].length > 5 ? dates[1].substring(0, dates[1].lastIndexOf(":")) : dates[1];
        $("#" + timeId).attr("value", timeValue);
        $("#" + timeId + " span")[0].innerHTML = timeValue;
    },

    funGetDatepicker: function (dateId, timeId) {
        ///<summary>获取日期</summary>
        ///<param name="dateId">日期主键</param>
        ///<param name="timeId">时间主键</param>
        var dateTimeValue = '';
        var dateValue = $("#" + dateId).btselect("val").value;
        var timeValue = $("#" + timeId).btselect("val").value;
        if (dateValue != "" && timeValue != "") {
            dateTimeValue = dateValue + " " + timeValue + ":0";
        }

        return dateTimeValue;
    },

    funGetLineInfo: function (containerId) {
        var _self = this;
        ///<summary>获取线路列表方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        ///<param name="_self" >类本身</param>
        var param = new Object();
        var divContainer = $("#" + containerId);
        if (!divContainer) {
            return;
        }
        var defaultValue = _self.defaultFaultObj["LineNum"];
        _self.funGetFaultInfo("Line", containerId, "LineNum", "LineName", param, "", SqlHelper.WEIXIUBASEDB, defaultValue || "");
    },

    funGetSpecialtyInfo: function (containerId) {
        var _self = this;
        ///<summary>获取专业列表方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        ///<param name="_self" >类本身</param>
        var param = new Object();
        var divContainer = $("#" + containerId);
        if (!divContainer) {
            return;
        }
        var defaultValue = _self.defaultFaultObj["SpecialtyNum"];
        _self.funGetFaultInfo("Specialty", containerId, "SpecialtyNum", "SpecialtyName", param, "", SqlHelper.WEIXIUBASEDB, defaultValue || "");
    },
    funGetFaultInfo: function (tableName, CId, colum1, colum2, relColumParam, whereCondition, database, value, emptyMsg) {
        var _self = this;
        ///<summary>获取故障设备信息公用方法</summary>
        ///<param name="tableName" >表名</param>
        ///<param name="CId" >容器ID</param>
        ///<param name="colum1" >表字段1，作为Key</param>
        ///<param name="colum2" >表字段2，作为Value</param>
        ///<param name="relColumParam" >需要查询的关联字段参数对象</param>
        ///<param name="whereCondition">直接使用的查询条件 如：and 字段名1='' and 字段名2 in('') and 字段名3 like '%%'</param>
        ///<param name="database" >需要查询的数据库名</param>
        ///<param name="value" >默认选中项的值selectedValue 如果默认第一个使用@first 如果默认[请选择]使用""或者null</param>
        ///<param name="emptyMsg" >没有查询到数据时的提示</param>
        SqlHelper.funGetDataByWhere(tableName, function (rows) {
            var deviceList = new Array();
            if (rows.length == 0) {
                if (emptyMsg) {
                    app.alert(emptyMsg);
                }
                //app.alert("查询不到相关设备");
            } else {
                var isContain = false;
                var isNeedCheck = !!value ? (value != "@first" && value != 'undefined') : false;//是否有指定初始值，如果默认第一个则没有，为空也没有，不为空且不系于@first则有
                for (var i = 0; i < rows.length; i++) {
                    var deviceItem = new Object();
                    deviceItem.key = rows[i][colum1];
                    deviceItem.value = rows[i][colum2];
                    deviceList.push(deviceItem);
                    if (isNeedCheck && value == rows[i][colum1]) {
                        isContain = true;
                    }
                }
                if (value == "@first") {
                    isContain = true;
                    value = rows[0][colum1];
                }
                var html = '<div id="' + CId + '" data-role="BTSelect" value="' + (isContain ? value : "") + '" callback="' + CId + 'Callback" data=\'[{"key":"","value":"请选择"}]\' ><span>请选择</span></div>';
                $("#" + CId).parent().html(html);
                $("#" + CId).attr("data", JSON.stringify(deviceList));
                $("#" + CId).uiwidget();
            }
        }, relColumParam, whereCondition, database);
    },
    setRefinePptions: function (isDriving) {
        if (isDriving) {
            $("#LiRefinePptions").css("display", "");
        } else {
            $("#RefinePptions").btselect("val", { value: '', label: '请选择' }, function (obj, data) {
                return true;
            });
            $("#LiRefinePptions").css("display", "none");

        }
    },

    funBackRefresh: function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                retParamStr = retParamStr.replace(/\n/g, "\\n");
                var retParam = JSON.parse(retParamStr);
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.defaultFaultObj = backParam.pageData;
                }
            }
        } catch (ex) {
            app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funBindPageData()
        }, 100);
    }
};


