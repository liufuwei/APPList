﻿var EqlistHelper = function () {
};

EqlistHelper.funSingleOrder = function (singleOrder, isScan) {
    ///<summary>单条工单操作</summary>
    ///<param name="singleOrder">工单对象数据</param>
    ///<param name="isScan">是否扫描 true为是，false为否</param>
    var opOrder = singleOrder;
    var jobPlanNum = opOrder["JobPlanNum"];
    var pageParam = new Object();
    var url = "";
    if (jobPlanNum) {
        url = "singleProcess.html";
        pageParam["IsOtherCheck"] = opOrder["IsOtherCheck"];
        pageParam["WONum"] = opOrder["WONum"];
        pageParam["PageHeader"] = opOrder["WONum"] + opOrder["DeviceLocation"];
    } else {
        var woType = opOrder["WOType"];
        switch (woType) {
            case "PM":  //PM计划修
            {
                pageParam["IsOtherCheck"] = opOrder["IsOtherCheck"];
                pageParam["WONum"] = opOrder["WONum"];
                pageParam["PageHeader"] = opOrder["WONum"] + opOrder["DeviceLocation"];
                url = "singleProcess.html";
            }
                break;
            case "CM": //CM故障工单----邱嘉楠新增业务逻辑
                pageParam["WONum"] = opOrder["WONum"];
                url = "faultReport.html";

                break;
            case "CBM": //隐患CBM故障工单
                pageParam["WONum"] = opOrder["WONum"];
                url = "faultReport.html";
                break;
            case "TJ": //TJ他检工单
                break;
            default:  //其他工单
            {
                pageParam["WONum"] = opOrder["WONum"];
                pageParam["PageHeader"] = opOrder["WONum"] + opOrder["DeviceLocation"];
                url = "otherProcess.html";
            }
                break;
        }
    }

    var nowDate = Common.funGetNowDate();
    var sqlText = "";
    if (isScan) {
        sqlText = "UPDATE OPOrders SET ActStart=ifnull(nullif(ActStart,''),'" + nowDate + "'), RecWay='s' , RecTime='" + nowDate + "' WHERE  WONum='" + opOrder["WONum"] + "' ";
    } else {
        sqlText = "UPDATE OPOrders SET ActStart=ifnull(nullif(ActStart,''),'" + nowDate + "') WHERE  WONum='" + opOrder["WONum"] + "' ";
    }

    EqlistHelper.funSqlSave(sqlText, function () {
        Common.funLoad(url, pageParam);
    });

};

EqlistHelper.funMultiOrder = function (orderList, OPOrdersDic, isScan) {
    ///<summary>多条工单操作</summary>
    ///<param name="orderList">工单列表对象数据</param>
    ///<param name="OPOrdersDic">工单列表字典</param>
    ///<param name="isScan">是否扫描 true为是，false为否</param>
    var woNumlen = orderList.length;
    var oPOrdersDic = OPOrdersDic;
    var deviceList = new Array();
    var titleList = new Array();
    var isBatchSubmit = true;
    var orderTypeName = "";

    for (var i = 0; i < woNumlen; i++) {
        var opOrder = oPOrdersDic.Item(orderList[i]);
        var isAllowedBatchSubmit = opOrder["IsAllowedBatchSubmit"];
        var deviceNum = opOrder["DeviceNum"];
        var deviceName = opOrder["DeviceName"];
        orderTypeName = opOrder["DeviceTypeName"];
        if (isAllowedBatchSubmit == "0") {
            isBatchSubmit = false;
            titleList.push(deviceNum + deviceName);
        } else {
            if (isBatchSubmit) {
                var deviceItem = new Object();
                deviceItem.key = opOrder["WONum"]; //工单编号WONum
                deviceItem.value = deviceNum + deviceName;//设备描述
                deviceList.push(deviceItem);
            }
        }
    }

    if (isBatchSubmit) {
        //如果是扫描进来的
        var orderWoNum = new Array();
        for (var j = 0; j < deviceList.length; j++) {
            orderWoNum.push(deviceList[j].woNum);
        }

        var nowDate = Common.funGetNowDate();
        var url = "multiProcess.html";
        var pageParam = new Object();
        pageParam.Devices = deviceList;
        pageParam["PageHeader"] = orderTypeName + "(" + deviceList.length + ")";
        pageParam.ActStart = nowDate;
        if (isScan) {
            //更新工单的记录方式为扫描 记录方式，p-选择 s-扫描
            var sqlUpdateOrder = "UPDATE OPOrders SET RecWay='s' , RecTime='" + nowDate + "'  WHERE  WONum IN ('" + orderWoNum.join("','") + "') ";
            EqlistHelper.funSqlSave(sqlUpdateOrder, function () {
                Common.funLoad(url, pageParam);
            });
        } else {
            Common.funLoad(url, pageParam);
        }

    } else {
        app.alert("提示以下设备不允许批量填报\n" + titleList.join("\n"));
    }
};

EqlistHelper.funSqlSelect = function (sql, successfun, params, scopeObject) {
    ///<summary>运行查询脚本</summary>
    ///<param name="sql">sql语句</param>
    ///<param name="successfun">回调函数</param>
    ///<param name="params">传递给回调函数的参数</param>
    ///<param name="scopeObject"></param>
    var db = app.database.open(Common.WEIXIUDB);
    app.database.executeQuery(db, sql, function (tx, results) {
        var len = results.rows.length;
        var rows = results.rows;
        var dataTable = new Array();
        for (var i = 0; i < len; i++) {
            var row = new Object();
            for (var clmField in rows.item(i)) {
                row[clmField] = rows.item(i)[clmField];
            }
            dataTable.push(row);
        }
        if (params) {
            successfun(dataTable, params, scopeObject);
        }
        else {
            successfun(dataTable);
        }
    });
};

EqlistHelper.funSqlSave = function (sql, successfun) {
    ///<summary>运行更新脚本</summary>
    ///<param name="sql">sql语句</param>
    ///<param name="successfun">回调函数</param>
    if (sql.length > 0) {
        var dbName = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(dbName, sql, successfun);
    }
};