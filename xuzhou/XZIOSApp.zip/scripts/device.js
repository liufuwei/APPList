﻿var DeviceMain = function () {};

DeviceMain.prototype = {
    funScansJump: function (locNum) {
        var pageParam = new Object();
        pageParam.LocationNum = locNum;
        Common.funLoad("deviceResume.html",pageParam);
    }
};

