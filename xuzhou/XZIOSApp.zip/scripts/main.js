﻿var Main = function () {
};

Main.prototype = {

 

    funCheckNetwork: function () {
        var retNetworkState = false;
        var networkState = navigator.network.connection.type;
        if (networkState == Connection.NONE) { //未连接
            retNetworkState = false;
        } else {
            retNetworkState = true;
        }
        return retNetworkState;
    },
  

    funInitUiData: function ()
    {
        var infoText = "";
        app.getGlobalVariable("UnitName", function (res)
        {
            if (res) {
                infoText = res;
            }
        });
        app.getGlobalVariable("OrgName", function (res)
        {

            if (res) {
                if (!infoText || infoText.length <= 0)
                {
                    infoText = res;
                }
            }
        });
        app.getGlobalVariable("UserName", function (res)
        {
           
            if (res)
            {
                $("#userInfo").html(res + "<i>" + infoText + "</i>");
            }

            if (infoText != "车辆检修室")
            {
                $("#FaultTwospan").hide();
            }
        });

        var sqlFaultCountText = "SELECT WONum from FaultsOrder where AppCode='18' and  WONum like '-%'";
        var sqlFaultCountTextTwo = "SELECT WONum from FaultsOrder where AppCode='23' and WONum like '-%'";
        // var sqlStartWkCountText = "SELECT PWONum from OPPlan where WorkStatus in ('2','3')";
        var sqlStartWkCountText = "SELECT PWONum from OPPlan ";
        var sqlUploadCountText = "SELECT  WONum as Id   from FaultsOrder where WONum like '-%' UNION ALL SELECT  PWONum as Id  from OPPlan where WorkStatus='3'";
        var faultCount = 0;
        var faultCountTwo = 0;
        var startWkCount = 0;
        var uploadCount = 0;
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx)
        {
            tx.executeSql(sqlFaultCountText, [], function (tx1, results)
            {
                var rows = Common.funConvertRowsJson(results);
                var rowCount = rows.length;
                faultCount = rowCount;
              
            });
            tx.executeSql(sqlFaultCountTextTwo, [], function (tx1, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowCount = rows.length;
                faultCountTwo = rowCount;

            });

            tx.executeSql(sqlStartWkCountText, [], function (tx1, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowCount = rows.length;
                startWkCount = rowCount;
            });
            tx.executeSql(sqlUploadCountText, [], function (tx1, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowCount = rows.length;
                uploadCount = rowCount;
            });

        }, function (error) {
            app.alert(error);
        },
        function ()
        {
            $("#lblFault").html("(" + faultCount + ")");
            $("#lblFaultTwo").html("(" + faultCountTwo + ")");
            $("#lblStartWork").html("(" + startWkCount + ")");
            $("#lblUploadWork").html("(" + uploadCount + ")");
        });

        var uri = "sdcard/android/data/" + app.id + "/crash/crash.log";
        app.file.readAsString(uri, function (result) {
            if (result) {
                $("#lblUploadSysEx").css("color", "red");
            }
        });

    },

    funUploadSysLog: function (scopeMain) {
        var netWork = scopeMain.funCheckNetwork();
        if (netWork == false) {
            app.alert("您当前没有用网络");
        } else {
            app.progress.start("上传系统问题提示", "正在处理中...");
            var userCode = "";
            var password = "";
            app.getGlobalVariable("UserCode", function (res) {
                if (res) {
                    userCode = res;
                }
            });
            app.getGlobalVariable("Password", function (res) {
                if (res) {
                    password = res;
                }
            });
            var uri = "sdcard/android/data/" + app.id + "/crash/crash.log";
            app.file.readAsString(uri, function (result) {
                if (result) {
                    var sysExItem = new Object();
                    sysExItem.Exception = result;
                    var requestParam = new Object();
                    requestParam.orgin = "stream";
                    requestParam.AuthBlock = new Object();
                    requestParam.AuthBlock.ClientNumber = device.uuid;
                    requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
                    requestParam.AuthBlock.Password = password;
                    requestParam.AuthBlock.UserCode = userCode;
                    requestParam.CallMethod = "Biz_SubmitOrderResult";
                    requestParam.PayLoad = sysExItem;
                    app.ajax({
                        "url": MobileConfig.UploadSysLog,
                        "data": requestParam,
                        "method": "POST",
                        "async": false,
                        "success": function (res) {
                            var responseData = JSON.parse(res.returnValue);
                            if (responseData.ResStatus == true) {
                                app.alert("系统问题上传成功", function () {
                                    app.progress.stop();
                                });
                                app.file.remove(uri);
                            } else {
                                app.alert(responseData.ResMsg, function () {
                                    app.progress.stop();
                                });
                            }
                        }
                    });
                } else {
                    app.alert("无系统问题记录", function () {
                        app.progress.stop();
                    });
                }
            }, function () {
                app.alert("无系统问题记录", function () {
                    app.progress.stop();
                });
            });
        }
    },

    funInitChkVersionDialog: function (containerId) {
        var networkState = navigator.network.connection.type;
        if (networkState == Connection.NONE) { //未连接
            app.hint("您当前没有用网络");
        } else {
            var isNewVersion = false;
            var localVersion = app.version;
            var platform = "";
            if (window.devicePlatform == "android") {
                platform = "android";
            } else if (window.devicePlatform == "iOS") {
                platform = "ios";
            }
            // localVersion = localVersion.substr(1, 3);
            localVersion = localVersion.replace("v", "");
            localVersion = localVersion - 0;
            var reqVersionParam = new Object();
            reqVersionParam.orgin = "stream";
            reqVersionParam.CallMethod = "Misc_CheckVersion";
            var dlDataParam = new Object();
            dlDataParam.DataType = "CheckVersion";
            dlDataParam.Platform = platform;
            reqVersionParam.AuthBlock = new Object();
            reqVersionParam.AuthBlock.UserCode = "admin";
            reqVersionParam.AuthBlock.Password = "112233";
            reqVersionParam.PayLoad = dlDataParam;
            app.ajax({
                "url": MobileConfig.DownBaseDataUrl,
                "data": reqVersionParam,
                "contentType": "application/json",
                "method": "POST",
                "async": true,
                "success": function (res) {
                    var responseData = JSON.parse(res.returnValue);
                    var serverVersion = responseData.PayLoad.VersionNumber;
                    serverVersion = serverVersion - 0;
                    if (localVersion < serverVersion) {
                        if (isNewVersion == false) {
                            //不是最新版本，显示出对话提示框
                            var dialogHtml = "";
                            dialogHtml += '<div data-role="BTButton" data-iconpos="right" data-status="1" data-theme="u">';
                            dialogHtml += '<span class="btn-text" style="padding-right:50px">';
                            dialogHtml += '<div id="btnUpdateApp" class="thumbnail-text" style="color:#CD5B45">';
                            dialogHtml += '&nbsp&nbsp发现版本更新，请点击下载';
                            dialogHtml += '</div>';
                            dialogHtml += '</span>';
                            dialogHtml += '<span class="icon icon-del" onclick="Main.funCloseDialog();">';
                            dialogHtml += '</span>';
                            dialogHtml += '</div>';
                            var cnt = document.getElementById(containerId);
                            if (cnt) {
                                cnt.innerHTML = dialogHtml;
                                ui.init();
                                $("#btnUpdateApp").click(function () {
                                    var updateApp = new UpdateApp();
                                    updateApp.funUpdateApp();
                                });
                            }
                        } else {
                            //是最新版本，隐藏提示框
                            Main.funCloseDialog();
                        }
                    } else {
                        //最新版本，则不显示出对话提示框
                        isNewVersion = true;
                        return isNewVersion;
                    }
                }
            });
        }
    },

    funFileDown: function () {
        var networkState = navigator.network.connection.type;
        if (networkState == Connection.NONE) { //未连接
            app.alert("您当前没有用网络");
        } else {
            var url = "http://eip2.gzmetro.com/Dept/YYZB/YYYZX/DocLib3/Forms/AllItems.aspx";
            var unitOrgNum = "";
            var specialtyNum = "";
            app.getGlobalVariable("UnitOrgNum", function (res) {
                if (res) {
                    unitOrgNum = res;
                }
            });
            app.getGlobalVariable("SpecialtyNum", function (res) {
                if (res) {
                    specialtyNum = res;
                }
            });
            if (unitOrgNum && specialtyNum) {
                url += "?RootFolder=%2fDept%2fYYZB%2fYYYZX%2fDocLib3%2fLMIS%2f" + unitOrgNum.substr(0, 4) + "%2f" + unitOrgNum.substr(0, 6) + "%2f" + unitOrgNum + "%2f" + specialtyNum + "&FolderCTID=&View=%7b1130C801%2d7CEB%2d4CDC%2dB573%2dD24926C57D6D%7d";
            }
            app.run(url);
        }
    },
    funBackRefresh: function () {
        var _self = this;
        _self.funInitUiData();
    }


};



Main.funCloseDialog = function () {
    ///<summary>关闭提示</summary>
    $("#checkVersionDialog").attr("style", "display: none !important");
};


