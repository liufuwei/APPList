var ResumeInfo = function () {
    this.PageParam = null;
    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);

    this.activePlan = false;
    this.activeFault = false;
    this.allParam = new Object();
};

ResumeInfo.prototype = {
    funInitEvent: function () {
        var _self =this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);
        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#baseMsg").click(function () {
            var isHas = $("#baseMsg").hasClass("btn-active");
            if (isHas == false) {
                $("#divBase").css("display", "");
                $("#divPlan").css("display", "none");
                $("#divFault").css("display", "none");
            }
        });
        $("#planMsg").click(function () {
            var isHas = $("#planMsg").hasClass("btn-active");
            if (isHas == false) {
                $("#divBase").css("display", "none");
                $("#divPlan").css("display", "");
                $("#divFault").css("display", "none");
            }
            _self.funPlanData();
        });
        $("#faultMsg").click(function () {
            var isHas = $("#faultMsg").hasClass("btn-active");
            if (isHas == false) {
                $("#divBase").css("display", "none");
                $("#divPlan").css("display", "none");
                $("#divFault").css("display", "");
            }
            _self.funFaultData();
        });
    },
    funInitData: function () {
        var _this = this;
        var pageParam = _this.PageParam;
        var requestParam = _this.allParam;
        var requestParam = new Object();
        requestParam.PayLoad = new Object();
        app.getPageParams(function (result) {
            if (result) {
                requestParam.PayLoad.LocationNum = result["LocationNum"];
            }
        });
        requestParam.orgin = "stream";
        requestParam.AuthBlock = new Object();
        requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
        requestParam.AuthBlock.ClientNumber = device.uuid;
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                requestParam.AuthBlock.UserCode = res;
            }
        });
        app.getGlobalVariable("Password", function (res) {
            if (res) {
                requestParam.AuthBlock.Password = res;
            }
        });
     
        _this.allParam = requestParam;
    },
    funBaseData: function () {
        var _this = this;
        var pageParam = _this.PageParam;
        var requestParam = _this.allParam;
        requestParam.CallMethod = "Misc_FetchLocationDeviceDetail";
        requestParam.AuthBlock = new Object();
        requestParam.AuthBlock.UserCode = "admin";
        requestParam.AuthBlock.Password = "112233";
        requestParam.PayLoad = new Object();
        app.getPageParams(function (result) {
            if (result) {
                requestParam.PayLoad.LocationNum = result["LocationNum"];
            }
        });       
        app.progress.start("提示", "数据正在处理...");
        app.ajax({
            "url": MobileConfig.DownFetchLocationDevices,
            "data": requestParam,
            "contentType": "application/json",
            "method": "POST",
            "timeout": 600000,
            "async": true,
            "success": function (res) {
                var baseData = JSON.parse(res.returnValue);
                if (baseData.ResStatus == true) {
                    app.progress.stop();
                    var baseDataList = baseData.PayLoad;
                    $('#locationNum').val(baseDataList.LocationNum);
                    $('#locationName').val(baseDataList.LocationName);
                    $('#deviceNum').val(baseDataList.DeviceNum);
                    $('#deviceName').val(baseDataList.DeviceName);
                    $('#brand').val(baseDataList.Brand == undefined ? "" : baseDataList.Brand);
                    $('#modelNum').val(baseDataList.ModelNum == undefined ? "" : baseDataList.ModelNum);
                    $('#classDesc').val(baseDataList.ClassDesc == undefined ? "" : baseDataList.ClassDesc);
                    $('#vendorName').val(baseDataList.VendorName == undefined ? "" : baseDataList.VendorName);
                    $('#manuName').val(baseDataList.ManuName == undefined ? "" : baseDataList.ManuName);
                    $('#outDept').val(baseDataList.OutDept == undefined ? "" : baseDataList.OutDept);
                } else {
                    app.alert(baseData.ResMsg, function () {
                        app.progress.stop();
                    });
                }

            }
        });
    },
    funPlanData: function () {
        var _this = this;
        var pageParam = _this.PageParam;
        var requestParam = _this.allParam;
        requestParam.CallMethod = "Misc_FetchPmList";
        requestParam.AuthBlock = new Object();
        requestParam.AuthBlock.UserCode = "admin";
        requestParam.AuthBlock.Password = "112233";
        requestParam.PayLoad = new Object();
        app.getPageParams(function (result) {
            if (result) {
                requestParam.PayLoad.LocationNum = result["LocationNum"];
            }
        });
        app.progress.start("提示", "数据正在处理...");
        app.ajax({
            "url": MobileConfig.DownFetchLocationDevices,
            "data": requestParam,
            "contentType": "application/json",
            "method": "POST",
            "async": true,
            "success": function (res) {
                var planData = JSON.parse(res.returnValue);
                if (planData.ResStatus == true) {
                    $('#divPlanlist').html('');
                    var ulDom = $('<ul class="list-view" data-corner="all"></ul>');
                    for (var i = 0; i < planData.PayLoad.length; i++) {
                        var WOCode = planData.PayLoad[i].WOCode;

                        var liDom = $('<li id="' + WOCode + '"></li>');
                        var lihtml = '<div data-role="BTButton" data-status="1">';
                        lihtml += '<span class="btn-text">';
                        lihtml += '<div class="row-box">';
                        lihtml += '<div class="span1">';
                        lihtml += '<div data-inline="false" >' + WOCode + "-" + planData.PayLoad[i].WOName + '</div>';
                        lihtml += '</div>';
                        lihtml += '</div>';
                        lihtml += '</span>';
                        lihtml += '</div>';
                        liDom.html(lihtml);

                        liDom.click(function () {
                            var pageParam = new Object();
                            pageParam.WONum = $(this).attr("id");
                            Common.funLoad("devicePlanDetail.html", pageParam);
                        })
                       
                        liDom.appendTo(ulDom)
                    }
                    if (planData.PayLoad.length == 0) {
                        var liDom = $('<li></li>');
                        var lihtml = '<div class="row-fluid">';
                        lihtml += '<div class="span10" align="center">***暂无数据***</div>';
                        lihtml += '</div>';
                        liDom.html(lihtml);
                        liDom.appendTo(ulDom)
                    }
                    ulDom.appendTo($('#divPlanlist'));
                    app.progress.stop();
                } else {
                    app.alert(planData.PayLoad.ResMsg, function () {
                        app.progress.stop();
                    });
                }

            }
        });
    },
    funFaultData: function () {
        var _this = this;
        var pageParam = _this.PageParam;
        var requestParam = _this.allParam;
        requestParam.CallMethod = "Misc_FetchFaultList";
        requestParam.AuthBlock = new Object();
        requestParam.AuthBlock.UserCode = "admin";
        requestParam.AuthBlock.Password = "112233";
        requestParam.PayLoad = new Object();
        app.getPageParams(function (result) {
            if (result) {
                requestParam.PayLoad.LocationNum = result["LocationNum"];
            }
        });
        app.progress.start("提示", "数据正在处理...");
        app.ajax({
            "url": MobileConfig.CmDownLoad,
            "data": requestParam,
            "contentType": "application/json",
            "method": "POST",
            "async": true,
            "success": function (res) {
                var FaultData = JSON.parse(res.returnValue);
                if (FaultData.ResStatus == true) {
                    app.progress.stop();
                    $('#divFaultlist').html('');
                    var ulDom = $('<ul class="list-view" data-corner="all"></ul>');
                    for (var i = 0; i < FaultData.PayLoad.length; i++) {
                        var WOCode = FaultData.PayLoad[i].WOCode;
                        var liDom = $('<li id="' + WOCode + '"></li>');
                        var lihtml = '<div data-role="BTButton" data-status="1">';
                        lihtml += '<span class="btn-text">';
                        lihtml += '<div class="row-box">';
                        lihtml += '<div class="span1">';
                        lihtml += '<div data-inline="false">' + WOCode + "-" + FaultData.PayLoad[i].WOName + '</div>';
                        lihtml += '</div>';
                        lihtml += '</div>';
                        lihtml += '</span>';
                        lihtml += '</div>';
                        liDom.html(lihtml);

                        liDom.click(function () {
                            var pageParam = new Object();
                            pageParam.WONum = $(this).attr("id");
                            Common.funLoad("deviceFaultDetail.html", pageParam);
                        })

                        liDom.appendTo(ulDom)
                    }
                    if (FaultData.PayLoad.length == 0) {
                        var liDom = $('<li></li>');
                        var lihtml = '<div class="row-fluid">';
                        lihtml += '<div class="span10" align="center">***暂无数据***</div>';
                        lihtml += '</div>';
                        liDom.html(lihtml);
                        liDom.appendTo(ulDom)
                    }
                    ulDom.appendTo($('#divFaultlist'));
                    
                } else {
                    app.alert(FaultData.ResMsg, function () {
                        app.progress.stop();
                    });
                }

            }
        });
    },
    funBackRefresh: function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var pageName = retParam["pageName"];
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funInitProcessData();
        }, 100);
    }
};