﻿var FaultQueryDetail = function () {
    this.PageParam = null;

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });

    })(this);
};


FaultQueryDetail.prototype = {


    funInitUiData: function () {
        var _self = this;
        var itemData = _self.PageParam;
        $("#txtWONUM").html("【" + itemData["WONUM"] + "】  " + itemData["DESCRIPTION"]);
        $("#txtDESCRIPTION_LONGDESCRIPTION").html(itemData["DESCRIPTION_LONGDESCRIPTION"]);
        $("#txtCUST_LINENUM").html(itemData["CUST_LINENUM"]);
        $("#txtCUST_SPECNUM").html(itemData["CUST_SPECNUM"]);
        $("#txtCUST_SUBSYSDESC").html("【" + itemData["CUST_SUBSYS"] + "】  " + itemData["CUST_SUBSYSDESC"]);
        $("#txtLOCATION").html("【" + itemData["LOCATION"] + "】  " + itemData["LOCATIONDESC"]);
        $("#txtASSETNUM").html("【" + itemData["ASSETNUM"] + "】  " + itemData["ASSETDESC"]);
        $("#txtFAILURECODE").html("【" + itemData["FAILURECODE"] + "】  " + itemData["FAILURECODEDESC"]);
        $("#txtPROBLEMCODE").html("【" + itemData["PROBLEMCODE"] + "】  " + itemData["PROBLEMCODEDESC"]);
        $("#txtWORKTYPE").html(itemData["WORKTYPE"]);
        $("#txtSTATUS").html(itemData["STATUS"]);
        $("#txtSTATUSDATE").html(itemData["STATUSDATE"]);
        $("#txtPERSONGROUP").html("【" + itemData["PERSONGROUP"] + "】 " + itemData["PERSONGROUPDESC"]);
        $("#txtFAILDATE").html(itemData["FAILDATE"]);
    }
};

