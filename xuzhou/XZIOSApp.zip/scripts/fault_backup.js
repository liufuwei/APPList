﻿﻿var Fault = function () {
    this.PageParam = null;

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);

    this.PhotoBox = null;

    this.VideoBox = null;

    this.AudioBox = null;

    this.defaultFaultObj = new Object();//临时参数

    this.FaultMaterial = null;

    this.IsEdit = false;

    this.CurrentUserInfo = new Object();//当前用户

};

Fault.prototype = {
    funInitEvent: function () {
        var _self = this;

        document.addEventListener("backbutton", function () {
            var tempFaultWoNum = "";
            app.getGlobalVariable("TempFaultWoNum", function (res) {
                if (res) {
                    tempFaultWoNum = res;
                }
            });
            app.setGlobalVariable("TempFaultWoNum", "");
            app.setGlobalVariable(tempFaultWoNum, "");
//                    Common.funGoBack();
            app.back();
        }, false);

        var funCode = function (returnObj) {
            if (returnObj) {
                $("#recordWayText").val("s");  //点击扫描后，渲染记录方式为 “s” 
                $("#recordTime").val(Common.funGetNowDate()); //点击扫描后，渲染记录 时间 
                //维修开始时间
                _self.funSetDatepicker("time_ActStartDate", "time_ActStartTime", Common.funGetNowDate());
                var tagCodeArr = new Array();
                tagCodeArr = returnObj["TagCode"].split(";");
                var tagWhereCondition = new Array();
                switch (returnObj["TagType"]) {
                    case "L":
                        for (var tagi = 0; tagi < tagCodeArr.length; tagi++) {
                            tagWhereCondition.push(" L.TagCode like '%" + tagCodeArr[tagi] + "%' ");//位置标签识别码 包含此标签编码(查找该标签的所有子集)
                            tagWhereCondition.push(" L.LocationNum like '%" + tagCodeArr[tagi] + "%' ");//位置编号 包含此标签编码(查找该标签的所有子集)
                        }
                        var whereCondition = " and RecordStatus='1' and LocationNum in (select L.LocationNum from Location L where L.RecordStatus='1' and  (" + tagWhereCondition.join(" OR ") + ") )";
                        _self.funGetFaultInfo("Device", "deviceList", "DeviceNum", "DeviceName", null, whereCondition, SqlHelper.WEIXIUBASEDB, "@first", "没有找到该标签对应的设备，请确定基础数据是否更新");
                        break;
                    default:
                        for (var tagi = 0; tagi < tagCodeArr.length; tagi++) {
                            tagWhereCondition.push(" L.TagCode like '%" + tagCodeArr[tagi] + "%' ");//位置标签识别码 包含此标签编码(查找该标签的所有子集)
                            tagWhereCondition.push(" L.LocationNum like '%" + tagCodeArr[tagi] + "%' ");//位置编号 包含此标签编码(查找该标签的所有子集)
                        }
                        var whereCondition = " and RecordStatus='1' and LocationNum in (select L.LocationNum from Location L where L.RecordStatus='1' and  (" + tagWhereCondition.join(" OR ") + ") )";
                        _self.funGetFaultInfo("Device", "deviceList", "DeviceNum", "DeviceName", null, whereCondition, SqlHelper.WEIXIUBASEDB, "@first", "没有找到该标签对应的设备，请确定基础数据是否更新");
                        break;

                }
            }
            else {
                navigator.notification.vibrate(2000);
                app.alert("未知标签！类型：" + res["TagType"] + ",识别编码：" + res["TagCode"]);
            }
        };
        $("#imback").click(function () {
            var tempFaultWoNum = "";
            app.getGlobalVariable("TempFaultWoNum", function (res) {
                if (res) {
                    tempFaultWoNum = res;
                }
            });
            app.setGlobalVariable("TempFaultWoNum", "");
            app.setGlobalVariable(tempFaultWoNum, "");
//                    Common.funGoBack();
            app.back();
        });
        //点击保存按钮触发的方法
        $("#btnSaveFault").click(function () {
            _self.funSaveFault();
        });

        //点击手工选择按钮
        $("#btnManualSelect").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM Device";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if(rows && rows[0]["count(*)"]>0){
                    var Obj = new Object();
                    Obj.pageData = _self.funGetPageData();
                    Obj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面
                    Common.funLoad("selectDevice.html", Obj);
                } else {
                    app.alert("暂无设备数据，请在主界面更新基础数据--设备");
                }
            });

        });

        //点击二维码扫描
        $("#btnBarCode").click(function () {
            Common.getBarcode(function (returnObj) {
                funCode(returnObj);
            }, function () {
                navigator.notification.vibrate(2000);
                app.alert("app扫描二维码，无法获取数据！");
            });
        });

        app.setting.get("bluetooth_key", "", function (rest) {
            if (rest) {
                setInterval(function () {
                    app.getGlobalVariable("bluetoothIsConnected", function (isCon) {
                        if (isCon == "F") {   //F ==失
                            app.bluetooth.connect(rest);
                        } else if (isCon == "S") { //成功
                            var res = window.bluetoothValue;
                            if (res) {
                                window.bluetoothValue = "";
                                var convertCode = Common.funConvertCode(res);
                                funCode(convertCode);
                            }
                        } else if (isCon == "H") { //正在连接请等待

                        }
                    });
                }, 1000);
            }
        });

        //是否临时修复 radiobutton点击事件
        $("#divIsTempRepair div").click(function () {
            if ($("#radioBtnIsTempRepairYes").hasClass("BTCheck_ON")) {
                _self.funSetIsTempRepairDatepicker(true);
            }
            else if ($("#radioBtnIsTempRepairNo").hasClass("BTCheck_ON")) {
                _self.funSetIsTempRepairDatepicker(false);
            }
        });

        //选择借匙时事件，只有有借匙才能填写借匙和还匙时间
        $("#chkIsCMList div").click(function () {
            var isVisible = false;
            $("#chkIsCMList div").each(function (index, item) {
                var divChk = $(item);
                if (divChk.hasClass("BTCheck_ON")) {
                    isVisible = true;
                    return;
                }
            });
            _self.funSetReturnBorrowKeyDatepicker(isVisible);

        });

        $("#btnMeasurePoint").click(function () {
            _self.funEditMeasurement();
        });

        $("#btnAddMaterial").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM Material";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if(rows && rows[0]["count(*)"]>0){
                    var pageParm = new Object();
                    pageParm.pageData = _self.funGetPageData();
                    pageParm.PWONum = pageParm.pageData.PWONum;
                    pageParm.WONum = pageParm.pageData.WONum;
                    app.getGlobalVariable("TempFaultWoNum", function (res) {
                        if (res) {
                            pageParm.TempFaultWoNum = res;
                        }
                    });
                    pageParm.GoPageName = "faultReport";
                    Common.funLoad("addMaterial.html", pageParm);
                } else {
                    app.alert("暂无物料数据，请在主界面更新基础数据--物料");
                }
            });
        });

        $("#tabfault").click(function () {
            var isHas = $("#tabfault").hasClass("btn-active");
            if (isHas == false) {
                $("#divfault").css("display", "");
                $("#divMateriel").css("display", "none");

                $("#btnBarCode").css("display", "");
                $("#btnManualSelect").css("display", "");
                $("#btnMeasurePoint").css("display", "");
                $("#btnAddMaterial").css("display", "");

                $("#btnAddMaterial").css("display", "none !important");
            }
        });

        $("#tabMateriel").click(function () {
            var isHas = $("#tabMateriel").hasClass("btn-active");
            if (isHas == false) {
                $("#divfault").css("display", "none");
                $("#divMateriel").css("display", "");

                $("#btnBarCode").css("display", "none !important");
                $("#btnManualSelect").css("display", "none !important");
                $("#btnMeasurePoint").css("display", "none !important");
                $("#btnAddMaterial").css("display", "none !important");

                $("#btnAddMaterial").css("display", "");
            }

        });

        //CM工单 CBM工单
        $("#radioBtnCM,#radioBtnCBM").click(function () {
            var faultType = $("div[name='isFault']").btradio("val");
            if (faultType != null) {
                var isFaultVal = faultType["value"];
                if (isFaultVal == "1") {
                    var orderType = $("div[name='OrderType']").btradio("val");
                    if (orderType != null) {
                        var orderTypeVal = orderType["value"] + "".toUpperCase();
                        if (orderTypeVal == "CM") {

                            $("#technologyStateList").btselect("val", {value: '故障', label: '故障'}, function (obj, data) {
                                return true;
                            });
                            $("div[name='groupIsUse']").btradio("val", "1");


                        } else if (orderTypeVal == "CBM") {
                            $("#technologyStateList").btselect("val", {value: '缺陷', label: '缺陷'}, function (obj, data) {
                                return true;
                            });
                        }
                    }
                }
            }


        });

        //是否故障
        $("#radioFaultYes,#radioFaultNo").click(function () {
            var faultType = $("div[name='isFault']").btradio("val");
            if (faultType != null) {
                var isFaultVal = faultType["value"];
                if (isFaultVal == "1") {
                    var orderType = $("div[name='OrderType']").btradio("val");
                    if (orderType != null) {
                        var orderTypeVal = orderType["value"] + "".toUpperCase();
                        if (orderTypeVal == "CM") {

                            $("#technologyStateList").btselect("val", {value: '故障', label: '故障'}, function (obj, data) {
                                return true;
                            });
                            $("div[name='groupIsUse']").btradio("val", "1");


                        } else if (orderTypeVal == "CBM") {
                            $("#technologyStateList").btselect("val", {value: '缺陷', label: '缺陷'}, function (obj, data) {
                                return true;
                            });
                        }
                    }
                } else if (isFaultVal == "0") {
                    $("#technologyStateList").btselect("val", {value: '非故障', label: '非故障'}, function (obj, data) {
                        return true;
                    });
                }
            }
        });


        $("#technologyStateList").bind('touchstart', function (e) {
            //是否故障为“否”时 不良技术状态固定为“非故障”，此时不良技术状态只读
            var faultType = $("div[name='isFault']").btradio("val");
            if (faultType != null) {
                var isFaultVal = faultType["value"];
                if (isFaultVal == "0") {
                    e.stopPropagation();
                }
            }
        });
    },

    funInitPageParam: function () {
        var _self = this;
        ///<summary>页面参数统一入口，初始化页面带来的参数</summary>
        //{
        //    WONum:0
        //    DeviceNum 1 
        //    RelationProcedureNum:
        //    RelationWONum:2
        //    RecordWay
        //    HasRelationAttachment:是否有关联过来的附件(有为1，其它情况为无)。如果保存这些附件到故障工单后，请清空此值 
        //}
        if (_self.PageParam && _self.PageParam["manualSelect"]) {
            //如果手选按钮有传参数过来的话，就执行这里的语句，如果没有，就执行else语句
            var manualSelect = _self.PageParam["manualSelect"];
            _self.defaultFaultObj = _self.PageParam["pageData"];
            if (manualSelect == "1") {
                _self.defaultFaultObj.DeviceNum = _self.PageParam["DeviceNum"];
                _self.defaultFaultObj.RecordWay = _self.PageParam["RecordWay"];
                _self.defaultFaultObj.RecordTime = _self.PageParam["RecordTime"];
            }
            _self.funInitPageData();
        }
        else if (_self.PageParam && _self.PageParam["addMaterial"]) {//物料
            _self.defaultFaultObj = _self.PageParam["pageData"];
            _self.funInitPageData();
        }
        else {
            _self.defaultFaultObj.FaultRecTime = Common.funGetNowDate();

            if (_self.PageParam) {
                _self.defaultFaultObj.WONum = _self.PageParam["WONum"];//计划修的故障工单号
                _self.defaultFaultObj.DeviceNum = _self.PageParam["DeviceNum"];
                _self.defaultFaultObj.LineNum = _self.PageParam["LineNum"];//线路编号
                _self.defaultFaultObj.SpecialtyNum = _self.PageParam["SpecialtyNum"];
                _self.defaultFaultObj.RelationProcedureNum = _self.PageParam["RelationProcedureNum"];
                _self.defaultFaultObj.RelationWONum = _self.PageParam["RelationWONum"];
                _self.defaultFaultObj.RecordWay = _self.PageParam["RecordWay"];
                _self.defaultFaultObj.HasRelationAttachment = _self.PageParam["HasRelationAttachment"];
                app.getGlobalVariable("SpecialtyNum", function (resVal) {
                    if (resVal) {
                        if (resVal == "gzw") {
                            _self.defaultFaultObj.StationFill = _self.PageParam["StationFill"];
                            _self.defaultFaultObj.IsNeedReqrev = "Y";
                        }
                    }
                });
            }
            var faultsOrderParam = new Object();
            faultsOrderParam.WONum = _self.defaultFaultObj.WONum ? _self.defaultFaultObj.WONum : "";
            SqlHelper.funGetData("FaultsOrder", function (rows) { //查询数据库获取数据
                if (rows && rows.length > 0) {
                    _self.defaultFaultObj = rows[0];
                    _self.funInitPageData();
                } else { //数据库不存在故障工单数据时
                    _self.defaultFaultObj.HasFollowUpWork = "0"; //是否需要后续跟进处理 默认否(新增工单不需要后续跟进)
                    if (!_self.defaultFaultObj.DeviceNum || _self.defaultFaultObj.DeviceNum.length <= 0) {
                        //DeviceNum is not exist then select RelationWONum from table OPOrders
                        var OPOrdersParam = new Object();
                        OPOrdersParam.WONum = _self.defaultFaultObj.WONum || _self.defaultFaultObj.RelationWONum;
                        SqlHelper.funGetData("OPOrders", function (rowsOPOrder) {
                            if (rowsOPOrder && rowsOPOrder.length > 0) {
                                _self.defaultFaultObj.PWONum = rowsOPOrder[0]["PWONum"];
                                _self.defaultFaultObj.DeviceNum = rowsOPOrder[0]["DeviceNum"];
                                _self.defaultFaultObj.LineNum = rowsOPOrder[0]["LineNum"];//线路编号
                                _self.defaultFaultObj.SpecialtyNum = rowsOPOrder[0]["SpecialtyNum"];
                                _self.defaultFaultObj.RecordWay = rowsOPOrder[0]["RecWay"];
                                _self.defaultFaultObj.RecordTime = rowsOPOrder[0]["RecTime"];

                                _self.defaultFaultObj.FaultPhenomenonNum = rowsOPOrder[0]["FaultPhenomenonNum"];
                                _self.defaultFaultObj.FaultCodeNum = rowsOPOrder[0]["FaultCodeNum"];
                                _self.defaultFaultObj.FaultReasonNum = rowsOPOrder[0]["FaultReasonNum"];
                                _self.defaultFaultObj.PresentDate = rowsOPOrder[0]["PresentDate"];
                                _self.defaultFaultObj.FaultSolutionNum = rowsOPOrder[0]["FaultSolutionNum"];
                                _self.defaultFaultObj.TraceCase = rowsOPOrder[0]["RepairContent"];//维修内容
                                //故障实际发生时间
                                _self.defaultFaultObj.FailDate = rowsOPOrder[0]["FailDate"];
                                //维修开始时间从工单的扫描时间中取
                                _self.defaultFaultObj.ActStart = _self.defaultFaultObj.RecordTime;
                                _self.defaultFaultObj.OrderType = rowsOPOrder[0]["WOType"];
                                //从故障工单OPOrders拿OrderDesc数据，赋给FaultDesc------邱嘉楠新增------
                                // _self.defaultFaultObj.FaultDesc = rowsOPOrder[0]["OrderDesc"];
                                _self.defaultFaultObj.Remark = rowsOPOrder[0]["OrderDesc"];
                                //赋值是否需要回执，
                                _self.defaultFaultObj.IsNeedReqrev = rowsOPOrder[0]["IsNeedReqrev"];
                            }
                            _self.funInitPageData();
                        }, OPOrdersParam, SqlHelper.WEIXIUDB);
                    } else {
                        _self.funInitPageData();
                    }
                }
            }, faultsOrderParam, SqlHelper.WEIXIUDB);
        }

    },

    funInitPageData: function () {
        var _self = this;
        ///<summary>页面数据初始化</summary>
        var faultsOrderParam = new Object();
        faultsOrderParam.WONum = _self.defaultFaultObj["WONum"];
        SqlHelper.funGetData("FaultsOrder", function (rows) { //查询数据库获取数据
            if (rows && rows.length > 0) {
                _self.IsEdit = true;
            }
        }, faultsOrderParam, SqlHelper.WEIXIUDB);
        var userCode = "";
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                _self.defaultFaultObj.RecUserName = res;
            }
            app.getGlobalVariable("UserCode", function (res1) {
                if (res1) {
                    userCode = res1;
                    var userP = new Object();
                    userP.UserCode = userCode;//_self.defaultFaultObj["RecUserNum"];
                    SqlHelper.funGetData("User", function (rowsUser) {
                        if (rowsUser && rowsUser.length > 0) {
                            _self.CurrentUserInfo = rowsUser[0];
                            //获取当前用户信息后再执行
                            _self.defaultFaultObj.RecUserNum = userCode;
                            if (!_self.defaultFaultObj["WONum"]) {

                                //新建工单编号格式为："-" + 员工号 + 时间戳new Date().getTime()    --注意，格式为全数字
                                var WONum = "-" + userCode + new Date().getTime();
                                _self.defaultFaultObj.WONum = WONum;
                                //故障实际发生时间，如果是新增则取当前
                                _self.defaultFaultObj.FailDate = Common.funGetNowDate();
                                _self.funBindPageData();
                            }
                            else {
                                if (_self.defaultFaultObj.WONum.indexOf("-") < 0) {
                                    _self.defaultFaultObj.IsOfPlan = "1";
                                }
                                _self.funBindPageData();
                            }
                        }
                    }, userP, SqlHelper.WEIXIUDB);
                }
            });
        });
    },

    funBindPageData: function () {
        var _self = this;
        ///<summary>绑定页面数据</summary>
        //记录人员姓名
        $("#disposeUser").val(_self.defaultFaultObj.RecUserName);
        if (!_self.defaultFaultObj["WONum"] || (_self.defaultFaultObj["WONum"] + "").indexOf("-") >= 0) {
            //审批 只有现场新增故障单的才显示
            $("#LiApproval").css("display", "");
            //是否后补单 只有现场新增故障单的才显示
            $("#LiIsAfter").css("display", "");
        }
        //故障代码备注
        $("#faultCodeMemo").val(_self.defaultFaultObj["FaultCodeMemo"] ? _self.defaultFaultObj["FaultCodeMemo"] : "");
        //获取故障描述
        $("#faultDesc").val(_self.defaultFaultObj["FaultDesc"] ? _self.defaultFaultObj["FaultDesc"] : "");
        //获取跟踪情况
        $("#traceCase").val(_self.defaultFaultObj["TraceCase"] ? _self.defaultFaultObj["TraceCase"] : "");
        //隐藏的关联文件记录编号
        $("#relatedAttRecNumText").val(_self.defaultFaultObj["RelatedAttRecNum"] ? _self.defaultFaultObj["RelatedAttRecNum"] : "");

        //是否后续跟进
        if (_self.defaultFaultObj["HasFollowUpWork"] == "1") {
            $("#radioBtnYes").btradio("val", "1");
        }
        //是否后补单,默认为是（新增）
        if (_self.defaultFaultObj["isAfter"] == "0") {
            //$("#radioBtnIsAfterYes").btradio("val", "1");
            $("#radioBtnIsAfterNo").btradio("val", "0");
        }
        //故障实际发生时间
        _self.funSetDatepicker("time_FailDate", "time_FailTime", _self.defaultFaultObj["FailDate"]);
        //处理时间
        $("#disposeTime").val(Common.funGetNowDate());
        //故障代码
        $("#faultCodeText").val(_self.defaultFaultObj["FaultCode"] || "");
        //记录方式
        $("#recordWayText").val(_self.defaultFaultObj["RecordWay"] || "");
        //记录时间
        $("#recordTime").val(_self.defaultFaultObj["RecordTime"] || "");
        //父工单号
        $("#PWONumText").val(_self.defaultFaultObj["PWONum"] || "");
        //关联工单编号
        $("#relWONumText").val(_self.defaultFaultObj["RelationWONum"] || "");
        //关联工序编号
        $("#relProcedureNumText").val(_self.defaultFaultObj["RelationProcedureNum"] || "");
        //获取工单号
        $("#WONumText").val(_self.defaultFaultObj["WONum"] || "");
        //初始化拍照控件
        _self.funInitPhotoBox("pboxList");
        //初始化录像控件
        _self.funInitVideoBox("vboxList");
        //录音
        _self.funInitAudioBox("aboxList");
        //隐藏的是否计划内
        $("#isOfPlanText").val(_self.defaultFaultObj["IsOfPlan"] || "0");
        //是否有关联过来的附件 如果保存这些关联附件到故障工单后，请清空此值
        $("#txtHasRelationAttachment").val(_self.defaultFaultObj["HasRelationAttachment"] || "");
        //到场时间
        if (_self.defaultFaultObj["PresentDate"] && _self.defaultFaultObj["PresentDate"] != '') {//如果有则加载
            _self.funSetDatepicker("time_PresentDateDate", "time_PresentDateTime", _self.defaultFaultObj["PresentDate"]);
        }
        else {//没有则查看 是否存在预请点时间
            app.getGlobalVariable("PointCheckinData", function (res) {
                if (res) {
                    var PointCheckinData_PageData = JSON.parse(res);
                    if (PointCheckinData_PageData["ScanTime"] && PointCheckinData_PageData["ScanTime"] != '') {
                        _self.funSetDatepicker("time_PresentDateDate", "time_PresentDateTime", PointCheckinData_PageData["ScanTime"]);
                    }
                    else {//没有预请点时间，则为空
                        _self.funSetDatepicker("time_PresentDateDate", "time_PresentDateTime", "");
                    }
                }
            });
        }

        //判断是CBM还是CM
        if (_self.defaultFaultObj["OrderType"] != "CBM") {
            $("#radioBtnCM").btradio("val", "CM");
        }


        //判断是否为物料归集
        if (_self.defaultFaultObj["MatCollect"] && _self.defaultFaultObj["MatCollect"] == "N") {
            $("#radioMatCollectNO").btradio("val", "N");
        }

        _self.funGetFaultDevice("deviceList");

        _self.funGetFaultClass("faultClassList");

        _self.funGetLineInfo("LineList");

        if ($("#deviceList").btselect("val").value == "") {
            try {
                _self.defaultFaultObj["LineNum"] = _self.CurrentUserInfo["LineNum"];
                _self.funGetLineInfo("LineList");
            } catch (e) {
            }
        }

        _self.funGetSpecialtyInfo("SpecialtyList");
        //无数据，默认当前人的第一个专业
        if (!_self.defaultFaultObj["SpecialtyNum"]) {
            try {
                var UserParam = new Object();
                if (_self.CurrentUserInfo && _self.CurrentUserInfo["UserNum"]) {
                    var specialties = _self.CurrentUserInfo["SpecialtyNum"];
                    var specialtyArr = specialties.split(",");
                    var SpecialtyParam = new Object();
                    SpecialtyParam.SpecialtyNum = specialtyArr[0];
                    SqlHelper.funGetData("Specialty", function (rowsSpecialty) {
                        if (rowsSpecialty && rowsSpecialty.length > 0) {
                            //绑定
                            _self.defaultFaultObj["SpecialtyNum"] = rowsSpecialty[0]["SpecialtyNum"];
                            _self.funGetSpecialtyInfo("SpecialtyList");
                            if (_self.defaultFaultObj["SpecialtyNum"] == "AFC") {
                                $("#ul_AFC").css("display", "");
                            }
                            else {
                                $("#ul_AFC").css("display", "none");
                            }
                        }
                    }, SpecialtyParam, SqlHelper.WEIXIUDB);
                }
            } catch (e) {
            }
        }
        var specialtyListKey = $("#SpecialtyList").btselect("val").value;
        if (specialtyListKey == "AFC") {
            $("#ul_AFC").css("display", "");
        }
        else {
            $("#ul_AFC").css("display", "none");
        }

        //审批Approval<!-- Team:班组, Dispatcher:调度, Assistant:值班助理-->
        if (_self.defaultFaultObj["Approval"] != "Dispatcher") {
            if (_self.defaultFaultObj["Approval"] == "Team") {
                $("#radioBtnTeam").btradio("val", "Team");
            }
            else if (_self.defaultFaultObj["Approval"] == "Assistant") {
                $("#radioBtnAssistant").btradio("val", "Assistant");
            }
        }

        //维修开始时间
        _self.funSetDatepicker("time_ActStartDate", "time_ActStartTime", _self.defaultFaultObj["ActStart"]);
        //获取时间
        $("#disposeTime").val(_self.defaultFaultObj["FaultRecTime"] || "");
        //获取关联工单编号
        $("#relWONumText").val(_self.defaultFaultObj["RelationWONum"] || "");
        //获取关联工序编号
        $("#relProcedureNumText").val(_self.defaultFaultObj["RelationProcedureNum"] || "");
        //获取父工单号
        $("#PWONumText").val(_self.defaultFaultObj["PWONum"] || "");
        //隐藏的记录方式
        $("#recordWayText").val(_self.defaultFaultObj["RecordWay"] || "");
        //记录时间
        $("#recordTime").val(_self.defaultFaultObj["RecordTime"] || "");

        try {
            _self.funSetDatepicker("time_BorrowDate", "time_BorrowTime", _self.defaultFaultObj["BorrowDate"]);
            _self.funSetDatepicker("time_ReturnDate", "time_ReturnTime", _self.defaultFaultObj["ReturnDate"]);
            if (_self.defaultFaultObj["IsTempRepair"]) {//是否临时修复
                if (_self.defaultFaultObj["IsTempRepair"] != "0") {
                    $("#radioBtnIsTempRepairYes").attr("class", "BTCheck_ON");
                    $("#radioBtnIsTempRepairNo").attr("class", "");
                    _self.funSetIsTempRepairDatepicker(true);
                }
                else {
                    _self.funSetIsTempRepairDatepicker(false);
                }
            }
            //临时修复时间
            _self.funSetDatepicker("time_TempRepairTimeDate", "time_TempRepairTimeTime", _self.defaultFaultObj["TempRepairTime"]);
            //完全修复时间
            _self.funSetDatepicker("time_ActFinishDate", "time_ActFinishTime", _self.defaultFaultObj["ActFinish"]);


            if (_self.defaultFaultObj["IsCM"]) {
                if (_self.defaultFaultObj["IsCM"] != "1") {
                    $("#radioFaultYes").attr("class", "");
                    $("#radioFaultNo").attr("class", "BTCheck_ON");
                }
            }
            //是否有借匙
            var keyTypeArr = _self.defaultFaultObj["KeyTypes"] ? _self.defaultFaultObj["KeyTypes"].split(";") : new Array();
            var keyTypeArr_len = keyTypeArr.length;
            for (var i = 0; i < keyTypeArr_len; i++) {
                switch (keyTypeArr[i]) {
                    case "M":
                        $("#chkIsCM_M").attr("class", "BTCheck_ON");
                        break;
                    case "CBX":
                        $("#chkIsCM_CBX").attr("class", "BTCheck_ON");
                        break;
                    case "CZJ":
                        $("#chkIsCM_CZJ").attr("class", "BTCheck_ON");
                        break;
                    case "CPX":
                        $("#chkIsCM_CPX").attr("class", "BTCheck_ON");
                        break;
                    default:
                        break;
                }
            }
            if (keyTypeArr_len > 0) {
                _self.funSetReturnBorrowKeyDatepicker(true);
            }
            else {
                _self.funSetReturnBorrowKeyDatepicker(false);
            }

            //涉及报表 
            var reportKey = _self.defaultFaultObj["Report"] || "";
            var reportText = reportKey == "" ? "请选择" : reportKey;
            $("#divReportList").attr("value", reportKey);
            $("#divReportList span")[0].innerHTML = reportText;

            $("#txtReportNum").val(_self.defaultFaultObj["ReportNum"] || "");
            $("#numberMoneyCost").val(_self.defaultFaultObj["MoneyCost"] || "");
            $("#numberMoneyCount").val(_self.defaultFaultObj["MoneyCount"] || "");
            $("#numberWaitTime").val(_self.defaultFaultObj["WaitTime"] || "");

            //备注
            $("#txtRemark").val(_self.defaultFaultObj["Remark"] || "");

            //不良持术状态
            var technologyStateKey = _self.defaultFaultObj["TechnologyState"] || "";

            if (technologyStateKey) {
                var technologyStateText = technologyStateKey;
                $("#technologyStateList").attr("value", technologyStateKey);
                $("#technologyStateList span")[0].innerHTML = technologyStateText;
            }


            if (_self.defaultFaultObj["IsNeedReqrev"] == "Y") {
                $("#radioBtnIsNeedReqrevYes").attr("class", "BTCheck_ON");
                $("#radioBtnIsNeedReqrevNo").attr("class", "");
            }

            $("#txtStationFill").val(_self.defaultFaultObj["StationFill"] || "");

            //响应时间
            if (_self.defaultFaultObj["ResponseDate"]) {
                _self.funSetDatepicker("time_responseDate", "time_responseTime", _self.defaultFaultObj["ResponseDate"]);
            } else {
                //如果数据没有响应时间，使用父工单的响应时间
                var faultsOrderParam = new Object();
                SqlHelper.funGetData("OPPlan", function (rows) { //查询数据库获取数据
                    if (rows && rows.length > 0) {
                        for (var i = 0; i < rows.length; i++) {
                            if (rows[i]["PWONum"] == _self.defaultFaultObj["PWONum"]) {
                                _self.funSetDatepicker("time_responseDate", "time_responseTime", rows[i]["ResponseTime"]);
                            }
                        }
                    }
                }, faultsOrderParam, SqlHelper.WEIXIUDB);
            }

        } catch (e) {

        }
        _self.funInitMaterial();
    },
    funInitMaterial: function () {
        var _self = this;
        var pageParam = new Object();
        pageParam.PWONum = $("#PWONumText").val();
        pageParam.WONum = $("#WONumText").val();
        app.getGlobalVariable("TempFaultWoNum", function (res) {
            if (res) {
                pageParam.TempFaultWoNum = res;
            }
        });
        var faultMaterial = new FaultMaterial(pageParam);
        _self.FaultMaterial = faultMaterial;
        faultMaterial.funInitMaterialData("materiallist");
    },

    funInitPhotoBox: function (containerId) {
        var _self = this;
        if (_self.PhotoBox == null) {
            var param = new Object();
            //拍照的类型，ObjectType为:A,B,C,D 其中：A,工单、B,工序、C,工具、D.故障
            param.ObjectType = "WORKORDER";
            //赋值主键：工单编号
            var WONum = _self.defaultFaultObj["WONum"] || "";//$("#WONumText").val();
            var PWONum = _self.defaultFaultObj["PWONum"] || "";// $("#PWONumText").val();   //2013/12/4 邱嘉楠新增
            param.ObjectID = WONum;
            param.ContainerId = containerId;
            param.PWONum = PWONum;
            param.OrderType = _self.defaultFaultObj["OrderType"];

            if (_self.PageParam) {
                var imgInfos = _self.PageParam["ImgInfos"] || [];
                param.InitAttList = imgInfos;
            }


            _self.PhotoBox = new PhotoBox(param);
            _self.PhotoBox.initBox(_self.PhotoBox);
        }

    },

    funInitVideoBox: function (containerId) {
        var _self = this;
        if (_self.VideoBox == null) {
            var param = new Object();
            //拍照的类型，ObjectType为:A,B,C,D 其中：A,工单、B,工序、C,工具、D.故障
            param.ObjectType = "WORKORDER";
            //赋值主键：工单编号
            var WONum = _self.defaultFaultObj["WONum"] || "";//$("#WONumText").val();
            var PWONum = _self.defaultFaultObj["PWONum"] || "";// $("#PWONumText").val();   //2013/12/4 邱嘉楠新增
            param.ObjectID = WONum;
            param.ContainerId = containerId;
            param.PWONum = PWONum;
            if (_self.PageParam) {
                var videoInfos = _self.PageParam["VideoInfos"] || [];
                param.InitAttList = videoInfos;
            }

            _self.VideoBox = new VideoBox(param);
            _self.VideoBox.initBox(_self.VideoBox);


        }
    },

    funInitAudioBox: function (containerId) {
        var _self = this;
        if (_self.AudioBox == null) {
            var param = new Object();
            param.ObjectType = "WORKORDER";
            var WONum = _self.defaultFaultObj["WONum"] || "";//$("#WONumText").val();
            var PWONum = _self.defaultFaultObj["PWONum"] || "";// $("#PWONumText").val();   //2013/12/4 邱嘉楠新增
            param.ObjectID = WONum;
            param.ContainerId = containerId;
            param.PWONum = PWONum;
            if (_self.PageParam) {
                var audioInfos = _self.PageParam["AudioInfos"] || [];
                param.InitAttList = audioInfos;
            }
            _self.AudioBox = new AudioBox(param);
            _self.AudioBox.initBox(_self.AudioBox);

        }

    },

    funGetFaultInfo: function (tableName, CId, colum1, colum2, relColumParam, whereCondition, database, value, emptyMsg) {
        var _self = this;
        ///<summary>获取故障设备信息公用方法</summary>
        ///<param name="tableName" >表名</param>
        ///<param name="CId" >容器ID</param>
        ///<param name="colum1" >表字段1，作为Key</param>
        ///<param name="colum2" >表字段2，作为Value</param>
        ///<param name="relColumParam" >需要查询的关联字段参数对象</param>
        ///<param name="whereCondition">直接使用的查询条件 如：and 字段名1='' and 字段名2 in('') and 字段名3 like '%%'</param>
        ///<param name="database" >需要查询的数据库名</param>
        ///<param name="value" >默认选中项的值selectedValue 如果默认第一个使用@first 如果默认[请选择]使用""或者null</param>
        ///<param name="emptyMsg" >没有查询到数据时的提示</param>
        SqlHelper.funGetDataByWhere(tableName, function (rows) {
            var deviceList = new Array();
            if (rows.length == 0) {
                if (emptyMsg) {
                    app.alert(emptyMsg);
                }
                //app.alert("查询不到相关设备");
            } else {
                var isContain = false;
                var isNeedCheck = !!value ? (value != "@first" && value != 'undefined') : false;//是否有指定初始值，如果默认第一个则没有，为空也没有，不为空且不系于@first则有
                for (var i = 0; i < rows.length; i++) {
                    var deviceItem = new Object();
                    deviceItem.key = rows[i][colum1];
                    deviceItem.value = rows[i][colum2];
                    deviceList.push(deviceItem);
                    if (isNeedCheck && value == rows[i][colum1]) {
                        isContain = true;
                    }
                }
                if (value == "@first") {
                    isContain = true;
                    value = rows[0][colum1];
                }
                var html = '<div id="' + CId + '" data-role="BTSelect" value="' + (isContain ? value : "") + '" callback="' + CId + 'Callback" data=\'[{"key":"","value":"请选择"}]\' ><span>请选择</span></div>';
                $("#" + CId).parent().html(html);
                $("#" + CId).attr("data", JSON.stringify(deviceList));
                $("#" + CId).uiwidget();
            }
        }, relColumParam, whereCondition, database);
    },

    funGetLineInfo: function (containerId) {
        var _self = this;
        ///<summary>获取线路列表方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        ///<param name="_self" >类本身</param>
        var param = new Object();
        var divContainer = $("#" + containerId);
        if (!divContainer) {
            return;
        }
        var defaultValue = _self.defaultFaultObj["LineNum"];
        _self.funGetFaultInfo("Line", containerId, "LineNum", "LineName", param, "", SqlHelper.WEIXIUBASEDB, defaultValue || "");
    },

    funGetSpecialtyInfo: function (containerId) {
        var _self = this;
        ///<summary>获取专业列表方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        ///<param name="_self" >类本身</param>
        var param = new Object();
        var divContainer = $("#" + containerId);
        if (!divContainer) {
            return;
        }
        var defaultValue = _self.defaultFaultObj["SpecialtyNum"];
        _self.funGetFaultInfo("Specialty", containerId, "SpecialtyNum", "SpecialtyName", param, "", SqlHelper.WEIXIUBASEDB, defaultValue || "");
    },

    funGetFaultDevice: function (containerId) {
        var _self = this;
        ///<summary>获取故障设备列表方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        ///<param name="_self" >类本身</param>
        var param = new Object();
        var divContainer = $("#" + containerId);
        if (!divContainer) {
            return;
        }
        param.DeviceNum = !!_self.defaultFaultObj["DeviceNum"] ? _self.defaultFaultObj["DeviceNum"] : "";
        _self.funGetFaultInfo("Device", containerId, "DeviceNum", "DeviceName", param, "", SqlHelper.WEIXIUBASEDB, _self.defaultFaultObj["DeviceNum"]);
    },

    funGetFaultClass: function (containerId) {
        var _self = this;
        var relParam = new Object();
        ///<summary>获取故障类别方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        ///<param name="relParam" >需查询关联表的字段</param>
        _self.funGetFaultInfo("FaultClass", containerId, "FaultClassCode", "FaultClassName", relParam, "", SqlHelper.WEIXIUBASEDB, _self.defaultFaultObj["FaultCodeNum"]);
    },
    funGetFaultPhe: function (containerId, relParam) {
        var _self = this;
        ///<summary>获取故障现象方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        ///<param name="relParam" >需查询关联表的字段</param>
        _self.funGetFaultInfo("FaultPhenomenon", containerId, "FaultPhenomenonNum", "FaultPhenomenonName", relParam, "", SqlHelper.WEIXIUBASEDB, _self.defaultFaultObj["FaultPhenomenonNum"]);
    },

    funGetFaultDeviceRsn: function (containerId, relParam) {
        var _self = this;
        ///<summary>获取故障原因方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        _self.funGetFaultInfo("FaultReason", containerId, "FaultReasonNum", "FaultReasonName", relParam, "", SqlHelper.WEIXIUBASEDB, _self.defaultFaultObj["FaultReasonNum"]);
    },

    funGetFaultDeviceSln: function (containerId, relParam) {
        var _self = this;
        ///<summary>获取故障解决方式的方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        _self.funGetFaultInfo("FaultSolution", containerId, "FaultSolutionNum", "FaultSolutionName", relParam, "", SqlHelper.WEIXIUBASEDB, _self.defaultFaultObj["FaultSolutionNum"]);

    },

    funSaveFault: function (goPageName) {
        var _self = this;
        var DeviceNum = ($("#deviceList").btselect("val").value == "请选择") ? "" : $("#deviceList").btselect("val").value;
        var DeviceName = ($("#deviceList").btselect("val").label == "请选择") ? "" : $("#deviceList").btselect("val").label;
        var FaultClassNum = ($("#faultClassList").btselect("val").value == "请选择") ? "" : $("#faultClassList").btselect("val").value;
        var FaultClassName = ($("#faultClassList").btselect("val").label == "请选择") ? "" : $("#faultClassList").btselect("val").label;
        var FaultPhenomenonNum = ($("#faultPheList").btselect("val").value == "请选择") ? "" : $("#faultPheList").btselect("val").value;
        var FaultPhenomenonName = ($("#faultPheList").btselect("val").label == "请选择") ? "" : $("#faultPheList").btselect("val").label;
        var FaultReasonNum = ($("#faultRsnList").btselect("val").value == "请选择") ? "" : $("#faultRsnList").btselect("val").value;
        var FaultReasonName = ($("#faultRsnList").btselect("val").label == "请选择") ? "" : $("#faultRsnList").btselect("val").label;
        var FaultSolutionNum = ($("#faultSlnList").btselect("val").value == "请选择") ? "" : $("#faultSlnList").btselect("val").value;
        var FaultSolutionName = ($("#faultSlnList").btselect("val").label == "请选择") ? "" : $("#faultSlnList").btselect("val").label;

        if (FaultPhenomenonName == "" && FaultReasonName == "" && FaultSolutionName == "") {
        } else if (FaultPhenomenonName != "" && FaultReasonName != "" && FaultSolutionName != "") {
        } else {
            if (FaultClassName == "") {
                app.alert("请选择故障类别");
            }
            else if (FaultPhenomenonName == "") {
                app.alert("请选择故障现象");
            }
            else if (FaultReasonName == "") {
                app.alert("请选择故障原因");
            }
            else {
                app.alert("请选择故障解决方式");
            }
            return;
        }
        var faultObj = _self.funGetPageData("1");
        if (faultObj["FaultDesc"]) {
            var WONum = faultObj["WONum"];
            var sqlList = new Array();
            faultObj.DeviceNum = DeviceNum;
            faultObj.DeviceName = (DeviceNum == "") ? "未知设备故障" : DeviceName;
            faultObj.FaultPhenomenonNum = FaultPhenomenonNum;
            faultObj.FaultPhenomenonName = FaultPhenomenonName;
            faultObj.FaultReasonNum = FaultReasonNum;
            faultObj.FaultReasonName = FaultReasonName;
            faultObj.FaultSolutionNum = FaultSolutionNum;
            faultObj.FaultSolutionName = FaultSolutionName;

            var delFaultSql = "Delete FROM FaultsOrder WHERE WONum='" + WONum + "'";
            sqlList.push(delFaultSql);

            var inertFaultsText = SqlTextHelper.funGetInsertText("FaultsOrder", [faultObj]);
            sqlList = sqlList.concat(inertFaultsText);
            if (WONum.substr(0, 1) != "-") {
                var updOrdersText = "UPDATE OPOrders set SelfFormIsFinished = '1',SelfFormUserName='" + faultObj.RecUserName + "',SelfFormFinishTime='" + faultObj.FaultRecTime + "',SelfFormUserCode ='" + faultObj.RecUserNum + "',RecWay ='" + faultObj.RecordWay + "',RecTime='" + faultObj.RecordTime + "' where WONum='" + WONum + "'";
                sqlList.push(updOrdersText);
            }

            if (_self.FaultMaterial != null) {
                var faultMaterial = _self.FaultMaterial;
                var materials = faultMaterial.funGetMaterialData(faultMaterial);
                var materlen = materials.length;
                if (materlen > 0) {
                    for (var i = 0; i < materlen; i++) {
                        var item = materials[i];
                        item.PWONum = faultObj["PWONum"] || "";
                        item.WONum = WONum;
                    }
                    var delSql = "Delete FROM OPMaterial WHERE WONum='" + WONum + "'";
                    sqlList.push(delSql);
                    var inertText = SqlTextHelper.funGetInsertText("OPMaterial", materials);
                    sqlList = sqlList.concat(inertText);
                }
            }
            _self.funCopyAttFile(function () {
                var db = app.database.open(Common.WEIXIUDB);
                app.database.executeNonQuery(db, sqlList, function () {
                    switch (goPageName) {
                        case "measurePoint": {
                            var pageParam = new Object();
                            pageParam.WONum = WONum;
                            pageParam.DeviceNum = DeviceNum;
                            Common.funLoad("measurePoint.html", pageParam);
                        }
                            break;
                        default: {
                            app.alert("保存成功", function () {
                                var tempFaultWoNum = "";
                                app.getGlobalVariable("TempFaultWoNum", function (res) {
                                    if (res) {
                                        tempFaultWoNum = res;
                                    }
                                });
                                app.setGlobalVariable("TempFaultWoNum", "");
                                app.setGlobalVariable(tempFaultWoNum, "");
                                Common.funGoBack();
                            });
                        }
                            break;
                    }
                });
            });
        } else {
            app.alert("请填写故障描述");
        }
    },

    funGetPageData: function (excludeCol) {
        var _self = this;
        ///<summary>获取页面数据，手选按钮的传值处理</summary>
        ///<param name ="excludeCol">排除字段，为1是进行排除，其它值不排除</param>
        var pageObj = new Object();
        //工单类型 字段不为空
        if ($("#radioBtnCBM").hasClass("BTCheck_ON")) {
            pageObj.OrderType = "CBM";
        }
        else {
            pageObj.OrderType = "CM";
        }

        //是否后续跟进 字段不为空
        if ($("#radioBtnYes").hasClass("BTCheck_ON")) {
            pageObj.HasFollowUpWork = "1";
        }
        else {
            pageObj.HasFollowUpWork = "0";
        }

        //是否物料归集
        if ($("#radioMatCollectYes").hasClass("BTCheck_ON")) {
            pageObj.MatCollect = "Y";
        }
        else {
            pageObj.MatCollect = "N";
        }


        //是否后补单
        if ($("#radioBtnIsAfterYes").hasClass("BTCheck_ON")) {
            pageObj.isAfter = "1";
        }
        else {
            pageObj.isAfter = "0";
        }


        //审批Approval<!-- Team:班组, Dispatcher:调度, Assistant:值班助理-->
        if ($("#radioBtnTeam").hasClass("BTCheck_ON")) {
            pageObj.Approval = "Team";
        }
        else if ($("#radioBtnDispatcher").hasClass("BTCheck_ON")) {
            pageObj.Approval = "Dispatcher";
        }
        else if ($("#radioBtnAssistant").hasClass("BTCheck_ON")) {
            pageObj.Approval = "Assistant";
        }
        else {
            pageObj.Approval = "";
        }

        //所选设备
        pageObj.DeviceNum = ($("#deviceList").btselect("val").value == "请选择") ? "" : $("#deviceList").btselect("val").value;
        // pageObj.FaultCodeNum = ($("#faultClassList").btselect("val").value == "请选择") ? "" : $("#faultClassList").btselect("val").value;
        pageObj.FaultPhenomenonNum = ($("#faultPheList").btselect("val").value == "请选择") ? "" : $("#faultPheList").btselect("val").value;
        pageObj.FaultReasonNum = ($("#faultRsnList").btselect("val").value == "请选择") ? "" : $("#faultRsnList").btselect("val").value;
        pageObj.FaultSolutionNum = ($("#faultSlnList").btselect("val").value == "请选择") ? "" : $("#faultSlnList").btselect("val").value;
        //故障代码备注
        pageObj.FaultCodeMemo = $("#faultCodeMemo").val();
        //故障描述
        pageObj.FaultDesc = $("#faultDesc").val();
        //跟踪情况
        pageObj.TraceCase = $("#traceCase").val();
        //处理时间
        pageObj.FaultRecTime = $("#disposeTime").val();
        //处理人
        pageObj.RecUserName = $("#disposeUser").val();
        //隐藏的故障代码
        pageObj.FaultCodeNum = $("#faultCodeText").val();//增加保存故障代码
        //隐藏的关联工单编号
        pageObj.RelationWONum = $("#relWONumText").val();
        //隐藏的关联工序编号
        pageObj.RelationProcedureNum = $("#relProcedureNumText").val();
        //隐藏的父工单号
        pageObj.PWONum = $("#PWONumText").val();
        //隐藏的工单编号
        pageObj.WONum = $("#WONumText").val();
        //隐藏的记录方式
        pageObj.RecordWay = $("#recordWayText").val();
        //隐藏的是否计划内
        pageObj.IsOfPlan = $("#isOfPlanText").val();
        //文件记录编号
        pageObj.RelatedAttRecNum = $("#relatedAttRecNumText").val();
        //记录人员编号
        var RecUserNum = "";
        app.getGlobalVariable("UserCode", function (res) {
            //获取全局变量UserCode
            if (res) {
                RecUserNum = res;
            }
        });
        pageObj.RecUserNum = RecUserNum;
        pageObj.RecordTime = $("#recordTime").val();
        if (excludeCol != "1") {
            //是否存在关联附件
            pageObj.HasRelationAttachment = $("#txtHasRelationAttachment").val();
        }


        //故障实际发生时间
        pageObj.FailDate = _self.funGetDatepicker("time_FailDate", "time_FailTime");
        //维修开始时间
        pageObj.ActStart = _self.funGetDatepicker("time_ActStartDate", "time_ActStartTime");

        //是否临时修复
        if ($("#radioBtnIsTempRepairNo").hasClass("BTCheck_ON")) {
            pageObj.IsTempRepair = "0";
        } else if ($("#radioBtnIsTempRepairYes").hasClass("BTCheck_ON")) {
            pageObj.IsTempRepair = "1";
        }
        //临时修复时间
        pageObj.TempRepairTime = _self.funGetDatepicker("time_TempRepairTimeDate", "time_TempRepairTimeTime");
        //完全修复时间
        pageObj.ActFinish = _self.funGetDatepicker("time_ActFinishDate", "time_ActFinishTime");

        //到场时间
        pageObj.PresentDate = _self.funGetDatepicker("time_PresentDateDate", "time_PresentDateTime");

        //线路
        var LineList = $("#LineList");
        pageObj.LineNum = LineList.btselect("val").value;
        pageObj.LineName = (LineList.btselect("val").label == "请选择") ? "" : LineList.btselect("val").label;

        var SpecialtyList = $("#SpecialtyList");
        pageObj.SpecialtyNum = SpecialtyList.btselect("val").value;
        pageObj.SpecialtyName = (SpecialtyList.btselect("val").label == "请选择") ? "" : SpecialtyList.btselect("val").label;

        //备注
        pageObj.Remark = $("#txtRemark").val();

        //不良持术状态
        pageObj.TechnologyState = $("#technologyStateList").btselect("val").value || "故障";

        //响应时间
        pageObj.ResponseDate = _self.funGetDatepicker("time_responseDate", "time_responseTime");

        pageObj.IsCM = $("#radioFaultYes").hasClass("BTCheck_ON") ? "1" : "0";

        if (document.getElementById("ul_AFC") && document.getElementById("ul_AFC").hasAttributes("style") && document.getElementById("ul_AFC").style.display != "none") {
            var keyTypeArr = new Array();
            if ($("#chkIsCM_M").hasClass("BTCheck_ON")) {
                keyTypeArr.push("M");
            }
            if ($("#chkIsCM_CBX").hasClass("BTCheck_ON")) {
                keyTypeArr.push("CBX");
            }
            if ($("#chkIsCM_CZJ").hasClass("BTCheck_ON")) {
                keyTypeArr.push("CZJ");
            }
            if ($("#chkIsCM_CPX").hasClass("BTCheck_ON")) {
                keyTypeArr.push("CPX");
            }
            pageObj.KeyTypes = keyTypeArr.join(";");

            //借匙时间
            pageObj.BorrowDate = _self.funGetDatepicker("time_BorrowDate", "time_BorrowTime");

            //还匙时间
            pageObj.ReturnDate = _self.funGetDatepicker("time_ReturnDate", "time_ReturnTime");

            //涉及报表 
            pageObj.Report = $("#divReportList").btselect("val").value;

            pageObj.ReportNum = $("#txtReportNum").val();
            pageObj.MoneyCost = $("#numberMoneyCost").val();
            pageObj.MoneyCount = $("#numberMoneyCount").val();
            pageObj.WaitTime = $("#numberWaitTime").val();

        }

        if ($("#radioBtnIsNeedReqrevYes").hasClass("BTCheck_ON")) {
            pageObj.IsNeedReqrev = "Y";
        }
        else {
            pageObj.IsNeedReqrev = "N";
        }


        pageObj.StationFill = $("#txtStationFill").val();


        return pageObj;
    },

    funEditMeasurement: function () {
        var _self = this;
        var deviceNum = $("#deviceList").btselect("val").value;
        if ((deviceNum == "请选择") || deviceNum == "") {
            app.alert("请先选择故障设备");
        } else {
            _self.funSaveFault("measurePoint");
        }
    },

    funSetTempFaultWoNum: function () {
        ///<summary>创建故障工单编号</summary>
        app.getGlobalVariable("TempFaultWoNum", function (res) {
            if (!res) {
                app.setGlobalVariable("TempFaultWoNum", Common.funGetPkId());
            }
        });
    },

    funSetDatepicker: function (dateId, timeId, date) {
        ///<summary>设置日期</summary>
        ///<param name="dateId">日期主键</param>
        ///<param name="timeId">时间主键</param>
        ///<param name="date">日期，为空则清除</param>
        if (!date || date == "") {
            $("#" + dateId).attr("value", "");
            $("#" + dateId + " span")[0].innerHTML = "日期";
            $("#" + timeId).attr("value", "");
            $("#" + timeId + " span")[0].innerHTML = "时间";
            return;
        }
        var dates = date.split(" ");
        $("#" + dateId).attr("value", dates[0]);
        $("#" + dateId + " span")[0].innerHTML = dates[0];
        var timeValue = dates[1].length > 5 ? dates[1].substring(0, dates[1].lastIndexOf(":")) : dates[1];
        $("#" + timeId).attr("value", timeValue);
        $("#" + timeId + " span")[0].innerHTML = timeValue;
    },

    funGetDatepicker: function (dateId, timeId) {
        ///<summary>获取日期</summary>
        ///<param name="dateId">日期主键</param>
        ///<param name="timeId">时间主键</param>
        var dateTimeValue = '';
        var dateValue = $("#" + dateId).btselect("val").value;
        var timeValue = $("#" + timeId).btselect("val").value;
        if (dateValue != "" && timeValue != "") {
            dateTimeValue = dateValue + " " + timeValue + ":0";
        }
        ;
        return dateTimeValue;
    },

    funSetReturnBorrowKeyDatepicker: function (isVisible) {
        var _self = this;
        ///<summary>设置借匙还匙日期控件</summary>
        ///<param name="isVisible">是否显示，不显示时清空数据</param>
        ///<param name="_self"></param>
        if (isVisible) {
            $("#LiBorrow").css("display", "");
            $("#LiReturn").css("display", "");
        }
        else {
            $("#LiBorrow").css("display", "none");
            $("#LiReturn").css("display", "none");
            _self.funSetDatepicker("time_BorrowDate", "time_BorrowTime", "");
            _self.funSetDatepicker("time_ReturnDate", "time_ReturnTime", "");
        }
    },

    funSetIsTempRepairDatepicker: function (isVisible) {
        var _self = this;
        ///<summary>是否临时修复日期控件</summary>
        ///<param name="isVisible">是为临时修复，否为完全修复</param>
        ///<param name="_self"></param>
        if (isVisible) {
            //临时修复时间
            $("#LiTempRepairTime").css("display", "");
            //完全修复时间
            $("#LiActFinish").css("display", "none");
        }
        else {
            $("#LiTempRepairTime").css("display", "none");
            $("#LiActFinish").css("display", "");
        }
        _self.funSetDatepicker("time_TempRepairTimeDate", "time_TempRepairTimeTime", "");
        _self.funSetDatepicker("time_ActFinishDate", "time_ActFinishTime", "");
    },

    funCopyAttFile: function (successFun, failureFun) {
        var _self = this;
        ///<summary>拷贝附件</summary>
        ///<param name="_self"></param>
        ///<param name="successFun">操作成功回调方法(不带参数)</param>
        ///<param name="failureFun">操作失败回调方法(不带参数)</param>
        if ($("#txtHasRelationAttachment").val() != "1") {
            successFun();
            return;
        }
        $("#txtHasRelationAttachment").val("");//清空数据，不再重复保存
        var objectId = $("#relProcedureNumText").val(); //_self.Param["RelationProcedureNum"] || "";
        if (objectId) {
            var db = app.database.open(Common.WEIXIUDB);
            var WONum = $("#WONumText").val();
            var PWONum = $("#PWONumText").val();
            db.transaction(function (tx) {
                tx.executeSql('SELECT * from AttFile where ObjectType="UDWOTASK" and ObjectID=?', [objectId], function (tx, results) {
                    var rows = Common.funConvertRowsJson(results);
                    var rowlen = rows.length;
                    for (var i = 0; i < rowlen; i++) {
                        var rowItem = rows[i];
                        var attPath = rowItem["AttPath"];
                        if (attPath) {
                            window.resolveLocalFileSystemURI(attPath, function (fileEntry) {
                                var startIndex = attPath.lastIndexOf("/");
                                var parent = attPath.substring(0, (startIndex));
                                var parentNameIndex = parent.lastIndexOf("/");
                                var parentName = parent.slice(parentNameIndex + 1);

                                var typeIndex = attPath.lastIndexOf(".");
                                var type = attPath.slice(typeIndex);
                                var newFileName = (-(Common.funGetPkId() - 0)) + type;
                                var parentEntry = new DirectoryEntry(parentName, parent + "/");
                                fileEntry.copyTo(parentEntry, newFileName, function () {
                                    var newAttPath = parent + "/" + newFileName;
                                    var attNum = Common.funGetPkId();
                                    var attType = rowItem["AttType"];
                                    var objectType = "WORKORDER";
                                    var attDesc = rowItem["AttDesc"];
                                    tx.executeSql('INSERT INTO AttFile(AttNum,AttType,ObjectType,ObjectID,AttDesc,AttPath,PWONum) VALUES ("' + attNum + '",?,?,?,?,?,?)', [attType, objectType, WONum, attDesc, newAttPath, PWONum]);
                                });
                            }, null);
                        }
                    }
                });
            }, function (error) {
                app.alert(error);
            }, function () {
                successFun();
            });
        }
    },
    funBackRefresh: function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                retParamStr = retParamStr.replace(/\n/g, "\\n");
                var retParam = JSON.parse(retParamStr);
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funSetTempFaultWoNum();
            _self.funInitPageParam();
        }, 100);
    }
};


