﻿var UploadRecord = function () {
    this.UpdRecordFilePath = "";
    this.UpdManifestList = new Array();
    (function (self) {
        if (self.UpdRecordFilePath == "") {
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fileSystem) {
                fileSystem.root.getDirectory("LmisUpdRecordFile", {create: true, exclusive: false},
                    function (fileEntry) {
                        self.UpdRecordFilePath = fileEntry.fullPath;
                        var uri = fileEntry.fullPath + "/LMIS_UploadOrder.txt";
                        app.file.readAsString(uri, function (res) {
                            if (res) {
                                self.UpdManifestList = JSON.parse(res);
                            }
                        });

                    }, function () {
                        app.alert("创建目录失败");
                    });
            });
        }
    })(this);
};

UploadRecord.prototype = {

    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnUploadWork").click(function () {
            var networkState = navigator.network.connection.type;
            if (networkState == Connection.NONE) { //未连接
                app.alert("您当前没有用网络");
            } else {
                app.confirm("所选工单将会重复上传,是否继续上传。", function (index) {
                    if (index == 2) {
                        _self.funUploadWork();
                    }
                }, "重复工单上传提示", "取消,确定");
            }
        });

        $("#btnClearWork").click(function () {
            _self.funClearWork();
        });
    },

    funInitUpdRecordData: function (containerId) {
        var _self = this;
        var lihtml = "";
        lihtml = ' <li>';
        lihtml += '<div class="row-fluid">';
        lihtml += '<div class="span10" align="center">***暂无上传数据记录***</div>';
        lihtml += '</div>';
        lihtml += '</li>';
        var orderList = _self.UpdManifestList;
        var orderlen = orderList.length;
        var endIndex = orderlen;
        var startIndex = (orderlen - 300) < 0 ? 0 : (orderlen - 300);

        if (orderlen > 0) {
            lihtml = "";
            for (var i = (endIndex - 1); i >= startIndex; i--) {
                var orderItem = orderList[i];

                var dataType = orderItem.DataType;
                var description = orderItem.Description;
                var userCode = orderItem.UserCode;
                var updDate = orderItem.Date;

                lihtml += '<li>';
                lihtml += '<div data-role="BTButton" data-status="1">';
                lihtml += '<span class="btn-text">';
                lihtml += '<div class="row-box">';
                lihtml += '<div class="span1">';
                if (dataType == "Plan") {
                    lihtml += '<div id="li' + i + '" index=' + i + ' data-role="BTCheck"  data-inline="false">' + description + '<br/>用户账号:' + userCode + ' &nbsp;&nbsp;&nbsp;&nbsp;上传时间:' + updDate + '</div>';
                } else if (dataType == "Fault") {
                    lihtml += '<div id="li' + i + '" index=' + i + ' data-role="BTCheck"  data-inline="false">【故障】' + description + '<br/>用户账号:' + userCode + ' &nbsp;&nbsp;&nbsp;&nbsp;上传时间:' + updDate + '</div>';
                }
                lihtml += '</div>';
                lihtml += '</div>';
                lihtml += '</span>';
                lihtml += '</div>';
                lihtml += ' </li>';
            }
        }

        var cnt = document.getElementById(containerId);
        if (cnt) {
            cnt.innerHTML = lihtml;
            if (orderlen > 0) {
                ui.init();
                _self.funBindEvent();
            }
        }
    },

    funBindEvent: function () {
        var _self = this;
        $("#btnAllChk").click(function () {
            var chkBox = $(this);
            var result = chkBox.btcheck("val");
            var length = _self.UpdManifestList.length;
            if (length > 0) {
                var isAllchked = false;
                if (result != null && result.value != "") {
                    isAllchked = true;
                }
                for (var i = 0; i < length; i++) {
                    var chkBoxItem = $("#li" + i);
                    if (isAllchked) {
                        chkBoxItem.removeClass('BTCheck_OFF').addClass('BTCheck_ON');
                    } else {
                        chkBoxItem.removeClass('BTCheck_ON').addClass('BTCheck_OFF');
                    }
                }
            }
        });
    },

    funGetChkList: function () {
        var _self = this;
        var planList = new Array();
        var faultList = new Array();
        var length = _self.UpdManifestList.length;
        if (length > 0) {
            for (var i = 0; i < length; i++) {
                var updItem = _self.UpdManifestList[i];
                if (updItem) {
                    var filePath = updItem.FilePath;
                    var chkBoxItem = $("#li" + i);
                    var result = chkBoxItem.btcheck("val");
                    if (result != null && result.value != "") {
                        var dataType = updItem["DataType"];
                        if (dataType == "Plan") {
                            planList.push({"Index": i, "FilePath": filePath});
                        } else if (dataType == "Fault") {
                            faultList.push({"Index": i, "FilePath": filePath});
                        }
                    }
                }
            }
        }
        return {"PlanList": planList, "FaultList": faultList};
    },


    funUploadWork: function () {
        var _self = this;
        var chkObj = _self.funGetChkList();
        var planList = chkObj.PlanList;
        var faultList = chkObj.FaultList;
        var chkListCount = planList.length + faultList.length;
        if (chkListCount > 0) {
            app.progress.start("上传提示", "正在处理中...");

            var nowDate = Common.funGetNowDate();
            var userCode = "";
            var password = "";
            app.getGlobalVariable("UserCode", function (res) {
                if (res) {
                    userCode = res;
                }
            });
            app.getGlobalVariable("Password", function (res) {
                if (res) {
                    password = res;
                }
            });

            var upPlanOkList = new Array();
            var upPlanErrorList = new Array();

            var upFaultOkList = new Array();
            var upFaultErrorList = new Array();

            var loseFileList = new Array();

            //递归单条上传工单  lsw/2017-11-09：因为iphone不能异步上传改成同步的递归上传数据，异步导致多选上传的时候上传是同一条记录
            //
            var funUpWk = function (i) {
                var wklen = planList.length;
                if (!i) {
                    i = 0;
                }
                if (i < wklen) {
                    var planItem = planList[i];
                    app.progress.start("上传提示", "正在上传数据[" + planItem["PWONum"] + "]...(" + (i + 1) + "/" + wklen + ")");
                    var uri = planItem.FilePath;
                    app.file.readAsString(uri, function (contentRes) {
                        funUploadDate(planItem.Index);
                        if (contentRes) {
                            var requestParam = JSON.parse(contentRes);
                            var wkItem = requestParam.PayLoad;
                            app.ajax({
                                "url": MobileConfig.UploadWorkUrl,
                                "data": requestParam,
                                "contentType": "application/json",
                                "method": "POST",
                                "timeout": 600000,
                                "async": false,
                                "success": function (res) {
                                    var responseData = JSON.parse(res.returnValue);
                                    if (responseData.ResStatus == true) {
                                        upPlanOkList.push(wkItem["PWONum"] + wkItem["OPCode"] + wkItem["OPName"]);
                                    } else {
                                        upPlanErrorList.push(wkItem["PWONum"] + wkItem["OPCode"] + wkItem["OPName"] + "[" + responseData.ResMsg + "]");
                                    }
                                    funUpWk(i + 1);
                                },
                                "fail": function (res) {
                                    upPlanErrorList.push(wkItem["PWONum"] + wkItem["OPCode"] + wkItem["OPName"] + "[网络错误]");
                                    //递归下一条
                                    funUpWk(i + 1);
                                }
                            });
                        }
                    }, function (res) {
                        loseFileList.push("PM:" + uri);
                    });
                } else {
                    funUpFault();
                }
            };

            var funUpFault = function (i) {
                var fltOrderlen = faultList.length;
                if (!i) {
                    i = 0;
                }
                if (i < fltOrderlen) {
                    var fltItem = faultList[i];
                    app.progress.start("上传提示", "正在上传故障数据[" + fltItem["PWONum"] + "]...(" + (i + 1) + "/" + fltOrderlen + ")");
                    var uri = fltItem.FilePath;
                    app.file.readAsString(uri, function (contentRes) {
                        funUploadDate(fltItem.Index);
                        if (contentRes) {
                            var requestParam = JSON.parse(contentRes);
                            var faultItem = requestParam.PayLoad;
                            app.ajax({
                                "url": MobileConfig.UploadFaultUrl,
                                "data": requestParam,
                                "contentType": "application/json",
                                "method": "POST",
                                "timeout": 600000,
                                "async": false,
                                "success": function (res) {
                                    var responseData = JSON.parse(res.returnValue);
                                    if (responseData.ResStatus == true) {
                                        upFaultOkList.push(faultItem["WONum"] + faultItem["DeviceName"] + faultItem["FaultDesc"]);
                                    } else {
                                        upFaultErrorList.push(faultItem["WONum"] + faultItem["DeviceName"] + faultItem["FaultDesc"] + "[" + responseData.ResMsg + "]");
                                    }
                                    funUpFault(i + 1);

                                },
                                "fail": function (res) {
                                    upFaultErrorList.push(faultItem["DeviceName"] + "[网络错误]");
                                    //递归发送下一条
                                    funUpFault(i + 1);
                                }
                            });
                        }
                    }, function (res) {
                        loseFileList.push("Fault:" + uri);
                    });
                } else {
                    funUpEndMsg(true);
                }
            };

            var funUpEndMsg = function () {
                var titleMsg = "";
                if (upPlanOkList.length > 0) {
                    titleMsg += "上传成功的工单如下\n" + upPlanOkList.join("\n") + "\n\n";
                }
                if (upPlanErrorList.length > 0) {
                    titleMsg += "上传失败的工单如下\n" + upPlanErrorList.join("\n") + "\n\n";
                }
                if (faultList.length > 0 && upFaultOkList.length > 0) {
                    titleMsg += "上传成功的故障如下\n" + upFaultOkList.join("\n") + "\n\n";
                } else if (faultList.length > 0 && upFaultErrorList.length > 0) {
                    titleMsg += "上传故障失败\n" + upFaultErrorList.join("\n") + "\n\n";
                }
                if (loseFileList.length > 0) {
                    titleMsg += "未找读取到文件列表信息\n" + loseFileList.join("\n");
                }
                if (titleMsg) {
                    app.alert(titleMsg, function () {
                        app.progress.stop();
                    });
                } else {
                    app.alert("上传成功", function () {
                        app.progress.stop();
                    });
                }
                funSaveUpDate();
            };

            var funUploadDate = function (index) {
                try {
                    var upfestListItem = _self.UpdManifestList[index];
                    if (upfestListItem) {
                        upfestListItem.Date = nowDate;
                        upfestListItem.UserCode = userCode;
                    }
                } catch (e) {

                }

            };

            var funSaveUpDate = function () {
                var content = JSON.stringify(_self.UpdManifestList);
                var saveFilePath = _self.UpdRecordFilePath + "/LMIS_UploadOrder.txt";
                app.file.writeAsString(saveFilePath, content, function (res) {
                });
            };

            funUpWk();
        } else {
            app.alert("请选择要上传的作业");
        }
    },

    funClearWork: function () {
        var _self = this;
        app.confirm("确认要删除7天之前的上传记录?", function (index) {
            if (index == 2) {
                app.progress.start("删除提示", "正在处理中...");
                var upMainfestList = _self.UpdManifestList;
                var upMainfestLen = upMainfestList.length;
                if (upMainfestLen > 0) {
                    var isChange = false;
                    var curtDate = new Date();
                    for (var i = 0; i < upMainfestLen; i++) {
                        var mainfestItem = upMainfestList[i];
                        var day = (curtDate - new Date(mainfestItem.Date.replace(/-/g, '/'))) / (1000 * 60 * 60 * 24);
                        if (day > 7) {
                            isChange = true;
                            var filePath = mainfestItem.FilePath;
                            app.file.remove(filePath);
                            delete upMainfestList[i];
                        }
                    }

                    if (isChange) {
                        var newUpdManifestList = new Array();
                        for (var j = 0; j < upMainfestLen; j++) {
                            if (upMainfestList[j]) {
                                newUpdManifestList.push(upMainfestList[j]);
                            }
                        }
                        _self.UpdManifestList = newUpdManifestList;
                        var content = JSON.stringify(newUpdManifestList);
                        var saveFilePath = _self.UpdRecordFilePath + "/LMIS_UploadOrder.txt";
                        app.file.writeAsString(saveFilePath, content, function (res) {
                            app.alert("删除成功", function () {
                                app.progress.stop();
                                _self.funInitUpdRecordData("planList");
                            });
                        }, function (res) {
                            app.alert("删除失败", function () {
                                app.progress.stop();
                            });
                        });
                    } else {
                        app.alert("暂无7天之前的上传记录", function () {
                            app.progress.stop();
                        });
                    }

                } else {
                    app.alert("暂无7天之前的上传记录", function () {
                        app.progress.stop();
                    });
                }
            }
        }, "删除上传记录确认", "取消,确定");
    }
};