﻿var ChangePassword = function () {

};
ChangePassword.prototype = {
    funInitEvent: function () {
        var _self = this;
        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnBack").click(function () {
            Common.funGoBack();
        });

        $("#btnChangePwd").click(function () {
            var userCode = $("#txtUserCode").val().trim();
            var oldPassword = $("#txtOldPassword").val().trim();
            var newPassword = $("#txtNewPassword").val().trim();
            var confirmNewPwd = $("#txtCfmNewPassword").val().trim();
            _self.funChangePwd(userCode, oldPassword, newPassword, confirmNewPwd);
        });
    },

    funChangePwd: function (userCode, oldPassword, newPassword, confirmNewPwd) {
        ///<summary>修改密码的方法:void</summary>
        ///<param name="userCode" >用户名</param>
        ///<param name="oldPassword">旧密码</param>
        ///<param name="newPassword">新密码</param>
        ///<param name="confirmNewPwd">确认新密码</param>
        if (oldPassword == "") {
            app.alert("原密码不能为空！");
        }
        else if (newPassword == "") {
            app.alert("新密码不能为空！");
        }
        else if (confirmNewPwd == "") {
            app.alert("确认新密码不能为空！");
        }
        else if (confirmNewPwd != newPassword) {
            app.alert("两次新密码输入不一致", function () {
                $("#txtNewPassword").val("");
                $("#txtCfmNewPassword").val("");
            });
        }
        else {
            //连接获取服务器的用户数据
            var requestParam = new Object();
            requestParam.CallMethod = "Biz_Password";
            requestParam.orgin = "stream";
            requestParam.AuthBlock = new Object();
            requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
            requestParam.AuthBlock.Password = b64_md5($("#txtOldPassword").val());
            requestParam.AuthBlock.UserCode = $("#txtUserCode").val();
            requestParam.AuthBlock.ClientNumber = device.uuid;
            requestParam.PayLoad = new Object();
            app.getGlobalVariable("UserCode", function (res) {
                if (res) {
                    requestParam.PayLoad.UserCode = res;
                }
            });
            requestParam.PayLoad.OldPassword = b64_md5($("#txtOldPassword").val());
            requestParam.PayLoad.NewPassword = b64_md5($("#txtNewPassword").val());
            app.progress.start("提示", "正在处理中...");
            app.ajax({
                "url": MobileConfig.ChangePwdUrl, "data": requestParam,
                "contentType": "application/json",
                "method": "POST", "async": true,
                "success": function (res) {
                    var getUserData = JSON.parse(res.returnValue);
                    if (getUserData.ResStatus == true) {
                        var changePwd = new ChangePassword();
                        changePwd.funChangeLocalDB(userCode, oldPassword, newPassword); //更改本地数据库的密码
                    } else {
                        app.alert(getUserData.ResMsg);
                        app.progress.stop();
                    }
                }
            });

        }
    },

    funInitInfo: function () {
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                $("#txtUserName").val(res);
            }
        });
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                $("#txtUserCode").val(res);
            }
        });
    },

    funChangeLocalDB: function (userCode, oldPassword, newPassword) {
        ///<summary>更改本地数据库:void</summary>
        var updateList = new Array(); //更新的List
        var updateObj = new Object(); //更新的Obj
        var selectObj = new Object(); // 查询的Obj
        updateObj.Password = b64_md5(newPassword); //新密码
        updateObj.WhereParam = new Object();
        updateObj.WhereParam.UserCode = userCode; //查询的用户工号
        updateList.push(updateObj);
        selectObj.UserCode = userCode; //用户工号
        selectObj.Password = b64_md5(oldPassword); //旧密码
        SqlHelper.funGetData("User", function (rows) {
            if (rows.length >= 1) {
                SqlHelper.funUpdateData("User", updateList, function (rows1) {
                    //更改本地数据库的密码
                    app.alert("密码更新成功", function () {
                        app.progress.stop();
                    });
                    $("#txtOldPassword").val("");
                    $("#txtNewPassword").val("");
                    $("#txtCfmNewPassword").val("");
                }, SqlHelper.WEIXIUBASEDB);
            }
            else {
                app.alert("抱歉，请确认原密码是否正确！");
            }

        }, selectObj, SqlHelper.WEIXIUBASEDB);
    }
}