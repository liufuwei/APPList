﻿var Eqlist = function () {
    this.OPOrdersDic = new Dictionary();
    this.TagType = "";
    this.PageParam = null;
    this.UserCode = "";
    this.StartWkList = new Array();
    this.SelList = new Array();

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
        app.getGlobalVariable("startWkList", function (res) {
            if (res) {
                _this.StartWkList = JSON.parse(res);
            }
        });
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                _this.UserCode = res;
            }
        });
    })(this);
};

Eqlist.prototype = {
    funInitEvent: function () {
        var _self = this;

        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);
        $("#btnLogOut").click(function () {
            Common.funLoadMain();
        });


        //扫码返回就是编号
        var funCode = function (res)
        {
            if (res)
            {
                 switch (res["TagType"]) {
                     case "L"://设备的位置标签
                         _self.TagType = res["TagType"];
                         _self.funGoOpPlan("L"+res["TagCode"], res["TagType"]);
                         break;
                     default:
                         _self.TagType = "L";
                         _self.funGoOpPlan(res["TagCode"], "L");
                         break;
                 }
            }
            else
            {
                navigator.notification.vibrate(2000);
                app.alert("未知标签！类型：" + res["TagType"] + ",识别编码：" + res["TagCode"]);
            }
        };
        function MainLoadTest(key, url, pageParams)
        {
            alert(JSON.stringify(pageParams));
            ///<summary>各个模块进入页面使用此跳转可以进入上次退出时的页面</summary>
            //alert("@liwch@main@" + key + "@@" + url);
            Common.funSetModuleKey(key, function (isFirstEnter) {
                if (isFirstEnter) {
                    Common.funLoad(url, pageParams);
                }
                else {
                    Common.funLoad(url);
                    //原来是funGoBack 但是用意未明，用了funGoBack 会导致主页跳转主页的文问题 暂时屏蔽
                    //                    Common.funGoBack();
                }
            }, function (exError) {
            });
        };
        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnComplete").click(function () {
            _self.funComplete();
        });

        $("#btnUnchecked").tap(function () {
            var isHas = $("#btnUnchecked").hasClass("btn-active");
            if (isHas == false) {
                $("#divChecked").css("display", "none");
                $("#divUnChecked").css("display", "");
            }
        });

        $("#btnChecked").tap(function () {
            var isHas = $("#btnChecked").hasClass("btn-active");
            if (isHas == false) {
                $("#divUnChecked").css("display", "none");
                $("#divChecked").css("display", "");
            }
        });

        $("#btnSwitchWk").click(function () {
            _self.funSwitchWk();
        });

        $("#btnNavigation").click(function () {
            Common.funLoad("navigation.html");
        });

        //app扫描二维码
        $("#btnBarCode").click(function ()
        {
            Common.getBarcode(function (res)
            {
                funCode(res);
            }, function () {
                navigator.notification.vibrate(2000);
                app.alert("app扫描二维码，无法获取数据！");
            });
        });


        app.setting.get("bluetooth_key", "", function (rest) {
            if (rest) {
                setInterval(function () {
                    app.getGlobalVariable("bluetoothIsConnected", function (isCon) {
                        if (isCon == "F") {   //F ==失
                            app.bluetooth.connect(rest);
                        } else if (isCon == "S") { //成功
                            var res = window.bluetoothValue;
                            if (res) {
                                window.bluetoothValue = "";
                                var convertCode = Common.funConvertCode(res);
                                funCode(convertCode);
                            }
                        } else if (isCon == "H") { //正在连接请等待

                        }
                    });
                }, 1000);
            }
        });
    },
    funInitUi: function () {
        var _self = this;
        var wklen = _self.StartWkList.length;
        if (wklen > 1) {
            $("#btnSwitchWk").attr("style", '');
        }

        var crtPwoNum = "";
        app.getGlobalVariable("CurrentPWONum", function (res) {
            if (res) {
                crtPwoNum = res;
            }
        });
        if (crtPwoNum) {
            for (var i = 0; i < wklen; i++) {
                var wk = _self.StartWkList[i];
                var switPwoNum = wk["PWONum"];
                if (crtPwoNum == switPwoNum) {
                    var opDesc = wk["OPDesc"];
                    if (opDesc) {
                        $("#pageTitle").text(opDesc + "-工单列表");
                    }
                    break;
                }
            }
        }
    },

    funComplete: function () {
        var _self = this;
        var wkList = _self.StartWkList;
        var wklen = wkList.length;

        var db = app.database.open(Common.WEIXIUDB);
        var funCmpOpPlan = function () {
            var updSql = "update OPPlan set WorkStatus='3' where ( ";
            for (var k = 0; k < wklen; k++) {
                if ((k + 1) == wklen) {
                    updSql += " PWONum='" + wkList[k]["PWONum"] + "'";
                } else {
                    updSql += " PWONum='" + wkList[k]["PWONum"] + "' or";
                }
            }
            updSql += " )";
            app.database.executeNonQuery(db, updSql, function () {

                var specialtyNum = "";
                app.getGlobalVariable("SpecialtyNum", function (resVal) {
                    if (resVal) {
                        specialtyNum = resVal;
                    }
                });

                if (specialtyNum == "gzw") {
                    Common.funLoad("choice.html");
                } else {
                    Common.funLoad("outCheck.html");
                }

            });
        };

        var selSql = "SELECT DISTINCT a.OPCode,a.OPName FROM OPPlan a inner JOIN OPOrders b on a.PWONum=b.PWONum where ( ";
        for (var i = 0; i < wklen; i++) {
            if ((i + 1) == wklen) {
                selSql += " a.PWONum='" + wkList[i]["PWONum"] + "'";
            } else {
                selSql += " a.PWONum='" + wkList[i]["PWONum"] + "' or";
            }
        }
        selSql += ") and (b.SelfFormIsFinished='' or b.SelfFormIsFinished='0')";

        app.database.executeQuery(db, selSql, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowlen = rows.length;
            if (rowlen > 0) {
                var msg = "有下列作业任务存在未检查完成的工单，是否强制结束？";
                for (var k = 0; k < rowlen; k++) {
                    var row = rows[k];
                    msg += "\n" + row["OPCode"] + row["OPName"];
                }
                app.confirm(msg, function (index) {
                    if (index == 2) {
                        funCmpOpPlan();
                    }
                }, "完成工单确认", "取消,确定");
            } else {
                funCmpOpPlan();
            }
        });
    },

    funInitOrdersData: function (uncheckedContainerId, checkedContainerId) {
        var _self = this;
        var unChkDataList = new Array();
        var chkedDataList = new Array();
        _self.SelList = new Array();
        var pWoNum = "";
        app.getGlobalVariable("CurrentPWONum", function (res) {
            if (res) {
                pWoNum = res;
                var sql = "";
                sql += "SELECT ";
                sql += "  a.*";
                sql += " ,(select count(*) from OrderProcedure where UppLayerProcedureNum='' and WONum=a.WONum) as TotalCount ";
                sql += " ,(select count(*) from OrderProcedure where UppLayerProcedureNum='' and ResultValue!='' AND WONum=a.WONum) as CompleteCount ";
                sql += " ,(select count(*) from OrderProcedure where  ResultValue!='' AND  UppLayerProcedureNum!='' and  WONum=a.WONum  ) as NextFillCount ";
                sql += " ,(SELECT count(*) from AttFile where ObjectID in ( select ProcedureNum FROM OrderProcedure where WONum=a.WONum  ) OR ObjectID=a.WONum ) as AttFileCount ";
                sql += " from OPOrders a ";
                sql += " WHERE a.PWONum='" + pWoNum + "' ";
                sql += " ORDER BY JobPlanNum asc, CompleteCount desc";
                var db = app.database.open(Common.WEIXIUDB);
                app.database.executeQuery(db, sql, function (tx, results) {
                    var rows = Common.funConvertRowsJson(results);
                    var rowslen = rows.length;
                    if (rowslen > 0) {

                        var funCacheData = function (row) {
                            var cacheItem = new Object();
                            cacheItem.WONum = row["WONum"];
                            cacheItem.DeviceNum = row["DeviceNum"];
                            cacheItem.DeviceName = row["DeviceName"];
                            cacheItem.JobPlanNum = row["JobPlanNum"];
                            cacheItem.DeviceTypeName = row["DeviceTypeName"];
                            cacheItem.DeviceLocation = row["DeviceLocation"];
                            cacheItem.WOType = row["WOType"];
                            cacheItem.RecWay = row["RecWay"];
                            cacheItem.OrderDesc = row["OrderDesc"] || "";
                            cacheItem.IsAllowedBatchSubmit = row["IsAllowedBatchSubmit"];
                            cacheItem.MutFormIsFinished = row["MutFormIsFinished"];
                            cacheItem.MutFormFinishTime = row["MutFormFinishTime"];
                            cacheItem.IsOtherCheck = row["IsOtherCheck"];
                            cacheItem.TotalCount = row["TotalCount"];
                            cacheItem.CompleteCount = row["CompleteCount"];
                            cacheItem.NextFillCount = row["NextFillCount"];
                            cacheItem.AttFileCount = row["AttFileCount"];
                            cacheItem.SelfFormUserCode = row["SelfFormUserCode"];
                            cacheItem.RecWay = row["RecWay"];
                            _self.OPOrdersDic.Add(cacheItem.WONum, cacheItem);
                        };

                        var funGetTitleText = function (cacheItem) {
                            var titleText = ' ( ';
                            titleText += cacheItem["CompleteCount"] + '/' + cacheItem["TotalCount"];

                            if (cacheItem["NextFillCount"] != "0") {
                                titleText += ' 异常';
                            }
                            if (cacheItem["AttFileCount"] != "0") {
                                titleText += ' 拍照';
                            }
                            titleText += ' )';
                            return titleText;
                        };

                        var crtUnChkType = "NA"; //当前未选中的类型
                        var crtChkedType = "NA"; //当前选中的类型
                        var uncheckedliHtml = "";
                        var checkedliHtml = "";

                        var unChkOrderCount = 0;
                        var chkedOrderCount = 0;
                        ////构造数组结构
                        for (var i = 0; i < rowslen; i++) {
                            funCacheData(rows[i]);
                            var selfFormIsFinished = rows[i]["SelfFormIsFinished"] || "0";
                            var jobPlanNum = rows[i]["JobPlanNum"];
                            if (selfFormIsFinished == "0") {
                                if (crtUnChkType != jobPlanNum) {
                                    var unChkDataItem = new Object();
                                    unChkDataItem.Items = new Array();
                                    unChkDataItem.WONums = new Array();
                                    unChkDataList.push(unChkDataItem);
                                    crtUnChkType = jobPlanNum;
                                }
                                unChkDataList[unChkDataList.length - 1].Items.push(rows[i]);
                                unChkDataList[unChkDataList.length - 1].WONums.push(rows[i]["WONum"]);
                            } else {
                                if (crtChkedType != jobPlanNum) {
                                    var chkDataItem = new Object();
                                    chkDataItem.Items = new Array();
                                    chkDataItem.WONums = new Array();
                                    chkedDataList.push(chkDataItem);
                                    crtChkedType = jobPlanNum;
                                }
                                chkedDataList[chkedDataList.length - 1].Items.push(rows[i]);
                                chkedDataList[chkedDataList.length - 1].WONums.push(rows[i]["WONum"]);
                            }
                        }


                        var unChkedLen = unChkDataList.length;
                        for (var j = 0; j < unChkedLen; j++) {
                            var unItems = unChkDataList[j].Items;
                            var items = unChkDataList[j].WONums.join(',');
                            uncheckedliHtml += '<ul class="list-view list-equipC" data-theme="c" data-corner="all">';
                            uncheckedliHtml += '<li>';
                            // uncheckedliHtml += '<span id="bntMut' + unItems[0]["JobPlanNum"] + '"  Items=' + items + '  class="beginTb">开始互检</span>';
                            // uncheckedliHtml += '<span id="bntStart' + unItems[0]["JobPlanNum"] + '" Items=' + items + ' style="right:120px;" class="beginTb">开始填报</span>';
                            // uncheckedliHtml += '<div  data-role="BTButton" data-icon=" icon-list-down"  data-iconpos="right" >';
                            // uncheckedliHtml += '<div  id="btnUnChkAll' + unItems[0]["JobPlanNum"] + '" Items=' + items + ' data-role="BTCheck">' + unItems[0]["DeviceTypeName"] + '</div>';
                            uncheckedliHtml += '</div>';
                            uncheckedliHtml += '<div class="collapse-content"><ul class="list-view">';
                            var unItemslen = unItems.length;
                            for (var k = 0; k < unItemslen; k++) {
                                uncheckedliHtml += '<li>';
                                uncheckedliHtml += '<div data-role="BTButton" >';
                                uncheckedliHtml += '<div class="row-box">';
                                uncheckedliHtml += '<div class="span1">';
                                uncheckedliHtml += '<div>' + unItems[k]["WONum"] + unItems[k]["DeviceLocation"] + funGetTitleText(unItems[k]) + '</div>';
                                uncheckedliHtml += '</div>';
                                uncheckedliHtml += '<div id=' + unItems[k]["WONum"] + '   data-inline="true"  data-status="1" align="right" class="btnStyleMini"><span class="">填报</span></div>';
                                uncheckedliHtml += '</div>';
                                uncheckedliHtml += '</div>';
                                uncheckedliHtml += '</li>';
                                unChkOrderCount++;
                                var chkObject = new Object();
                                chkObject.id = "chk" + unItems[k]["WONum"];
                                chkObject.WONum = unItems[k]["WONum"];
                                _self.SelList.push(chkObject);
                            }
                            uncheckedliHtml += '</ul>';
                            uncheckedliHtml += '</div>';
                            uncheckedliHtml += '</li>';
                            uncheckedliHtml += '</ul>';
                        }

                        var chkedLen = chkedDataList.length;
                        for (var l = 0; l < chkedLen; l++) {
                            var chkedItems = chkedDataList[l].Items;
                            var itemsChked = chkedDataList[l].WONums.join(',');
                            checkedliHtml += '<ul class="list-view list-equipC" data-theme="c" data-corner="all">';
                            checkedliHtml += '<li>';
                            // checkedliHtml += '<span id="btnMutualInspection' + chkedItems[0]["JobPlanNum"] + '" Items=' + itemsChked + ' class="beginTb">开始互检</span>';
                            // checkedliHtml += '<div  data-role="BTButton" data-icon=" icon-list-down"  data-iconpos="right" >';
                            // checkedliHtml += '<div  id="btnChkedAll' + chkedItems[0]["JobPlanNum"] + '" Items=' + itemsChked + '>' + chkedItems[0]["DeviceTypeName"] + '</div>';
                            checkedliHtml += '</div>';
                            checkedliHtml += '<div class="collapse-content"><ul class="list-view">';
                            var chkItemslen = chkedItems.length;
                            for (var m = 0; m < chkItemslen; m++) {
                                var mutFormIsFinished = chkedItems[m]["MutFormIsFinished"];
                                var mutFormIsFinishTime = chkedItems[m]["MutFormFinishTime"];
                                var mutualFinishTxt = "【已填报】";
                                if (mutFormIsFinished == "1") {
                                    mutualFinishTxt = "【已完成互检】";
                                } else if (mutFormIsFinished == "0" && mutFormIsFinishTime) {
                                    mutualFinishTxt = "【完成部分互检】";
                                }


                                checkedliHtml += '<li>';
                                checkedliHtml += '<div data-role="BTButton" >';
                                checkedliHtml += '<div class="row-box">';
                                checkedliHtml += '<div class="span1">';
                                if (chkedItems[m]["OrderDesc"].lastIndexOf("他检") > 0) {
                                    checkedliHtml += '<div>' + chkedItems[m]["WONum"] + "_" + chkedItems[m]["OrderDesc"] + mutualFinishTxt + funGetTitleText(chkedItems[m]) + '</div>';
                                } else {
                                    checkedliHtml += '<div>' + chkedItems[m]["WONum"] + "_" + chkedItems[m]["DeviceLocation"] + mutualFinishTxt + funGetTitleText(chkedItems[m]) + '</div>';
                                }
                                checkedliHtml += '</div>';
                                // if (chkedItems[m]["SelfFormUserCode"] == _self.UserCode) {
                                checkedliHtml += '<div id=' + chkedItems[m]["WONum"] + '  data-inline="true"  data-status="1" align="right" class="btnStyleMini"><span class="">修改</span></div>';
                                // } else {
                                //     checkedliHtml += '<div id="inspect_' + chkedItems[m]["WONum"] + '" data-role="BTButton"  data-theme="a" data-status="1" align="right" class="btnSize"><span class="">互检</span></div>';
                                // }
                                checkedliHtml += '</div>';
                                checkedliHtml += '</div>';
                                checkedliHtml += '</li>';
                                chkedOrderCount++;
                                var chkedObject = new Object();
                                chkedObject.id = "chked" + chkedItems[m]["WONum"];
                                chkedObject.WONum = chkedItems[m]["WONum"];
                                _self.SelList.push(chkedObject);
                            }
                            checkedliHtml += '</ul>';
                            checkedliHtml += '</div>';
                            checkedliHtml += '</li>';
                            checkedliHtml += '</ul>';

                        }
                        $("#lblUnChkCount").text("未检查(" + unChkOrderCount + ")");
                        $("#lblChkCount").text("已检查(" + chkedOrderCount + ")");

                        var uncheckedCnt = document.getElementById(uncheckedContainerId);
                        if (uncheckedCnt) {
                            if (uncheckedliHtml) {
                                uncheckedCnt.innerHTML = uncheckedliHtml;
                            } else {
                                uncheckedCnt.innerHTML = "";
                            }
                        }

                        var checkedCnt = document.getElementById(checkedContainerId);
                        if (checkedCnt) {
                            if (checkedliHtml) {
                                checkedCnt.innerHTML = checkedliHtml;
                            } else {
                                checkedCnt.innerHTML = "";
                            }
                        }

                        if (uncheckedliHtml || checkedliHtml) {
                            ui.init();
                            _self.funBindEvent(unChkDataList, chkedDataList);
                        }
                    }
                });
            }
        });
    },

    funBindEvent: function (unChkDataList, chkedDataList) {
        var _self = this;
        var unChkedLen = unChkDataList.length;
        for (var i = 0; i < unChkedLen; i++) {
            var unItems = unChkDataList[i].Items;
            var unItemslen = unItems.length;
            var jobPlanNum = unItems[0]["JobPlanNum"];

            $("#bntStart" + jobPlanNum).click(function () {

                var btnStart = $(this);
                var items = btnStart.attr("Items").split(',');
                var itemlen = items.length;
                var woNumList = new Array();
                for (var j = 0; j < itemlen; j++) {
                    var wONum = items[j];
                    if ($("#chk" + wONum).hasClass('BTCheck_ON')) {
                        woNumList.push(wONum);
                    }
                }

                if (woNumList.length == 1) {
                    EqlistHelper.funSingleOrder(_self.OPOrdersDic.Item(woNumList[0]), false);
                } else if (woNumList.length > 1) {
                    EqlistHelper.funMultiOrder(woNumList, _self.OPOrdersDic, false);
                } else {
                    app.alert("请先选择需要填报的工单");
                }
            });

            $("#btnUnChkAll" + jobPlanNum).click(function () {
                var unChkAll = $(this);
                var isCheckAll = unChkAll.hasClass('BTCheck_ON');
                var items = unChkAll.attr("Items").split(',');
                var itemlen = items.length;
                for (var j = 0; j < itemlen; j++) {
                    if (isCheckAll) {
                        $("#chk" + items[j]).removeClass("BTCheck_OFF").addClass("BTCheck_ON");
                    } else {
                        $("#chk" + items[j]).removeClass("BTCheck_ON").addClass("BTCheck_OFF");
                    }
                }
            });

            //点击填报按钮的绑定事件
            for (var k = 0; k < unItemslen; k++) {
                _self.funBindFillTap(unItems[k]["WONum"]);
            }
        }

        var chkedLen = chkedDataList.length;
        for (var l = 0; l < chkedLen; l++) {
            var chkedItems = chkedDataList[l].Items;
            var chkItemslen = chkedItems.length;
            var _jobPlanNum = chkedItems[0]["JobPlanNum"];
            $("#btnMutualInspection" + _jobPlanNum).click(function () {
                var btnMutualInspection = $(this);
                var items = btnMutualInspection.attr("Items");
                _self.funMutualProcess(items, "chked");
            });

            $("#btnChkedAll" + _jobPlanNum).click(function () {
                var ChkedAll = $(this);
                var isCheckAll = ChkedAll.hasClass('BTCheck_ON');
                var itemsChked = ChkedAll.attr("Items").split(',');
                var itemlen = itemsChked.length;
                for (var j = 0; j < itemlen; j++) {
                    if (isCheckAll) {
                        $("#chked" + itemsChked[j]).removeClass("BTCheck_OFF").addClass("BTCheck_ON");
                    } else {
                        $("#chked" + itemsChked[j]).removeClass("BTCheck_ON").addClass("BTCheck_OFF");
                    }
                }
            });

            //修改按钮事件
            for (var m = 0; m < chkItemslen; m++) {
                _self.funBindFillTap(chkedItems[m]["WONum"]);
            }
        }
    },
    //todo
    funBindFillTap: function (WONum) {
        var _self = this;
        $("#" + WONum).click(function () {
            var chkedCtr = $("#" + WONum);
            var sql = "SELECT RecTime FROM OPOrders WHERE WONum = '" + WONum + "'";
            EqlistHelper.funSqlSelect(sql, function (row) {
                if (row && row[0]["RecTime"]) {
                   EqlistHelper.funSingleOrder(_self.OPOrdersDic.Item(chkedCtr.attr("id")), false);
                } else {
                    app.alert("还未扫描设备", function () {
                        EqlistHelper.funSingleOrder(_self.OPOrdersDic.Item(chkedCtr.attr("id")), false);
                    });
                   
                }
               
            });
           
        });
        $("#inspect_" + WONum).click(function () {
            _self.funMutualProcess(WONum);
        });
    },


    funMutualProcess: function (items) {
        var itemsChked = items.split(',');
        var itemlen = itemsChked.length;
        var woNumList = new Array();
        for (var j = 0; j < itemlen; j++) {
            var wONum = itemsChked[j];
            woNumList.push(wONum);
        }
        if (woNumList.length > 0) {
            var url = "mutualInspection.html";
            var sql = "SELECT * FROM OPOrders WHERE WONum IN ('" + woNumList.join("','") + "')";
            EqlistHelper.funSqlSelect(sql, function (rowsOrder) {
                if (rowsOrder && rowsOrder.length > 0) {
                    var rowsLenOrder = rowsOrder.length;
                    var pageParam = new Object();
                    pageParam.Devices = new Array();
                    for (var orderNum = 0; orderNum < rowsLenOrder; orderNum++) {
                        var objDevice = new Object();
                        objDevice.key = rowsOrder[orderNum]["WONum"];
                        objDevice.value = rowsOrder[orderNum]["DeviceNum"] + rowsOrder[orderNum]["DeviceName"];
                        pageParam.Devices.push(objDevice);
                    }
                    if (pageParam.Devices && pageParam.Devices.length > 1) {
                        pageParam.PageHeader = "工序互检-" + rowsOrder[0]["DeviceTypeName"] + "(" + pageParam.Devices.length + ")";
                    } else {
                        pageParam.PageHeader = "工序互检-" + rowsOrder[0]["DeviceLocation"];
                    }
                    Common.funLoad(url, pageParam);
                }
                else {
                    app.alert("请先,选择要开始互检的工单!");
                }
            });
        } else {
            app.alert("请先,选择要开始互检的工单");
        }
    },

    funSwitchWk: function () {
        var _self = this;
        var wklen = _self.StartWkList.length;
        var switchWks = new Array();
        var crtPwoNum = "";
        app.getGlobalVariable("CurrentPWONum", function (res) {
            if (res) {
                crtPwoNum = res;
            }
        });
        for (var i = 0; i < wklen; i++) {
            var wk = _self.StartWkList[i];
            var switPwoNum = wk["PWONum"];
            if (crtPwoNum != switPwoNum) {
                var item = new Object();
                item.key = switPwoNum;
                item.value = (wk["Mark"] || "") + wk["OPDesc"];
                switchWks.push(item);
            }
        }
        app.wheelSelect.oneSelect(switchWks,
            function (res) {
                var pWoNum = res["key"];
                app.setGlobalVariable("CurrentPWONum", pWoNum);
                _self.funInitUi();
                _self.funInitOrdersData("divUnChecked", "divChecked");
            }, "", "请选择要切换的工单");
    },

    funSetCompMark: function () {
        var _self = this;
        var sqlWhere = "";
        var startWkList = _self.StartWkList;
        var leng = startWkList.length;
        if (leng > 1) {
            for (var k = 0; k < leng; k++) {
                if ((k + 1) == leng) {
                    sqlWhere += " PWONum='" + startWkList[k].PWONum + "' ";
                } else {
                    sqlWhere += " PWONum='" + startWkList[k].PWONum + "' or";
                }
                startWkList[k]["Mark"] = "√";
            }

            if (leng > 0) {
                var sql = "SELECT PWONum FROM OPOrders WHERE SelfFormIsFinished='0' and" + sqlWhere + " group by PWONum";
                var db = app.database.open(Common.WEIXIUDB);
                app.database.executeQuery(db, sql, function (tx, results) {
                    var rows = Common.funConvertRowsJson(results);
                    var rowlen = rows.length;
                    if (rowlen > 0) {
                        for (var i = 0; i < leng; i++) {
                            var pwONum = startWkList[i].PWONum;
                            for (var j = 0; j < rowlen; j++) {
                                if (pwONum == rows[j]["PWONum"]) {
                                    startWkList[i]["Mark"] = "";
                                    break;
                                }
                            }
                        }
                    }
                });
            }
        }
    },

    funScanTags: function (tagCode) {
        var _self = this;
        ///<summary>扫描区域标签</summary>
        ///<param name="tagCode">标签编码</param>
        var pwoNums = new Array();
        var tagCodeArr = new Array();
        tagCodeArr = tagCode.split(";");
        for (var i = 0; i < _self.StartWkList.length; i++) {
            pwoNums.push(_self.StartWkList[i].PWONum);
        }
        _self.CurrentTagCode = tagCode;
        //已扫描的IsScan为1，未扫描的为0 或者null
        var sql = "UPDATE OPAreasTags SET IsScan='1' WHERE PWONum in ('" + pwoNums.join("','") + "') AND TagCode in ('" + tagCodeArr.join("','") + "') ";
        EqlistHelper.funSqlSave(sql, function () {
            var sqlSelect = "SELECT TagCode,AreaID,AreaName,CoordX,CoordY,IsScan FROM OPPlan P INNER JOIN OPAreasTags A ON P.PWONum=A.PWONum WHERE P.PWONum in ('" + pwoNums.join("','") + "') AND A.TagCode in ('" + tagCodeArr.join("','") + "') GROUP BY TagCode,AreaID,AreaName,CoordX,CoordY,IsScan ";
            EqlistHelper.funSqlSelect(sqlSelect, _self.funSetTag, true, _self);
        });

    },

    funSetTag: function (OPAreasTags, isShowMessage) {
        var _self = this;
        ///<summary>描绘区域标签</summary>
        ///<param name="OPAreasTags">计划区域标签</param>
        ///<param name="isShowMessage">是否显示提示信息</param>
        ///<param name="isNoticeArea">是否提示区域信息</param>
        if (isShowMessage && (!OPAreasTags || OPAreasTags.length <= 0)) {
            navigator.notification.vibrate(2000);
            navigator.notification.beep(3);
            app.alert("你已超出区域！", null, "温馨提示", "OK");
            return;
        }
        //提示信息
        if (isShowMessage) {//如果不是初始化时 会进行提示信息 (扫描时进入此方法)
            var pwoNums = new Array();
            for (var i = 0; i < _self.StartWkList.length; i++) {
                pwoNums.push(_self.StartWkList[i].PWONum);
            }
            var sql = "SELECT PO.* FROM OPAreasTags A INNER JOIN OPOrders PO ON A.PWONum=PO.PWONum AND A.AreaID=PO.DeviceOfAreaNum WHERE A.PWONum IN('" + pwoNums.join("','") + "')  AND A.TagCode='" + OPAreasTags[0].TagCode + "' AND (PO.SelfFormIsFinished='0' or PO.SelfFormIsFinished is NULL)  ORDER BY PO.DeviceOfAreaNum";
            EqlistHelper.funSqlSelect(sql, _self.funShowGoingArea, OPAreasTags, _self);
        }
    },

    funShowGoingArea: function (OPOrders, OPAreasTags) {
        var _self = this;
        ///<summary>提示进入区域</summary>
        ///<param name="OPOrders">工单集合</param>
        ///<param name="OPAreasTags">区域数组</param>
        if (!OPAreasTags || OPAreasTags.length <= 0) {
            return;
        }
        var messageList = new Array();
        for (var j = 0; j < OPAreasTags.length; j++) {
            var deviceOfAreaString = "【" + OPAreasTags[j].AreaName + "】区域计划检修设备如下：\r\n";
            var oporder = new Array();
            for (var i = 0; i < OPOrders.length; i++) {
                oporder.push(">>" + OPOrders[i].WONum + OPOrders[i].DeviceLocation);
            }
            messageList.push(deviceOfAreaString + oporder.join("\r\n"));
        }
        var message = messageList.join("\r\n");
        app.confirm("你当前所在作业区域：\n" + message, function (index) {
            var date = Common.funGetNowDate();
            var sql = "INSERT INTO TagRecords(PWONum,TagCode,ScanTime,TagType,EnterOrExit) ";
            var values = "";
            var planlen = _self.StartWkList.length;
            //可能存在多个父工单对应一个区域
            if (OPAreasTags && OPAreasTags.length > 0) {
                for (var i = 0; i < OPAreasTags.length; i++) {
                    var obj = OPAreasTags[i];
                    for (var j = 0; j < planlen; j++) {
                        var planItem = _self.StartWkList[j];
                        values += " select '" + planItem.PWONum + "','" + obj.TagCode + "','" + date + "','" + (_self["TagType"] || "P") + "','" + (index == 1 ? 1 : 0) + "' union all ";
                    }
                }
            }
            if (values.length > 0) {
                sql = sql + values.substring(0, values.length - 10);
                EqlistHelper.funSqlSave(sql, null);
            }
        }, "提示", "进入,退出");
    },

    funGoOpPlan: function (tagCode, type) {
        var _self = this;
        ///<summary>扫描设备/位置工单二维码标签</summary>
        ///<param name="tagCode">标签编码</param>
        ///<param name="type">标签类型</param>
        var pwoNums = new Array();
        for (var i = 0; i < _self.StartWkList.length; i++) {
            pwoNums.push(_self.StartWkList[i]["PWONum"]);
        }
        var tagCodeArr = new Array();
        tagCodeArr = tagCode.split(";");
        var tagWhereCondition = new Array();
        for (var tagi = 0; tagi < tagCodeArr.length; tagi++) {
            tagWhereCondition.push(" LocationCode like '%" + tagCodeArr[tagi] + "%' ");
        }
        var sqlOPOrders = "SELECT * FROM  OPOrders  WHERE WONum IN('" + pwoNums.join("','") + "')  AND ( " + tagWhereCondition.join(" OR ") + " ) ";
        EqlistHelper.funSqlSelect(sqlOPOrders, function (OPOrdersList) {//查询标签对应本次作业内的设备
            if (!OPOrdersList || OPOrdersList.length <= 0) {
                app.alert("本次作业任务无此设备！");
                return;
            }

            var len = OPOrdersList.length;
            var Orders0 = OPOrdersList[0];
            var value = "";
            var sql = "INSERT INTO TagRecords(PWONum,TagCode,ScanTime,TagType,EnterOrExit) ";

            var nowDate = Common.funGetNowDate();
            for (var i = 0; i < tagCodeArr.length; i++) {
                for (var j = 0; j < OPOrdersList.length; j++) {
                    value += " select '" + OPOrdersList[j].PWONum + "','" + tagCodeArr[i] + "','" + nowDate + "','" + type + "','1'  union all ";
                }
            }

            // 记录子工单的扫描时间
            for (var i = 0; i < OPOrdersList.length; i++) {
                var sqlText = "";
                sqlText = "UPDATE OPOrders SET ActStart=ifnull(nullif(ActStart,''),'" + nowDate + "'), RecWay='s' , RecTime='" + nowDate + "' WHERE  WONum='" + OPOrdersList[i].WONum + "' ";
                EqlistHelper.funSqlSave(sqlText);
            }

            if (value.length > 10) {
                sql = sql + value.substring(0, value.length - 10);
            }
            EqlistHelper.funSqlSave(sql, function () {//保存扫描记录
                if (len == 1) {
                    EqlistHelper.funSingleOrder(Orders0, true);
                }
                else if (len > 1) {
                    var url = "scansEqlist.html";
                    var pageParam = new Object();
                    pageParam.CurrentTagCode = tagCode;
                    Common.funLoad(url, pageParam);
                }
            });
        });
    },
    funBackRefresh: function () {
        app.progress.start("提示", "刷新数据中...");
        var _self = this;
        _self.funSetCompMark();
        _self.funInitOrdersData("divUnChecked", "divChecked");
        app.progress.stop();
    }

};



