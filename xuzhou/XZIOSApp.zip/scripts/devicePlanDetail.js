var PlanDetail = function () {
    this.PageParam = null;
    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);
};
PlanDetail.prototype = {
    funInitUiData: function () {
        var _self = this;
        var pageParam = _self.PageParam;
        var requestParam = new Object();
        requestParam.AuthBlock = new Object();
        requestParam.CallMethod = "Misc_FetchPlanDetail";
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                requestParam.AuthBlock.UserCode = res;
            }
        });
        app.getGlobalVariable("Password", function (res) {
            if (res) {
                requestParam.AuthBlock.Password = res;
            }
        });
        requestParam.PayLoad = new Object();
        app.getPageParams(function (result) {
            if (result) {
                requestParam.PayLoad.WONum = result["WONum"];
            }
        });
        app.progress.start("提示", "数据正在处理...");
        app.ajax({
                    "url": MobileConfig.CmDownLoad,
                        "data": requestParam,
                        "contentType": "application/json",
                        "method": "POST",
                        "async": true,
                        "success": function (res) {
                        var plantDetailData = JSON.parse(res.returnValue);
                        if (plantDetailData.ResStatus == true) {
                            app.progress.stop();
                            var plantDetail = plantDetailData.PayLoad;
                            $('#divBase>div:nth-child(1)>div:last-child').html(plantDetail.FormStatusName);
                            $('#divBase>div:nth-child(2)>div:last-child').html(plantDetail.WOCode);
                            $('#divBase>div:nth-child(3)>div:last-child').html(plantDetail.WOName);
                            $('#divBase>div:nth-child(4)>div:last-child').html(plantDetail.LineName);
                            $('#divBase>div:nth-child(5)>div:last-child').html(plantDetail.MaintenanceCycleName);
                            $('#divBase>div:nth-child(6)>div:last-child').html(plantDetail.JobTypeName);
                            $('#divBase>div:nth-child(7)>div:last-child').html(plantDetail.LocationCode + "—" + plantDetail.LocationName);
                            $('#divBase>div:nth-child(8)>div:last-child').html(plantDetail.EquipmentCode + "—" + plantDetail.EquipmentName);

                            $('#divBase>div:nth-child(9)>div:last-child').html(plantDetail.SpecialtyName);
                            $('#divBase>div:nth-child(10)>div:last-child').html(plantDetail.SubSystemName);
                            $('#divBase>div:nth-child(11)>div:last-child').html(plantDetail.JobHeadUserName);
                            $('#divBase>div:nth-child(12)>div:last-child').html(plantDetail.JobHeadUserTel);
                            $('#divBase>div:nth-child(13)>div:last-child').html(plantDetail.PlannedBeginTime);
                            $('#divBase>div:nth-child(14)>div:last-child').html(plantDetail.PlannedEndTime);
                            $('#divBase>div:nth-child(15)>div:last-child').html(plantDetail.ActualBeginTime);
                            $('#divBase>div:nth-child(16)>div:last-child').html(plantDetail.ActualEndTime);
                        } else {
                            app.alert(plantDetailData.ResMsg, function () {
                        app.progress.stop();
                    });
                }

            }
        });
    },

    funBackRefresh : function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var pageName = retParam["pageName"];
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funInitUiData();
        }, 100);
    }
};
