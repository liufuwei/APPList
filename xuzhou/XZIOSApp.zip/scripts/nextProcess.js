﻿var NextProcess = function () {
    this.PageParam = null;

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });

    })(this);

    this.ProcessDic = new Dictionary();

    this.PhotoBox = null;

    this.VideoBox = null;

    this.AudioBox = null;

    this.DescCtrId = ""; //描述控件ID    
};

NextProcess.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);

        $("#btnSaveProcess").click(function () {
            _self.funSaveProcess();
        });

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnFaultReport").click(function () {
            var faultObj = new Object();
            faultObj.RelationWONum = _self.PageParam["WONum"];
            //关联工单号
            faultObj.RelationProcedureNum = _self.PageParam["UppLayerProcedureNum"]; //关联工序号--拿到上层工序编号
            faultObj.HasRelationAttachment = "1"; //是否有关联过来的附件(有为1，其它情况为无)
            faultObj.ImgInfos = _self.PhotoBox.getImgInfo();
            faultObj.VideoInfos = _self.VideoBox.getVideoInfo();
            faultObj.AudioInfos = _self.AudioBox.getAudioInfo();
            var desCtrId = _self.DescCtrId;
            if (desCtrId) {
                faultObj.StationFill = $("#" + desCtrId).val();
            }
            Common.funLoad("faultReport.html", faultObj);
        });


        $("#btnAddNote").click(function () {
            var wONum = _self.PageParam["WONum"];
            Common.funLoad("orderNote.html", {"WONum": wONum});
        });

    },
    funInitUiData: function () {
        var _self = this;
        var sqlParam = new Object();
        sqlParam.WONum = _self.PageParam["WONum"];
        SqlHelper.funGetData("OPOrders", function (rowsOrder) {
            var rowsOrderlen = rowsOrder.length;
            if (rowsOrderlen > 0) {
                $("#pageTitle").text(rowsOrder[0]["DeviceLocation"]);
            }
        }, sqlParam);
    },

    funInitPhotoBox: function (containerId) {
        var _self = this;
        if (_self.PhotoBox == null) {
            var param = new Object();
            param.ObjectType = "UDWOTASK";
            param.ObjectID = _self.PageParam["UppLayerProcedureNum"];
            param.ContainerId = containerId;
            _self.PhotoBox = new PhotoBox(param);
        }
        _self.PhotoBox.initBox(_self.PhotoBox);
    },

    funInitVideoBox: function (containerId) {
        var _self = this;
        if (_self.VideoBox == null) {
            var param = new Object();
            param.ObjectType = "UDWOTASK";
            param.ObjectID = _self.PageParam["UppLayerProcedureNum"];
            param.ContainerId = containerId;
            _self.VideoBox = new VideoBox(param);
        }
        _self.VideoBox.initBox(_self.VideoBox);
    },

    funInitAudioBox: function (containerId) {
        var _self = this;
        if (_self.AudioBox == null) {
            var param = new Object();
            param.ObjectType = "UDWOTASK";
            param.ObjectID = _self.PageParam["UppLayerProcedureNum"];
            param.ContainerId = containerId;
            _self.AudioBox = new AudioBox(param);
        }
        _self.AudioBox.initBox(_self.AudioBox);
    },

    funInitNextProcessData: function (containerId) {
        var _self = this;
        var sqlParam = new Object();
        sqlParam.UppLayerProcedureNum = _self.PageParam["UppLayerProcedureNum"];
        sqlParam.OrderParam = "ProcedureGroup asc,SortNum asc";
        SqlHelper.funGetData("OrderProcedure", function (rows) {
            var rowslen = rows.length;
            if (rowslen > 0) {
                var funCacheData = function (row) {
                    var itemObj = new Object();
                    itemObj.ProcedureNum = row["ProcedureNum"];
                    itemObj.FormWay = row["FormWay"];
                    itemObj.OptionsValue = row["OptionsValue"];
                    itemObj.MaxValue = row["MaxValue"];
                    itemObj.MinValue = row["MinValue"];
                    itemObj.HasChildProcedure = row["HasChildProcedure"];
                    itemObj.ResultValue = row["ResultValue"];
                    itemObj.PWONum = row["PWONum"];
                    itemObj.PointName = row["PointName"];
                    var isPhotoGraph = row["IsPhotoGraph"];
                    itemObj.IsPhotoGraph = isPhotoGraph;
                    if (row["FormWay"].toLowerCase() != "b" || row["FormWay"].toLowerCase() != "c") {
                        if (isPhotoGraph == "1") {
                            itemObj.FormWay = "D";
                            row["FormWay"] = "D";
                        }
                    }
                    _self.ProcessDic.Add(itemObj.ProcedureNum, itemObj);
                };

                var liHtml = "";
                for (var i = 0; i < rowslen; i++) {
                    var item = rows[i];
                    funCacheData(item);
                    var formWay = item["FormWay"].toLowerCase();
                    var procedureNum = item["ProcedureNum"];
                    var resultValue = item["ResultValue"] || "";
                    var pointName = item["PointName"];
                    var techStandard = item["TechStandard"] || "";

                    liHtml += '<ul class="list-view " data-corner="all">';
                    liHtml += '<li>';
                    liHtml += '<div id="Item' + procedureNum + '" data-role="BTButton" mousedown="false" mouseup="false">';
                    liHtml += '<div class="row-box">';
                    liHtml += '<div class="span1 label">';

                    liHtml += ' <div class="procDesc"  handler="TechStandardMsg"  TechStandard="' + techStandard + '" >';


                    liHtml += item["ProcedureDesc"];
                    if (pointName) {
                        liHtml += '[单位:' + pointName + ']';
                    }
                    switch (formWay) {
                        case "d": {
                            liHtml += '<img src="bingoTouch/css/images/camera.png"/> ';
                        }
                            break;
                        case "e": {
                            liHtml += '<img src="bingoTouch/css/images/camera.png"/> ';
                        }
                            break;
                        case "f": {
                            liHtml += '<img src="bingoTouch/css/images/camera.png"/> ';
                        }
                            break;
                    }

                    liHtml += '</div>';
                    liHtml += '</div>';

                    liHtml += '<div class="sinPromh">';
                    switch (formWay) {
                        case "b": {
                            if (resultValue) {
                                liHtml += '<input id=' + procedureNum + ' value=' + resultValue + '  type="number" class="singInput" />';
                            } else {
                                liHtml += '<input id=' + procedureNum + '  type="number" class="singInput" />';
                            }
                        }
                            break;
                        case "c": {
                            if (_self.DescCtrId == "") {
                                _self.DescCtrId = procedureNum;
                            }
                            if (resultValue) {
                                liHtml += '<input id=' + procedureNum + '  value=' + resultValue + ' type="text" class="singInput" />';
                            } else {
                                liHtml += '<input id=' + procedureNum + '  type="text" class="singInput" />';
                            }
                        }
                            break;
                        default: {
                            var optionsValue = item["OptionsValue"].split(';');
                            var optionslen = optionsValue.length;
                            for (var l = 0; l < optionslen; l++) {
                                var optionVal = optionsValue[l];
                                if (optionVal == resultValue) {
                                    liHtml += '<div id=' + procedureNum + "_" + l + '  name=' + procedureNum + ' data-role="BTRadio" value="' + optionsValue[l] + '" class="BTCheck_ON" >' + optionsValue[l] + '</div>';
                                } else {
                                    liHtml += '<div id=' + procedureNum + "_" + l + '  name=' + procedureNum + ' data-role="BTRadio" value="' + optionsValue[l] + '" >' + optionsValue[l] + '</div>';
                                }
                            }
                        }
                            break;
                    }
                    liHtml += '<div id="errorMsg' + procedureNum + '" class="inputEro"></div>';
                    liHtml += '</div>';
                    liHtml += '</div>';
                    liHtml += '</li>';
                    liHtml += '</ul>';
                }

                if (liHtml) {
                    var cnt = document.getElementById(containerId);
                    if (cnt) {
                        cnt.innerHTML = liHtml;
                        ui.init();
                        _self.funBindEvent();
                    }
                }
            }
        }, sqlParam);
    },

    funBindEvent: function () {
        var _self = this;
        var processDic = _self.ProcessDic;
        var arrVals = processDic.Values();
        var valsLen = arrVals.length;
        for (var i = 0; i < valsLen; i++) {
            var item = arrVals[i];
            var ctrId = item["ProcedureNum"];
            var formWay = item["FormWay"].toLowerCase();
            if (formWay == "b" || formWay == "c") {
                $("#" + ctrId).on("blur", function () {
                    var ctr = $(this);
                    var procedureNum = ctr.attr("id");
                    var resultValue = ctr.val();
                    if (resultValue) {
                        _self.funTextItem(procedureNum, resultValue);
                    } else {
                        item.ResultValue = "";
                    }
                });
            } else {
                var optionslen = item["OptionsValue"].split(";").length;
                for (var j = 0; j < optionslen; j++) {
                    $("#" + ctrId + "_" + j).click(function () {
                        var ctr = $(this);
                        var cntId = ctr.attr("id");

                        var numAndposition = cntId.split("_");
                        var procedureNum = numAndposition[0];
                        var positionNum = numAndposition[1];
                        var resultValue = ctr.btcheck("val").value;

                        var curPageParam = _self.PageParam;
                        curPageParam["positionId"] = cntId;
                        Common.funUpdateCurrentPageparam(curPageParam);

                        _self.funRadioItem(procedureNum, resultValue, positionNum);
                    });

                    $("#" + ctrId + "_" + j).longTap(function () {
                        var ctr = $(this);
                        app.confirm("确认清除所选工序的结果?", function (index) {
                            if (index == 2) {
                                var numAndposition = ctr.attr("id").split("_");
                                var procedureNum = numAndposition[0];
                                _self.funSingleRowSave(procedureNum, "");
                                ctr.removeClass('BTCheck_ON');
                                var procItem = _self.ProcessDic.Item(procedureNum);
                                procItem.ResultValue = "";
                            }
                        }, "清除确认提示", "取消,确定");
                    });
                }
            }
        }

        $("#divProcesslist div[handler='TechStandardMsg']").click(function () {
            var desc = $(this).attr("TechStandard") || "暂无工序技术标准描述";
            app.alert(desc, function () {
            }, "工序技术标准", "关闭");
        });
    },

    funTextItem: function (procedureNum, resultValue) {
        var _self = this;
        var item = _self.ProcessDic.Item(procedureNum);
        var formWay = item["FormWay"].toLowerCase();
        var isSave = true;
        //B: 测量值，C: 文本框
        if (formWay == "b") {
            $("#errorMsg" + procedureNum).text("");
            if (isNaN(resultValue)) {
                $("#errorMsg" + procedureNum).text("数值格式填写有误");
                isSave = false;
            } else {
                var minValue = item["MinValue"] - 0;
                var maxValue = item["MaxValue"] - 0;
                if (!(minValue == 0 && maxValue == 0)) {
                    var resultVal = resultValue - 0;
                    if (resultVal < minValue || resultVal > maxValue) {
                        $("#errorMsg" + procedureNum).text("填入数据范围有误,已超出最小值与最大值的范围[" + minValue + "至" + maxValue + "]");
                    }
                }
            }
        }
        if (isSave) {
            item.ResultValue = resultValue;
            _self.funSingleRowSave(procedureNum, resultValue);
        } else {
            item.ResultValue = "";
        }
    },

    funRadioItem: function (procedureNum, resultValue, positionNum) {
        var _self = this;
        _self.funSingleRowSave(procedureNum, resultValue, function () {
            var item = _self.ProcessDic.Item(procedureNum);
            var optionsValue = item["OptionsValue"];
            var optionslen = optionsValue.split(";").length;
            var hasChildProcedure = item["HasChildProcedure"];
            var pwoNum = item["PWONum"];

            var url = "nextProcess.html";
            var pageParam = new Object();
            pageParam["UppLayerProcedureNum"] = procedureNum;
            pageParam["ResultValue"] = resultValue;
            pageParam["WONum"] = _self.PageParam["WONum"];
            pageParam["PWONum"] = pwoNum;

            if ((positionNum - 0 + 1) == optionslen && hasChildProcedure == "1") { //说明是最后个按钮
                pageParam["UppLayerProcedureNum"] = procedureNum;
                Common.funLoad(url, pageParam);

            } else {
                var formWay = item["FormWay"].toLowerCase();
                switch (formWay) {
                    case "a":
                        item.ResultValue = resultValue;
                        _self.funSingleRowSave(procedureNum, resultValue);
                        break;
                    case "d": {
                        if ((positionNum - 0) == 0) {
                            url = "processphoto.html";
                            Common.funLoad(url, pageParam);
                        } else {
                            item.ResultValue = resultValue;
                            _self.funSingleRowSave(procedureNum, resultValue);
                        }
                    }
                        break;
                    case "f": {
                        if ((positionNum - 0) == 0) {
                            url = "processpVideo.html";
                            Common.funLoad(url, pageParam);
                        } else {
                            item.ResultValue = resultValue;
                            _self.funSingleRowSave(procedureNum, resultValue);
                        }
                    }
                    default:
                        app.alert("未知类型");
                        break;
                }
            }
        });
    },

    funSingleRowSave: function (procedureNum, resultValue, successfun) {
        var sqlParam = new Object();
        if (resultValue) {
            app.getGlobalVariable("UserName", function (res) {
                if (res) {
                    sqlParam.SelfFormUserName = res;
                }
            });
            app.getGlobalVariable("UserCode", function (res) {
                if (res) {
                    sqlParam.SelfFormUserCode = res;
                }
            });
        } else {
            sqlParam.SelfFormUserName = "";
            sqlParam.SelfFormUserCode = "";
        }

        sqlParam.ResultValue = resultValue;
        sqlParam.SelfFormTime = Common.funGetNowDate();
        sqlParam.WhereParam = new Object();
        sqlParam.WhereParam.ProcedureNum = procedureNum;
        SqlHelper.funUpdateData("OrderProcedure", [sqlParam], successfun);
    },

    funSaveProcess: function () {
        var _self = this;
        app.progress.start("提示", "正在处理中...");
        setTimeout(function () {
            var isAllFill = true; //是否允许提交
            var processDic = _self.ProcessDic;
            var arrVals = processDic.Values();
            var valsLen = arrVals.length;
            for (var i = 0; i < valsLen; i++) {
                var item = arrVals[i];
                if (item["ResultValue"] == "") { //说明还没填写
                    isAllFill = false;
                    $("#Item" + item["ProcedureNum"]).addClass("unfih");
                } else {
                    $("#Item" + item["ProcedureNum"]).removeClass("unfih");
                }
            }

            app.progress.stop();
            if (isAllFill) {
                var procedureNum = _self.PageParam["UppLayerProcedureNum"];
                var resultValue = _self.PageParam["ResultValue"];
                var userName = "";
                var userCode = "";
                var newDate = Common.funGetNowDate();
                var wONum = _self.PageParam["WONum"];
                app.getGlobalVariable("UserName", function (res) {
                    if (res) {
                        userName = res;
                    }
                });
                app.getGlobalVariable("UserCode", function (res) {
                    if (res) {
                        userCode = res;
                    }
                });
                var sqlUpdProcess = "update OrderProcedure set ResultValue='" + resultValue + "' ,SelfFormTime='" + newDate + "' ,SelfFormUserName ='" + userName + "' ,SelfFormUserCode='" + userCode + "' where ProcedureNum='" + procedureNum + "'";
                var sqlUpdOpOrders = "UPDATE OPOrders set IsOtherCheck='1' where WONum='" + wONum + "'";
                var db = app.database.open(Common.WEIXIUDB);
                app.database.executeNonQuery(db, [sqlUpdProcess, sqlUpdOpOrders], function () {
                    Common.funGoBack();
                });
            } else {
                app.alert("存在工序未填报结果，请手工输入完成后再提交");
            }
        }, 1500);
    },
    funBackRefresh : function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var pageName = retParam["pageName"];
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funInitUiData();
            _self.funInitPhotoBox("pboxList");
            _self.funInitVideoBox("vboxList");
            _self.funInitAudioBox("aboxList");

            _self.funInitNextProcessData("divProcesslist");
        },100);
    }
};

