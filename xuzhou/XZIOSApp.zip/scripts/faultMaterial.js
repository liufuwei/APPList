﻿//工具类没有页面
var FaultMaterial = function (param) {
    this.Param = param;

    this.OPMaterialList = new Array();
};

FaultMaterial.prototype = {
    funInitMaterialData: function (containerId) {
        var _self = this;
        var woNum = _self.Param["WONum"] || "";
        var pWoNum = _self.Param["PWONum"] || "";
        var tempFaultWoNum = _self.Param["TempFaultWoNum"];
        if (tempFaultWoNum) {
            app.getGlobalVariable(tempFaultWoNum, function (res) {
                if (res) {
                    var tempMaterialList = JSON.parse(res);
                    var templen = tempMaterialList.length;
                    for (var i = 0; i < templen; i++) {
                        var item = tempMaterialList[i];
                        var tempMaterItem = new Object();
                        tempMaterItem.PWONum = pWoNum;
                        tempMaterItem.WONum = woNum;
                        tempMaterItem.OPMateriaID = "";
                        tempMaterItem.OPMaterialNum = item.OPMaterialNum;
                        tempMaterItem.OPMaterialName = item.OPMaterialName;
                        tempMaterItem.OPMaterialUnit = item.OPMaterialUnit;
                        tempMaterItem.OPMaterialCount = item.OPMaterialCount;
                        tempMaterItem.BeforePlanRegTime = "";
                        tempMaterItem.BeforePlanRegCount = "";
                        tempMaterItem.FinishChkTime = item.FinishChkTime;
                        tempMaterItem.FinishChkCount = item.FinishChkCount;
                        tempMaterItem.IsOut = item.IsOut;
                        _self.OPMaterialList.push(tempMaterItem);
                    }
                    tempMaterialList = null;
                }
            });
        }
        if (woNum) {
            var sql = "SELECT * from OPMaterial where WONum='" + woNum + "'";
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeQuery(db, sql, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowlen = rows.length;
                if (rowlen > 0) {
                    for (var i = 0; i < rowlen; i++) {
                        _self.OPMaterialList.push(rows[i]);
                    }
                }
                _self.funDrawList(containerId);
            });
        } else {
            _self.funDrawList(containerId);
        }
    },

    funDrawList: function (containerId) {
        var _self = this;
        var liHtml = "";
        var materialList = _self.OPMaterialList;
        var materiallen = materialList.length;
        for (var k = 0; k < materiallen; k++) {
            var row = materialList[k];
            var oPMaterialNum = row["OPMaterialNum"];
            var materialName = row["OPMaterialName"];
            var materialUnit = row["OPMaterialUnit"] || "";
            var materCount = (row["FinishChkCount"] || "0") - 0;
            if (materCount == 0) {
                materCount = row["OPMaterialCount"] || "0";
            }
            var cntId = "txtMater" + oPMaterialNum;
            liHtml += '<li>';
            liHtml += '<div class="row-fluid">';
            if (materialUnit) {
                liHtml += '<div class="span6">' + materialName + '[' + materialUnit + ']</div>';
            } else {
                liHtml += '<div class="span6">' + materialName + '</div>';
            }
            liHtml += '<div class="span3" align="center"><input id="' + cntId + '" type="number" value="' + materCount + '" class="toolNum"/></div>';
            liHtml += '<div class="span3" align="center"><a CntId="' + cntId + '" id="btnAddMater' + oPMaterialNum + '" href="javascript:void(0)" class="addN"></a><a  CntId="' + cntId + '" id="btnMinusMater' + oPMaterialNum + '"  href="javascript:void(0)" class="minusN"></a></div>';
            liHtml += '</div>';
            liHtml += '</li>';
        }

        var cnt = document.getElementById(containerId);
        if (cnt) {
            if (liHtml) {
                cnt.innerHTML = liHtml;
                _self.funBindMaterEvent(_self);
            } else {
                liHtml = ' <li  >';
                liHtml += '<div class="row-fluid">';
                liHtml += '<div align="center">***暂无数据***</div>';
                liHtml += '</div>';
                liHtml += '</li>';
                cnt.innerHTML = liHtml;
            }
        }
    },

    funUpCount: function (cntId) {
        if (cntId) {
            var cnt = $("#" + cntId);
            var count = Number(cnt.val()) || 0;
            count += 1;
            if (count < 0) {
                count = 0;
            }
            cnt.val(count);
            cnt.attr("value", count);
        }
    },

    funDownCount: function (cntId) {
        if (cntId) {
            var cnt = $("#" + cntId);
            var count = Number(cnt.val()) || 0;
            count -= 1;
            if (count < 0) {
                count = 0;
            }
            cnt.val(count);
            cnt.attr("value", count);
        }
    },

    funBindMaterEvent: function () {
        var _self = this;
        var materialList = _self.OPMaterialList;
        var materiallen = materialList.length;
        for (var i = 0; i < materiallen; i++) {
            var item = materialList[i];
            var ctrId = item["OPMaterialNum"];
            $("#btnAddMater" + ctrId).click(function () {
                var ctr = $(this);
                var cntId = ctr.attr("CntId");
                _self.funUpCount(cntId);
            });

            $("#btnMinusMater" + ctrId).click(function () {
                var ctr = $(this);
                var cntId = ctr.attr("CntId");
                _self.funDownCount(cntId);
            });
        }
    },

    funGetMaterialData: function () {
        var _self = this;
        var materialList = _self.OPMaterialList;
        var materiallen = materialList.length;
        for (var i = 0; i < materiallen; i++) {
            var item = materialList[i];
            var oPMaterialNum = item["OPMaterialNum"];
            var finishChkCount = Number($("#txtMater" + oPMaterialNum).val()) || "0";
            item.FinishChkCount = finishChkCount;
        }
        return materialList;
    }

};