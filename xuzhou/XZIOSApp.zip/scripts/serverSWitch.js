﻿ServerSWitch = function () {
    this.LmisUrls = [
        "http://10.50.22.26:8003",
        "http://10.50.22.27:8003"
    ];
};

ServerSWitch.prototype = {

    funInitEvent: function () {
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);

        $("#imback").click(function () {
            app.back();
        });
    },
    funInitServerList: function (containerId) {
        var lihtml = "";
        var _self = this;
        var lmisUrlList = _self.LmisUrls;
        var limsUrlLen = lmisUrlList.length;
        var defLmisUrl = localStorage.getItem("LmisUrl") || _homeUrl;
        for (var i = 0; i < limsUrlLen; i++) {
            var urlItem = lmisUrlList[i];
            lihtml += '<li>';
            lihtml += '<div data-role="BTButton" data-status="1">';
            lihtml += '<span class="btn-text">';
            lihtml += '<div class="row-box">';
            lihtml += '<div class="span1">';
            if (defLmisUrl && urlItem.indexOf(defLmisUrl) > -1) {
                lihtml += '<div id="liItem' + i + '"  itemIndex=' + i + '  class="BTCheck_ON"  data-role="BTRadio" name="LmisUrl" data-inline="false">' + urlItem + '</div>';
            } else {
                lihtml += '<div id="liItem' + i + '"  itemIndex=' + i + '  data-role="BTRadio" name="LmisUrl" data-inline="false">' + urlItem + '</div>';
            }
            lihtml += '</div>';
            lihtml += '</div>';
            lihtml += '</span>';
            lihtml += '</div>';
            lihtml += ' </li>';
        }

        if (lihtml) {
            var cnt = document.getElementById(containerId);
            if (cnt) {
                cnt.innerHTML = lihtml;
                ui.init();
                _self.funBindEvent();
            }
        }
    },

    funBindEvent: function () {
        var lmisUrlList = this.LmisUrls;
        var limsUrlLen = lmisUrlList.length;
        for (var i = 0; i < limsUrlLen; i++) {
            $("#liItem" + i).click(function () {
                var cnt = $(this);
                var itemIndex = cnt.attr("itemIndex");
                var lmisUrl = lmisUrlList[itemIndex];
                localStorage.setItem("LmisUrl", lmisUrl);
            });
        }
    }
};