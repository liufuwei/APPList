﻿var MutualInspection = function () {
    this.PageParam = null;

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);

    this.SelectProcessDic = new Dictionary(); //选择工序
    this.InputProcessDic = new Dictionary();//文本框工序

    this.MutualInsPersons = new Array();
    this.MutualInsPersons.push({"key": "NA", "value": "--请选择--"});
};

MutualInspection.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);


        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#tabSelect").click(function () {
            var isHas = $("#tabSelect").hasClass("btn-active");
            if (isHas == false) {
                $("#divInput").css("display", "none");
                $("#divSelect").css("display", "");
            }
        });

        $("#tabInput").click(function () {
            var isHas = $("#tabInput").hasClass("btn-active");
            if (isHas == false) {
                $("#divSelect").css("display", "none");
                $("#divInput").css("display", "");
            }
        });


        $("#btnAddNote").click(function () {
            var devices = _self.PageParam["Devices"];
            var wONum = devices[0].key;
            Common.funLoad("orderNote.html", {"WONum": wONum});
        });

        $("#btnSaveProcess").click(function () {
            _self.funSaveProcess();
        });
        $("#btnInputPerson").click(function () {
            $('#dlO').dialog("open");
        });

        $("#mutualPersonsSelector").click(function () {
            _self.funSwitchMutualPerson();
        });

        $('#dlO').dialog({
            width: "80%",
            autoOpen: false,
            buttons: {
                '取消': function () {
                    this.close();
                },
                '登录': function () {
                    _self.funLogin($("#txtUserCode").val(), b64_md5($("#txtPassWord").val()));
                    $("#txtUserCode").val("");
                    $("#txtPassWord").val("");
                    this.close();
                }
            }
        }).dialog("data", "_wrap").addClass("dialog-btstyle").addClass("dialog-btstyle-button");

    },
    funLogin: function (userCode, password) {
        var _self = this;
        ///<summary>互检人登录</summary>
        ///<param name="userCode">用户编码</param>
        ///<param name="password">登录密码</param>

        var sql = "SELECT * FROM User WHERE UserCode='" + userCode + "' and Password='" + password + "'";
        var db = app.database.open(Common.WEIXIUBASEDB);
        app.database.executeQuery(db, sql, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowslen = rows.length;
            if (rowslen > 0) {
                var uName = rows[0].UserName;
                var uCode = rows[0].UserCode;
                var isNewUser = true;
                var mutualInsPersons = _self.MutualInsPersons;
                var personlen = mutualInsPersons.length;
                for (var i = 0; i < personlen; i++) {
                    var personItem = mutualInsPersons[i];
                    if (personItem["key"] == uCode) {
                        isNewUser = false;
                        break;
                    }
                }
                if (isNewUser) {
                    mutualInsPersons.push({"key": uCode, "value": uName});
                    app.setGlobalVariable("MutualIns_Persons", JSON.stringify(mutualInsPersons));
                    _self.funSetMutualPerson();
                } else {
                    app.alert("该互检用户已登录存在");
                }
            } else {
                app.alert("账号或密码错误！");
            }
        });
    },

    funInitUi: function () {
        var _self = this;
        var title = _self.PageParam["PageHeader"];
        if (title) {
            $("#pageTitle").text(title);
        }
        app.getGlobalVariable("MutualIns_Persons", function (res) {
            if (res) {
                _self.MutualInsPersons = JSON.parse(res);
            }
        });

        var deviceList = _self.PageParam["Devices"];
        var devicelen = deviceList.length;
        if (devicelen == 1) {
            $("#btnAddNote").css("display", "");
        }
        _self.funSetMutualPerson();
    },

    funSetMutualPerson: function () {
        var _self = this;
        var personlen = _self.MutualInsPersons.length;
        var item = _self.MutualInsPersons[personlen - 1];
        var key = item["key"];
        var value = item["value"];
        var mutuaPreCtr = $("#mutualPersonsSelector");
        mutuaPreCtr.text(value);
        mutuaPreCtr.attr("key", key);
    },

    funSwitchMutualPerson: function () {
        var _self = this;
        var persons = _self.MutualInsPersons;
        var mutuaPreCtr = $("#mutualPersonsSelector");
        var defkey = mutuaPreCtr.attr("key") || "NA";
        app.wheelSelect.oneSelect(persons,
            function (res) {
                var key = res["key"];
                var value = res["value"];
                mutuaPreCtr.text(value);
                mutuaPreCtr.attr("key", key);
            }, defkey, "请选择互检人员");
    },

    funInitProcessData: function (cntSelectId, cntInputId) {
        var _self = this;
        var deviceList = _self.PageParam["Devices"];
        var wONumList = new Array();
        var devicelen = deviceList.length;
        for (var j = 0; j < devicelen; j++) {
            var wONumItem = deviceList[j].key;
            wONumList.push("WONum='" + wONumItem + "'");
        }
        var sqlWhere = " (" + wONumList.join(" or ") + ") ";
        var sql = "SELECT * FROM OrderProcedure WHERE " + sqlWhere + " and UppLayerProcedureNum='' and IsMutCheck='1' and SelfFormTime!='' Order by WONum,SortNum  asc";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sql, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowslen = rows.length;
            if (rowslen > 0) {
                var funCacheData = function (processDic, rowItem) {
                    var jobTaskNum = rowItem["JobTaskNum"];
                    var cacheItem = processDic.Item(jobTaskNum);
                    if (cacheItem == null) {
                        cacheItem = new Object();
                        cacheItem.IsKeyTask = rowItem["IsKeyTask"];
                        cacheItem.FormWay = rowItem["FormWay"];
                        cacheItem.OptionsValue = rowItem["OptionsValue"];
                        cacheItem.MaxValue = rowItem["MaxValue"];
                        cacheItem.MinValue = rowItem["MinValue"];
                        cacheItem.HasChildProcedure = rowItem["HasChildProcedure"];
                        cacheItem.JobTaskNum = jobTaskNum;
                        cacheItem.ProcedureDesc = rowItem["ProcedureDesc"];
                        cacheItem.PointName = rowItem["PointName"];
                        cacheItem.ProcessItems = new Array();
                        processDic.Add(jobTaskNum, cacheItem);
                    }
                    var procItem = new Object();
                    procItem.JobTaskNum = jobTaskNum;
                    procItem.WONum = rowItem["WONum"];
                    procItem.ProcedureNum = rowItem["ProcedureNum"];
                    procItem.ResultValue = rowItem["ResultValue"];
                    procItem.MutFormUserCode = rowItem["MutFormUserCode"];
                    procItem.MutFormUserName = rowItem["MutFormUserName"];
                    cacheItem.ProcessItems.push(procItem);
                };

                for (var i = 0; i < rowslen; i++) {
                    var row = rows[i];
                    var formWay = row["FormWay"].toLowerCase();   //工序类型 a-单选、b-输入测量值、c-输入文本，d-单选+拍照;
                    if (formWay == "b" || formWay == "c") {
                        funCacheData(_self.InputProcessDic, row);
                    } else {

                        funCacheData(_self.SelectProcessDic, row);
                    }
                }
            }
            _self.funDrawList(cntSelectId, cntInputId);
        });
    },

    funDrawList: function (cntSelectId, cntInputId) {
        var _self = this;
        var liSelectHtml = "";
        var liInputHtml = "";
        var selectCount = 0;
        var inputCount = 0;
        var funGetUnusalVal = function (item) {
            var unusalValue = "";
            var optionsValue = item["OptionsValue"].split(';');
            var optionslen = optionsValue.length;
            var lastOptionVal = optionsValue[optionslen - 1];
            var pocItemlen = item.ProcessItems.length;
            for (var j = 0; j < pocItemlen; j++) {
                var procItem = item.ProcessItems[j];
                if (procItem["ResultValue"] == lastOptionVal) {
                    unusalValue += "工单:" + item.ProcessItems[j]["WONum"] + "-结果:" + procItem["ResultValue"] + ";";
                }
            }
            if (unusalValue) {
                unusalValue = '[' + unusalValue + ']';
            }
            return unusalValue;
        };
        var funDrawSelectProc = function () {
            var selectProcessDic = _self.SelectProcessDic; //选择类型工序
            var selectVals = selectProcessDic.Values();
            var selectLen = selectVals.length;
            selectCount = selectLen;
            for (var i = 0; i < selectLen; i++) {
                var item = selectVals[i];
                var jobTaskNum = item["JobTaskNum"];
                var pointName = item["PointName"];
                var pocItemlen = item.ProcessItems.length;
                liSelectHtml += '<li>';
                liSelectHtml += '<div data-role="BTButton" mousedown="false" mouseup="false">';
                liSelectHtml += '<div class="row-box">';
                liSelectHtml += '<div class="span1 label">';
                liSelectHtml += '<div id="' + jobTaskNum + '" value="' + jobTaskNum + '" data-role="BTCheck" data-inline="false">';
                liSelectHtml += ' <div class="label">';
                liSelectHtml += (i + 1) + '、' + item["ProcedureDesc"];
                if (pointName) {
                    liSelectHtml += '[单位:' + pointName + ']';
                }
                liSelectHtml += '<span class="inputEro">';
                liSelectHtml += funGetUnusalVal(item);
                liSelectHtml += '</span>';
                liSelectHtml += '</div>';
                liSelectHtml += '</div>';
                liSelectHtml += '</div>';
                if (pocItemlen == 1) {
                    liSelectHtml += '<div class="sinPromh">' + item.ProcessItems[0]["MutFormUserName"] + '</div>';
                }
                liSelectHtml += ' </div>';
                liSelectHtml += ' </div>';
                liSelectHtml += ' </li>';
            }
            if (liSelectHtml) {
                var cntSelect = document.getElementById(cntSelectId);
                if (cntSelect) {
                    cntSelect.innerHTML = '<ul class="list-view list-check" data-corner="all">' + liSelectHtml + '</ul>';
                }
            }
        };
        var funDrawInputProc = function () {
            var keyProcessVals = _self.InputProcessDic.Values();
            var keyProcesslen = keyProcessVals.length;
            inputCount = keyProcesslen;
            if (keyProcesslen > 0) {
                var devicelen = _self.PageParam["Devices"].length;
                for (var i = 0; i < devicelen; i++) {
                    var deviceItem = _self.PageParam["Devices"][i];
                    var woNum = deviceItem["key"];
                    var keyProcItemHtml = "";
                    for (var k = 0; k < keyProcesslen; k++) {
                        var keyProcessItem = keyProcessVals[k];
                        var procItem = _self.funGetProcItem(keyProcessItem.ProcessItems, woNum);
                        if (procItem) {
                            var inputWay = keyProcessItem["FormWay"].toLowerCase();
                            var keyJobTaskNum = keyProcessItem["JobTaskNum"];
                            var keyCrtId = keyJobTaskNum + "_" + woNum;
                            var resultValue = procItem["ResultValue"] || "";
                            var pointName = keyProcessItem["PointName"];
                            if (inputWay == "b" || inputWay == "c") {
                                keyProcItemHtml += '<li>';
                                keyProcItemHtml += '<div data-role="BTButton" mousedown="false" mouseup="false">';
                                keyProcItemHtml += '<div class="row-box">';
                                keyProcItemHtml += '<div class="span1 label">';
                                keyProcItemHtml += '<div id="' + keyCrtId + '" value="' + keyCrtId + '" data-role="BTCheck" data-inline="false">';
                                keyProcItemHtml += ' <div class="label">';
                                keyProcItemHtml += (i + 1) + '.' + (k + 1) + '、' + keyProcessItem["ProcedureDesc"];
                                if (pointName) {
                                    keyProcItemHtml += '[单位:' + pointName + ']';
                                }
                                if (resultValue) {
                                    keyProcItemHtml += '<span class="inputEro">[' + resultValue + ']</span>';
                                }
                                keyProcItemHtml += '</div>';
                                keyProcItemHtml += '</div>';
                                keyProcItemHtml += '</div>';
                                keyProcItemHtml += '<div class="sinPromh">' + procItem["MutFormUserName"] + '</div>';
                                keyProcItemHtml += ' </div>';
                                keyProcItemHtml += ' </div>';
                                keyProcItemHtml += ' </li>';
                            }
                        }
                    }

                    if (keyProcItemHtml) {

                        liInputHtml += '<ul class="list-view list-view-head list-check" data-corner="all">';
                        liInputHtml += '<li>';
                        liInputHtml += '<div data-role="BTButton" mousedown="false">';
                        liInputHtml += '<span class="btn-text">';
                        liInputHtml += (i + 1) + '、' + deviceItem["value"];
                        liInputHtml += '</span>';
                        liInputHtml += ' </div>';
                        liInputHtml += ' </li>';
                        liInputHtml += keyProcItemHtml;
                        liInputHtml += "</ul>";
                    }
                }

                if (liInputHtml) {
                    var cntInput = document.getElementById(cntInputId);
                    if (cntInput) {
                        cntInput.innerHTML = liInputHtml;
                    }
                }
            }
        };
        var funDrawCount = function () {
            $("#lblISelectCount").text("选择类工序(" + selectCount + ")");
            $("#lblInputCount").text("测量类工序(" + inputCount + ")");
            if (selectCount == 0 && inputCount == 0) {
                var cntSelect = document.getElementById(cntSelectId);
                if (cntSelect) {
                    var setlihtml = '<ul class="list-view list-check" data-corner="all">' + liSelectHtml + '</ul>';
                    setlihtml += '<li>';
                    setlihtml += '<div data-role="BTButton" mouseup="false" mousedown="false" data-status="1">';
                    setlihtml += '<span class="btn-text">该工单没有互检工序，可以点击"保存"对整个工单进行互检确认。</span>';
                    setlihtml += '</div>';
                    setlihtml += '</li>';
                    setlihtml += '</ul>';
                    cntSelect.innerHTML = setlihtml;
                }
                var cntInput = document.getElementById(cntInputId);
                if (cntInput) {
                    var inputlihtml = '<ul class="list-view list-check" data-corner="all">' + liSelectHtml + '</ul>';
                    inputlihtml += '<li>';
                    inputlihtml += '<div data-role="BTButton" mouseup="false" mousedown="false" data-status="1">';
                    inputlihtml += '<span class="btn-text">该工单没有互检工序，可以点击"保存"对整个工单进行互检确认。</span>';
                    inputlihtml += '</div>';
                    inputlihtml += '</li>';
                    inputlihtml += '</ul>';
                    cntInput.innerHTML = inputlihtml;
                }
            }
        };

        funDrawSelectProc();
        funDrawInputProc();
        funDrawCount();
        if (liSelectHtml || liInputHtml) {
            ui.init();
        }
    },

    funGetProcItem: function (procItems, woNum) {
        ///<summary>获取单个工序的信息</summary>
        var procItem = null;
        var proclen = procItems.length;
        for (var i = 0; i < proclen; i++) {
            var item = procItems[i];
            if (item.WONum == woNum) {
                procItem = item;
                break;
            }
        }
        return procItem;
    },

    funSaveProcess: function () {
        var _self = this;
        ///<summary>保存</summary>
        var mutuaPreCtr = $("#mutualPersonsSelector");
        var updateUserCode = mutuaPreCtr.attr("key") || "NA";
        var updateUserName = mutuaPreCtr.text();
        if (updateUserCode == "NA") {
            app.alert("请先登录互检入信息！", function () {
                $('#dlO').dialog("open");
            });
        } else {
            var deviceList = _self.PageParam["Devices"];
            var devicelen = deviceList.length;
            var wONumWhereList = new Array();//工单号数组
            for (var j = 0; j < devicelen; j++) {
                wONumWhereList.push("'" + deviceList[j].key + "'");
            }
            var wONumWhereText = wONumWhereList.join(",");
            var dbName = app.database.open(Common.WEIXIUDB);
            var sql = "select * from OPOrders where  WONum IN (" + wONumWhereText + ")  and SelfFormUserCode='" + updateUserCode + "'";
            app.database.executeQuery(dbName, sql, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if (rows.length > 0) {
                    app.alert("互检人不能为自己检人");
                } else {
                    var sqlList = _self.funGetUpdProceTextList(updateUserCode, updateUserName);
                    var sqlText = "SELECT WONum from OPOrders where WONum IN (" + wONumWhereText + ") and MutFormIsFinished='0'";
                    var itemList = new Array();
                    dbName.transaction(function (tx2) {
                        for (var i = 0; i < sqlList.length; i++) {
                            tx2.executeSql(sqlList[i]);
                        }
                        tx2.executeSql(sqlText, [], function (tx1, rest) {
                            itemList = Common.funConvertRowsJson(rest);
                        });
                    }, function (error) {
                        app.alert(error);
                    }, function () {
                        var itemlistCount = itemList.length;
                        if (itemlistCount > 0) {
                            app.confirm("还有工序未互检完成,是否强制结束?", function (index) {
                                if (index == 2) {
                                    Common.funGoBack();
                                }
                            }, "提示", "取消,确定");
                        } else {
                            Common.funGoBack();
                        }
                    });
                }
            });
        }
    },

    funGetUpdProceTextList: function (updateUserCode, updateUserName) {
        var _self = this;
        var updSqlList = new Array();
        var updateDate = Common.funGetNowDate();
        var deviceList = _self.PageParam["Devices"];
        var devicelen = deviceList.length;
        if (devicelen > 0) {
            var wONumWhereList = new Array();//工单号数组
            for (var j = 0; j < devicelen; j++) {

                wONumWhereList.push("'" + deviceList[j].key + "'");
            }
            var wONumWhereText = wONumWhereList.join(",");

            var funGetChkInputProc = function () {
                var inputProcessDic = _self.InputProcessDic;//文本框工序
                var inputProcessVals = inputProcessDic.Values();
                var inputProcesslen = inputProcessVals.length;
                if (inputProcesslen > 0) {
                    for (var i = 0; i < devicelen; i++) {
                        var woNum = deviceList[i].key;
                        for (var k = 0; k < inputProcesslen; k++) {
                            var inputProcessItem = inputProcessVals[k];
                            var jobTaskNum = inputProcessItem["JobTaskNum"];
                            var crtId = jobTaskNum + "_" + woNum;
                            var ctr = $("#" + crtId);
                            if (ctr.length > 0) {
                                var isCheckOn = ctr.hasClass('BTCheck_ON');
                                if (isCheckOn) {
                                    var sqlText = "UPDATE OrderProcedure SET MutFormTime='" + updateDate + "',MutFormUserCode='" + updateUserCode + "',MutFormUserName='" + updateUserName + "' WHERE  WONum='" + woNum + "' AND JobTaskNum='" + jobTaskNum + "' AND UppLayerProcedureNum='' AND IsMutCheck='1' ";
                                    updSqlList.push(sqlText);
                                }
                            }
                        }
                    }
                }
            };
            var funGetChkSelectProc = function () {
                var selectProcessDic = _self.SelectProcessDic; //选择工序
                var selectVals = selectProcessDic.Values();
                var selectLen = selectVals.length;
                if (selectLen > 0) {
                    for (var i = 0; i < selectLen; i++) {
                        var item = selectVals[i];
                        var jobTaskNum = item["JobTaskNum"];
                        var ctr = $("#" + jobTaskNum);
                        var isCheckOn = ctr.hasClass('BTCheck_ON');
                        if (isCheckOn) {
                            var sqlText = "UPDATE OrderProcedure SET MutFormTime='" + updateDate + "',MutFormUserCode='" + updateUserCode + "',MutFormUserName='" + updateUserName + "' WHERE WONum IN (" + wONumWhereText + ") AND  JobTaskNum='" + jobTaskNum + "' AND UppLayerProcedureNum='' AND IsMutCheck='1' ";
                            updSqlList.push(sqlText);
                        }
                    }
                }
            };
            funGetChkInputProc();
            funGetChkSelectProc();

            for (var g = 0; g < devicelen; g++) {
                var updateOrderSqlText = "UPDATE OPOrders SET MutFormFinishTime='" + updateDate + "',MutFormUserCode='" + updateUserCode + "',MutFormUserName='" + updateUserName + "' WHERE WONum=" + wONumWhereList[g];
                updSqlList.push(updateOrderSqlText);
            }

            var updMutFinishText = " UPDATE OPOrders SET MutFormIsFinished='1' where WONum IN (" + wONumWhereText + ")  and WONum NOT IN (SELECT WONum FROM OrderProcedure WHERE  WONum IN (" + wONumWhereText + ") AND UppLayerProcedureNum='' AND MutFormUserCode='' AND IsMutCheck='1' GROUP BY WONum )";
            updSqlList.push(updMutFinishText);
        }
        return updSqlList;
    },

    funInitSelectUser: function () {
        var _self = this;
        var sql = "SELECT * FROM OPUsers ";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sql, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowslen = rows.length;
            if (rowslen > 0) {
                for (var i = 0; i < rowslen; i++) {
                    var row = rows[i];
                    var uName = row.UserName;
                    var uCode = row.UserCode;
                    _self.MutualInsPersons.push({"key": uCode, "value": uName});
                }
            }
        });
    },
    funBackRefresh : function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var pageName = retParam["pageName"];
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funInitSelectUser();
            _self.funInitProcessData("divSelect", "divInput");
        }, 100);
    }
};
