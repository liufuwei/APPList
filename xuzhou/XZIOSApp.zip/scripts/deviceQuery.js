﻿var Device = function () {


    this.Lines = new Array();
    this.Stations = new Array();
    this.Specialtys = new Array();

};

Device.prototype = {
    funInitEvent: function () {
        var _self = this;

        //返回
        $("#imback").click(function () {
            app.back();
        });

        //线路
        $("#LineList").click(function () {
            var lines = _self.Lines;
            if (lines.length > 0) {
                var lineCtr = $("#LineList");
                var defkey = "";
                app.wheelSelect.oneSelect(lines,
                    function (res) {
                        var key = res["key"];
                        var value = res["value"];
                        lineCtr.text(value);
                        lineCtr.attr("key", key);
                        _self.funLoadStationData(key);
                    }, defkey, "请选择线路");
            } else {
                app.alert("暂无线路基础数据");
            }
        });

        //车站
        $("#StationList").click(function () {
            var stations = _self.Stations;
            if (stations.length > 0) {
                var stationCtr = $("#StationList");
                var defkey = "";
                app.wheelSelect.oneSelect(stations,
                    function (res) {
                        var key = res["key"];
                        var value = res["value"];
                        stationCtr.text(value);
                        stationCtr.attr("key", key);
                    }, defkey, "请选择车站");
            } else {
                app.alert("暂无车站基础数据");
            }
        });

        //专业
        $("#SpecialtyList").click(function () {
            var specialtys = _self.Specialtys;
            if (specialtys.length > 0) {
                var specialtyCtr = $("#SpecialtyList");
                var defkey = "";
                app.wheelSelect.oneSelect(specialtys,
                    function (res) {
                        var key = res["key"];
                        var value = res["value"];
                        specialtyCtr.text(value);
                        specialtyCtr.attr("key", key);

                    }, defkey, "请选择专业");
            } else {
                app.alert("暂无专业基础数据");
            }
        });

        //点击查询 渲染到列表下面
        $('#btnQueryDevice').click(function () {
            device.funQueryDevice();
        });

    },

    //车站的控件
    funLoadStationData: function (lineNum) {
        var _self = this;
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            tx.executeSql("select LocationNum as 'key',LocationName as value from Location where ( LocationNum like '" + lineNum + "Z%' or LocationNum like '" + lineNum + "D%' OR  LocationNum like '" + lineNum + "O%' ) and length(LocationNum)=6", [], function (tx1, results) {
                _self.Stations = Common.funConvertRowsJson(results);
            });
        }, function (error) {
            app.alert(error);
        }, function () {
            var stationlen = _self.Stations.length;
            var stationCtr = $("#StationList");
            stationCtr.text("--全部--");
            stationCtr.attr("key", "NA");
        });
    },

    //线路、专业的控件
    funInitData: function () {
        var _self = this;
        var userCode = "";
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                userCode = res;
            }
        });
        if (userCode) {
            var db = app.database.open(Common.WEIXIUDB);
            var userRows = new Array();
            db.transaction(function (tx) {
                tx.executeSql("SELECT LineNum as 'key' ,LineName as value from Line", [], function (tx1, results) {
                    _self.Lines = Common.funConvertRowsJson(results);
                    $("#LineList").text(_self.Lines[7]["value"]);
                    $("#LineList").attr("key", _self.Lines[0]["key"]);
                    _self.funLoadStationData(_self.Lines[0]["key"])
                });
                tx.executeSql("SELECT SpecialtyNum as 'key',SpecialtyName as value  from Specialty", [], function (tx1, results) {
                    _self.Specialtys = Common.funConvertRowsJson(results);
                    $("#SpecialtyList").attr("key", _self.Specialtys[0]["key"]);
                });
            }, function (error) {
                app.alert(error);
            }, function () {
                var linelen = _self.Lines.length;
                if (linelen > 0) {
                    _self.Lines.unshift({"key": "NA", "value": "--全部--"});
                }

                var specialtylen = _self.Specialtys.length;
                if (specialtylen > 0) {
                    _self.Specialtys.unshift({"key": "NA", "value": "--全部--"});
                }
            });
        }
    },
    //线路、车站、设备、位置的请求数据
    funGetRequeryParam: function () {
        var retParam = new Object();
        var line = $("#LineList").attr("key") || "NA";
        if (line != "NA") {
            retParam.LineNum = line;
        }
        var station = $("#StationList").attr("key") || "NA";
        if (station != "NA") {
            retParam.StationNum = station;
        }
        var Specialty = $("#SpecialtyList").attr("key") || "NA";
        if (Specialty != "NA") {
            retParam.SpecNum = Specialty;
        }
        var txtDevice = $("#txtDeviceName").val().trim();
        if (txtDevice != "") {
            retParam.LocationName = txtDevice;
        }
        return retParam;
    },

    //ajax链接后台请求数据
    funQueryDevice: function () {
        var _self = this;
        var downParam = _self.funGetRequeryParam();
        var requestParam = new Object();
        requestParam.orgin = "stream";
        requestParam.CallMethod = "Misc_FetchLocationDevicesList";
        requestParam.AuthBlock = new Object();
        requestParam.AuthBlock.ClientNumber = device.uuid;
        requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                requestParam.AuthBlock.UserCode = res;
            }
        });
        app.getGlobalVariable("Password", function (res) {
            if (res) {
                requestParam.AuthBlock.Password = res;
            }
        });
        requestParam.PayLoad = downParam;
        app.progress.start("提示", "数据正在处理...");
        app.ajax({
            "url": MobileConfig.DownFetchLocationDevices,
            "data": requestParam,
            "contentType": "application/json",
            "method": "POST",
            "async": true,
            "success": function (res) {
                var retDataInfo = JSON.parse(res.returnValue);
                if (retDataInfo.ResStatus == true) {
                    var fetchLocationDevicesList = retDataInfo.PayLoad;
                    if (fetchLocationDevicesList.length > 0) {
                        _self.funLoadUiList(fetchLocationDevicesList);
                        app.progress.stop();
                    } else {
                        $('#planList').empty();
                        app.alert("暂无数据", function () {
                            app.progress.stop();
                        });
                    }
                } else {
                    app.alert(retDataInfo.ResMsg, function () {
                        app.progress.stop();
                    });
                }
            }
        });
    },

    //拼接到列表下面渲染出来
    funLoadUiList: function (devicesList) {
        //alert(devicesList.length);
        var deviceLen = devicesList.length;
        $('#planList').empty();
        var ulDom = $('<ul class="list-view list-decice" data-corner="all"></ul>');
        for (var i = 0; i < deviceLen; i++) {
            var row = devicesList[i];
            var li = '<li LocationNum=' + row.LocationNum + ' style="border: 1px solid #ccc; height: 80px; line-height: 80px; overflow: hidden">' +
                row.LocationNum + ';' + row.LocationName + ';' +
                '</li>';
            var liDom = $(li).click(function () {
                Common.funLoad("deviceResume.html", "LocationNum=" + $(this).attr('LocationNum'));
            });
            liDom.appendTo(ulDom)
        }
        ulDom.appendTo($('#planList'))

    },
    funBackRefresh: function () {
        this.funInitData();
    }

};
