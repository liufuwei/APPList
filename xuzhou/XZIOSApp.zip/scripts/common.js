﻿/// <reference path="../bingoTouch/plugins.js" />


var Common = {};

Common.WEIXIUDB = "WEIXIUDB";
Common.WEIXIUBASEDB = "WEIXIUDB";

//测试版本配置
// Common.ISDEBUG = true;
// Common.preUrlM = "http://10.105.184.37:7002/maximo";
//正式版本配置
// Common.ISDEBUG = false;
// Common.preUrlM = "http://lmis.gzmtr.com:8088/maximo";


Common.funRemoveItem = function (array, item) {
    for (var i = 0; i < array.length; i++) {
        if (array[i] == item) {
            array.splice(i, 1);
            break;
        }
    }
};


Common.funGetNowDate = function () {
    ///<summary>//获取当前日期:[此方法得到的是一个日期格式的字符串]</summary>
    var now = new Date();
    var s = now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + " " + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
    return s;
};
//获取今天的时间
Common.funTodayDate = function () {
    var now = new Date();
    var s = now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate();
    return s;
};

Common.funCompareDate = function (datetime1, datetime2) {
    ///<summary>对比日期，日期格式：2013-3-1 15:10:5。
    ///返回结果：datetime1>datetime2返回true,否则返回false。</summary>
    ///<param name="datetime1">日期1</param>
    ///<param name="datetime2">日期2</param>
    ///<return></return>
    var result = false;
    try {
        if (datetime1 && datetime2) {
            var endDate = Date.parse(datetime1.replace(/-/g, "/"));
            var beginDate = Date.parse(datetime2.replace(/-/g, "/"));
            if (endDate > beginDate) {
                result = true;
            }
        }
    } catch (e) {
        result = false;
    }
    return result;
};

Common.funCompareDateCM = function (datetime1, datetime2) {
    ///<summary>对比日期，日期格式：2013-3-1 15:10:5。
    ///返回结果：datetime1>datetime2返回true,否则返回false。</summary>
    ///<param name="datetime1">日期1</param>
    ///<param name="datetime2">日期2</param>
    ///<return></return>
    var result = false;
    try {
        if (datetime1 && datetime2) {
            var endDate = Date.parse(datetime1.replace(/-/g, "/"));
            var beginDate = Date.parse(datetime2.replace(/-/g, "/"));
            if (endDate >= beginDate) {
                result = true;
            }
        }
    } catch (e) {
        result = false;
    }
    return result;
};

Common.funGetPkId = function () {
    ///<summary>获取一个客户端PKID</summary>
    var newPkId = Math.random() + "";
    return -(newPkId.slice(2) - 0);
};

Common.funLogOut = function () {
    ///<summary>注册:void</summary>
    app.confirm("您确定要注销当前登录吗?", function (index) {
        if (index == 2) {
            Common.funClearModuleCache();//删除页面跳转保存的全局变量
            var db = app.database.open("WEIXIUDB");
            app.database.executeNonQuery(db, "delete from OPUsers where 1=1", function () {
                app.load({url: "login.html"});
            });

        }
    }, "提示", "取消,确定");
};

//3.4弃用 lsw
Common.funGetStartWkList = function () {
    ///<summary>//获取当前开始的作业任务</summary>
    ///<returns>返回Json对象数组[{PWONum:父工单编号,OPDesc:工单描述}]</returns>
    var retVale = null;
    app.getGlobalVariable("startWkList", function (res) {
        if (res) {
            retVale = JSON.parse(res);
        }
    });
    return retVale;
};

Common.funConvertRowsJson = function (results) {
    ///<summary>把results对象转成RowsJson，此方法使用app.database.executeQuery成功回调函数中</summary>
    ///<param name="results">
    ///results对象结构如下
    ///results.rows.length
    ///results.rowsAffected,
    ///results.insertId,
    /// results.rows.item(i).field
    ///</param>
    var rowsJson = new Array();
    if (results) {
        var len = results.rows.length;
        var rows = results.rows;
        for (var i = 0; i < len; i++) {
            var row = new Object();
            for (var clmField in rows.item(i)) {
                row[clmField] = rows.item(i)[clmField] + "";
            }
            rowsJson.push(row);
        }
    }
    return rowsJson;
};

Common.funConcatArray = function (targetList, sourceList) {
    var sourcelen = sourceList.length;
    for (var i = 0; i < sourcelen; i++) {
        var item = sourceList[i];
        targetList.push(item);
    }
    return targetList;
};

Common.funSetPageParam = function (pageName, pageParm) {
    app.setGlobalVariable(pageName, JSON.stringify(pageParm));
};

//3.4版本弃用 lsw
Common.funGetPageParam = function (pageName) {
    var retValue = null;
    if (!retValue) {
        app.getGlobalVariable(pageName, function (res) {
            if (res) {
                retValue = JSON.parse(res);
                app.setGlobalVariable(pageName, null);
            }
        });
    }
    if (!retValue) {
        retValue = Common.funGetPageparam();
    }
    return retValue;
};
Common.getPageParams = function () {
    var retValue = null;
    app.getPageParams(function (res) {
        retValue = res;
    });
    return retValue;
};

Common.funConvertCode = function (res) {
    var retObj = null;
    if (res && (res + "").length > 0) {
        if (/^[0-9]*$/.test(res.substring(0, 1))) {//如果第一位不是标签类型，而是数字，则默认为L类型 设备的位置标签
            res = "L" + res;
        }
        var resArr = (res + "").split("|");
        if (resArr && resArr.length > 0 && (resArr[0] + "").length > 0) {
            var resString = resArr[0].toString();
            retObj = new Object();
            retObj.TagType = resString.substring(0, 1).toUpperCase();
            retObj.TagCode = resString.substring(1, resString.length);
            if (resArr[1]) {
                retObj.TagComment = resArr[1].toString();
            } else {
                retObj.TagComment = null;
            }
        }
    }
    return retObj;
};

Common.getBarcode = function (success, fail) {
    ///<summary>通用二维码扫描方法</summary>
    ///<param name="success">成功回调 
    ///返回Object：{TagCode:"",TagType:"",TagComment:""} TagCode：标签；TagType：标签类型；TagComment：标签说明
    ///</param>
    ///<param name="fail">失败回调</param>
    app.scan(function (res) {
        //alert("getBarcode@@@@@@@@@@@@@@@@@" + JSON.stringify(res));
        var returnObj = Common.funConvertCode(res);
        success(returnObj);
    });
    //Cordova.exec(function (res) {
    //    //alert("getBarcode@@@@@@@@@@@@@@@@@" + JSON.stringify(res));
    //    var returnObj = Common.funConvertCode(res);
    //    success(returnObj);
    //}, fail, "BarcodeScanner", "scan", []);
};

/*****************************************************************/
/*****************  跳转方法  Start  *****************************/
/*****************************************************************/

/** 保存所有模块跳转时的信息 使用键值对
 modulesDic[
 key:moduleKey,          //模块的Key
 ModuleParams:obj        //模块跳转时的信息 对应下方的实体currentModuleParams
 ];

 //当前使用的模块对应的跳转信息
 currentModuleParams:[
 key:moduleKey,          //模块的Key 保存回modulesDic时通过此参数对应
 curModuleParamsStack:{  //数组 堆栈 保存上一条跳转页面信息
        [
            PrePageURL:url,
            NextPageURL:url,
            PageParams:obj
        ],[],……
    },
 currentPageParams:obj   //当前页面参数
 ];
 **/

Common.funClearModuleCache = function (modeuleName) {
    ///<summary>清除页面跳转的缓存</summary>
    ///<param name ="modeuleName">模块名，为null时删除全部</param>
    var ModulesParamsDicName = "modulesParamsDic";
    var CurrentModuleParamsName = "currentModuleParams";
    var returnObj = new Object();
    if (!modeuleName) {
        app.setGlobalVariable(CurrentModuleParamsName, '');
        app.setGlobalVariable(ModulesParamsDicName, '');
    }
    else {
        app.getGlobalVariable(ModulesParamsDicName, function (res) {//获取各个导航模块的页面参数数组
            if (res) {
                //alert("@liwch@" + res);
                var modulesParamsDic = JSON.parse(res);
                if (modulesParamsDic[modeuleName]) {
                    modulesParamsDic[modeuleName] = null;
                }
                app.setGlobalVariable(ModulesParamsDicName, JSON.stringify(modulesParamsDic));
            }
        });
    }

};

Common.funUpdateCurrentPageparam = function (pageParams, errorFunc) {
    ///<summary>修改当前页面参数</summary>
    ///<param name="pageParams">页面参数</param>
    var ModulesParamsDicName = "modulesParamsDic";
    var CurrentModuleParamsName = "currentModuleParams";
    var CurModuleParamsStackName = "curModuleParamsStack";
    var CurrentPageParamsName = "currentPageParams";
    var returnObj = new Object();
    app.getGlobalVariable(CurrentModuleParamsName, function (resModuleParams) {
        try {
            //修改参数
            var CurrentModuleParams = JSON.parse(resModuleParams);
            CurrentModuleParams[CurrentPageParamsName] = pageParams;
            //重新保存参数
            app.setGlobalVariable(CurrentModuleParamsName, JSON.stringify(CurrentModuleParams));
        } catch (e) {
            //resModuleParams当前页面参数不存在，则报错。其它报错也提示
            if (errorFunc)
                errorFunc(e.message);
        }
    });
};

//3.4弃用 lsw
Common.funGetPageparam = function () {
    ///<summary>获取页面参数,只适合使用Common.funLoad()或者Common.funGoBack()方法跳转的</summary>
    var ModulesParamsDicName = "modulesParamsDic";
    var CurrentModuleParamsName = "currentModuleParams";
    var CurModuleParamsStackName = "curModuleParamsStack";
    var CurrentPageParamsName = "currentPageParams";
    var returnObj = new Object();
    app.getGlobalVariable(CurrentModuleParamsName, function (resModuleParams) {
        if (resModuleParams) {
            var CurrentModuleParams = JSON.parse(resModuleParams);
            returnObj = CurrentModuleParams[CurrentPageParamsName];
        }
        else {

        }
    });
    return returnObj;
};

Common.funSetModuleKey = function (moduleKey, successFunc, faultFunc) {
    ///<summary>设置当前模块Key</summary>
    ///<param name="moduleKey">模块Key</param>
    ///<param name="successFunc">成功回调</param>
    ///<param name="faultFunc">失败回调</param>
    var ModulesParamsDicName = "modulesParamsDic";
    var CurrentModuleParamsName = "currentModuleParams";
    var CurModuleParamsStackName = "curModuleParamsStack";
    var isFirstEnter = false;//是否第一次进入此模块 是为true 不是为false
    try {
        app.getGlobalVariable(ModulesParamsDicName, function (res) {//获取各个导航模块的页面参数数组
            if (res) {
                var modulesParamsDic = JSON.parse(res);
                app.getGlobalVariable(CurrentModuleParamsName, function (resCurr) {//获取当前模块的页面参数
                    if (resCurr) {//把当前模块有数据 则保存到 模块组参数集合
                        var CurrentModuleParams = JSON.parse(resCurr);
                        if (CurrentModuleParams)
                            modulesParamsDic[CurrentModuleParams.key] = CurrentModuleParams;
                    }
                    if (!modulesParamsDic[moduleKey]) {//目标模块不存在
                        isFirstEnter = true;//第一次进入此模块
                        var loadModuleParams = new Object();
                        //目标模块初始化
                        loadModuleParams.key = moduleKey;
                        loadModuleParams.curModuleParamsStack = new Array();
                        loadModuleParams.currentPageParams = null;
                        modulesParamsDic[loadModuleParams.key] = loadModuleParams;
                    }
                    else {
                        if (!modulesParamsDic[moduleKey][CurModuleParamsStackName] || modulesParamsDic[moduleKey][CurModuleParamsStackName].length <= 0) {
                            isFirstEnter = true;//第一次进入此模块
                        } else {

                        }
                    }
                    //保存全局变量
                    app.setGlobalVariable(ModulesParamsDicName, JSON.stringify(modulesParamsDic));
                    app.setGlobalVariable(CurrentModuleParamsName, JSON.stringify(modulesParamsDic[moduleKey]));
                    successFunc(isFirstEnter);
                });
            }
            else {//如果没有 导航模块的页面参数数组
                isFirstEnter = true;//第一次进入此模块
                var modulesParamsDic = new Object();
                var currentModuleParams = new Object();
                //把当前模块保存到 导航模块的页面参数数组
                currentModuleParams.key = moduleKey;
                currentModuleParams.curModuleParamsStack = null;
                currentModuleParams.currentPageParams = null;
                modulesParamsDic[currentModuleParams.key] = currentModuleParams;
                //保存全局变量
                app.setGlobalVariable(ModulesParamsDicName, JSON.stringify(modulesParamsDic));
                app.setGlobalVariable(CurrentModuleParamsName, JSON.stringify(currentModuleParams));
                successFunc(isFirstEnter);
            }
        });
    } catch (e) {
        faultFunc(e);
    }
};

Common.funLoadMain = function () {
    ///<summary>跳转回首页</summary>
    Common.funLoad("main.html");
};

Common.funLoad = function (url, pageParams, isNeedBack, errorFunc) {
    ///<summary>跳转</summary>
    ///<param name="url">跳转地址</param>
    ///<param name="pageParams">跳转参数</param>
    ///<param name="isNeedBack">是否要记录(记录则入栈，返回本页面) 默认为记录，0为不记录</param>
    ///<param name="errorFunc">出错回调事件</param>
    //pageKey:导航菜单Key
    var ModulesParamsDicName = "modulesParamsDic";
    var CurrentModuleParamsName = "currentModuleParams";
    var CurModuleParamsStackName = "curModuleParamsStack";
    var CurrentPageParamsName = "currentPageParams";
    try {
        app.getGlobalVariable(CurrentModuleParamsName, function (resModuleParams) {
            if (resModuleParams) {
                var CurrentModuleParams = JSON.parse(resModuleParams);
                var CurModuleParamsStack = CurrentModuleParams[CurModuleParamsStackName];
                /*var currentPageArr = window.location.pathname.split("/");
                if (!isNeedBack || isNeedBack != "0") {//为空 或者不等于0
                    var currentPageParams = new Object();
                    currentPageParams.PageParams = CurrentModuleParams[CurrentPageParamsName];
                    currentPageParams.PrePageURL = currentPageArr[currentPageArr.length - 1];//当前页面
                    currentPageParams.NextPageURL = url;//下个页面
                    if (!CurModuleParamsStack)
                        CurModuleParamsStack = new Array();
                    CurModuleParamsStack.push(currentPageParams);
                    //alert(JSON.stringify(CurrentModuleParams[CurrentPageParamsName]) + "@liwch@" + JSON.stringify(currentPageParams))
                }*/
                //跳转前 保存入堆栈
                CurrentModuleParams[CurrentPageParamsName] = pageParams;
                CurrentModuleParams[CurModuleParamsStackName] = CurModuleParamsStack;//跳转前 保存入堆栈
                app.setGlobalVariable(CurrentModuleParamsName, JSON.stringify(CurrentModuleParams));
                if (pageParams) {
                    app.load({url: url, params: pageParams});
                } else {
                    app.load({url: url});
                }
            }
            else {
                errorFunc("请设置首页Key！");
                return;
            }
        });

    } catch (e) {
        if (errorFunc)
            errorFunc(e);
    }
};

Common.funGoBack = function (backParams, pageName, errorFunc) {
    try {
        if (backParams) {
            //传入的是方法直接调用
            if (typeof backParams === "function" || backParams instanceof Function) {
                app.back(backParams);
            } else {//传入是参数
                var params = {
                    "pageName": pageName,
                    "backParam": backParams
                };
                app.back("callPageback('" + JSON.stringify(params) + "')");
            }

            // if (!isNeedBack || isNeedBack != "0") {
            //     app.getGlobalVariable(CurrentModuleParamsName, function (resModuleParams) {
            //         //alert("funGoBack@@liwch@@#" + resModuleParams);
            //         var CurrentModuleParams = JSON.parse(resModuleParams);
            //         var CurModuleParamsStack = CurrentModuleParams[CurModuleParamsStackName];
            //         var currentPageArr = window.location.pathname.split("/");
            //         var currentUrl = currentPageArr[currentPageArr.length - 1];
            //
            //         var loadPageParams = CurModuleParamsStack[CurModuleParamsStack.length - 1];
            //         CurModuleParamsStack.pop();
            //         CurrentModuleParams[CurModuleParamsStackName] = CurModuleParamsStack;
            //         if (reTurnParams) {
            //             CurrentModuleParams[CurrentPageParamsName] = reTurnParams;
            //         } else {
            //             CurrentModuleParams[CurrentPageParamsName] = loadPageParams["PageParams"];
            //         }
            //         app.setGlobalVariable(CurrentModuleParamsName, JSON.stringify(CurrentModuleParams));
            //         //alert("@liwch@" + loadPageParams["PrePageURL"]);
            //         app.load({url: loadPageParams["PrePageURL"]});
            //     });
            // }

        } else {
            app.back("callPageback()");
        }
    } catch (e) {
        if (errorFunc)
            errorFunc(e);
    }
};
/*****************************************************************/
/*****************  跳转方法  end    *****************************/
/*****************************************************************/
