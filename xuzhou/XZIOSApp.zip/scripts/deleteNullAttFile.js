﻿var DeleteNullAttFile = function () {
    this.AttFileList = new Array();
};

DeleteNullAttFile.prototype = {
    funInitEvent:function () {
        var _self = this;
        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnDelAttFile").click(function () {
            var attNumList = _self.funGetChkList();
            if (attNumList.length > 0) {
                app.confirm("确认要删除无效附件数据吗?", function(index) {
                    if (index == 2) {
                        _self.funDelAttFile(attNumList);
                    }
                }, "删除无效附件数据确认", "取消,确定");
            } else {
                app.alert("请选择要删除的附件");
            }
        });

        $("#btnUploadAttFile").click(function() {
            _self.funUploadAtt();
        });
    },
    funInitUiData: function () {
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                $("#username").html(res);
            }
        });

        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                $("#usercode").html("（" + res + "）");
            }
        });
    },

    funInitAttFileData: function (containerId) {
        var _self = this;
        _self.AttFileList.length = 0;
        var sqlText = "";
        sqlText += "select AttNum,AttPath,ObjectType,ObjectID from AttFile where AttNum NOT IN ( ";
        sqlText += " SELECT a.AttNum FROM AttFile a INNER JOIN OPPlan b on a.PWONum=b.PWONum ";
        sqlText += " UNION ";
        sqlText += " SELECT a.AttNum FROM AttFile a INNER JOIN FaultsOrder b on a.ObjectID=b.WONum ";
        sqlText += " ) ";
        var db = app.database.open(Common.WEIXIUDB);

        app.database.executeQuery(db, sqlText, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var leng = rows.length;
            var lihtml = "";
            if (leng == 0) {
                lihtml = ' <li>';
                lihtml += '<div class="row-fluid">';
                lihtml += '<div class="span10" align="center">***暂无无效附件数据***</div>';
                lihtml += '</div>';
                lihtml += '</li>';
            } else {

                var funObjType = function (objectType) {
                    var objTypeText = "";
                    switch (objectType) {
                        case "WORKORDER":
                            objTypeText = "工单/故障";
                            break;
                        case "UDWOTASK":
                            objTypeText = "工序";
                            break;
                        case "UDTOOLCK":
                            objTypeText = "工具";
                            break;
                        default:
                            objTypeText = "【N/A】";
                            break;
                    }
                    return objTypeText;
                };

                for (var i = 0; i < leng; i++) {
                    var row = rows[i];
                    var attNum = row["AttNum"];
                    _self.AttFileList.push(attNum);
                    lihtml += '<li>';
                    lihtml += '<div data-role="BTButton" data-status="1">';
                    lihtml += '<span class="btn-text">';
                    lihtml += '<div class="row-box">';
                    lihtml += '<div class="span1">';
                    lihtml += '<div id="li' + attNum + '" data-role="BTCheck" data-inline="false">';
                    lihtml += "路径:" + row["AttPath"] + "<br/>" + "关联实体类型:" + funObjType(row["ObjectType"]) + "<br/>" + "关联实体编号:" + row["ObjectID"];
                    lihtml += '</div>';
                    lihtml += '</div>';
                    lihtml += '</div>';
                    lihtml += '</span>';
                    lihtml += '</div>';
                    lihtml += ' </li>';
                }
            }
            var cnt = document.getElementById(containerId);
            if (cnt) {
                cnt.innerHTML = lihtml;
                ui.init();
                if (leng > 0) {
                    _self.funBindEvent();
                }
            }
        });
    },

    funBindEvent: function () {
        var _self = this;
        $("#btnAllChk").click(function () {
            var chkBox = $(this);
            var result = chkBox.btcheck("val");
            var length = _self.AttFileList.length;
            if (length > 0) {
                var isAllchked = false;
                if (result != null && result.value != "") {
                    isAllchked = true;
                }
                for (var i = 0; i < length; i++) {
                    var chkBoxItem = $("#li" + _self.AttFileList[i]);
                    if (isAllchked) {
                        chkBoxItem.removeClass('BTCheck_OFF').addClass('BTCheck_ON');
                    } else {
                        chkBoxItem.removeClass('BTCheck_ON').addClass('BTCheck_OFF');
                    }
                }
            }
        });
    },

    funGetChkList: function () {
        var _self = this;
        var attList = new Array();
        var length = _self.AttFileList.length;
        if (length > 0) {
            for (var i = 0; i < length; i++) {
                var id = _self.AttFileList[i];
                var chkBoxItem = $("#li" + id);
                var result = chkBoxItem.btcheck("val");
                if (result != null && result.value != "") {
                    attList.push(id);
                }
            }
        }
        return attList;
    },

    funDelAttFile: function (attNumList) {
        var _self = this;
        var sqlList = new Array();
        var attNumLeng = attNumList.length;
        for (var i = 0; i < attNumLeng; i++) {
            sqlList.push("DELETE FROM AttFile where AttNum='" + attNumList[i] + "'");
        }
        var sqlCount = sqlList.length;
        if (sqlCount > 0) {
            var db = app.database.open(Common.WEIXIUDB);
            db.transaction(function (tx) {
                for (var j = 0; j < sqlCount; j++) {
                    tx.executeSql(sqlList[j]);
                }
            }, function (error) { app.alert(error, function () { app.progress.stop(); }); }, function () {
                app.progress.stop();
                _self.funInitAttFileData("attFileList");
            });
        } else { app.progress.stop(); }
    },

    funUploadAtt: function () {
        var _self = this;
        var attList = _self.funGetChkList();
        var attlen = attList.length;
        if (attlen > 0) {
            var attachments = new Array();
            var userCode = "";
            var password = "";
            app.getGlobalVariable("UserCode", function (res) { if (res) { userCode = res; } });
            app.getGlobalVariable("Password", function (res) { if (res) { password = res; } });

            var upAttFileIdList = new Array();
            var upattAllOk = true;
            var upAttCount = 0;

            var funUpAttach = function () {
                var attachlen = attachments.length;
                var ft = new FileTransfer();
                for (var i = 0; i < attachlen; i++) {
                    var attachItem = attachments[i];
                    var attPath = attachItem.AttPath;
                    var attNum = attachItem.AttNum;
                    var objid = attachItem.ObjectID;
                    var attDesc = attachItem.AttDesc;
                    var type = attachItem.AttType;
                    var objname = attachItem.ObjectType;
                    var isUpLoad = attachItem.IsUpLoad;
                    if (isUpLoad == "0") {
                        upAttCount++;
                        upAttFileIdList.push(attNum);
                        if (attachlen == upAttCount) {
                            funUpEndMsg();
                        }
                    } else {
                        var options = new FileUploadOptions();
                        options.fileName = attPath.substr(attPath.lastIndexOf('/') + 1);
                        options.chunkedMode = false;
                        options.params = attachItem;
                        var url = MobileConfig.UploadAttachUrl + "?userid=" + userCode + "&password=" + password + "&attnum=" + attNum + "&id=" + objid + "&attpath=" + attPath + "&description=" + attDesc + "&type=" + type + "&objname=" + objname;
                        url = encodeURI(url);
                        ft.upload(attPath, url, function (res) {
                            upAttCount++;
                            var responseData = JSON.parse(res.response);
                            if (responseData.ResStatus == true) {
                                var payLoad = responseData.PayLoad;
                                upAttFileIdList.push(payLoad.AttNum);
                            } else {
                                upattAllOk = false;
                            }
                            if (attachlen == upAttCount) {
                                funUpEndMsg();
                            }
                        }, function (error) {
                            upattAllOk = false;
                            upAttCount++;
                            if (attachlen == upAttCount) {
                                funUpEndMsg();
                            }
                        }, options);
                    }
                }
            };

            var funUpEndMsg = function () {
                var titleMsg = "";
                if (upattAllOk == true) {
                    titleMsg += "上传附件成功";
                } else {
                    if (upattAllOk == false && upAttFileIdList.length > 0) {
                        titleMsg += "部分附件上传失败";
                    } else {
                        titleMsg += "上传附件失败";
                    }
                }
                app.alert(titleMsg, function () {
                    app.alert(titleMsg, function () {
                        if (upAttFileIdList.length > 0) {
                            _self.funDelAttFile(upAttFileIdList);
                        } else {
                            app.progress.stop();
                        }
                    });
                });
            };
            var attNums = attList.join("','");
            var sqlAttachmentText = "SELECT a.PWONum,a.AttNum,a.AttType,a.ObjectType,a.ObjectID,a.AttDesc,a.AttPath,a.IsUpLoad FROM AttFile a where a.AttNum in ('" + attNums + "')";
            var db = app.database.open(Common.WEIXIUDB);
            db.transaction(function (tx) {
                tx.executeSql(sqlAttachmentText, [], function (tx1, results) { attachments = Common.funConvertRowsJson(results); });
            }, function (error) { app.alert(error); }, function () {
                funUpAttach();
            });
        } else {
            app.alert("请选择要上传的附件");
        }
    }
};