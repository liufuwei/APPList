﻿//相关页面:
var SingleProcess = function () {

    this.PageParam = null;

    this.ProcessDic = new Dictionary();

    this.MutualInsPersons = new Array();

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);
};


SingleProcess.prototype = {
    funInitEvent: function () {
        var _self = this;

        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);

        $("#btnSaveProcess").click(function () {
            _self.funSaveProcess();
        });

        $("#mutualPersonsSelector").click(function () {
            _self.funSwitchPerson();
        });

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnFaultReport").click(function () {
            var faultObj = new Object();
            faultObj.RelationWONum = _self.PageParam["WONum"];
            Common.funLoad("faultReportCreate.html", faultObj);

        });

        $("#btnAddNote").click(function () {
            var wONum = _self.PageParam["WONum"];
            Common.funLoad("orderNote.html", {"WONum": wONum});

        });

        $("#btnOtherCheck").click(function () {
            var otherChkVal = $("#btnOtherCheck").attr("otherChkVal");
            _self.funSetOtherChkVal(otherChkVal);
        });

        $("#btnInputPerson").click(function () {
            $('#dlO').dialog("open");
        });
        $('#dlO').dialog({
            width: "80%",
            autoOpen: false,
            buttons: {
                '取消': function () {
                    this.close();
                },
                '登录': function () {
                    _self.funAddPerson($("#txtUserCode").val(), $("#txtPassWord").val());
                    $("#txtUserCode").val("");
                    $("#txtPassWord").val("");
                    this.close();
                }
            }
        }).dialog("data", "_wrap").addClass("dialog-btstyle").addClass("dialog-btstyle-button");

    },
    funAddPerson: function (usercode, password) {
        var _self = this;
        ///<summary>添加作业人员方法:void</summary>
        ///<param name="username" >作业人员的用户名</param>
        ///<param name="password">作业人员的密码</param>
        if (usercode && password) {
            var getSqlParam = new Object();
            getSqlParam.UserCode = usercode;
            getSqlParam.Password = b64_md5(password);
            SqlHelper.funGetData("User", function (rows1) {
                if (rows1.length == 0) {
                    app.alert("请输入正确的账号和密码");
                } else {
                    var insertSqlParamList = new Array();
                    var userObj = new Object();
                    userObj.UserNum = rows1[0].UserNum;
                    userObj.UserName = rows1[0].UserName;
                    userObj.UserCode = rows1[0].UserCode;
                    userObj.LoginTime = Common.funGetNowDate();
                    userObj.isAdd = "1";
                    insertSqlParamList.push(userObj);

                    //判断业务Users表里是否存在了
                    var newusersObjParam = new Object();
                    newusersObjParam.UserCode = usercode;
                    SqlHelper.funGetData("OPUsers", function (rows4) {
                        if (rows4.length >= 1) {
                            app.alert("已存在，无需再添加作业人员");
                        } else {
                            //插入业务Users表
                            SqlHelper.funInsertData("OPUsers", insertSqlParamList, function (rows2) {
                                app.alert("添加人员成功", function () {
                                    _self.MutualInsPersons.push({"key": userObj.UserCode, "value": userObj.UserName});
                                    _self.funSetMutualPerson();
                                });
                            });
                        }
                    }, newusersObjParam);
                }
            }, getSqlParam);
        } else {
            app.alert("账号或密码不能为空！");
        }


    },
    funSetMutualPerson: function () {
        var _self = this;
        var personlen = _self.MutualInsPersons.length;
        var item = _self.MutualInsPersons[personlen - 1];
        var key = item["key"];
        var value = item["value"];
        var mutuaPreCtr = $("#mutualPersonsSelector");
        mutuaPreCtr.text(value);
        mutuaPreCtr.attr("key", key);
    },
    funSwitchPerson: function () {
        var _self = this;
        var persons = _self.MutualInsPersons;
        var mutuaPreCtr = $("#mutualPersonsSelector");
        app.wheelSelect.oneSelect(persons,
            function (res) {
                var key = res["key"];
                var value = res["value"];
                mutuaPreCtr.text(value);
                mutuaPreCtr.attr("key", key);
            }, "", "请选择自检人员");
    },
    funInitUi: function () {
        var _self = this;
        var title = _self.PageParam["PageHeader"];
        if (title) {
            $("#pageTitle").text(title);
        }

        //获取作业人员
        SqlHelper.funGetData("OPUsers", function (rows) {
            for (var i = 0; i < rows.length; i++) {
                var item = rows[i];
                var userCode = item["UserCode"];
                var userName = item["UserName"];
                _self.MutualInsPersons.push({"key": userCode, "value": userName});
            }
            if (rows.length > 0) {
                var item1 = rows[0];
                var userCode1 = item1["UserCode"];
                var userName1 = item1["UserName"];
                var mutuaPreCtr = $("#mutualPersonsSelector");
                mutuaPreCtr.text(userName1);
                mutuaPreCtr.attr("key", userCode1);
            }
        });

        var wONum = _self.PageParam["WONum"];
        if (wONum) {
            var sql = "SELECT a.IsOtherCheck from OPOrders a  WHERE a.WONum='" + wONum + "' ";
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeQuery(db, sql, function (tx, results) {
                var isOtherCheck = "0";
                var rows = Common.funConvertRowsJson(results);
                if (rows.length > 0) {
                    isOtherCheck = rows[0]["IsOtherCheck"] || "0";
                }
                if (isOtherCheck == "0") {
                    $("#otherCheckText").text("请求他检");
                    $("#otherCheckText").removeClass("OtherChk");
                    $("#btnOtherCheck").attr("otherChkVal", "1");
                } else if (isOtherCheck == "1") {
                    $("#otherCheckText").text("取消他检");
                    $("#otherCheckText").addClass("OtherChk");
                    $("#btnOtherCheck").attr("otherChkVal", "0");
                }
            });
        }
    },

    funInitProcessData: function (containerId) {
        var _self = this;
        var orderRow = new Array();
        var orderPrcRow = new Array();
        var funDrawPoc = function () {
            var rows = orderPrcRow;
            var rowslen = rows.length;
            if (rowslen > 0) {
                var funCacheData = function (row) {
                    var itemObj = new Object();
                    itemObj.ProcedureNum = row["ProcedureNum"];
                    itemObj.IsKeyTask = row["IsKeyTask"];
                    itemObj.FormWay = row["FormWay"];
                    itemObj.OptionsValue = row["OptionsValue"];
                    itemObj.MaxValue = row["MaxValue"];
                    itemObj.MinValue = row["MinValue"];
                    itemObj.HasChildProcedure = row["HasChildProcedure"];
                    itemObj.ResultValue = row["ResultValue"];
                    itemObj.PredecessorTasks = row["PredecessorTasks"];
                    itemObj.PointName = row["PointName"];
                    itemObj._TempNo = row["_TempNo"];

                    var isPhotoGraph = row["IsPhotoGraph"];
                    itemObj.IsPhotoGraph = isPhotoGraph;
                    if (row["FormWay"].toLowerCase() != "b" || row["FormWay"].toLowerCase() != "c") {
                        if (isPhotoGraph == "1") {
                            itemObj.FormWay = "D";
                            row["FormWay"] = "D";
                        }
                    }

                    _self.ProcessDic.Add(itemObj.ProcedureNum, itemObj);
                };

                var procedureGroupList = new Array();
                var procedureList = new Array();

                var liHtml = "";
                for (var i = 0; i < rowslen; i++) {
                    var procedureGroup = rows[i]["ProcedureGroup"];
                    if ($.inArray(procedureGroup, procedureGroupList) == -1) {
                        procedureGroupList.push(procedureGroup);
                        var procedureItem = new Object();
                        procedureItem.GroupName = procedureGroup;
                        procedureItem.Items = new Array();
                        procedureList.push(procedureItem);
                    }
                    procedureList[procedureList.length - 1].Items.push(rows[i]);
                }

                var grouplen = procedureList.length;

                for (var j = 0; j < grouplen; j++) {
                    var groupName = procedureList[j]["GroupName"] || "设备工序";
                    liHtml += '<ul class="list-view list-view-head list-check" data-corner="all">';
                    liHtml += '<li>';
                    liHtml += '<div data-role="BTButton" mousedown="false" data-status="1">';
                    liHtml += ' <span class="btn-text">' + (j + 1) + '、' + groupName + '</span>';
                    liHtml += '</div>';
                    liHtml += '</li>';
                    var items = procedureList[j].Items;
                    var itemslen = items.length;
                    for (var k = 0; k < itemslen; k++) {
                        var item = items[k];
                        item._TempNo = (j + 1) + '.' + (k + 1); //临时编号
                        funCacheData(item);//缓存数据
                        var formWay = item["FormWay"].toLowerCase();
                        var procedureDesc = item["ProcedureDesc"];
                        var procedureNum = item["ProcedureNum"];
                        var resultValue = item["ResultValue"];
                        var isKeyTask = item["IsKeyTask"];
                        var pointName = item["PointName"];
                        var techStandard = item["TechStandard"] || "";
                        liHtml += '<li>';

                        liHtml += '<div id="Item' + procedureNum + '" data-role="BTButton" mousedown="false" mouseup="false" >';
                        liHtml += '<div class="row-box">';
                        liHtml += '<div class="span1 label" >';
                        liHtml += ' <div class="procDesc"  handler="TechStandardMsg" ordNum="' + (j + 1) + '.' + (k + 1) + '" TechStandard="' + techStandard + '" >';
                        liHtml += (j + 1) + '.' + (k + 1) + ' ' + procedureDesc;
                        if (pointName) {
                            liHtml += '[单位:' + pointName + ']';
                        }
                        if (isKeyTask == "1") {
                            liHtml += '<img src="bingoTouch/css/images/KeyProcess.png"/>';
                        }
                        switch (formWay) {
                            case "d": {
                                liHtml += '<img src="bingoTouch/css/images/camera.png"/> ';
                            }
                                break;
                            case "e": {
                                liHtml += '<img src="bingoTouch/css/images/audio.png"/> ';
                            }
                                break;
                            case "f": {
                                liHtml += '<img src="bingoTouch/css/images/video.png"/> ';
                            }
                                break;
                        }
                        liHtml += '</div>';

                        liHtml += '</div>';
                        //begin
                        liHtml += ' <div class="sinPromh">';
                        //A:单选，B:测量值，C:文本框,D:单选+拍照,E:单选+录音,F:单选+录像
                        switch (formWay) {
                            case "b": {
                                if (resultValue) {
                                    liHtml += '<input id=' + procedureNum + ' value=' + resultValue + '  type="number" class="singInput" />';
                                } else {
                                    liHtml += '<input id=' + procedureNum + '  type="number" class="singInput" />';
                                }
                            }
                                break;
                            case "c": {
                                if (resultValue) {
                                    liHtml += '<textarea rows="3" cols="20" id=' + procedureNum + '/>' + resultValue + '</textarea>';
                                } else {
                                    liHtml += '<textarea rows="3" cols="20" id=' + procedureNum + '></textarea>';//class="singInput"
                                }
                            }
                                break;
                            default: {
                                var optionsValue = item["OptionsValue"].split(';');
                                var optionslen = optionsValue.length;
                                for (var l = 0; l < optionslen; l++) {
                                    var optionVal = optionsValue[l];
                                    if (optionVal == resultValue) {
                                        liHtml += '<div id=' + procedureNum + "_" + l + '  name=' + procedureNum + ' data-role="BTRadio" value="' + optionsValue[l] + '" class="BTCheck_ON" >' + optionsValue[l] + '</div>';
                                    } else {
                                        liHtml += '<div id=' + procedureNum + "_" + l + '  name=' + procedureNum + ' data-role="BTRadio" value="' + optionsValue[l] + '" >' + optionsValue[l] + '</div>';
                                    }
                                }
                            }
                                break;
                        }
                        liHtml += '<div id="errorMsg' + procedureNum + '" class="inputEro"></div>';
                        liHtml += '</div>';
                        liHtml += '</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                    }

                    liHtml += '</ul>';
                }

                if (liHtml) {
                    var cnt = document.getElementById(containerId);
                    if (cnt) {
                        //liwch 添加换行，最后一行看不见问题
                        cnt.innerHTML = liHtml + "<br/><br/><br/><br/><br/><br/><br/>";
                        ui.init();
                        _self.funBindEvent();
                        setTimeout(function () {
                            _self.funInitPosition();
                        }, 600);
                    }
                }
            }
        };
        var funInitActDate = function () {
            var rowlen = orderRow.length;
            if (rowlen > 0) {
                var actStart = orderRow[0]["ActStart"];
                var actFinish = orderRow[0]["ActFinish"];
                if (actStart) {
                    var actStarts = actStart.split(" ");
                    $("#time_ActStartDate").btdatepicker("val", actStarts[0]);
                    $("#time_ActStartTime").btdatepicker("val", actStarts[1].substring(0, actStarts[1].lastIndexOf(":")));
                }
                if (actFinish) {
                    var actFinishs = actFinish.split(" ");

                    $("#time_ActFinishDate").btdatepicker("val",actFinishs[0]);
                    $("#time_ActFinishTime").btdatepicker("val",actFinishs[1].substring(0, actFinishs[1].lastIndexOf(":")));
                }
            }
        };
        var wONum = _self.PageParam["WONum"];
        var sqlOrderText = "SELECT ActStart,ActFinish from OPOrders where WONum='" + wONum + "'";
        var sqlOrderPrcText = "SELECT * FROM OrderProcedure where UppLayerProcedureNum='' and WONum='" + wONum + "'  ORDER BY SortNum-0 asc";
        //WO-20180123-0001
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            tx.executeSql(sqlOrderText, [], function (tx1, results) {
                orderRow = Common.funConvertRowsJson(results);
            });
            tx.executeSql(sqlOrderPrcText, [], function (tx1, results) {
                orderPrcRow = Common.funConvertRowsJson(results);
            });
        }, function (error) {
            app.alert(error);
        }, function () {
            funDrawPoc();
            funInitActDate();
        });

    },

        funInitPosition: function () {
        var _self = this;
        var param = _self.PageParam;
        var positionId = param["positionId"];
        if (positionId) {
            var positionCnt = document.getElementById(positionId);
            if (positionCnt) {
                positionCnt.scrollIntoView(false);
            }
        }
    },

    funBindEvent: function () {
        var _self = this;

        var processDic = _self.ProcessDic;
        var arrVals = processDic.Values();
        var valsLen = arrVals.length;
        for (var i = 0; i < valsLen; i++) {
            var item = arrVals[i];
            var ctrId = item["ProcedureNum"];
            var formWay = item["FormWay"].toLowerCase();
            if (formWay == "b" || formWay == "c") {
                $("#" + ctrId).on("blur", function () {
                    var ctr = $(this);
                    var procedureNum = ctr.attr("id");
                    var isPrePass = _self.funPreVerify(procedureNum);
                    if (isPrePass) {
                        var resultValue = ctr.val();
                        _self.funTextItem(procedureNum, resultValue);
                    } else {
                        ctr.val("");
                    }
                });
            } else {
                var optionslen = item["OptionsValue"].split(";").length;
                for (var j = 0; j < optionslen; j++) {
                    $("#" + ctrId + "_" + j).click(function () {
                        var ctr = $(this);
                        var cntId = ctr.attr("id");
                        var numAndposition = cntId.split("_");
                        var procedureNum = numAndposition[0];
                        var positionNum = numAndposition[1];
                        var resultValue = ctr.btcheck("val").value;
                        var isPrePass = _self.funPreVerify(procedureNum);
                        if (isPrePass) {
                            var curPageParam = _self.PageParam;
                            curPageParam["positionId"] = cntId;
                            Common.funUpdateCurrentPageparam(curPageParam);
                            _self.funRadioItem(procedureNum, resultValue, positionNum);
                        } else {
                            ctr.removeClass('BTCheck_ON');
                        }
                    });

                    $("#" + ctrId + "_" + j).longTap(function () {
                        var ctr = $(this);
                        app.confirm("确认清除所选工序的结果?", function (index) {
                            if (index == 2) {
                                var numAndposition = ctr.attr("id").split("_");
                                var procedureNum = numAndposition[0];
                                _self.funSingleRowSave(procedureNum, "");
                                ctr.removeClass('BTCheck_ON');
                                var procItem = _self.ProcessDic.Item(procedureNum);
                                procItem.ResultValue = "";
                            }
                        }, "清除确认提示", "取消,确定");
                    });
                }
            }
        }

        $("#divProcesslist div[handler='TechStandardMsg']").click(function () {
            var desc = $(this).attr("TechStandard") || "暂无工序技术标准描述";
            var ordNum = $(this).attr("ordNum");

            app.alert(desc, function () {
            }, ordNum + "工序技术标准", "关闭");
        });
    },

    funTextItem: function (procedureNum, resultValue) {
        var _self = this;
        var item = _self.ProcessDic.Item(procedureNum);
        var formWay = item["FormWay"].toLowerCase();
        var isSave = true;
        if (resultValue) {
            if (formWay == "b") {
                $("#errorMsg" + procedureNum).text("");
                if (isNaN(resultValue)) {
                    $("#errorMsg" + procedureNum).text("数值格式填写有误");
                    isSave = false;
                } else {
                    var minValue = item["MinValue"] - 0;
                    var maxValue = item["MaxValue"] - 0;
                    if (!(minValue == 0 && maxValue == 0)) {
                        var resultVal = resultValue - 0;
                        if (resultVal < minValue || resultVal > maxValue) {
                            $("#errorMsg" + procedureNum).text("填入数据范围有误,已超出最小值与最大值的范围[" + minValue + "至" + maxValue + "]");
                        }
                    }
                }
            }
        }
        if (isSave) {
            item.ResultValue = resultValue;
            _self.funSingleRowSave(procedureNum, resultValue);
        }
    },

    funRadioItem: function (procedureNum, resultValue, positionNum) {
        var _self = this;
        var item = _self.ProcessDic.Item(procedureNum);
        var optionsValue = item["OptionsValue"];
        var optionslen = optionsValue.split(";").length;
        var hasChildProced = item["HasChildProcedure"];
        var url = "nextProcess.html";

        var pageParam = new Object();
        pageParam["UppLayerProcedureNum"] = procedureNum;
        pageParam["ResultValue"] = resultValue;

        if ((positionNum - 0 + 1) == optionslen && hasChildProced == "1" && false) { //说明是最后个按钮 屏蔽，长沙维修项目不使用
            pageParam["WONum"] = _self.PageParam["WONum"];
            Common.funLoad(url, pageParam);
        } else {
            //TODO FormWay是什么？
            var formWay = item["FormWay"].toLowerCase();
            switch (formWay) {
                case "a": {
                    item.ResultValue = resultValue;
                    _self.funSingleRowSave(procedureNum, resultValue);
                }
                    break;
                case "d": {
                    if ((positionNum - 0) == 0) {
                        url = "processphoto.html";
                        Common.funLoad(url, pageParam);
                    } else {
                        item.ResultValue = resultValue;
                        _self.funSingleRowSave(procedureNum, resultValue);
                    }
                }
                    break;
                case "f": {
                    if ((positionNum - 0) == 0) {
                        url = "processpVideo.html";
                        Common.funLoad(url, pageParam);
                    } else {
                        item.ResultValue = resultValue;
                        _self.funSingleRowSave(procedureNum, resultValue);
                    }
                }
                    break;
                case "e": {
                    if ((positionNum - 0) == 0) {
                        url = "processpAudio.html";
                        Common.funLoad(url, pageParam);
                    } else {
                        item.ResultValue = resultValue;
                        _self.funSingleRowSave(procedureNum, resultValue);
                    }
                }
                    break;
                default:
                    app.alert("未知类型");
                    break;
            }
        }
    },

    funSingleRowSave: function (procedureNum, resultValue) {
        var sqlParam = new Object();
        sqlParam.ResultValue = resultValue;
        sqlParam.SelfFormUserName = $("#mutualPersonsSelector").text();
        sqlParam.SelfFormUserCode = $("#mutualPersonsSelector").attr("key");
        sqlParam.SelfFormTime = Common.funGetNowDate();
        sqlParam.WhereParam = new Object();
        sqlParam.WhereParam.ProcedureNum = procedureNum;
        SqlHelper.funUpdateData("OrderProcedure", [sqlParam]);
    },

    funSaveProcess: function () {
        var _self = this;
        app.progress.start("提示", "正在处理中...");
        setTimeout(function () {
            var completeOneOfSumit = true; //是否启用一次性提交
            var completeKeyProcessSumit = true;//关键工序是否填写整
            var defaultSaveItemList = new Array(); //允许默认保存，但又填报的数据
            var processDic = _self.ProcessDic;
            var arrVals = processDic.Values();
            var valsLen = arrVals.length;
            for (var i = 0; i < valsLen; i++) {
                var item = arrVals[i];
                var resultValue = item["ResultValue"];
                var isKeyTask = item["IsKeyTask"];
                var procedureNum = item["ProcedureNum"];
                if (resultValue == "") { //说明还没填写

                    $("#Item" + procedureNum).addClass("unfih");
                    var formWay = item["FormWay"].toLowerCase();

                    if (formWay == "b" || formWay == "c") {
                        completeKeyProcessSumit = false;
                    } else {
                        if (isKeyTask == "1") {
                            completeKeyProcessSumit = false;
                        } else {
                            completeOneOfSumit = false;

                            defaultSaveItemList.push(procedureNum);
                        }
                    }
                } else {
                    $("#Item" + procedureNum).removeClass("unfih");
                }
            }
            app.progress.stop();
            if (completeOneOfSumit == false && defaultSaveItemList.length > 0) {
                app.confirm("存在工序未填报结果,未填报的是否通过一次性提交", function (index) {
                    if (index == 2) {
                        _self.funSetDefaultOption(defaultSaveItemList, function () {
                            if (completeKeyProcessSumit == true) { //说明关键工序已全部填写完成.
                                _self.funChangeStatus();
                            } else {
                                app.alert("存在关键工序未填报完，请手工输入完成后再提交");
                            }
                        });
                    }
                }, "提示", "取消,确定");

            } else if (completeKeyProcessSumit == false) {
                app.alert("存关键工序未填报完，请手工输入完成后再提交");
            } else {
                _self.funChangeStatus();
            }
        }, 1500);
    },

    funSetDefaultOption: function (defaultSaveItemList, successfun) {
        var _self = this;
        var processDic = _self.ProcessDic;
        var itemlen = defaultSaveItemList.length;
        var sqlParamList = new Array();
        for (var i = 0; i < itemlen; i++) {
            var procedureNum = defaultSaveItemList[i];
            var cnt = $("#" + procedureNum + "_" + 0);
            var resultValue = cnt.attr("value");
            cnt.removeClass('BTCheck_OFF').addClass('BTCheck_ON');

            $("#Item" + procedureNum).removeClass("unfih");

            var sqlParam = new Object();
            sqlParam.ResultValue = resultValue;
            sqlParam.SelfFormUserName = $("#mutualPersonsSelector").text();
            sqlParam.SelfFormUserCode = $("#mutualPersonsSelector").attr("key");
            sqlParam.SelfFormTime = Common.funGetNowDate();
            sqlParam.WhereParam = new Object();
            sqlParam.WhereParam.ProcedureNum = procedureNum;
            sqlParamList.push(sqlParam);
            processDic.Item(procedureNum).ResultValue = resultValue;
        }
        SqlHelper.funUpdateData("OrderProcedure", sqlParamList, successfun);
    },

    funChangeStatus: function () {
        var _self = this;
        var dtNow = new Date();
        var now = new Date(dtNow.getTime() + 60 * 1000);
        var curDate = now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + " " + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
        var actStart = _self.funGetDatepicker("time_ActStartDate", "time_ActStartTime");
        var actFinish = _self.funGetDatepicker("time_ActFinishDate", "time_ActFinishTime");
        var retVal = Common.funCompareDate(actFinish, actStart);
        if (retVal) {
            var sqlParamList = new Array();
            var sqlParam = new Object();
            sqlParam.SelfFormIsFinished = "1";
            sqlParam.SelfFormFinishTime = Common.funGetNowDate();
            sqlParam.SelfFormUserName = $("#mutualPersonsSelector").text();
            sqlParam.SelfFormUserCode = $("#mutualPersonsSelector").attr("key");
            sqlParam.ActStart = actStart;
            sqlParam.ActFinish = actFinish;
            sqlParam.WhereParam = new Object();
            sqlParam.WhereParam.WONum = _self.PageParam["WONum"];
            sqlParamList.push(sqlParam);
            SqlHelper.funUpdateData("OPOrders", sqlParamList, function () {
                Common.funGoBack();
            });
        } else {
            app.alert("实际完成时间需大于实际开始时间");
        }
    },

    funGetDatepicker: function (dateId, timeId) {
        ///<summary>获取日期</summary>
        ///<param name="dateId">日期主键</param>
        ///<param name="timeId">时间主键</param>
        var dateTimeValue = '';
        var dateValue = $("#" + dateId).btselect("val").value;
        var timeValue = $("#" + timeId).btselect("val").value;
        if (dateValue != "" && timeValue != "") {
            dateTimeValue = dateValue + " " + timeValue + ":0";
        }
        ;
        return dateTimeValue;
    },

    funPreVerify: function (procedureNum) {
        var _self = this;

        var isPass = true;
        var titleMsg = new Array();

        if (procedureNum) {
            var processDic = _self.ProcessDic;
            var procItem = processDic.Item(procedureNum);
            if (procItem) {
                var preTasks = procItem["PredecessorTasks"] || "";
                if (preTasks) {
                    var tasks = preTasks.split(",");
                    var tasklen = tasks.length;
                    for (var i = 0; i < tasklen; i++) {
                        var preProcNum = tasks[i];
                        var item = processDic.Item(preProcNum);
                        if (item) {
                            var resultValue = item["ResultValue"] || "";
                            if (resultValue == "") {
                                isPass = false;
                                titleMsg.push(item["_TempNo"]);
                            }
                        }
                    }
                }
            }
        }
        if (isPass == false) {
            app.alert("请先检查[" + titleMsg.join("\n") + "]条工序");
        }
        return isPass;
    },

    funSetOtherChkVal: function (otherChkVal) {
        var _self = this;
        var wONum = _self.PageParam["WONum"];
        var sqlUpdOpOrders = "UPDATE OPOrders set IsOtherCheck='" + otherChkVal + "' where WONum='" + wONum + "'";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(db, [sqlUpdOpOrders], function () {
            var titleMsg = (otherChkVal == "0") ? "该工单已取消他检请求" : "该工单已设置为需要他检";
            app.alert(titleMsg, function () {
                if (otherChkVal == "0") {
                    $("#otherCheckText").text("请求他检");
                    $("#otherCheckText").removeClass("OtherChk");
                    $("#btnOtherCheck").attr("otherChkVal", "1");
                } else {
                    $("#otherCheckText").text("取消他检");
                    $("#otherCheckText").addClass("OtherChk");
                    $("#btnOtherCheck").attr("otherChkVal", "0");
                }
            });
        });
    },
    funBackRefresh: function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var pageName = retParam["pageName"];
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("SingleProcess.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funInitUi();
            _self.funInitProcessData("divProcesslist");
        }, 100);
    }

};










