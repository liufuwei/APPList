﻿﻿//移动终端配置信息
var MobileConfig = {};

var _homeUrl = "http://dtyy.xzdtjt.com:8095/";//徐州正式环境
//var _homeUrl = "http://dtyy.xzdtjt.com:8098//";//徐州测试环境
var _preUrl = _homeUrl;

var _preUrlM = _preUrl+"/Home/Api";

var _preUrlUpload = _preUrl+"/Home/UploadFile";

//服务端下载工单Url
MobileConfig.DownWorkUrl = _preUrlM;

//获取下载单状态
MobileConfig.GetDownWkStatusUrl = _preUrlM;

//下载基础数据
MobileConfig.DownBaseDataUrl = _preUrlM;

//上传单传地址
MobileConfig.UploadWorkUrl = _preUrlM;

//上传故障
MobileConfig.UploadFaultUrl = _preUrlM;

//上传
MobileConfig.UploadAttachUrl = _preUrlUpload;

//更改密码Url
MobileConfig.ChangePwdUrl = _preUrlM;

//软件版本检测
MobileConfig.Misc_CheckVersion = _preUrlM;

//上传系统日志
MobileConfig.UploadSysLog = _preUrlM;

//故障工单响应
MobileConfig.FaultWOReply = _preUrlM;

//检查重复上传工单
MobileConfig.ChkOrderRepeatSubmit = _preUrlM;

MobileConfig.CmDownLoad = _preUrlM;

//设备履历工单
MobileConfig.DownFetchLocationDevices = _preUrlM;

//下载新版本     
MobileConfig.UpdateApp = _preUrl;
