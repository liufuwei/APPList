﻿var Safety = function () {
    this.StartWkList = new Array();

    (function (_this) {
        app.getGlobalVariable("startWkList", function (res) {
            if (res) {
                _this.StartWkList = JSON.parse(res);
            }
        });
    })(this);

    this.SafetyNumList = new Array();
};

Safety.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnLogOut").click(function () {
            Common.funLoadMain();
        });


        $("#btnSaveProcess").click(function () {
            var isPass = _self.funVerificationData();
            if (isPass) {
                _self.funSaveSafe();
            } else {
                app.alert("请先逐条阅读安全注意事项,确认区域是否已接管,确认安全措施是否落实");
            }
        });
    },
    funInitSafetyData: function (containerId) {
        var _self = this;
        var sqlWhere = "";
        var leng = _self.StartWkList.length;
        for (var k = 0; k < leng; k++) {
            if ((k + 1) == leng) {
                sqlWhere += " PWONum='" + _self.StartWkList[k].PWONum + "' ";
            } else {
                sqlWhere += " PWONum='" + _self.StartWkList[k].PWONum + "' or";
            }
        }
        if (leng > 0) {
            var safetyItem = new Array();
            var safetyMain = new Object();
            var opPlans = new Array();
            var areasTags = new Array();
            var sqlSafetytxt = "SELECT  * from OPSafety where " + sqlWhere + " ORDER BY OPSafetyClass,OPsafetySec";
            var sqlSafetyMaintxt = "select * from OPSafetyMain where " + sqlWhere;
            var sqlPlantxt = "select OPName,OPCode from OPPlan where " + sqlWhere;
            var sqlAreasTagtxt = " SELECT AreaName from OPAreasTags where " + sqlWhere;
            var db = app.database.open(Common.WEIXIUDB);
            db.transaction(function (tx) {
                tx.executeSql(sqlSafetytxt, [], function (tx1, results) {
                    var rows = Common.funConvertRowsJson(results);
                    var rowlen = rows.length;
                    for (var i = 0; i < rowlen; i++) {
                        var row = rows[i];
                        var safetyNum = row["OPSafetyNum"];
                        var isConfirm = row["IsConfirm"];
                        if (safetyNum) {
                            var position = -1;
                            var safetylen = safetyItem.length;
                            for (var j = 0; j < safetylen; j++) {
                                if (safetyItem[j]["OPSafetyNum"] == safetyNum) {
                                    position = j;
                                    if (isConfirm == "0") {
                                        safetyItem[j]["IsConfirm"] = "0";
                                    }
                                    break;
                                }
                            }
                            if (position == -1) {
                                safetyItem.push(row);
                            }
                        }
                    }
                });
                tx.executeSql(sqlSafetyMaintxt, [], function (tx1, results) {
                    var rows = Common.funConvertRowsJson(results);
                    var rowlen = rows.length;
                    for (var i = 0; i < rowlen; i++) {
                        var row = rows[i];
                        if (i == 0) {
                            safetyMain = row;
                        } else {
                            var isTakeover = row["IsTakeover"];
                            var isConfirm = ["IsConfirm"];

                            if (isTakeover == "0") {
                                safetyMain.IsTakeover = "0";
                            }

                            if (isConfirm == "0") {
                                safetyMain.IsTakeover = "0";
                            }
                        }
                    }
                });
                tx.executeSql(sqlPlantxt, [], function (tx1, results) {
                    opPlans = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlAreasTagtxt, [], function (tx1, results) {
                    var rows = Common.funConvertRowsJson(results);
                    var rowlen = rows.length;
                    for (var i = 0; i < rowlen; i++) {
                        var row = rows[i];
                        var areaName = row["AreaName"];
                        if (areaName) {
                            var position = $.inArray(areaName, areasTags);
                            if (position == -1) {
                                areasTags.push(areaName);
                            }
                        }
                    }
                });

            }, function (error) {
                app.alert(error);
            }, function () {
                var dataItem = new Object();
                dataItem.SafetyItem = safetyItem;
                dataItem.SafetyMain = safetyMain;
                dataItem.OpPlans = opPlans;
                dataItem.AreasTags = areasTags;

                _self.funDrawSafeDataUi(containerId, dataItem);

            });
        }
    },

    funDrawSafeDataUi: function (containerId, dataItem) {
        var _self = this;
        var liHtml = "";
        var funDrawSafatyItem = function () {
            var safatylen = dataItem.SafetyItem.length;
            var safeClass = "";
            if (safatylen > 0) {
                for (var i = 0; i < safatylen; i++) {
                    var safatyItem = dataItem.SafetyItem[i];
                    var safetyNum = safatyItem["OPSafetyNum"];
                    if (safeClass != safatyItem["OPSafetyClass"]) {
                        safeClass = safatyItem["OPSafetyClass"];
                        if (safeClass) {
                            liHtml += '<li>';
                            liHtml += '<div class="row-box">';
                            liHtml += '<b>' + safeClass + '</b>';
                            liHtml += '</div>';
                            liHtml += '</li>';
                        }
                    }
                    liHtml += '<li>';
                    liHtml += '<div data-role="BTButton" data-status="1">';
                    liHtml += '<span class="btn-text">';
                    liHtml += '<div class="row-box">';
                    if (safatyItem["IsConfirm"] == "1") {
                        liHtml += '<div id="chk' + safetyNum + '" data-role="BTCheck" data-inline="false" class="BTCheck_ON"  >' + safatyItem["OPSafetyDesc"] + '</div>';
                    } else {
                        liHtml += '<div id="chk' + safetyNum + '" data-role="BTCheck" data-inline="false">' + safatyItem["OPSafetyDesc"] + '</div>';
                    }
                    liHtml += '</div>';
                    liHtml += '</span>';
                    liHtml += '</div>';
                    liHtml += '</li>';
                    _self.SafetyNumList.push(safetyNum);
                }
            }
        };
        var funDrawTakeover = function () {
            var isTakeover = dataItem.SafetyMain["IsTakeover"] || "0";
            liHtml += '<li>';
            liHtml += '<div class="row-box">';
            liHtml += '<b>二,本作业区域是否已接管&nbsp;&nbsp;&nbsp;&nbsp;</b>';
            if (isTakeover == "1") {
                liHtml += '<div id="divTakeover" name="IsTakeover" data-role="BTRadio" data-inline="false"  class="BTCheck_ON" >是</div>';
            } else {
                liHtml += '<div id="divTakeover" name="IsTakeover" data-role="BTRadio" data-inline="false" >是</div>';
            }
            liHtml += '&nbsp;&nbsp;';
            if (isTakeover == "0") {
                liHtml += '<div name="IsTakeover" data-role="BTRadio" data-inline="false" class="BTCheck_ON" >否</div>';
            } else {
                liHtml += '<div name="IsTakeover" data-role="BTRadio" data-inline="false">否</div>';
            }
            liHtml += '</div>';
            liHtml += '</li>';
            liHtml += '<li>';
            liHtml += '<div class="row-box">';
            liHtml += '<b>若作业范围位于未接管区域,注意:</b>';
            liHtml += '</div>';
            liHtml += ' </li>';
            liHtml += '<li>';
            liHtml += '<div class="row-box">&nbsp;&nbsp;1.因作业性质仍属于施工行为,由建设单位及施工承包单位对本施工过程的质量负责.</div>';
            liHtml += '</li>';
            liHtml += '<li>';
            liHtml += '<div class="row-box">&nbsp;&nbsp;2.施工单位应尊守国家相关安全法规,施工期间不得影响运营已接管区域的设备质量,安全.</div>';
            liHtml += '</li>';
            liHtml += '<li>';
            liHtml += '<div class="row-box">&nbsp;&nbsp;3.若需要进入已管理区域,施工单位需提前与运营沟通,协调.</div>';
            liHtml += '</li>';
        };
        var funDrawPlanAndArea = function () {
            var opPlans = dataItem.OpPlans;
            var opPlanlen = dataItem.OpPlans.length;
            var oPNames = new Array();
            var opCodes = new Array();
            for (var j = 0; j < opPlanlen; j++) {
                var opPlan = opPlans[j];
                oPNames.push(opPlan["OPName"]);
                opCodes.push(opPlan["OPCode"]);
            }

            liHtml += '<li>';
            liHtml += '<div class="row-box">';
            liHtml += '<b>三,本作业的情况</b>';
            liHtml += '</div>';
            liHtml += '</li>';
            liHtml += '<li>';
            liHtml += '<div class="row-box">&nbsp;&nbsp;<b>作业名称</b>:&nbsp;&nbsp;' + oPNames.join(",") + '</div>';
            liHtml += '</li>';
            //liHtml += '<li>';
            //liHtml += '<div class="row-box">&nbsp;&nbsp;<b>作业令</b>:&nbsp;&nbsp;' + opCodes.join(",") + '</div>';
            //liHtml += '</li>';
            //liHtml += ' <li>';
            //liHtml += ' <div class="row-box">&nbsp;&nbsp;<b>作业地点及部位</b>:&nbsp;&nbsp;' + dataItem.AreasTags.join(",") + '</div>';
            //liHtml += '</li>';
        };
        var funDrawConfirm = function () {
            var isConfirm = dataItem.SafetyMain["IsConfirm"] || "0";
            liHtml += ' <li>';
            liHtml += '<div class="row-box">';
            liHtml += '<b>四,作业安全措施是否已经落实&nbsp;&nbsp;&nbsp;&nbsp;</b>';
            if (isConfirm == "1") {
                liHtml += '<div id="divConfirm"  name="IsConfirm" data-role="BTRadio" data-inline="false"  class="BTCheck_ON"  >是</div>';
            } else {
                liHtml += '<div id="divConfirm"  name="IsConfirm" data-role="BTRadio" data-inline="false">是</div>';
            }
            liHtml += ' &nbsp;&nbsp;';
            if (isConfirm == "0") {
                liHtml += '<div  name="IsConfirm" data-role="BTRadio" data-inline="false"  class="BTCheck_ON" >否</div>';
            } else {
                liHtml += '<div  name="IsConfirm" data-role="BTRadio" data-inline="false">否</div>';
            }
            liHtml += '</div>';
            liHtml += '</li>';
        };
        funDrawSafatyItem();
        funDrawTakeover();
        funDrawPlanAndArea();
        funDrawConfirm();
        var cnt = document.getElementById(containerId);
        if (cnt) {
            cnt.innerHTML += liHtml;
            ui.init();
        }
    },

    funSaveSafe: function () {
        var _self = this;
        var isConfim = "0";
        var isTakeover = "0";
        var confirm = $("#divConfirm").btcheck("val");
        if (confirm) {
            isConfim = "1";
        }
        var takeover = $("#divTakeover").btcheck("val");
        if (takeover) {
            isTakeover = "1";
        }

        var confirmTime = Common.funGetNowDate();

        var safetyItems = new Array();
        var safetylen = _self.SafetyNumList.length;
        for (var i = 0; i < safetylen; i++) {
            var safetyNum = _self.SafetyNumList[i];
            var itemConfirm = $("#chk" + safetyNum).btcheck("val");
            if (itemConfirm) {
                safetyItems.push({"OPSafetyNum": safetyNum, "IsConfirm": "1"});
            } else {
                safetyItems.push({"OPSafetyNum": safetyNum, "IsConfirm": "0"});
            }
        }

        var sqlTextList = new Array();
        var leng = _self.StartWkList.length;
        for (var k = 0; k < leng; k++) {
            var wkItem = _self.StartWkList[k];
            var pWonum = wkItem.PWONum;
            var safetyMainNum = Common.funGetPkId();
            var delSafetyMaintxt = "DELETE FROM  OPSafetyMain where PWONum='" + pWonum + "'";
            sqlTextList.push(delSafetyMaintxt);

            var intSafetyMainTxt = "INSERT INTO OPSafetyMain(PWONum,IsTakeover,IsConfirm,ConfirmTime,SafetyMainNum)VALUES('" + pWonum + "','" + isTakeover + "','" + isConfim + "','" + confirmTime + "','" + safetyMainNum + "')";
            sqlTextList.push(intSafetyMainTxt);
            for (var j = 0; j < safetylen; j++) {
                var safetyItem = safetyItems[j];
                var updSafetytxt = "UPDATE OPSafety set IsConfirm='" + safetyItem["IsConfirm"] + "',SafetyMainNum='" + safetyMainNum + "' where OPSafetyNum='" + safetyItem["OPSafetyNum"] + "' and PWONum='" + pWonum + "'";
                sqlTextList.push(updSafetytxt);
            }
        }
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(db, sqlTextList, function () {
            Common.funLoad("eqlist.html");
        });
    },

    funVerificationData: function () {
        var _self = this;
        var isPass = true;
        var confirm = $("#divConfirm").btcheck("val");
        if (!confirm) {
            isPass = false;
        }
        if (isPass) {
            var takeover = $("#divTakeover").btcheck("val");
            if (!takeover) {
                isPass = false;
            }
        }
        if (isPass) {
            var safetylen = _self.SafetyNumList.length;
            for (var i = 0; i < safetylen; i++) {
                var safetyNum = _self.SafetyNumList[i];
                var itemConfirm = $("#chk" + safetyNum).btcheck("val");
                if (!itemConfirm) {
                    isPass = false;
                    break;
                }
            }
        }
        return isPass;
    },
    funBackRefresh : function () {
        var _self = this;
        app.getGlobalVariable("startWkList", function (res) {
            if (res) {
                _self.StartWkList = JSON.parse(res);
            }
        });

        setTimeout(function () {
            app.refresh();
        }, 100);
    }
};

