﻿var FaultHandle = function () {
    this.PageParam = null;
    this.PWONumList = new Array();
    this.PWOSimple = new Array();
    this.OPOrdersDic = new Dictionary();
    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);
};

FaultHandle.prototype = {

    funInitEvent: function () {
        var _self = this;
        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnDownload").click(function () {
            _self.funDownWorkNew();
            //choice.funStartWork(choice);
        });
        $("#tab1").click(function () {
            var isHas = $("#tab1").hasClass("btn-active");
            if (isHas == false) {
                $("#serverList").css("display", "");
                $("#btnDownload").css("display", "");
                $("#localList").css("display", "none");
            }
        });

        $("#tab2").click(function () {
            var isHas = $("#tab2").hasClass("btn-active");
            if (isHas == false) {
                $("#localList").css("display", "");
                $("#serverList").css("display", "none");
                $("#btnDownload").css("display", "none");
            }
        });

        $("#btnLogOut").click(function () {
            Common.funLoadMain();
        });

        var funCode = function (res) {
            if (res) {
                switch (res["TagType"]) {    
                    case "L"://设备的位置标签      
                        _self.funChoicePlan("L"+res["TagCode"]);
                        break;
                    default:
                        _self.funChoicePlan(res["TagCode"]);
                        break;
                }
            } else {
                navigator.notification.vibrate(2000);
                app.alert("未知标签！类型：" + res["TagType"] + ",识别编码：" + res["TagCode"]);
            }
        };

        $("#btnBarCode").click(function () {
            Common.getBarcode(function (res) {
                funCode(res);
            }, function () {
                navigator.notification.vibrate(2000);
                app.alert("app扫描二维码，无法获取数据！");
            });
        });


        app.setting.get("bluetooth_key", "", function (rest) {
            if (rest) {
                setInterval(function () {
                    app.getGlobalVariable("bluetoothIsConnected", function (isCon) {
                        if (isCon == "F") {   //F ==失
                            app.bluetooth.connect(rest);
                        } else if (isCon == "S") { //成功
                            var res = window.bluetoothValue;
                            if (res) {
                                window.bluetoothValue = "";
                                var convertCode = Common.funConvertCode(res);
                                funCode(convertCode);
                            }
                        } else if (isCon == "H") { //正在连接请等待

                        }
                    });
                }, 1000);
            }
        });
    },
    funGetDownParam: function () {
        var downParam = new Object();

        app.getGlobalVariable("IsOutSourceUser", function (res) {
            downParam.IsOutUser = res || "0";
        });

        //downParam.OrderDate = Common.funTodayDate();
        downParam.OrderDate = "2017-09-20";
        app.getGlobalVariable("UnitOrgNum", function (res) {
            if (res) {
                downParam.UnitID = res;
            }
        });
        downParam.OutOrderCheck = "0";
        downParam.IncludeUnMutCheck = "0";
        downParam.WorkType = "CM";

        return downParam;
    },
    funSaveDownWork: function (planList, isPcDown) {
        var _self = this;
        var sqlPlanText = "select OPCode,OPName,PWONum,WorkStatus from OPPlan order by WorkStatus asc";
        var db = app.database.open(Common.WEIXIUDB);
        var attFiles = new Array();
        var acthSavePath = "";
        var savePlanOrderCount = 0;

        app.database.executeQuery(db, sqlPlanText, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowlen = rows.length;
            var orderlen = planList.length;
            var planOrders = new Array();
            var exitsPlans = new Array();
            for (var i = 0; i < orderlen; i++) {
                var planOrder = planList[i];
                var isSave = true;
                for (var k = 0; k < rowlen; k++) {
                    var row = rows[k];
                    if (planOrder.PWONum == row.PWONum) { //说明存在
                        isSave = false;
                        var wkStatusText = "";
                        switch (row.WorkStatus) {
                            case "1":
                                wkStatusText = "【未开始】";
                                break;
                            case "2":
                                wkStatusText = "【进行中】";
                                break;
                            case "3":
                                wkStatusText = "【已完成未提交】";
                                break;
                            case "4":
                                wkStatusText = "【已发送到电脑】";
                                break;
                            default:
                                wkStatusText = "【N/A】";
                                break;
                        }
                        exitsPlans.push(row["OPCode"] + row["OPName"] + wkStatusText);
                        break;
                    }
                }
                //planOrders.push(planOrder);
                if (isSave) {
                    planOrders.push(planOrder);
                }
            }
            if (exitsPlans.length > 0) {
                app.confirm("以下工单已存在，将不会下载,是否继续?\n\n" + exitsPlans.join('\n'), function (index) {
                    if (index == 2) {
                        funSaveWk(planOrders);
                    } else {
                        app.progress.stop();
                    }
                }, "与本地工单冲突提示", "取消,确定");
            } else {
                funSaveWk(planOrders);
            }

            // funSaveWk(planOrders);
        });

        var funSaveWk = function (planOrders) {
            var sqlTextList = funInitSqlList(planOrders);
            if (isPcDown == false) {
                funGetAtchList(planOrders);
            } else {
                funConvertAtch(planOrders);
            }
            savePlanOrderCount = planOrders.length;
            planOrders = null;

            if (sqlTextList.length > 0) {
                app.database.executeNonQuery(db, sqlTextList, function () {
                    var atchlen = attFiles.length;
                    if (atchlen > 0) {
                        funDownAtch();
                    } else {
                        app.progress.stop();
                        _self.funInitPlanData("localList");
                        app.alert("下载了" + savePlanOrderCount + "待办故障工单", function () {

                        });
                    }
                });
            } else {
                app.progress.stop();
                //显示工单
                app.alert("下载了0待办工单");
            }


        };

        var funInitSqlList = function (planOrders) {
            var sqlTextList = new Array();
            var planlen = planOrders.length;
            for (var i = 0; i < planlen; i++) {
                var item = planOrders[i];
                var planItem = new Object();

                planItem.PWONum = item.PWONum;
                planItem.PlanFetchDate = item.PlanFetchDate;
                planItem.LineNum = item.LineNum;
                planItem.LineName = item.LineName;
                planItem.OPName = item.OPName;
                planItem.OPDate = item.OPDate;
                planItem.OPCode = item.OPCode;
                planItem.OPOrgNum = item.OPOrgNum;
                planItem.OPOrgName = item.OPOrgNum;
                planItem.UnitOrgNum = item.UnitOrgNum;
                planItem.UnitOrgName = item.UnitOrgName;
                planItem.PlanNote = item.PlanNote;
                planItem.WOType = item.WOType;
                planItem.IsOutOrder = item.IsOutOrder;
                planItem.OutOrderCheck = item.OutOrderCheck;
                planItem.ResponseTime = item.ResponseTime;
                planItem.ResponseUserCode = item.ResponseUserCode;
                planItem.ResponseUserName = item.ResponseUserName;
                planItem.RepairTime = item.RepairTime;
                planItem.RepairUserCode = item.RepairUserCode;
                planItem.RepairUserName = item.RepairUserName;

                Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPPlan", [planItem]));

                if (item.OPOrders != null && item.OPOrders.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPOrders", item.OPOrders));
                }

                if (item.OrderProcedure != null && item.OrderProcedure.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OrderProcedure", item.OrderProcedure));
                }

                if (item.OPAreasTags != null && item.OPAreasTags.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPAreasTags", item.OPAreasTags));
                }

                if (item.OPMaterial != null && item.OPMaterial.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPMaterial", item.OPMaterial));
                }

                if (item.OPTools != null && item.OPTools.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPTools", item.OPTools));
                }

                if (item.AttFile != null && item.AttFile.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("AttFile", item.AttFile));
                }

                if (item.OPOutMaterial != null && item.OPOutMaterial.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPMaterial", item.OPMaterial));
                }

                if (item.OutMaterial != null && item.OutMaterial.length > 0) {
                    var itemlen = item.OutMaterial.length;
                    for (var j = 0; j < itemlen; j++) {
                        var itemNum = item.OutMaterial[j]["ItemNum"];
                        if (itemNum) {
                            sqlTextList.push("delete from OutMaterial Where ItemNum='" + itemNum + "'");
                        }
                    }
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OutMaterial", item.OutMaterial));
                }

                if (item.OPSafety != null && item.OPSafety.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPSafety", item.OPSafety));
                }
            }
            return sqlTextList;
        };

        var funGetAtchList = function (planOrders) {
            var planlen = planOrders.length;
            for (var i = 0; i < planlen; i++) {
                var item = planOrders[i];
                if (item.AttFile != null && item.AttFile.length > 0) {
                    var atchlen = item.AttFile.length;
                    for (var j = 0; j < atchlen; j++) {
                        var attFileItem = item.AttFile[j];
                        var attPath = attFileItem.AttPath || "";
                        var attNum = attFileItem.AttNum || "";
                        if (attPath != "" && attNum != "") {
                            var atchItem = new Object();
                            atchItem.AttNum = attNum;
                            atchItem.AttPath = attPath;
                            attFiles.push(atchItem);
                        }
                    }
                }
            }
        };

        var funDownAtch = function () {
            var atchlen = attFiles.length;
            if (atchlen > 0) {
                if (acthSavePath == "") {
                    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fileSystem) {
                        fileSystem.root.getDirectory("LmisAtchFile", {create: true, exclusive: false},
                            function (fileEntry) {
                                acthSavePath = fileEntry.fullPath;
                            }, function () {
                                app.alert("创建目录失败");
                            });
                    });
                }

                if (acthSavePath) {
                    var downIndex = 0;
                    var isDown = true;
                    var isAllDownSuc = true;
                    var funDownInterval = setInterval(function () {
                        if (downIndex < atchlen) {
                            if (isDown) {
                                isDown = false;
                                var atchItem = attFiles[downIndex];
                                var attPath = atchItem["AttPath"];
                                var startIndex = attPath.lastIndexOf("/");
                                var localFilePath = acthSavePath + attPath.slice(startIndex);
                                atchItem["AttPath"] = localFilePath;
                                var fileTransfer = new FileTransfer();

                                var fileUri = encodeURI(attPath);
                                fileTransfer.download(fileUri, localFilePath, function (entry) {
                                    var attNum = attFiles[downIndex]["AttNum"];
                                    var localAttPath = atchItem["AttPath"];
                                    var updAttFileTxt = "update AttFile set AttPath='" + localAttPath + "' where AttNum='" + attNum + "'";
                                    app.database.executeNonQuery(db, updAttFileTxt, function () {
                                        isDown = true;
                                        downIndex++;
                                    }, function () {
                                        isDown = true;
                                        isAllDownSuc = false;
                                        downIndex++;
                                    });
                                }, function (error) {
                                    isDown = true;
                                    isAllDownSuc = false;
                                    downIndex++;
                                });
                            }
                        } else {
                            attFiles = null;
                            clearInterval(funDownInterval);
                            _self.funInitPlanData("localList");
                            var titleMsg = "下载了" + savePlanOrderCount + "待办故障工单";
                            if (isAllDownSuc == false) {
                                titleMsg += "\n" + "有部分附件未下载成功!";
                            }
                            app.alert(titleMsg, function () {
                                app.progress.stop();
                                app.refresh();
                            });
                        }
                    }, 800);
                }
            }
        };

        var funConvertAtch = function (planOrders) {
            var planlen = planOrders.length;
            var fileSystem = null;
            var directryEntry = null;
            if (planlen > 0) {
                if (acthSavePath == "") {
                    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (_fileSystem) {
                        fileSystem = _fileSystem;
                        fileSystem.root.getDirectory("LimisAtchFile", {create: true, exclusive: false},
                            function (_directryEntry) {
                                directryEntry = _directryEntry;
                                acthSavePath = _directryEntry.fullPath;
                            }, function () {
                                app.alert("创建目录失败");
                            });
                    });
                }

                if (fileSystem != null && directryEntry != null) {
                    for (var i = 0; i < planlen; i++) {
                        var item = planOrders[i];
                        if (item.AttFile != null && item.AttFile.length > 0) {
                            var attFilelen = item.AttFile.length;
                            for (var k = 0; k < attFilelen; k++) {
                                var attFileItem = item.AttFile[k];
                                var attPath = attFileItem.AttPath || "";
                                if (attPath != "") {
                                    var startIndex = attPath.lastIndexOf("/");
                                    var fileName = attPath.slice(startIndex + 1);
                                    var imageUri = "/sdcard/download/" + fileName;
                                    var localFilePath = acthSavePath + "/" + fileName;
                                    fileSystem.root.getFile(imageUri, null, function (fileEntry) {
                                        fileEntry.moveTo(directryEntry, fileName, function () {
                                            attFileItem["AttPath"] = localFilePath;
                                        });
                                    });
                                }
                            }
                        }
                    }
                }
            }
        };
    },

    funInitUiData: function () {
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                $("#username").html(res);
            }
        });

        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                $("#usercode").html("（" + res + "）");
            }
        });
    },

    //containerId = localList
    funInitPlanData: function (containerId) {
        var _self = this;
        _self.PWONumList.length = 0;
        var sqlText = "SELECT *,( select count(c.PWONum) from OPOrders c where RecWay='s' and c.PWONum=PWONum ) as ScanNum ,( select count(o.PWONum) as scanNum from OPOrders o where o.PWONum=PWONum ) as OrderNum  FROM OPPlan ORDER BY WOType ASC,OPDate ASC,WorkStatus ASC ";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sqlText, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var lihtml = "";
            if (rows.length == 0) {
                lihtml += '<li>';
                lihtml += '<div data-role="BTButton"  data-status="1">';
                lihtml += '<span class="btn-text">暂无待办故障工单</span>';
                lihtml += '</div>';
                lihtml += '</li>';

                $("#btnClearWork").attr("style", "display: none !important");

            } else {

                var funGetWkStatus = function (workStatus) {
                    var wkStatusText = "";
                    switch (workStatus) {
                        case "1":
                            wkStatusText = "【未开始】";
                            break;
                        case "2":
                            wkStatusText = "【进行中】";
                            break;
                        case "3":
                            wkStatusText = "【已完成未上传】";
                            break;
                        case "4":
                            wkStatusText = "【已发送到电脑】";
                            break;
                        default:
                            wkStatusText = "【N/A】";
                            break;
                    }
                    return wkStatusText;
                };


                var funGetScanDesc = function (scanNumVal, orderNumVal) {
                    var scanDesc = "";
                    if (scanNumVal == orderNumVal) {
                        scanDesc = "【已完全扫描】";
                    } else if (scanNumVal > 0) {
                        scanDesc = "【未完成扫描】";
                    } else {
                        scanDesc = "【未扫描】";
                    }
                    return scanDesc;
                };


                var funGetOpStatus = function (operateStatus) {
                    var opStatusText = "";
                    switch (operateStatus) {
                        case "1":
                            opStatusText = "class='BTCheck_OFF'";
                            break;
                        case "2":
                            opStatusText = "class='BTCheck_ON'";
                            break;
                        default:
                            opStatusText = "class='BTCheck_OFF'";
                            break;
                    }
                    return opStatusText;
                };

                var leng = rows.length;

                var faultNum = 0;
                for (var i = 0; i < leng; i++) {
                    var row = rows[i];
                    var responseTime = row["ResponseTime"];
                    var repairTime = row["RepairTime"];
                    var pWoNum = row["PWONum"];
                    var wOType = row["WOType"];
                    var oPcode = row["OPCode"] ? "(" + row["OPCode"] + ")" : "";
                    var responeUser = row["ResponseUserName"] ? "(响应人：" + row["ResponseUserName"] + ")" : "";
                    var outOrderCheck = row["OutOrderCheck"];
                    var outOrderIsConfirm = row["OutOrderIsConfirm"];
                    var scanNum = row["ScanNum"] || 0;
                    var orderNum = row["OrderNum"] || 0;

                    lihtml += '<li>';
                    lihtml += '<div data-role="BTButton" data-status="1">';
                    lihtml += '<span class="btn-text">';
                    lihtml += '<div class="row-box">';
                    lihtml += '<div class="span1">';
                    if (wOType == "CM") {
                        lihtml += '<div id=' + row["PWONum"] + ' _WorkStatus=' + row["WorkStatus"] + ' value=' + row["PWONum"] + funGetOpStatus(row["OperateStatus"]) + ' data-inline="false">' + "<b><font style='color: red;font-size: 35px'>! </font></b>" + row["PWONum"] + "_" + row["OPName"] + oPcode + responeUser + '</div>';
                        _self.PWONumList.push(row["PWONum"]);
                        faultNum++;
                    }
                    lihtml += '</div>';
                    if (outOrderCheck == "1" && outOrderIsConfirm == "0") {
                        lihtml += '<div id="orderconfirm_' + pWoNum + '" PWONum="' + pWoNum + '"  class="moreFill" align="right">确认</div>';
                    }
                    if (wOType == "CM") {
                        if (responseTime == "") {
                            lihtml += '<div id="act_' + pWoNum + '" PWONum="' + pWoNum + '" activity="ResponseTime" class="moreFill" align="right">响应</div>';
                            //lihtml += '<div id="eorRpt_' + pWoNum + '" PWONum="' + pWoNum + '" activity="ErrorReport" class="moreFill" align="right">误报</div>';
                        } else if (repairTime == "") {
                            //lihtml += '<div id="eorRpt_' + pWoNum + '" PWONum="' + pWoNum + '" activity="ErrorReport" class="moreFill" align="right">误报</div>';
                        }
                    }
                    lihtml += '</div>';
                    lihtml += '</span>';
                    lihtml += '</div>';
                    lihtml += ' </li>';
                }
            }
            if (!faultNum) {
                faultNum = 0;
            }
            $("#lblChkCount").text("已下载(" + faultNum + ")");

            var cnt = $('#' + containerId);
            if (cnt) {
                cnt.empty();
                cnt.html(lihtml);
                //ui.init();
                _self.funBindEvent(rows);
                $('#localList li').click(function (e) {
                    e.stopPropagation();
                    var index = $(this).index();
                    _self.funStartWorkLi(index);
                })
            }
        });
    },

    funStartWork: function () {
        var _self = this;
        var length = _self.PWONumList.length;
        if (length > 0) {
            var startWkList = new Array();
            var wkDescList = new Array();
            var sqlTextList = new Array();
            var repFlautWkList = new Array();

            var specialtyNum = "";
            app.getGlobalVariable("SpecialtyNum", function (resVal) {
                if (resVal) {
                    specialtyNum = resVal;
                }
            });

            for (var i = 0; i < length; i++) {
                var chkBox = $("#" + _self.PWONumList[i]);
                var result = chkBox.btcheck("val");
                var sqlparam = new Object();
                sqlparam.WhereParam = new Object();
                if (result != null && result.value != "") {
                    var wk = new Object();
                    wk.PWONum = result.value;
                    wk.OPDesc = result.label;
                    startWkList.push(wk);
                    wkDescList.push(wk.OPDesc);
                    if (chkBox.attr("_WorkStatus") == "1") {
                        sqlparam.WorkStatus = "2";
                    }
                    sqlparam.OperateStatus = "2";

                    var retCnt = $("#act_" + _self.PWONumList[i]);
                    if (retCnt.length > 0) {
                        var activity = retCnt.attr("activity");
                        if (activity == "ResponseTime") {
                            repFlautWkList.push(wk.OPDesc);
                        }
                    }
                } else {
                    sqlparam.OperateStatus = "1";
                }
                sqlparam.WhereParam.PWONum = _self.PWONumList[i];
                var sqlText = SqlTextHelper.funUpdateDataText("OPPlan", sqlparam);
                sqlTextList.push(sqlText);
            }
            if (repFlautWkList.length > 0) {
                if (specialtyNum == "afc" || specialtyNum == "acs") {
                    app.alert("存在故障工单,请先响应后填报");
                } else {
                    app.confirm("以下故障未应响请是否继续一下步填报\n" + repFlautWkList.join("\n"), function (index) {
                        if (index == 2) {
                            app.confirm("确认要开始填报以下故障工单?\n" + wkDescList.join("\n"), function (index) {
                                if (index == 2) {
                                    var db = app.database.open(Common.WEIXIUDB);
                                    app.database.executeNonQuery(db, sqlTextList, function () {
                                        app.setGlobalVariable("CurrentPWONum", startWkList[0].PWONum);
                                        app.setGlobalVariable("startWkList", JSON.stringify(startWkList));
                                        Common.funLoad("tool.html");
                                    });
                                }
                            }, "开始填报故障工单确认", "取消,确定");
                        }
                    }, "故障工单未应响提示", "取消,确定");
                }

            } else if (startWkList.length > 0) {
                app.confirm("确认要开始填报以下故障工单?\n" + wkDescList.join("\n"), function (index) {
                    if (index == 2) {
                        var db = app.database.open(Common.WEIXIUDB);
                        app.database.executeNonQuery(db, sqlTextList, function () {
                            app.setGlobalVariable("CurrentPWONum", startWkList[0].PWONum);
                            app.setGlobalVariable("startWkList", JSON.stringify(startWkList));
                            if (specialtyNum == "gzw") {
                                Common.funLoad("eqlist.html");
                            } else {
                                Common.funLoad("tool.html");
                            }
                        });
                    }
                }, "开始填报工单确认", "取消,确定");
            } else {
                app.alert("请先选择要开始填报的待办故障工单");
            }
        } else {
            app.alert("不存在待办故障工单开始填报");
        }
    },
    funStartWorkLi: function (index) {
        var _self = this;
        var length = _self.PWONumList.length;
        if (length > 0) {
            var startWkList = new Array();
            var wkDescList = new Array();
            var sqlTextList = new Array();
            var repFlautWkList = new Array();

            var specialtyNum = "";
            app.getGlobalVariable("SpecialtyNum", function (resVal) {
                if (resVal) {
                    specialtyNum = resVal;
                }
            });

            var chkBox = $("#" + _self.PWONumList[index]);
            var sqlparam = new Object();
            sqlparam.WhereParam = new Object();
            var wk = new Object();
            wk.PWONum = _self.PWONumList[index];
            wk.OPDesc = chkBox.text();
            startWkList.push(wk);
            wkDescList.push(wk.OPDesc);
            if (chkBox.attr("_WorkStatus") == "1") {
                sqlparam.WorkStatus = "2";
            }
            sqlparam.OperateStatus = "2";

            var retCnt = $("#act_" + _self.PWONumList[index]);
            if (retCnt.length > 0) {
                var activity = retCnt.attr("activity");
                if (activity == "ResponseTime") {
                    repFlautWkList.push(wk.OPDesc);
                }
            }
            sqlparam.WhereParam.PWONum = _self.PWONumList[index];
            var sqlText = SqlTextHelper.funUpdateDataText("OPPlan", sqlparam);
            sqlTextList.push(sqlText);


            if (repFlautWkList.length > 0) {
                app.confirm("该工单未响应，请先响应！", function (index) {
                }, "故障工单填报", "确定");
            } else if (startWkList.length > 0) {
                var pageParam = new Object();
                pageParam.WONum = startWkList[0].PWONum;
                Common.funLoad('faultReportCM.html', pageParam);
            }
        } else {
            app.alert("不存在待办故障工单开始填报");
        }
    },

    funBindEvent: function (rows) {
        var _self = this;
        var rowlen = rows.length;
        for (var i = 0; i < rowlen; i++) {
            var item = rows[i];
            var wOType = item["WOType"];
            var isOutOrder = item["IsOutOrder"];
            var pWoNum = item["PWONum"];
            if (wOType == "CM") {
                var responseTime = item["ResponseTime"];
                var repairTime = item["RepairTime"];
                if (responseTime == "" || repairTime == "") {
                    $("#act_" + pWoNum).click(function (e) {
                        e.stopPropagation();
                        var ctr = $(this);
                        var pwoNum = ctr.attr("PWONum");
                        var activity = ctr.attr("activity");
                        var msg = "";
                        var title = "";
                        if (activity == "ResponseTime") {
                            msg = "确认响应该工单";
                            title = "响应工单确认";
                        } else {
                            msg = "确认修复完成该工单";
                            title = "修复完成工单确认";
                        }
                        app.confirm(msg, function (index) {
                            if (index == 2) {
                                _self.funFaultReply(pwoNum, activity);
                            }
                        }, title, "取消,确定");
                    });
                }

                $("#eorRpt_" + pWoNum).click(function (e) {
                    e.stopPropagation();
                    var ctr = $(this);
                    app.confirm("确认该工单为误报工单?", function (index) {
                        if (index == 2) {
                            var pwoNum = ctr.attr("PWONum");
                            var activity = ctr.attr("activity");
                            _self.funFaultReply(pwoNum, activity);
                        }
                    }, "误报工单确认", "取消,确定");
                });

            }

            if (isOutOrder == "1") {
                $("#orderconfirm_" + pWoNum).click(function () {
                    var ctr = $(this);
                    var pwonum = ctr.attr("PWONum");
                    var sqlPlanText = "update OPPlan set OutOrderIsConfirm='1' where PWONum='" + pwonum + "'";

                    var userCode = "";
                    var cfirmTime = Common.funGetNowDate();
                    app.getGlobalVariable("UserCode", function (res) {
                        if (res) {
                            userCode = res;
                        }
                    });
                    var sqlOrderText = "update OPOrders set IsConfirm='1' ,ConfirmUserCode='" + userCode + "',ConfirmTime='" + cfirmTime + "' where PWONum='" + pwonum + "'";

                    var db = app.database.open(Common.WEIXIUDB);
                    app.database.executeNonQuery(db, [sqlPlanText, sqlOrderText], function () {
                        ctr.remove();
                    });
                });

            }
        }
    },

    funFaultReply: function (pWoNum, activity) {
        var _self = this;
        var requestParam = new Object();
        var actTime = Common.funGetNowDate();
        var replyItem = new Object();
        replyItem.PWONum = pWoNum;
        replyItem.ActivityType = activity;
        replyItem.ActivityTime = actTime;
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                replyItem.UserCode = res;
            }
        });
        requestParam.orgin = "stream";
        requestParam.AuthBlock = new Object();
        requestParam.AuthBlock.RequestTime = actTime;
        requestParam.AuthBlock.ClientNumber = device.uuid;
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                requestParam.AuthBlock.UserCode = res;
            }
        });
        app.getGlobalVariable("Password", function (res) {
            if (res) {
                requestParam.AuthBlock.Password = res;
            }
        });
        requestParam.CallMethod = "Misc_FaultWOReply";
        requestParam.PayLoad = replyItem;
        app.progress.start("提示", "数据正在处理...");


        app.ajax({
            "url": MobileConfig.FaultWOReply, "data": requestParam,
            "contentType": "application/json",
            "method": "POST", "async": false,
            "success": function (res) {
                app.progress.stop();
                var responseData = JSON.parse(res.returnValue);
                if (responseData.ResStatus == true) {
                    if (activity == "ErrorReport") {
                        _self.funDelPaln(pWoNum);
                    } else {
                        var usercode = "";
                        app.getGlobalVariable("UserCode", function (resVal) {
                            if (resVal) {
                                usercode = resVal;
                            }
                        });
                        var sqlText = "";
                        switch (activity) {
                            case "ResponseTime":
                                sqlText = "update OPPlan set ResponseTime='" + actTime + "' ,ResponseUserCode='" + usercode + "' where PWONum='" + pWoNum + "'";
                                // sqlText = "update OPOrders set ResponseTime='" + actTime + "' where PWONum='" + pWoNum + "'";
                                break;
                            case "RepairTime":
                                sqlText = "update OPPlan set RepairTime='" + actTime + "' ,RepairUserCode='" + usercode + "' where PWONum='" + pWoNum + "'";
                                break;
                        }
                        var db = app.database.open(Common.WEIXIUDB);
                        app.database.executeNonQuery(db, sqlText, function () {
                            var ctr = $("#act_" + pWoNum);
                            if (activity == "RepairTime") {
                                $("#eorRpt_" + pWoNum).remove();
                                ctr.remove();
                            } else {
                                ctr.remove();
                            }
                        });
                        // app.refresh();
                    }
                } else {
                    app.alert(responseData.ResMsg);
                }
            }
        });
    }
    ,

    funDelPaln: function (pwoNum) {
        var _self = this;
        var delTagRecordsText = "delete from TagRecords where PWONum='" + pwoNum + "' ";
        var delOPMaterialText = "delete from OPMaterial where PWONum='" + pwoNum + "' ";
        var delOPToolsText = "delete from OPTools where PWONum='" + pwoNum + "' ";
        var delOPAreasTagsText = "delete from OPAreasTags where PWONum='" + pwoNum + "' ";
        var delAttFileText = "delete from AttFile where PWONum='" + pwoNum + "' ";
        var delFaultsOrderText = "delete from FaultsOrder where PWONum='" + pwoNum + "' ";
        var delOrderProcedureText = "delete from OrderProcedure where PWONum='" + pwoNum + "' ";
        var delOPOrdersText = "delete from OPOrders where PWONum='" + pwoNum + "' ";
        var delOPPlanText = "delete from OPPlan where PWONum='" + pwoNum + "' ";
        var delOPSafetyText = "delete from OPSafety where PWONum='" + pwoNum + "' ";
        var delOPSafetyMainText = "delete from OPSafetyMain where PWONum='" + pwoNum + "' ";

        var selAttFileText = "select AttPath  from AttFile where PWONum='" + pwoNum + "' ";

        var attRows = new Array();
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            tx.executeSql(selAttFileText, [], function (tx1, results) {
                attRows = Common.funConvertRowsJson(results);
            });
            tx.executeSql(delTagRecordsText);
            tx.executeSql(delOPMaterialText);
            tx.executeSql(delOPToolsText);
            tx.executeSql(delOPAreasTagsText);
            tx.executeSql(delAttFileText);
            tx.executeSql(delOrderProcedureText);
            tx.executeSql(delFaultsOrderText);
            tx.executeSql(delOPOrdersText);
            tx.executeSql(delOPSafetyText);
            tx.executeSql(delOPSafetyMainText);
            tx.executeSql(delOPPlanText);

        }, function (error) {
            app.alert(error);
        }, function () {
            var attlen = attRows.length;
            if (attRows > 0) {
                for (var j = 0; j < attlen; j++) {
                    var path = attRows[j];
                    if (path) {
                        window.resolveLocalFileSystemURI(path, function (fileEntry) {
                            fileEntry.remove();
                        }, null);
                    }
                }
            }
            _self.funInitPlanData("localList");
        });
    }
    ,

    funChoicePlan: function (tagCode) {
        var _self = this;
        var pwoNumList = _self.PWONumList;
        var pwoNumlen = pwoNumList.length;
        if (tagCode && pwoNumlen > 0) {
            var tagCodeArr = tagCode.split(";");
            var tagWhereCondition = new Array();
            for (var tagi = 0; tagi < tagCodeArr.length; tagi++) {
                tagWhereCondition.push(" TagCode like '%" + tagCodeArr[tagi] + "%' ");
                tagWhereCondition.push(" AssetTagCode like '%" + tagCodeArr[tagi] + "%' ");
                tagWhereCondition.push(" DeviceLocationNum like '%" + tagCodeArr[tagi] + "%' ");
            }

            for (var i = 0; i < pwoNumlen; i++) {
                var pwoNum = pwoNumList[i];
                var chkBox = $("#" + pwoNum);
                var result = chkBox.btcheck("val");
                if (result != null && result.value != "") {
                    chkBox.removeClass("BTCheck_ON").addClass("BTCheck_OFF");
                }
            }

            var sqlText = "SELECT DISTINCT PWONum FROM OPOrders WHERE (" + tagWhereCondition.join(" OR ") + " )";
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeQuery(db, sqlText, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowlen = rows.length;
                if (rowlen > 0) {
                    for (var j = 0; j < rowlen; j++) {
                        var chkedBox = $("#" + rows[j]["PWONum"]);
                        var rets = chkBox.btcheck("val");
                        if (rets == null) {
                            chkedBox.removeClass("BTCheck_OFF").addClass("BTCheck_ON");
                        }
                    }
                }
            });
        }
    }
    ,

    //containerId = "localList"
    funPlanData: function (containerId) {
        var _self = this;
        var lihtml = "";
        if (_self.PWOSimple.length == 0) {
            lihtml += '<li>';
            lihtml += '<div data-role="BTButton" mouseup="false" mousedown="false" data-status="1">';
            lihtml += '<span class="btn-text">暂无待办工单</span>';
            lihtml += '</div>';
            lihtml += '</li>';
            $("#btnClearWork").attr("style", "display: none !important");
            $("#btnAllChk").attr("style", "display: none !important");
        } else {
            $("#lblUnChkCount").text("可下载(" + _self.PWOSimple.length + ")");
            var leng = _self.PWOSimple.length;
            for (var i = 0; i < leng; i++) {
                var row = _self.PWOSimple[i];
                _self.PWONumList.push(row["PWONum"]);
                lihtml += '<li>';
                lihtml += '<div data-role="BTButton" data-status="1">';
                lihtml += '<span class="btn-text">';
                lihtml += '<div class="row-box">';
                lihtml += '<div class="span1">';
                lihtml += '<div id=' + row["PWONum"] + ' value=' + row["PWONum"] + ' data-role="BTCheck" ' + "class='BTCheck_OFF'" + ' data-inline="false">' + row["PWONum"] + "_" + row["OPName"] + '</div>';
                lihtml += '</div>';
                lihtml += '</div>';
                lihtml += '</span>';
                lihtml += '</div>';
                lihtml += ' </li>';
            }
        }

        var cnt = document.getElementById(containerId);
        if (cnt) {
            cnt.innerHTML = lihtml;
            ui.init();
        }
        // _self.funBindEvent();

    }
    ,
    funSearchWork: function () {
        var _self = this;
        var lasversionNum = "";
        var funIsNewApk = function () {
            var retIsNewApk = true;
            var localVersion = "";
            var platform = "";
            if (window.devicePlatform == "android") {
                platform = "android";
            } else if (window.devicePlatform == "iOS") {
                platform = "ios";
            }
            app.getInfo(function (res) {
                localVersion = res.versionName + "";
                localVersion = localVersion.substr(1, 3);
                localVersion = localVersion - 0;

                var reqVersionParam = new Object();
                reqVersionParam.orgin = "stream";
                reqVersionParam.CallMethod = "Com_DownloadBaseData";
                var dlDataParam = new Object();
                dlDataParam.DataType = "CheckVersion";
                dlDataParam.Platform = platform;
                reqVersionParam.AuthBlock = new Object();
                reqVersionParam.AuthBlock.UserCode = "admin";
                reqVersionParam.AuthBlock.Password = "112233";
                reqVersionParam.PayLoad = dlDataParam;
                app.ajax({
                    "url": MobileConfig.DownBaseDataUrl, "data": reqVersionParam,
                    "contentType": "application/json",
                    "method": "POST", "async": false,
                    "success": function (res) {
                        var responseData = JSON.parse(res.returnValue);
                        var serverVersion = responseData.PayLoad.VersionNumber;
                        serverVersion = serverVersion - 0;
                        if (localVersion < serverVersion) {
                            lasversionNum = serverVersion;
                            retIsNewApk = false;
                        }
                    }
                });
                return retIsNewApk;
            });
        };
        var funSearch = function () {
            var downParam = _self.funGetDownParam();
            var requestParam = new Object();
            requestParam.orgin = "stream";
            requestParam.CallMethod = "Biz_FetchOrderList";
            requestParam.AuthBlock = new Object();
            requestParam.AuthBlock.ClientNumber = device.uuid;
            requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
            app.getGlobalVariable("UserCode", function (res) {
                if (res) {
                    requestParam.AuthBlock.UserCode = res;
                }
            });
            app.getGlobalVariable("Password", function (res) {
                if (res) {
                    requestParam.AuthBlock.Password = res;
                }
            });
            requestParam.PayLoad = downParam;
            app.ajax({
                "url": MobileConfig.DownWorkUrl,
                "data": requestParam,
                "contentType": "application/json",
                "method": "POST",
                "timeout": 600000,
                "async": true,
                "success": function (res) {
                    var planOrder = JSON.parse(res.returnValue);
                    if (planOrder.ResStatus == true) {
                        _self.PWOSimple = planOrder.PayLoad;
                        _self.funPlanData("serverList");
                        app.progress.stop();
                    } else {
                        app.alert(planOrder.ResMsg, function () {
                            app.progress.stop();
                        });
                    }
                },
                "fail": function (res) {
                    app.alert("由于网络原因,暂时没有接收到数据,请稍后重试\n" + JSON.stringify(res), function () {
                        app.progress.stop();
                    });
                }
            });
        };

        var networkState = navigator.network.connection.type;
        if (networkState == Connection.NONE) { //未连接
            app.confirm("当前没有可用的网络，是否通过USB获取工单?", function (index) {
                if (index == 2) {
                    _self.funPcDownWork();
                }
            }, "提示", "取消,确定");
        } else {
            app.progress.start("下载提示", "正在处理中...");
            var isNewApk = funIsNewApk();
            if (isNewApk == false) {
                app.progress.stop();
                app.alert("版本已更新，请先更新到[v" + lasversionNum + "]版本", function () {
                    Common.funClearModuleCache();//删除页面跳转保存的全局变量
                    var db = app.database.open("WEIXIUDB");
                    app.database.executeNonQuery(db, "delete from OPUsers where 1=1", function () {
                        app.load({url: "login.html"});
                    });
                });
            } else {
                funSearch();
            }
        }
    }
    ,
    funDownWorkNew: function () {
        var _self = this;

        var funDownWk = function (filePath) {
            setTimeout(function () {
                var paramObj = new Object();
                paramObj.filepath = filePath;
                var param = new Object();
                param.PayLoad = paramObj;
                app.ajax({
                    "url": MobileConfig.GetDownWkStatusUrl,
                    "data": param,
                    "contentType": "application/json",
                    "method": "POST",
                    "async": true,
                    "success": function (res) {
                        var statusObj = JSON.parse(res.returnValue);
                        var status = statusObj.status;
                        if (status == "H") {
                            funDownWk(filePath);
                        } else if (status == "F") {
                            app.alert("调用失败", function () {
                                app.progress.stop();
                            });
                        } else if (status == "S") {
                            var acthSavePath = "";
                            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fileSystem) {
                                fileSystem.root.getDirectory("LimisWkFile", {create: true, exclusive: false},
                                    function (fileEntry) {
                                        acthSavePath = fileEntry.fullPath;
                                        if (acthSavePath) {
                                            var startIndex = filePath.lastIndexOf("/");
                                            var localFilePath = acthSavePath + filePath.slice(startIndex);
                                            var fileTransfer = new FileTransfer();
                                            var fileUri = encodeURI(filePath);
                                            fileTransfer.download(fileUri, localFilePath, function (entry) {
                                                app.file.readAsString(localFilePath, function (res) {
                                                    var planOrder = JSON.parse(res);
                                                    app.file.remove(localFilePath); //删除文件
                                                    if (planOrder.ResStatus == true) {
                                                        var planList = planOrder.PayLoad;
                                                        if (planList.length > 0) {
                                                            _self.funSaveDownWork(planList, true);
                                                        } else {
                                                            app.progress.stop();
                                                            app.alert("下载了0待办工单");
                                                        }
                                                    } else {
                                                        app.progress.stop();
                                                        app.alert(planOrder.ResMsg);
                                                    }
                                                }, function (res) {
                                                    app.alert(res, function () {
                                                        app.progress.stop();
                                                    });
                                                });
                                            }, function (error) {
                                                app.alert("待办工单下载失败", function () {
                                                    app.progress.stop();
                                                });
                                            });
                                        }
                                    }, function () {
                                        app.alert("创建目录失败", function () {
                                            app.progress.stop();
                                        });
                                    });
                            });

                        }
                    }
                });
            }, 2000);
        };
        app.progress.start("下载提示", "正在处理中...");

        var funGetDownNumList = function () {
            var length = _self.PWOSimple.length;
            var selNumList = "";
            if (length > 0) {
                for (var i = 0; i < length; i++) {
                    var chkBox = $("#" + _self.PWOSimple[i]["PWONum"]);
                    var result = chkBox.btcheck("val");
                    if (result != null && result.value != "") {
                        selNumList = selNumList + ",'" + _self.PWOSimple[i]["PWONum"] + "'";
                    }
                }
                //去掉第一个逗号
                selNumList = selNumList.substring(1, selNumList.length);
            }
            return selNumList;
        };
        var selNumList = funGetDownNumList();
        if (selNumList.length > 0) {
            var requestParam = new Object();
            requestParam.orgin = "stream";
            requestParam.CallMethod = "Biz_FetchPlanOrder";
            requestParam.AuthBlock = new Object();
            requestParam.AuthBlock.ClientNumber = device.uuid;
            requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
            app.getGlobalVariable("UserCode", function (res) {
                if (res) {
                    requestParam.AuthBlock.UserCode = res;
                }
            });
            app.getGlobalVariable("Password", function (res) {
                if (res) {
                    requestParam.AuthBlock.Password = res;
                }
            });

            requestParam.PayLoad = new Object();
            requestParam.PayLoad.PWONumList = selNumList;
            app.ajax({
                "url": MobileConfig.DownWorkUrl,
                "data": requestParam,
                // "contentType": "text/json; charset=utf-8",
                "contentType": "application/json",
                "method": "POST",
                "timeout": 600000,
                "async": true,
                "success": function (res) {
                    var planOrder = JSON.parse(res.returnValue);
                    if (planOrder.ResStatus == true) {
                        var planList = planOrder.PayLoad;
                        if (planList.length > 0) {
                            var filePath = planOrder.PayLoad[0].filepath;
                            funDownWk(filePath);
                        } else {
                            app.alert("下载了0待办工单", function () {
                                app.progress.stop();
                            });
                        }
                    } else {
                        app.alert(planOrder.ResMsg, function () {
                            app.progress.stop();
                        });
                    }
                },
                "fail": function (res) {
                    app.alert("由于网络原因,暂时没有接收到数据,请稍后重试\n" + JSON.stringify(res), function () {
                        app.progress.stop();
                    });
                }
            });
        } else {
            if (_self.PWOSimple.length > 0) {
                app.alert("请选择要下载的工单。", function () {
                    app.progress.stop();
                });
            } else {
                app.alert("请先查询工单。", function () {
                    app.progress.stop();
                });
            }
        }
    }
    ,

    //返回刷新
    funBackRefresh: function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var pageName = retParam["pageName"];
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.Param = backParam;
                }
            }
        } catch (ex) {
            app.alert("btnhandlefault.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {

            _self.funSearchWork();
            _self.funInitPlanData("localList");
        }, 100);
    }
};