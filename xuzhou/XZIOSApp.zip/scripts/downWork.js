﻿var DownWork = function () {
    this.PWONumList = new Array();

    //工单号和描述的集合,查询后返回
    this.PWOSimple = new Array();

    this.Lines = new Array();
    this.Stations = new Array();
    this.Specs = new Array();
    this.downParam = new Object();

};
var a = 0;
var b = 0;
DownWork.prototype = {

    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        //用框架.click方法去调用会重复执行重复下载数据，超级bug，换成原生的点击方式
        $("#btnConfirmWork").click(function () {
            _self.funDownWorkNew();
        });
        $("#btnDownWork").click(function () {
            _self.funSearchWork();
        });
        //$("#btnDownOutChk").click(function () {
        //    // _self.funDownWork();
        //    _self.funDownWorkNew();
        //});


        // 专业
        $("#SpecList").click(function () {
            var specs = _self.Specs;
            if (specs.length > 0) {
                var specsCtr = $("#SpecList");
                var defkey = "";
                app.wheelSelect.oneSelect(specs,
                    function (res) {
                        var key = res["key"];
                        var value = res["value"];
                        specsCtr.text(value);
                        specsCtr.attr("key", key);
                    }, defkey, "请选择专业");
            } else {
                app.alert("暂无专业基础数据");
            }
        });

        $("#LineList").click(function () {
            var lines = _self.Lines;
            if (lines.length > 0) {
                var lineCtr = $("#LineList");
                var defkey = "";
                app.wheelSelect.oneSelect(lines,
                    function (res) {
                        var key = res["key"];
                        var value = res["value"];
                        lineCtr.text(value);
                        lineCtr.attr("key", key);
                        _self.funLoadStationData(key);
                    }, defkey, "请选择线路");
            } else {
                app.alert("暂无线路基础数据");
            }
        });

        $("#StationList").click(function () {
            var stations = _self.Stations;
            if (stations.length > 0) {
                var stationCtr = $("#StationList");
                var defkey = "";
                app.wheelSelect.oneSelect(stations,
                    function (res) {
                        var key = res["key"];
                        var value = res["value"];
                        stationCtr.text(value);
                        stationCtr.attr("key", key);
                    }, defkey, "请选择车站");
            } else {
                app.alert("暂无车站基础数据");
            }
        });
    },
    funInitUiData: function () {
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                $("#username").html(res);
            }
        });

        app.getGlobalVariable("UserCode", function (res) {
            if (res) {

                $("#usercode").html("（" + res + "）");
            }
        });

        //app.getGlobalVariable("IsOutSourceUser", function (res) {
        //    var isOut = res || "0";
        //    if (isOut == "0") {
        //        $("#liOut").remove();
        //    } else {
        //        $("#liOut").css("display", "");
        //    }
        //});

        var newDate = new Date();
        var datePickVal = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();

        //$("#divDateStar").btdatepicker("val", datePickVal);
        $("#divDateEnd").btdatepicker("val", datePickVal);
    },

    funBindEvent: function () {
        var _self = this;
        $("#divPlanOrder").click(function () {
            $("#btnDownOutChk").css("display", "none !important");
            $("#liOPcode").css("display", "");
            $("#liLine").css("display", "");
        });

        $("#divOutOrder").click(function () {
            $("#btnDownOutChk").css("display", "");
            $("#liOPcode").css("display", "none !important");
            $("#liLine").css("display", "none !important");
        });

        // $("div[name='unit']").click(function () {
        //     var unitVal = $("div[name='unit']").btcheck("val");
        //     if (unitVal) {
        //         var key = unitVal.value;
        //         if (key == "UserCode") {
        //             $("#txtUserCode").val("");
        //             $("#txtUserCode").css("display", "none");
        //         } else if (key == "UnitOrgNum") {
        //             $("#txtUserCode").css("display", "");
        //             document.getElementById("txtUserCode").setAttribute("placeholder", "请输入工班");
        //         } else {
        //             $("#txtUserCode").css("display", "");
        //             document.getElementById("txtUserCode").setAttribute("placeholder", "请输入账号");
        //         }
        //     }
        // });

        $("#btnAllChk").click(function () {
            var chkBox = $(this);
            var result = chkBox.btcheck("val");
            var length = _self.PWONumList.length;
            if (length > 0) {
                var isAllchked = false;
                if (result != null && result.value != "") {
                    isAllchked = true;
                }

                for (var i = 0; i < length; i++) {
                    var chkBoxItem = $("#" + _self.PWONumList[i]);
                    if (isAllchked) {
                        chkBoxItem.removeClass('BTCheck_OFF').addClass('BTCheck_ON');
                    } else {
                        chkBoxItem.removeClass('BTCheck_ON').addClass('BTCheck_OFF');
                    }
                }
            }
        });
    },

    //获取查询条件
    funGetDownParam: function () {
        var downParam = new Object();

        app.getGlobalVariable("IsOutSourceUser", function (res) {
            downParam.IsOutUser = res || "0";
        });

        var dateValueStar = $("#divDateStar").btselect("val").value;
        var dateValueEnd = $("#divDateEnd").btselect("val").value;
        downParam.OrderDateStar = dateValueStar;
        downParam.OrderDateEnd = dateValueEnd;

        // var userCode = $("#txtUserCode").val().trim();
        var unitVal = $("div[name='unit']").btcheck("val");
        if (unitVal) {
            var liKey = unitVal.value;
            //关联本工班
            if (liKey == "UnitOrgNum") {
                app.getGlobalVariable("UnitOrgNum", function (res) {
                    if (res) {
                        downParam.UnitID = res;
                    }
                });
                // downParam.UnitID = userCode;
                // } else if (liKey == "Other") {
                //     downParam.UserCode = userCode;
            } else {
                app.getGlobalVariable("UserCode", function (res) {
                    if (res) {
                        downParam.UserCode = res;
                    }
                });
            }
        }

        // PM / CM
        var WorkTapeVal = $("div[name='WorkTapeCMPM']").btcheck("val");
        if (WorkTapeVal) {
            var key = WorkTapeVal.value;
            if (key == "0") { //CM
                downParam.WorkType = 'CM';
            } else if (key == "1") { //PM
                downParam.WorkType = 'PM';
            }
        }
        // 专业
        var specnum = $("#SpecList").attr("key") || "NA";
        if (specnum != "NA") {
            downParam.SpecNum = specnum;
        }

        var isutOrder = $("#divOutOrder").btcheck("val");
        if (isutOrder) {
            downParam.OutOrderCheck = "1";
            app.getGlobalVariable("UnitOrgNum", function (res) {
                if (res) {
                    downParam.UnitID = res;
                }
            });

        } else {
            downParam.OutOrderCheck = "0";

            var oPCode = $("#txtOPCode").val().trim();
            if (oPCode != "") {
                downParam.WONum = oPCode;
            }

            var station = $("#StationList").attr("key") || "NA";
            if (station != "NA") {
                downParam.StationID = station;
            }
            var lineNum = $("#LineList").attr("key") || "NA";
            if (lineNum != "NA") {
                downParam.LineNum = lineNum;
            }
        }
        return downParam;
    },


    funSaveDownWork: function (planList, isPcDown) {
        var _self = this;
        var sqlPlanText = "select OPCode,OPName,PWONum,WorkStatus from OPPlan order by WorkStatus asc";
        var db = app.database.open(Common.WEIXIUDB);
        var attFiles = new Array();
        var acthSavePath = "";
        var savePlanOrderCount = 0;

        //遍历本地是否已存在要下载的工单，
        //如果已存在，不会更新，因为本地有操作步骤，避免覆盖
        app.database.executeQuery(db, sqlPlanText, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowlen = rows.length;
            var orderlen = planList.length;
            var planOrders = new Array();
            var exitsPlans = new Array();
            //遍历网络返回
            for (var i = 0; i < orderlen; i++) {
                var planOrder = planList[i];
                var isSave = true;
                //遍历本地
                for (var k = 0; k < rowlen; k++) {
                    var row = rows[k];
                    if (planOrder.PWONum == row.PWONum) { //说明存在
                        isSave = false;
                        exitsPlans.push(row["OPCode"] + row["OPName"]);
                        break;
                    }
                }
                if (isSave) {
                    if ($.inArray(planOrders, planOrder) == -1) {
                        if ($.inArray(planOrders, planOrder) == -1) {
                            planOrders.push(planOrder);
                        }
             
                    }
                }
            }

            if (exitsPlans.length > 0) {
                app.confirm("以下工单已存在，将不会下载,是否继续?\n\n" + exitsPlans.join('\n'), function (index) {
                    if (index == 2) {
                        funSaveWk(planOrders);
                    } else {
                        app.progress.stop();
                    }
                }, "与本地工单冲突提示", "取消,确定");
            } else {
                funSaveWk(planOrders);
            }
        });

        var funSaveWk = function (planOrders) {
            var sqlTextList = funInitSqlList(planOrders);
            if (isPcDown == false) {
                funGetAtchList(planOrders);
            } else {
                funConvertAtch(planOrders);
            }
            savePlanOrderCount = planOrders.length;
            planOrders = null;
            if (sqlTextList.length > 0) {
                app.database.executeNonQuery(db, sqlTextList, function () {
                    var atchlen = attFiles.length;
                    if (atchlen > 0) {
                        funDownAtch();
                    } else {
                        app.progress.stop();
                        app.alert("下载了" + savePlanOrderCount + "待办工单", function () {
                            _self.funSearchWork();
                        });
                    }
                });
            } else {
                app.alert("下载了0待办工单\n", function () {
                    app.progress.stop();
                });
            }
        };

        var funInitSqlList = function (planOrders) {
            var _self = this;
            var sqlTextList = new Array();
            var planlen = planOrders.length;
            for (var i = 0; i < planlen; i++) {
                var item = planOrders[i];
                var planItem = new Object();
                planItem.PWONum = item.PWONum;
                planItem.PlanFetchDate = item.PlanFetchDate;
                planItem.LineNum = item.LineNum;
                planItem.LineName = item.LineName;
                planItem.OPName = item.OPName;
                planItem.OPDate = item.OPDate;
                planItem.OPCode = item.OPCode;
                planItem.OPOrgNum = item.OPOrgNum;
                planItem.OPOrgName = item.OPOrgNum;
                planItem.UnitOrgNum = item.UnitOrgNum;
                planItem.UnitOrgName = item.UnitOrgName;
                planItem.PlanNote = item.PlanNote;
                planItem.WOType = item.WOType;
                planItem.IsOutOrder = item.IsOutOrder;
                planItem.OutOrderCheck = item.OutOrderCheck;
                planItem.ResponseTime = item.ResponseTime;
                planItem.ResponseUserCode = item.ResponseUserCode;
                planItem.ResponseUserName = item.ResponseUserName;
                planItem.RepairTime = item.RepairTime;
                planItem.RepairUserCode = item.RepairUserCode;
                planItem.RepairUserName = item.RepairUserName;
                planItem.DeviceLocationNum = item.DeviceLocationNum;
                planItem.DeviceTypeNum = item.DeviceTypeNum;

                Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPPlan", [planItem]));
                if (item.OPOrders && item.OPOrders.length > 0) {
                    //去掉null值的数据
                    for(var l =0; l<item.OPOrders.length ; l++){
                        var object = item.OPOrders[l];
                        for (var k in object) {
                            var value = object[k];
                            if (!value || typeof value !== 'object') {
                                if (value === '' || value === null || value === undefined) {
                                    delete object[k];
                                }
                            }
                        }
                    }
                    if (item.OPOrders[0].WOType === "CM") {
                        var json = funGetFault(item.OPOrders[0],planItem.PWONum);
                        var faultOrder = json.faultOrder;
                        var opOrder = json.opOrder;
                        Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("FaultsOrder", [faultOrder]));
                        Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPOrders", item.OPOrders));
                    } else {
                        Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPOrders", item.OPOrders));
                    }
                }

                if (item.OrderProcedure && item.OrderProcedure.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OrderProcedure", item.OrderProcedure));
                }

                if (item.OPAreasTags && item.OPAreasTags.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPAreasTags", item.OPAreasTags));
                }

                if (item.OPMaterial && item.OPMaterial.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPMaterial", item.OPMaterial));
                }

                if (item.OPTools && item.OPTools.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPTools", item.OPTools));
                }

                if (item.AttFile && item.AttFile.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("AttFile", item.AttFile));
                }

                if (item.OPOutMaterial && item.OPOutMaterial.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPMaterial", item.OPMaterial));
                }

                if (item.OutMaterial && item.OutMaterial.length > 0) {
                    var itemlen = item.OutMaterial.length;
                    for (var j = 0; j < itemlen; j++) {
                        var itemNum = item.OutMaterial[j]["ItemNum"];
                        if (itemNum) {
                            sqlTextList.push("delete from OutMaterial Where ItemNum='" + itemNum + "'");
                        }
                    }
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OutMaterial", item.OutMaterial));
                }

                if (item.OPSafety && item.OPSafety.length > 0) {
                    Common.funConcatArray(sqlTextList, SqlTextHelper.funGetInsertText("OPSafety", item.OPSafety));
                }
            }
            return sqlTextList;
        };
        var funGetFault = function (planOrder, PWONum) {
            if (planOrder && planOrder.WOType !== "CM") {
                return;
            }
            var json = new Object();
            var faultOrder = new Object();
            faultOrder.PWONum = PWONum;
            faultOrder.WONum = planOrder.WONum;
            faultOrder.WOType = planOrder.WOType;
            faultOrder.SpecialtyNum = planOrder.SpecialtyNum;
            faultOrder.SpecialtyName = planOrder.SpecialtyName;
            faultOrder.LineNum = planOrder.LineNum;
            faultOrder.LineName = planOrder.LineName;
            faultOrder.DeviceNum = planOrder.DeviceNum;
            faultOrder.DeviceName = planOrder.DeviceName;
            faultOrder.SubSystemID = planOrder.SubSystemID;
            faultOrder.SubSystemNum = planOrder.SubSystemNum;
            faultOrder.SubSystemName = planOrder.SubSystemName;
            faultOrder.RecUserName = planOrder.RecUserName;
            faultOrder.FaultRecTime = planOrder.FaultRecTime;
            faultOrder.FaultDesc = planOrder.FaultDesc;
            faultOrder.ResponseTime = planOrder.ResponseTime;
            faultOrder.FaultReportUserName = planOrder.FaultReportUserName;
            faultOrder.FaultRepMobilePhone = planOrder.FaultRepMobilePhone;
            faultOrder.FaultLocation = planOrder.FaultLocation;
            faultOrder.FaultJournalTime = planOrder.FaultJournalTime;
            faultOrder.FaultTime = planOrder.FaultTime;
            faultOrder.OperationTimeFault = planOrder.OperationTimeFault;
            faultOrder.RequestCompletionTime = planOrder.RequestCompletionTime;
            faultOrder.JobHeadUserName = planOrder.JobHeadUserName;
            faultOrder.JobHeadUserID = planOrder.JobHeadUserID;
            faultOrder.IsApplySGPlan = planOrder.IsApplySGPlan;
            faultOrder.IsEquipmentFailure = planOrder.IsEquipmentFailure;
            faultOrder.FaultCriminalTime = planOrder.FaultCriminalTime;
            faultOrder.LocationID = planOrder.LocationID;
            faultOrder.LocationCode = planOrder.LocationCode;
            faultOrder.LocationName = planOrder.LocationName;
            faultOrder.DeviceTypeNum = planOrder.DeviceTypeNum;
            faultOrder.DeviceTypeName = planOrder.DeviceTypeName;
            faultOrder.IsOutSource = planOrder.IsOutSource;
            faultOrder.FaultClassify = planOrder.FaultClassify;
            faultOrder.FaultCategory = planOrder.FaultCategory;
            faultOrder.RefinePptions = planOrder.RefinePptions;
            faultOrder.IsRepair = planOrder.IsRepair;
            faultOrder.ActualFaultTime = planOrder.ActualFaultTime;
            faultOrder.ActualEndTime = planOrder.ActualEndTime;
            faultOrder.FaultCompleteTime = planOrder.FaultCompleteTime;
            faultOrder.EquipmentStopStartTime = planOrder.EquipmentStopStartTime;
            faultOrder.EquipmentStopEndTime = planOrder.EquipmentStopEndTime;
            faultOrder.FaultDescription = planOrder.FaultDescription;
            faultOrder.FaultReason = planOrder.FaultReason;
            faultOrder.FaultMemo = planOrder.FaultMemo;
            faultOrder.OrderDesc = planOrder.OrderDesc;
            faultOrder.DownLoadUserCode = _self.downParam.UserCode;

            faultOrder.FormerEquipment = planOrder.FormerEquipment;
            faultOrder.FormerEquipmentLocation = planOrder.FormerEquipmentLocation;
            faultOrder.NewEquipment = planOrder.NewEquipment;
            faultOrder.NewEquipmentLocation = planOrder.NewEquipmentLocation;

            faultOrder.FormerEquipmentName = planOrder.FormerEquipmentName;
            faultOrder.FormerEquipmentLocationName = planOrder.FormerEquipmentLocationName;
            faultOrder.NewEquipmentName = planOrder.NewEquipmentName;
            faultOrder.NewEquipmentLocationName = planOrder.NewEquipmentLocationName;
          
            faultOrder.TrainNumber = planOrder.TrainNumber;
            faultOrder.TrainBody = planOrder.TrainBody;
            faultOrder.ContractName = planOrder.ContractName;
            faultOrder.ContractCode = planOrder.ContractCode;
            faultOrder.Supplier = planOrder.Supplier;
            faultOrder.SupplierTel = planOrder.SupplierTel;

            json.faultOrder = faultOrder;
            var opOrder = new Object();
            opOrder.PWONum = PWONum;
            opOrder.WONum = planOrder.WONum;
            opOrder.WOType = planOrder.WOType;
            json.opOrder = opOrder;
            return json;
        };

        var funGetAtchList = function (planOrders) {
            var planlen = planOrders.length;
            for (var i = 0; i < planlen; i++) {
                var item = planOrders[i];
                if (item.AttFile != null && item.AttFile.length > 0) {
                    var atchlen = item.AttFile.length;
                    for (var j = 0; j < atchlen; j++) {
                        var attFileItem = item.AttFile[j];
                        var attPath = attFileItem.AttPath || "";
                        var attNum = attFileItem.AttNum || "";
                        if (attPath != "" && attNum != "") {
                            var atchItem = new Object();
                            atchItem.AttNum = attNum;
                            atchItem.AttPath = attPath;
                            attFiles.push(atchItem);
                        }
                    }
                }
            }
        };

        var funDownAtch = function () {
            var atchlen = attFiles.length;
            if (atchlen > 0) {
                if (acthSavePath == "") {
                    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fileSystem) {
                        fileSystem.root.getDirectory("LmisAtchFile", {create: true, exclusive: false},
                            function (fileEntry) {
                                acthSavePath = fileEntry.fullPath;
                            }, function () {
                                app.alert("创建目录失败");
                            });
                    });
                }

                if (acthSavePath) {
                    var downIndex = 0;
                    var isDown = true;
                    var isAllDownSuc = true;
                    var funDownInterval = setInterval(function () {
                        if (downIndex < atchlen) {
                            if (isDown) {
                                isDown = false;
                                var atchItem = attFiles[downIndex];
                                var attPath = atchItem["AttPath"];
                                var startIndex = attPath.lastIndexOf("/");
                                var localFilePath = acthSavePath + attPath.slice(startIndex);
                                atchItem["AttPath"] = localFilePath;
                                var fileTransfer = new FileTransfer();

                                var fileUri = encodeURI(attPath);
                                fileTransfer.download(fileUri, localFilePath, function (entry) {
                                    var attNum = attFiles[downIndex]["AttNum"];
                                    var localAttPath = atchItem["AttPath"];
                                    var updAttFileTxt = "update AttFile set AttPath='" + localAttPath + "' where AttNum='" + attNum + "'";
                                    app.database.executeNonQuery(db, updAttFileTxt, function () {
                                        isDown = true;
                                        downIndex++;
                                    }, function () {
                                        isDown = true;
                                        isAllDownSuc = false;
                                        downIndex++;
                                    });
                                }, function (error) {
                                    isDown = true;
                                    isAllDownSuc = false;
                                    downIndex++;
                                });
                            }
                        } else {
                            attFiles = null;
                            clearInterval(funDownInterval);
                            var titleMsg = "下载了" + savePlanOrderCount + "待办工单";
                            if (isAllDownSuc == false) {
                                titleMsg += "\n" + "有部分附件未下载成功!";
                            }
                            app.alert(titleMsg, function () {
                                app.progress.stop();
                                app.refresh();
                            });
                        }
                    }, 800);
                }
            }
        };

        var funConvertAtch = function (planOrders) {
            var planlen = planOrders.length;
            var fileSystem = null;
            var directryEntry = null;
            if (planlen > 0) {
                if (acthSavePath == "") {
                    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (_fileSystem) {
                        fileSystem = _fileSystem;
                        fileSystem.root.getDirectory("LimisAtchFile", {create: true, exclusive: false},
                            function (_directryEntry) {
                                directryEntry = _directryEntry;
                                acthSavePath = _directryEntry.fullPath;
                            }, function () {
                                app.alert("创建目录失败");
                            });
                    });
                }

                if (fileSystem != null && directryEntry != null) {
                    for (var i = 0; i < planlen; i++) {
                        var item = planOrders[i];
                        if (item.AttFile != null && item.AttFile.length > 0) {
                            var attFilelen = item.AttFile.length;
                            for (var k = 0; k < attFilelen; k++) {
                                var attFileItem = item.AttFile[k];
                                var attPath = attFileItem.AttPath || "";
                                if (attPath != "") {
                                    var startIndex = attPath.lastIndexOf("/");
                                    var fileName = attPath.slice(startIndex + 1);
                                    var imageUri = "/sdcard/download/" + fileName;
                                    var localFilePath = acthSavePath + "/" + fileName;
                                    fileSystem.root.getFile(imageUri, null, function (fileEntry) {
                                        fileEntry.moveTo(directryEntry, fileName, function () {
                                            attFileItem["AttPath"] = localFilePath;
                                        });
                                    });
                                }
                            }
                        }
                    }
                }
            }
        };
        _self.funSearchWork();
    },

    funInitLineData: function () {
        var _self = this;
        var userCode = "";
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                userCode = res;
            }
        });
        if (userCode) {
            var db = app.database.open(Common.WEIXIUDB);
            db.transaction(function (tx) {
                tx.executeSql("SELECT LineNum as 'key' ,LineName as value from Line", [], function (tx1, results) {
                    _self.Lines = Common.funConvertRowsJson(results);
                });
            }, function (error) {
                app.alert(error);
            }, function () {
                var linelen = _self.Lines.length;
                if (linelen > 0) {
                    _self.Lines.unshift({ "key": "NA", "value": "--请选择--" });
                }
            });
        }

    },
    funInitSpecData: function () {
        var _self = this;
        var userCode = "";
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                userCode = res;
            }
        });
        if (userCode) {
            var db = app.database.open(Common.WEIXIUDB);
            db.transaction(function (tx) {
                tx.executeSql("SELECT SpecialtyNum as 'key' ,SpecialtyName as value from Specialty", [], function (tx1, results) {
                    _self.Specs = Common.funConvertRowsJson(results);
                });
            }, function (error) {
                app.alert(error);
            }, function () {
                var linelen = _self.Specs.length;
                if (linelen > 0) {
                    _self.Specs.unshift({"key": "NA", "value": "--请选择--"});
                }
            });
        }
    },

    funLoadStationData: function (lineNum) {
        var _self = this;
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            // tx.executeSql("select LocationNum as 'key',LocationName as value from Location where ( LocationNum like '" + lineNum + "Z%' or LocationNum like '" + lineNum + "D%' OR  LocationNum like '" + lineNum + "O%' ) and length(LocationNum)=6", [], function (tx1, results) { _self.Stations = Common.funConvertRowsJson(results); });
            tx.executeSql("select LocationNum as 'key',LocationName as value from Location where LocationNum like '" + lineNum + "%' and length(LocationNum)=6", [], function (tx1, results) {
                _self.Stations = Common.funConvertRowsJson(results);
            });
        }, function (error) {
            app.alert(error);
        }, function () {
            var stationlen = _self.Stations.length;
            var stationCtr = $("#StationList");
            if (stationlen > 0) {
                _self.Stations.unshift({"key": "NA", "value": "--请选择--"});
            }
            //默认选择站点
            // if (stationlen > 0) {
            //     stationCtr.text(_self.Stations[0]["value"]);
            //     stationCtr.attr("key", _self.Stations[0]["key"]);
            // } else {
            stationCtr.text("--请选择--");
            stationCtr.attr("key", "NA");
            // }
        });
    },
  
    funPlanData: function (containerId) {
        var _self = this;
        var lihtml = "";
        $("#pwNum").text("待办工单(" + _self.PWOSimple.length + ")");
        if (_self.PWOSimple.length == 0) {
            lihtml += '<li>';
            lihtml += '<div data-role="BTButton" mouseup="false" mousedown="false" data-status="1">';
            lihtml += '<span class="btn-text">暂无待办工单</span>';
            lihtml += '</div>';
            lihtml += '</li>';
            $("#btnClearWork").attr("style", "display: none !important");
            $("#btnAllChk").attr("style", "display: none !important;margin-top: 20PX;");
        } else {
            $("#btnAllChk").attr("style", "display: block;margin-top: 20PX;");
            var leng = _self.PWOSimple.length;
            for (var i = 0; i < leng; i++) {
                var row = _self.PWOSimple[i];
                _self.PWONumList.push(row["PWONum"]);
                lihtml += '<li>';
                lihtml += '<div data-role="BTButton" data-status="1">';
                lihtml += '<span class="btn-text">';
                lihtml += '<div class="row-box">';
                lihtml += '<div class="span1">';
                lihtml += '<div id=' + row["PWONum"] + ' value=' + row["PWONum"] + ' data-role="BTCheck" ' + "class='BTCheck_OFF'" + ' data-inline="false">' + row["PWONum"] + "_" + row["OPName"] + '</div>';
                lihtml += '</div>';
                lihtml += '</div>';
                lihtml += '</span>';
                lihtml += '</div>';
                lihtml += ' </li>';
            }
        }

        var cnt = document.getElementById(containerId);
        if (cnt) {
            cnt.innerHTML = lihtml;
            ui.init();
        }
        _self.funBindEvent();

    },
    funSearchWork: function () {
        var _self = this;
        var lasversionNum = "";
        var funIsNewApk = function () {
            var retIsNewApk = true;
            var localVersion = "";
            var platform = "";
            if (window.devicePlatform == "android") {
                platform = "android";
            } else if (window.devicePlatform == "iOS") {
                platform = "ios";
            }
            app.getInfo(function (res) {
                localVersion = res.versionName + "";
                localVersion = localVersion.substr(1, 3);
                localVersion = localVersion - 0;

                var reqVersionParam = new Object();
                reqVersionParam.orgin = "stream";
                reqVersionParam.CallMethod = "Com_DownloadBaseData";
                var dlDataParam = new Object();
                dlDataParam.DataType = "CheckVersion";
                dlDataParam.Platform = platform;
                reqVersionParam.AuthBlock = new Object();
                reqVersionParam.AuthBlock.UserCode = "admin";
                reqVersionParam.AuthBlock.Password = "112233";
                reqVersionParam.PayLoad = dlDataParam;
                app.ajax({
                    "url": MobileConfig.DownBaseDataUrl, "data": reqVersionParam,
                    "contentType": "application/json",
                    "method": "POST", "async": false,
                    "success": function (res) {
                        var responseData = JSON.parse(res.returnValue);
                        var serverVersion = responseData.PayLoad.VersionNumber;
                        serverVersion = serverVersion - 0;
                        if (localVersion < serverVersion) {
                            lasversionNum = serverVersion;
                            retIsNewApk = false;
                        }
                    }
                });
                return retIsNewApk;
            });
        };
        var funSearch = function () {
            _self.downParam = _self.funGetDownParam();//查询工单，获取查询条件
            var requestParam = new Object();
            requestParam.orgin = "stream";
            requestParam.CallMethod = "Biz_FetchOrderList";//查询工单
            requestParam.AuthBlock = new Object();
            requestParam.AuthBlock.ClientNumber = device.uuid;
            requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
            app.getGlobalVariable("UserCode", function (res) {
                if (res) {
                    requestParam.AuthBlock.UserCode = res;
                }
            });
            app.getGlobalVariable("Password", function (res) {
                if (res) {
                    requestParam.AuthBlock.Password = res;
                }
            });
            requestParam.PayLoad = _self.downParam;
            app.ajax({
                "url": MobileConfig.DownWorkUrl,
                "data": requestParam,
                "contentType": "application/json",
                // "contentType": "application/x-www-form-urlencoded",
                "method": "POST",
                "timeout": 600000,
                "async": true,
                "success": function (res) {
                    var planOrder = JSON.parse(res.returnValue);
                    //不显示已下载工单
                    if (planOrder.ResStatus == true) {
                        var planList = planOrder.PayLoad;
                        var sqlPlanText = "select OPCode,OPName,PWONum,WorkStatus from OPPlan order by WorkStatus asc";
                        var db = app.database.open(Common.WEIXIUDB);

                        //遍历本地是否已存在要下载的工单，
                        //如果已存在，不会更新，因为本地有操作步骤，避免覆盖
                        app.database.executeQuery(db, sqlPlanText, function (tx, results) {
                            var rows = Common.funConvertRowsJson(results);
                            var rowlen = rows.length;
                            var orderlen = planList.length;
                            var planOrders = new Array();
                            var exitsPlans = new Array();
                            //遍历网络返回
                            for (var i = 0; i < orderlen; i++) {
                                var planOrder = planList[i];
                                var isSave = true;
                                //遍历本地
                                for (var k = 0; k < rowlen; k++) {
                                    var row = rows[k];
                                    if (planOrder.PWONum == row.PWONum) { //说明存在
                                        isSave = false;
                                        exitsPlans.push(row["OPCode"] + row["OPName"]);
                                        break;
                                    }
                                }
                                if (isSave) {
                                    if ($.inArray(planOrders, planOrder) == -1) {
                                        planOrders.push(planOrder);
                                    }
                               
                                }
                            }

                            _self.PWOSimple = planOrders;
                            _self.funPlanData("planList");
                            app.progress.stop();
                        });


                    } else {
                        app.alert(planOrder.ResMsg, function () {
                            app.progress.stop();
                        });
                    }
                },
                "fail": function (res) {
                    app.alert("由于网络原因,暂时没有接收到数据,请稍后重试\n" + JSON.stringify(res), function () {
                        app.progress.stop();
                    });
                }
            });
        };


        app.progress.start("下载提示", "正在处理中...");
        // var isNewApk = funIsNewApk();
        // //TODO 屏蔽了判断更新
        // if (isNewApk == false) {
        //     app.progress.stop();
        //     app.alert("版本已更新，请先更新到[v" + lasversionNum + "]版本", function () {
        //         Common.funClearModuleCache();//删除页面跳转保存的全局变量
        //         var db = app.database.open("WEIXIUDB");
        //         app.database.executeNonQuery(db, "delete from OPUsers where 1=1", function () {
        //             app.load({url: "login.html"});
        //         });
        //     });
        // } else {
        //     funSearch();
        // }


        funSearch();
    },

    funDownWorkNew: function () {
        var _self = this;
        app.progress.start("下载提示", "正在处理中...");

        var funGetDownNumList = function () {
            var length = _self.PWOSimple.length;
            var selNumList = "";
            if (length > 0) {
                for (var i = 0; i < length; i++) {
                    var chkBox = $("#" + _self.PWOSimple[i]["PWONum"]);
                    var result = chkBox.btcheck("val");
                    if (result != null && result.value != "") {
                        selNumList = selNumList + ",'" + _self.PWOSimple[i]["PWONum"] + "'";
                    }
                }
                //去掉第一个逗号
                selNumList = selNumList.substring(1, selNumList.length);
            }
            return selNumList;
        };
        var selNumList = funGetDownNumList();
        if (selNumList.length > 0) {
            var requestParam = new Object();
            requestParam.orgin = "stream";
            requestParam.CallMethod = "Biz_FetchPlanOrder";//下载工单
            requestParam.AuthBlock = new Object();
            requestParam.AuthBlock.ClientNumber = device.uuid;
            requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
            app.getGlobalVariable("UserCode", function (res) {
                if (res) {
                    requestParam.AuthBlock.UserCode = res;
                }
            });
            app.getGlobalVariable("Password", function (res) {
                if (res) {
                    requestParam.AuthBlock.Password = res;
                }
            });

            requestParam.PayLoad = _self.downParam;
            requestParam.PayLoad.PWONumList = selNumList;
            app.ajax({
                "url": MobileConfig.DownWorkUrl,
                "data": requestParam,
                // "contentType": "text/json; charset=utf-8",
                "contentType": "application/json",
                "method": "POST",
                "timeout": 600000,
                "async": true,
                "success": function (res) {
                    var planOrder = JSON.parse(res.returnValue);
                    if (planOrder.ResStatus == true) {
                        var planList = planOrder.PayLoad;
                        if (planList.length > 0) {
                            _self.funSaveDownWork(planList, true);
                        } else {
                            app.alert("下载了0待办工单\n", function () {
                                app.progress.stop();
                            });
                        }
                    } else {
                        app.alert("下载失败\n" + planOrder.ResMsg, function () {
                            app.progress.stop();
                        });
                    }
                },
                "fail": function (res) {
                    app.alert("由于网络原因,暂时没有接收到数据,请稍后重试\n" + JSON.stringify(res), function () {
                        app.progress.stop();
                    });
                }
            });


        } else {
            if (_self.PWOSimple.length > 0) {
                app.alert("请选择要下载的工单。", function () {
                    app.progress.stop();
                });
            } else {
                app.alert("请先查询工单。", function () {
                    app.progress.stop();
                });
            }

        }


    },
    deleteEmptyProperty :function (object){
        for (var i in object) {
            var value = object[i];
            if (!value || typeof value !== 'object') {
                if (value === '' || value === null || value === undefined) {
                    delete object[i];
                }
            }
        }
    },

    funBackRefresh: function () {
        var _self = this;
        //初始化界面数据
        _self.funInitUiData();
        //初始化线路数据
        _self.funInitLineData();
        //初始化专业数据
        _self.funInitSpecData();
    }
};
