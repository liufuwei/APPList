var FaultDetail = function () {
    this.PageParam = null;
    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);
};
FaultDetail.prototype = {
    funInitUiData: function () {
        var _self = this;
        var pageParam = _self.PageParam;
        var requestParam = new Object();
        requestParam.AuthBlock = new Object();
        requestParam.CallMethod = "Misc_FetchFaultDetail";
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                requestParam.AuthBlock.UserCode = res;
            }
        });
        app.getGlobalVariable("Password", function (res) {
            if (res) {
                requestParam.AuthBlock.Password = res;
            }
        });
        requestParam.PayLoad = new Object();
        app.getPageParams(function (result) {
            if (result) {
                requestParam.PayLoad.WONum = result["WONum"];
            }
        });
        app.progress.start("提示", "数据正在处理...");
        app.ajax({
                    "url": MobileConfig.CmDownLoad,
                        "data": requestParam,
                        "contentType": "application/json",
                        "method": "POST",
                        "async": true,
                        "success": function (res) {
                        var faultDetailData = JSON.parse(res.returnValue);
                        if (faultDetailData.ResStatus == true) {
                            app.progress.stop();
                            var faultDetail = faultDetailData.PayLoad;
                            $('#divBase>div:nth-child(1)>div:last-child').html(faultDetail.FormStatusName);
                            $('#divBase>div:nth-child(2)>div:last-child').html(faultDetail.WOCode);
                            $('#divBase>div:nth-child(3)>div:last-child').html(faultDetail.WOName);

                            $('#divBase>div:nth-child(4)>div:last-child').html(faultDetail.FaultReportUserName);
                            $('#divBase>div:nth-child(5)>div:last-child').html(faultDetail.FaultRepMobilePhone);

                            $('#divBase>div:nth-child(6)>div:last-child').html(faultDetail.LineName);
                            $('#divBase>div:nth-child(7)>div:last-child').html(faultDetail.LocationCode + "—" + faultDetail.LocationName);
                            $('#divBase>div:nth-child(8)>div:last-child').html(faultDetail.EquipmentCode + "—" + faultDetail.EquipmentName);

                            $('#divBase>div:nth-child(9)>div:last-child').html(faultDetail.SpecialtyName);
                            $('#divBase>div:nth-child(10)>div:last-child').html(faultDetail.SubSystemName);
                            $('#divBase>div:nth-child(11)>div:last-child').html(faultDetail.FaultTime);
                            $('#divBase>div:nth-child(12)>div:last-child').html(faultDetail.FaultLocation);
                            $('#divBase>div:nth-child(13)>div:last-child').html(faultDetail.StartFaultDescription);
                            $('#divBase>div:nth-child(14)>div:last-child').html(faultDetail.FaultClassify);
                            $('#divBase>div:nth-child(15)>div:last-child').html(faultDetail.JobHeadUserName);
                            $('#divBase>div:nth-child(16)>div:last-child').html(faultDetail.FaultAnswerTime);
                            $('#divBase>div:nth-child(17)>div:last-child').html(faultDetail.FaultCompleteTime);

                            $('#divBase>div:nth-child(18)>div:last-child').html(faultDetail.FaultDescription);
                            $('#divBase>div:nth-child(19)>div:last-child').html(faultDetail.FaultReason);
                            $('#divBase>div:nth-child(20)>div:last-child').html(faultDetail.FaultMemo);
                        } else {
                            app.alert(faultDetailData.ResMsg, function () {
                        app.progress.stop();
                    });
                }

            }
        });
    },

    funBackRefresh : function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var pageName = retParam["pageName"];
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funInitUiData();
        }, 100);
    }
};
