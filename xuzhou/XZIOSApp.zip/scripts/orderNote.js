﻿//工单备注
var OrderNote = function () {
    this.PageParam = null;
    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);
};

OrderNote.prototype = {
    funInitEvent:function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);
        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSaveNote").click(function () {
            var note = $("#txtDeviceNote").val().trim();
            _self.funSaveDeviceNote(note);
        });
    },
    funInitNote: function (containerId) {
        var _self = this;
        var wONum = _self.PageParam["WONum"];
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            tx.executeSql('SELECT DeviceNote FROM OPOrders WHERE  WONum=?', [wONum], function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowlen = rows.length;
                if (rowlen > 0) {
                    var note = rows[0]["DeviceNote"] || "";
                    if (note) {
                        $("#" + containerId).val(note);
                    }
                }
            });
        }, function (error) {
            app.alert(error);
        });
    },

    funSaveDeviceNote: function (note) {
        var _self = this;
        var wONum = _self.PageParam["WONum"];
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            tx.executeSql('update OPOrders set DeviceNote=? where WONum=?', [note, wONum]);
        }, function (error) {
            app.alert(error);
        }, function () {
            //app.back();
            Common.funGoBack();
        });
    }
};