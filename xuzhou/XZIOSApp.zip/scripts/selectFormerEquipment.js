﻿var SelDevice = function () {
    this.PageParam = null;
    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);
};

SelDevice.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
  
            var faultObj = _self.PageParam;
            faultObj.manualSelect = "0"; //手选页面传回一个“1”回去上一个填报故障信息页面
            Common.funGoBack(faultObj, "selectFormerEquipment.html");
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSelectDevice").click(function () {
            _self.funSelectDevice("txtDeviceName", "devicelist");
        });
    },

    funSelectDevice: function (inputCntId, containerId) {
    
        var _self = this;
        var inputCtr = $("#" + inputCntId);
        var deviceName = inputCtr.val().trim();
        if (deviceName) {
            var sql = 'select * from Device where DeviceName like "%' + deviceName + '%" or DeviceNum like "%' + deviceName + '%"';
            var db = app.database.open(Common.WEIXIUBASEDB);
            app.database.executeQuery(db, sql, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowlen = rows.length;
                var liHtml = "";
                if (rowlen > 0)
                {
                    inputCtr.val("");
                    var row1 = rows[0];
                    for (var i = 0; i < rowlen; i++)
                    {
                        var row = rows[i];
                        var FormerEquipment = row.DeviceNum;
                        var FormerEquipmentName = row.DeviceName;
                        var FormerEquipmentLocation= row.LocationNum;
                        var FormerEquipmentLocationName = row.LocationName;
                        var locationName = row.LocationName;
                        liHtml += '<li  id="li' + FormerEquipment + '"  FormerEquipment="' + FormerEquipment +'"  FormerEquipmentName="' + FormerEquipmentName + '"  FormerEquipmentLocation="' + FormerEquipmentLocation +'"  FormerEquipmentLocationName="' + FormerEquipmentLocationName + '">';
                        liHtml += '<div class="row-fluid">';
                        liHtml += '<div class="span6">' + FormerEquipment + '<br/>' + FormerEquipmentName + '</div>';
                        liHtml += '<div class="span5">' + locationName + '</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                    }
                }
                var cnt = document.getElementById(containerId);
                if (cnt) {
                    var childItems = cnt.children;
                    var childlen = childItems.length;
                    for (var j = 1; j < childlen; j++) {
                        cnt.removeChild(childItems[1]);
                    }
                    if (liHtml) {
                        cnt.innerHTML += liHtml;
                       
                        _self.funBindEvent(rows);
                    } else {
                        liHtml += '<li>';
                        liHtml += '<div class="row-fluid">';
                        liHtml += '<div class="span10" align="center">***暂无数据***</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                        cnt.innerHTML += liHtml;
                    }
                }
            });
        } else {
            app.alert("请输入设备名称");
        }
    },

    funBindEvent: function (rows)
    {
        var _self = this;
        for (var i = 0; i < rows.length; i++)
        {
            var deviceNum =rows[i]["DeviceNum"];
            $("#li" + deviceNum).click(function ()
            {
                var ctr = $(this);
                var FormerEquipment = ctr.attr("FormerEquipment");
                var FormerEquipmentName = ctr.attr("FormerEquipmentName");
                var FormerEquipmentLocation = ctr.attr("FormerEquipmentLocation");
                var FormerEquipmentLocationName = ctr.attr("FormerEquipmentLocationName");
                var faultObj = _self.PageParam;
                faultObj.pageData.FormerEquipment = FormerEquipment;
                faultObj.pageData.FormerEquipmentName =FormerEquipment+"_"+FormerEquipmentName;
                faultObj.pageData.FormerEquipmentLocation = FormerEquipmentLocation;
                faultObj.pageData.FormerEquipmentLocationName =FormerEquipmentLocationName;
                // faultObj.pageData.RecordWay = "p"; //p-选择 s-扫描
                // faultObj.pageData.RecordTime = Common.funGetNowDate();
                faultObj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面
                Common.funGoBack(faultObj, "selectFormerEquipment.html");
            });
        }
    }
};
