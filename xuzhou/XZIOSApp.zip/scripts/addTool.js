/**
 * Created by linsw on 2018/1/2.
 */
var AddTool = function () {
    this.PageParam = null;
    this.StartWkList = new Array();

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
        app.getGlobalVariable("startWkList", function (res) {
            if (res) {
                _this.StartWkList = JSON.parse(res);
            }
        });
    })(this);

    this.SelectTool = null;
    this.OrdersList = new Array();
    this.OrdersList.push({"key": "NA", "value": "--请选择--", "PWONum": ""});
};

AddTool.prototype = {

    funInitEvent: function () {
        var _self = this;
        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSearchTool").click(function () {
            _self.SelectTool = null;
            _self.funSearchTool("toolList");
        });


        $("#btnSaveTool").click(function () {
            _self.funSaveTool();
        });

        $("#btnWONumSelect").click(function () {
            _self.funSwitchWONum();
        });

    },
    funInitProcessData: function () {
        var _self = this;
        var param = _self.PageParam;
        if (param) {
            var pWoNumList = new Array();
            var wklist = _self.StartWkList;
            var wklen = wklist.length;
            for (var k = 0; k < wklen; k++) {
                var pWoNum = wklist[k]["PWONum"];
                pWoNumList.push("PWONum='" + pWoNum + "'");
            }
            if (pWoNumList.length > 0) {
                var sqlWhere = " (" + pWoNumList.join(" or ") + ") ";
                var selSql = " SELECT  PWONum, WONum,DeviceLocation FROM OPOrders where" + sqlWhere;
                var db = app.database.open(Common.WEIXIUDB);
                app.database.executeQuery(db, selSql, function (tx, results) {
                    var rows = Common.funConvertRowsJson(results);
                    var rowlen = rows.length;
                    if (rowlen > 0) {
                        for (var i = 0; i < rowlen; i++) {
                            var row = rows[i];
                            _self.OrdersList.push({
                                "key": row["PWONum"],
                                "value": row["WONum"] + "_" + row["DeviceLocation"],
                                "PWONum": row["PWONum"]
                            });
                        }
                        $("#btnWONumSelect").attr("PWONum", rows[0]["PWONum"]);
                        $("#btnWONumSelect").attr("WONum", rows[0]["PWONum"].split('_')[0]);
                        $("#btnWONumSelect").text(rows[0]["PWONum"])
                    }

                });
            }
        }
        _self.funSearchTool("toolList");
    },
    funSearchTool: function (containerId) {
        var _self = this;
        var toolCtr = $("#txtToolName");
        var toolName = toolCtr.val();
        toolCtr.val("");
        var sqlText = "";
        sqlText += "select * from Tool where OPToolNum like '%" + toolName + "%' or OPToolName like '%" + toolName + "%' limit 100";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sqlText, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowslen = rows.length;
            var liHtml = "";
            for (var i = 0; i < rowslen; i++) {
                var row = rows[i];
                var oPToolNum = row["OPToolNum"] || "";
                var oPToolName = row["OPToolName"] || "";
                var oPToolUnit = row["OPToolUnit"] || "";
                var descText = oPToolNum + "  " + oPToolName;
                if (oPToolUnit) {
                    descText += "(" + oPToolUnit + ")";
                }
                liHtml += '<li id="li' + oPToolNum + '" oPToolNum=' + oPToolNum + ' oPToolName=' + oPToolName + ' oPToolUnit=' + oPToolUnit + ' >';
                liHtml += '<div class="row-fluid">';
                liHtml += '<div class="span10">' + descText + '</div>';
                liHtml += '</div>';
                liHtml += '</li>';
            }

            var cnt = document.getElementById(containerId);
            if (cnt) {
                var childItems = cnt.children;
                var childlen = childItems.length;
                for (var j = 1; j < childlen; j++) {
                    cnt.removeChild(childItems[1]);
                }
                if (liHtml) {
                    cnt.innerHTML += liHtml;
                    _self.funBindEvent(rows);
                } else {
                    liHtml += '<li>';
                    liHtml += '<div class="row-fluid">';
                    liHtml += '<div class="span10" align="center">***暂无数据***</div>';
                    liHtml += '</div>';
                    liHtml += ' </li>';
                    cnt.innerHTML += liHtml;
                }
            }
        });

    },

    funBindEvent: function (rows) {
        var _self = this;
        var rowlen = rows.length;
        for (var i = 0; i < rowlen; i++) {
            var row = rows[i];
            var oPToolNum = row["OPToolNum"] || "";
            if (oPToolNum) {
                $("#li" + oPToolNum).click(function () {
                    var liItem = $(this);
                    var oPToolNum = liItem.attr("OPToolNum");
                    var oPToolName = liItem.attr("OPToolName");
                    var oPToolUnit = liItem.attr("OPToolUnit");
                    var descText = oPToolNum + "  " + oPToolName;
                    if (oPToolUnit) {
                        descText += "(" + oPToolUnit + ")";
                    }
                    var toolName = $("#txtToolName");
                    toolName.val(descText);

                    if (_self.SelectTool == null) {
                        _self.SelectTool = new Object();
                    }
                    _self.SelectTool.OPToolNum = oPToolNum;
                    _self.SelectTool.OPToolName = oPToolName || "";
                    _self.SelectTool.OPToolUnit = oPToolUnit || "";
                });
            }
        }
    },

    funSwitchWONum: function () {
        var _self = this;
        var ordersList = _self.OrdersList;
        if (ordersList.length > 1) {
            var wONumSelectCtr = $("#btnWONumSelect");
            var defkey = wONumSelectCtr.attr("key") || "NA";
            app.wheelSelect.oneSelect(ordersList,
                function (res) {
                    var key = res["key"];
                    var value = res["value"];
                    if (key == "NA") {
                        wONumSelectCtr.attr("WONum", "");
                    } else {
                        wONumSelectCtr.attr("PWONum", key);
                        wONumSelectCtr.attr("WONum", value.split('_')[0]);
                    }
                    wONumSelectCtr.text(value);
                }, defkey, "工单编号");
        }
    },
    funSaveTool: function () {
        var _self = this;
        var toolItem = _self.SelectTool;
        var param = _self.PageParam;
        if (toolItem != null) {
            var wONumSelectCtr = $("#btnWONumSelect");
            var wONum = wONumSelectCtr.attr("WONum") || "NA";
            if (wONum == "NA") {
                app.alert("请选择工单编号");
            } else {
                var toolCount = $("#txtCount").val();
                if (toolCount && !isNaN(toolCount)) {
                    var oPToolNum = toolItem.OPToolNum;
                    var sqlText = "SELECT * from OPTools where PWONum='" + wONum + "' and OPToolNum='" + oPToolNum + "'";
                    var db = app.database.open(Common.WEIXIUDB);
                    app.database.executeQuery(db, sqlText, function (tx, results) {
                        var rows = Common.funConvertRowsJson(results);
                        var rowslen = rows.length;
                        if (rowslen > 0) {
                            app.alert("该工具已存在该工单");
                        } else {
                            var pageName = param["GoPageName"];
                            switch (pageName) {
                                case "outCheck": {
                                    _self.funSaveOPTool();
                                }
                                    break;
                                case "faultReport": {
                                    _self.funSaveFaultTool();
                                }
                                    break;
                            }
                        }
                    });
                } else {
                    app.alert("数量不能为空");
                }
            }
        } else {
            app.alert("请选择需要添加的工具");
        }
    },

    funSaveFaultTool: function () {
        var _self = this;
        var tempFaultWoNum = _self.PageParam.TempFaultWoNum;
        var tempToolList = new Array();
        app.getGlobalVariable(tempFaultWoNum, function (res) {
            if (res) {
                tempToolList = JSON.parse(res);
            }
        });
        var toolDataItem = _self.funGettoolData();
        var tempToolLen = tempToolList.length;
        var isExist = false;
        for (var i = 0; i < tempToolLen; i++) {
            if (tempToolList[i].OPToolNum == toolDataItem.OPToolNum) {
                isExist = true;
                break;
            }
        }
        if (isExist) {
            app.alert("该工具已存于在该故障工单中");
        } else {
            tempToolList.push(toolDataItem);
            app.setGlobalVariable(tempFaultWoNum, JSON.stringify(tempToolList));
            var faultObj = _self.PageParam;
            faultObj.addTool = "tool";
            Common.funGoBack(faultObj, "tool.html");
        }
    },

    funSaveOPTool: function () {
        var _self = this;
        var toolDataItem = _self.funGetToolData();
        var paramEntityList = new Array();
        var planTool = new Object();
        planTool.PWONum = toolDataItem.PWONum;
        planTool.OPToolNum = toolDataItem.OPToolNum;
        planTool.OPToolName = toolDataItem.OPToolName;
        planTool.OPToolCount = toolDataItem.FinishChkCount;
        planTool.OPToolUnit = toolDataItem.OPToolUnit;
        paramEntityList.push(planTool);

        var sql = "INSERT INTO 'OPTools' ('PWONum', 'OPToolNum', 'OPToolName', 'OPToolUnit', 'OPToolCount') VALUES ('"+toolDataItem.PWONum+"', '"+toolDataItem.OPToolNum+"', '"+toolDataItem.OPToolName+"', '"+toolDataItem.OPToolUnit+"', '"+toolDataItem.FinishChkCount+"')";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(db, [sql], function () {
            Common.funGoBack();
        });
    },

    funGetToolData: function () {
        var _self = this;
        var toolItem = _self.SelectTool;
        var wONumSelectCtr = $("#btnWONumSelect");
        var toolDataItem = new Object();
        toolDataItem.PWONum = wONumSelectCtr.attr("PWONum") || "";
        toolDataItem.WONum = wONumSelectCtr.attr("WONum");
        toolDataItem.OPToolNum = toolItem.OPToolNum;
        toolDataItem.OPToolName = toolItem.OPToolName;
        toolDataItem.OPToolUnit = toolItem.OPToolUnit;
        toolDataItem.OPToolCount = "0";
        toolDataItem.FinishChkTime = Common.funGetNowDate();
        toolDataItem.FinishChkCount = $("#txtCount").val();
        app.getGlobalVariable("IsOutSourceUser", function (res) {
            var isOut = res || "0";
            toolDataItem.IsOut = isOut;
        });
        return toolDataItem;
    }
};

funBackRefresh = function (retParamStr) {
    var _self = this;
    try {
        if (retParamStr) {
            var retParam = JSON.parse(retParamStr);
            var pageName = retParam["pageName"];
            var backParam = retParam["backParam"];
            if (backParam) {
                _self.PageParam = backParam;
            }
        }
    } catch (ex) {
        app.alert("addTool.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
    }
    setTimeout(function () {
        _self.funInitProcessData();
    }, 100);
};

