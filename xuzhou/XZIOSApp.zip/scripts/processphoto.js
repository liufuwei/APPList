﻿var Processphoto = function () {
    this.PageParam = null;

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });

    })(this);

    this.PhotoBox = null;
};

Processphoto.prototype = {
    funInitEvent:function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSave").click(function () {
            _self.funSaveProcess("pboxList");
        });
    },
    funInitPageHeader: function () {
        var _self = this;
        var orderObj = new Object();
        orderObj.WONum = _self.PageParam["WONum"];
        SqlHelper.funGetData("OPOrders", function (rowsOrder) {
            var rowsOrderlen = rowsOrder.length;
            if (rowsOrderlen > 0) {
                $("#pageTitle").text(rowsOrder[0]["DeviceLocation"]);
            };
        }, orderObj);
    },

    funInitPhotoBox: function (containerId) {
        var _self = this;
        if (_self.PhotoBox == null) {
            var param = new Object();
            param.ObjectType = "UDWOTASK";
            param.ObjectID = _self.PageParam["UppLayerProcedureNum"];
            param.ContainerId = containerId;
            _self.PhotoBox = new PhotoBox(param);
        }
        _self.PhotoBox.initBox(_self.PhotoBox);
    },

    funSaveProcess: function (containerId) {
        var _self = this;

        var count = $('#' + containerId + ' > div[class="photoList"]').length;
        if (count <= 1) {
            app.alert("照片数量不能为0");
        } else {
            var procedureNum = _self.PageParam["UppLayerProcedureNum"];
            var resultValue = _self.PageParam["ResultValue"];

            var sqlParam = new Object();
            sqlParam.ResultValue = resultValue;
            app.getGlobalVariable("UserName", function (res) { if (res) { sqlParam.SelfFormUserName = res; } });
            app.getGlobalVariable("UserCode", function (res) { if (res) { sqlParam.SelfFormUserCode = res; } });
            sqlParam.SelfFormTime = Common.funGetNowDate();
            sqlParam.WhereParam = new Object();
            sqlParam.WhereParam.ProcedureNum = procedureNum;
            SqlHelper.funUpdateData("OrderProcedure", [sqlParam], function () {
                //app.back();
                Common.funGoBack();
            });
        }
    },
    funBackRefresh: function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var pageName = retParam["pageName"];
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funInitPhotoBox("pboxList");
            _self.funInitPageHeader();
        }, 100);
    }
};