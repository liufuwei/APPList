﻿var FaultList = function () {
};
FaultList.prototype = {
    funInitFaultListData: function (containerId) {
        var _self = this;
        var sqlText = "SELECT * FROM FaultsOrder Where WONum LIKE '-%'";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sqlText, function (tx, results)
        {
            var rows = Common.funConvertRowsJson(results);
            var liHtml = "";
            var rowlen = rows.length;
            if (rowlen > 0) {

                for (var i = 0; i < rowlen; i++)
                {
                    var item = rows[i];
                    if (item.AppCode == "23") {
                        var deviceName = item.DeviceName;
                        var faultDesc = item.FaultDesc;
                        var wONum = item.WONum;
                        liHtml += '<li  id="li' + wONum + '"  >';
                        liHtml += '<div class="row-fluid">';
                        liHtml += '<div id="btnSel' + wONum + '"  WONum="' + wONum + '" class="span10">';
                        liHtml += deviceName + '_' + faultDesc;
                        liHtml += '</div>';
                        liHtml += '<div class="span2" align="right">';
                        liHtml += '<a WONum="' + wONum + '" id="btnDel' + wONum + '" href="javascript:void(0)" class="delN"></a>';
                        liHtml += '</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                    }

                }
            }
            if (liHtml == "") {
                liHtml = ' <li>';
                liHtml += '<div class="row-fluid">';
                liHtml += '<div class="span10" align="center">***暂无数据***</div>';
                liHtml += '</div>';
                liHtml += '</li>';
            }
            var cnt = document.getElementById(containerId);
            if (cnt) {
                cnt.innerHTML += liHtml;
                if (rowlen > 0) {
                    _self.funBindEvent(rows);
                }
            }
        });
    },

    funBindEvent: function (rows) {
        var _self = this;
        var rowlen = rows.length;
        for (var i = 0; i < rowlen; i++) {
            var item = rows[i];
            var wONum = item["WONum"];
            $("#btnDel" + wONum).click(function () {
                var ctr = $(this);
                var wonum = ctr.attr("WONum");
                _self.funDelFault(wonum);
            });

            $("#btnSel" + wONum).click(function () {
                var ctr = $(this);
                var wonum = ctr.attr("WONum");
                Common.funLoad("faultReportCreate.html", { "WONum": wonum });
            });
        }
    },

    funDelFault: function (wonum) {
        app.confirm("确认要删除所选故障工单?", function (index) {
            if (index == 2) {
                var sqlText = "DELETE FROM FaultsOrder where WONum='" + wonum + "'";
                var delAttText = "DELETE FROM AttFile where ObjectID='" + wonum + "'";
                var delMeasurementText = "DELETE FROM Measurement where WONum='" + wonum + "'";
                var delMaterialText = "DELETE FROM OPMaterial where WONum='" + wonum + "'";
                var db = app.database.open(Common.WEIXIUDB);
                app.database.executeNonQuery(db, [sqlText, delAttText, delMeasurementText, delMaterialText], function () {
                    $("#btnDel" + wonum).unbind("tap");
                    $("#btnSel" + wonum).unbind("tap");
                    var liCtr = $("#li" + wonum);
                    liCtr.remove();
                });
            }
        }, "删除故障工单确认", "取消,确定");
    },
    funBackRefresh: function () {
        var _self = this;
        app.refresh();
        // _self.funInitFaultListData("faultList");
    }
};

