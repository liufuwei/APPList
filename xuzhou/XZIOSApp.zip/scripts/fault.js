﻿﻿
var Fault = function () {
    this.PageParam = new Object();

    this.PhotoBox = null;

    this.VideoBox = null;

    this.AudioBox = null;

    this.defaultFaultObj = new Object();//临时参数

    this.FaultMaterial = null;

    this.IsEdit = false;

    this.CurrentUserInfo = new Object();//当前用户

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam.WONum = result.WONum;
            }
        });
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                _this.CurrentUserInfo.UserCode = res;
            }
        });
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                _this.CurrentUserInfo.UserName = res;
                _this.defaultFaultObj.RecUserName = res;
            }
        });

    })(this);

};

Fault.prototype = {
  
    funInitEvent: function () {

        var _self = this;

        document.addEventListener("backbutton", function () {
            var tempFaultWoNum = "";
            app.getGlobalVariable("TempFaultWoNum", function (res) {
                if (res) {
                    tempFaultWoNum = res;
                }
            });
            app.setGlobalVariable("TempFaultWoNum", "");
            app.setGlobalVariable(tempFaultWoNum, "");
//                    Common.funGoBack();
            app.back();
        }, false);

        $("#imback").click(function () {
            var tempFaultWoNum = "";
            app.getGlobalVariable("TempFaultWoNum", function (res) {
                if (res) {
                    tempFaultWoNum = res;
                }
            });
            app.setGlobalVariable("TempFaultWoNum", "");
            app.setGlobalVariable(tempFaultWoNum, "");
//                    Common.funGoBack();
            app.back();
        });
        //点击保存按钮触发的方法
        $("#btnSaveFault").click(function () {
            _self.funSaveFault();
        });


        $("#DeviceName").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM Device";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if (rows && rows[0]["count(*)"] > 0) {
                    var Obj = new Object();
                    Obj.pageData = _self.funGetPageData();
                    Obj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面
                    Common.funLoad("selectDevice.html", Obj);
                } else {
                    app.alert("暂无设备数据，请在主界面更新基础数据--设备");
                }
            });
        });

        $("#FormerEquipmentName").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM Device";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if (rows && rows[0]["count(*)"] > 0) {
                    var Obj = new Object();
                    Obj.pageData = _self.funGetPageData();
                    Obj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面
                    Common.funLoad("selectFormerEquipment.html", Obj);
                } else {
                    app.alert("暂无设备数据，请在主界面更新基础数据--设备");
                }
            });
        });

        $("#NewEquipmentName").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM Device";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if (rows && rows[0]["count(*)"] > 0) {
                    var Obj = new Object();
                    Obj.pageData = _self.funGetPageData();
                    Obj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面
                    Common.funLoad("selectNewEquipment.html", Obj);
                } else {
                    app.alert("暂无设备数据，请在主界面更新基础数据--设备");
                }
            });
        });

        $("#LocationName").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM Location";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if (rows && rows[0]["count(*)"] > 0) {
                    var Obj = new Object();
                    Obj.pageData = _self.funGetPageData();
                    Obj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面
                    Common.funLoad("selectLocation.html", Obj);
                } else {
                    app.alert("暂无位置数据，请在主界面更新基础数据--位置");
                }
            });
        });

      
        /*$("#btnManualSelect").click(function () {
            var device = {
                "LocationID": "LocationID1",
                "LocationNum":"LocationNum1",
                "LocationName": "LocationName1",
                "ParentLocationNum": "ParentLocationNum1"
            };
            var inertFaultsText = SqlTextHelper.funGetInsertText("Location", [device]);
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeNonQuery(db, inertFaultsText, function () {
                alert("success")
            }, function () {
                alert("fail")
            });
        });*/
    },

   


    /**
     * 通过工单号查询故障数据
     */
    funInitPageParam: function () {
      
        var _self = this;
        ///<summary>页面参数统一入口，初始化页面带来的参数</summary>
        _self.defaultFaultObj.FaultRecTime = Common.funGetNowDate();

        if (_self.PageParam) {
            _self.defaultFaultObj.WONum = _self.PageParam["WONum"];//计划修的故障工单号
        }
        var faultsOrderParam = new Object();
        faultsOrderParam.WONum = _self.defaultFaultObj.WONum ? _self.defaultFaultObj.WONum : "";
        if (faultsOrderParam.WONum != "") {
            SqlHelper.funGetData("FaultsOrder", function (rows) { //查询数据库获取数据
                if (rows && rows.length > 0) {
                    _self.defaultFaultObj = rows[0];
                    _self.funInitPageData();
                } else {
                    Common.funGoBack();
                    app.alert("故障工单数据有误请重新下载")
                }
            }, faultsOrderParam, SqlHelper.WEIXIUDB);
        } else {
            _self.funInitPageData();
        }

    },

    funInitPageData: function ()
    {
       
        var _self = this;
        ///<summary>页面数据初始化</summary>
        SqlHelper.funGetData("User", function (rowsUser) {
            if (rowsUser && rowsUser.length > 0) {
                _self.CurrentUserInfo = rowsUser[0];
                var userCode = rowsUser[0].UserCode;
                //获取当前用户信息后再执行
                if (!_self.defaultFaultObj["WONum"]) {
                    //新建工单编号格式为："-" + 员工号 + 时间戳new Date().getTime()    --注意，格式为全数字
                    var WONum = "-" + userCode + new Date().getTime();
                    _self.defaultFaultObj.WONum = WONum;
                    //故障实际发生时间，如果是新增则取当前
                    _self.defaultFaultObj.FailDate = Common.funGetNowDate();
                }
                _self.funBindPageData();
            }
        }, _self.CurrentUserInfo, SqlHelper.WEIXIUDB);
    },

    funBindPageData: function ()
    {
        var _self = this;
        ///<summary>绑定页面数据</summary>
        //初始化拍照控件
        _self.funInitPhotoBox("pboxList");
        //初始化录像控件
        _self.funInitVideoBox("vboxList");
        //录音
        _self.funInitAudioBox("aboxList");
   
        //记录人员姓名
        $("#FaultReportUserName").val(_self.defaultFaultObj.FaultReportUserName || "");
        $("#FaultRepMobilePhone").val(_self.defaultFaultObj.FaultRepMobilePhone || "");
        $("#FaultDesc").val(_self.defaultFaultObj.FaultDesc || "");
        $("#FaultLocation").val(_self.defaultFaultObj.FaultLocation || "");
        $("#FaultJournalTime").val(_self.defaultFaultObj.FaultJournalTime || "");
        $("#FaultTime").val(_self.defaultFaultObj.FaultTime || "");
        $("#OperationTimeFault").val(_self.defaultFaultObj.OperationTimeFault == "1" ? "是" : "否");
        $("#RequestCompletionTime").val(_self.defaultFaultObj.RequestCompletionTime || "");

        $("#RecUserName").val(_self.defaultFaultObj.RecUserName || _self.CurrentUserInfo.UserName);
        $("#FaultRecTime").val(_self.defaultFaultObj.FaultRecTime || Common.funGetNowDate());


        $("#JobHeadUserName").val(_self.defaultFaultObj.JobHeadUserName || "");

        if (_self.defaultFaultObj["IsApplySGPlan"] == "1")
        {
            $("#radioBtnIsApplySGPlanYes").btradio("val", "1");
            $("#radioBtnIsApplySGPlanNo").hide();
            $("#radioBtnIsApplySGPlanYes").show();
        }
        else
        {
        
            $("#radioBtnIsApplySGPlanNo").btradio("val", "0");
            $("#radioBtnIsApplySGPlanYes").hide();
            $("#radioBtnIsApplySGPlanNo").show();
        }

        //if (_self.defaultFaultObj["IsApplySGPlan"] == "1")
        //{
        //    $("#IsApplySGPlanVal").val("1");
        //    $("#IsApplySGPlanVal").text("是");
        //}
        //else
        //{
        //    $("#IsApplySGPlanVal").val("0");
        //    $("#IsApplySGPlanVal").text("否");
        //}

        
        if (_self.defaultFaultObj["IsEquipmentFailure"] == "1") {
            $("#radioBtnIsEquipmentFailureYes").btradio("val", "0");
        } else {
            $("#radioBtnIsEquipmentFailureNo").btradio("val", "0");
        }
        _self.funSetDatepicker("FaultCriminalDate", "FaultCriminalTime", _self.defaultFaultObj["FaultCriminalTime"]);

        ////二维码扫描结果
        //app.getPageParams(function (params)
        //{
        //    $("#LocationName").val(_self.defaultFaultObj.LocationName || "");
        //});

        $("#LocationName").val(_self.defaultFaultObj.LocationName || "");

        $("#DeviceName").val(_self.defaultFaultObj.DeviceName || "");
        $("#DeviceTypeName").val(_self.defaultFaultObj.DeviceTypeName || "");

      
        $("#FormerEquipmentName").val(_self.defaultFaultObj.FormerEquipmentName || "");
        $("#FormerEquipmentLocationName").val(_self.defaultFaultObj.FormerEquipmentLocationName || "");

        $("#NewEquipmentName").val(_self.defaultFaultObj.NewEquipmentName || "");
        $("#NewEquipmentLocationName").val(_self.defaultFaultObj.NewEquipmentLocationName || "");

        $("#LineList").val(_self.defaultFaultObj.LineName || "");
        $("#SpecialtyList").val(_self.defaultFaultObj.SpecialtyName || "");

        _self.funGetSubSystemInfo("SubSystemList");

        if (_self.defaultFaultObj["IsOutSource"] == "1")
        {
            $("#radioBtnIsOutSourceYes").btradio("val", "1");
            $("#IsHasContractName").show();
            $("#IsHasSupplier").show();
            $("#IsHasContractCode").show();
            $("#IsHasSupplierTel").show();

            $("#ContractName").val(_self.defaultFaultObj.ContractName || "");
            $("#Supplier").val(_self.defaultFaultObj.Supplier || "");
            $("#ContractCode").val(_self.defaultFaultObj.ContractCode || "");
            $("#SupplierTel").val(_self.defaultFaultObj.SupplierTel || "");

        }
        else
        {
            $("#radioBtnIsOutSourceNo").btradio("val", "0");
            $("#IsHasContractName").hide();
            $("#IsHasSupplier").hide();
            $("#IsHasContractCode").hide();
            $("#IsHasSupplierTel").hide();
        }
 
        //是否委外隐藏和显示
        $("#radioBtnIsOutSourceYes").click(function ()
        {
            $("#IsHasContractName").show();
            $("#IsHasSupplier").show();
            $("#IsHasContractCode").show();
            $("#IsHasSupplierTel").show();
        });
        $("#radioBtnIsOutSourceNo").click(function () {
            $("#IsHasContractName").hide();
            $("#IsHasSupplier").hide();
            $("#IsHasContractCode").hide();
            $("#IsHasSupplierTel").hide();
        });


        //车体
       
        $("#TrainBody").val(_self.defaultFaultObj.TrainBody || "");
        //车次
        $("#TrainNumber").val(_self.defaultFaultObj.TrainNumber || "");

        //if (FaultClassify != "") {
        //    $("#FaultClassify").btselect("val", {value: FaultClassify, label: FaultClassify}, function (obj, data) {
        //        return true;
        //    });
        //}
        $("#FaultClassify").val(_self.defaultFaultObj.FaultClassify || "");
        
        var FaultCategory = _self.defaultFaultObj.FaultCategory || "";
        var FaultCategoryStr = "";
        var isDriving = false;
        switch (FaultCategory) {
            case "Driving":
                isDriving = true;
                FaultCategoryStr = "影响行车";
                break;
            case "CustomerService":
                FaultCategoryStr = "影响客服";
                break;
            case "Other":
                FaultCategoryStr = "其他";
                break;
            default:
                FaultCategoryStr = "请选择";
                break;
        }

        $("#FaultCategory").btselect("val", {value: FaultCategory, label: FaultCategoryStr}, function (obj, data) {
            return true;
        });
        var RefinePptions = _self.defaultFaultObj.RefinePptions || "";
        var RefinePptionsStr = "";
        switch (RefinePptions) {
            case "Late":
                RefinePptionsStr = "晚点";
                break;
            case "Chink":
                RefinePptionsStr = "清客";
                break;
            case "Help":
                RefinePptionsStr = "救援";
                break;
            case "Downline":
                RefinePptionsStr = "下线";
                break;
            case "Unthreaded":
                RefinePptionsStr = "抽线";
                break;
            default:
                RefinePptionsStr = "请选择";
                break;
        }

        _self.setRefinePptions(isDriving,RefinePptions,RefinePptionsStr);


        if (_self.defaultFaultObj["IsRepair"] == "1") {
            $("#radioBtnIsRepairYes").btradio("val", "1");
        } else {
            $("#radioBtnIsRepairNo").btradio("val", "0");
        }
        _self.funSetDatepicker("ActualFaultDate", "ActualFaultTime", _self.defaultFaultObj["ActualFaultTime"]);
        _self.funSetDatepicker("ResponseDate", "ResponseTime", _self.defaultFaultObj["ResponseTime"]);
        _self.funSetDatepicker("ActualEndDate", "ActualEndTime", _self.defaultFaultObj["ActualEndTime"]);
        _self.funSetDatepicker("FaultCompleteDate", "FaultCompleteTime", _self.defaultFaultObj["FaultCompleteTime"]);
        _self.funSetDatepicker("EquipmentStopStartDate", "EquipmentStopStartTime", _self.defaultFaultObj["EquipmentStopStartTime"]);
        _self.funSetDatepicker("EquipmentStopEndDate", "EquipmentStopEndTime",  _self.defaultFaultObj["EquipmentStopEndTime"]);


        $("#FaultDescription").val(_self.defaultFaultObj.FaultDescription || "");
        $("#FaultReason").val(_self.defaultFaultObj.FaultReason || "");
        $("#FaultMemo").val(_self.defaultFaultObj.FaultMemo || "");
        $("#OrderDesc").val(_self.defaultFaultObj.OrderDesc || "");

        _self.funInitMaterial();
    },

 

    funSetTempFaultWoNum: function () {
        ///<summary>创建故障工单编号</summary>
        app.getGlobalVariable("TempFaultWoNum", function (res) {
            if (!res) {
                app.setGlobalVariable("TempFaultWoNum", Common.funGetPkId());
            }
        });
    },
    funInitMaterial: function () {
        var _self = this;
        var pageParam = new Object();
        pageParam.PWONum = $("#PWONumText").val();
        pageParam.WONum = $("#WONumText").val();
        app.getGlobalVariable("TempFaultWoNum", function (res) {
            if (res) {
                pageParam.TempFaultWoNum = res;
            }
        });
        var faultMaterial = new FaultMaterial(pageParam);
        _self.FaultMaterial = faultMaterial;
        faultMaterial.funInitMaterialData("materiallist");
    },

    funInitPhotoBox: function (containerId) {
        var _self = this;
        if (_self.PhotoBox == null) {
            var param = new Object();
            //拍照的类型，ObjectType为:A,B,C,D 其中：A,工单、B,工序、C,工具、D.故障
            param.ObjectType = "WORKORDER";
            //赋值主键：工单编号
            var WONum = _self.defaultFaultObj["WONum"] || "";//$("#WONumText").val();
            var PWONum = _self.defaultFaultObj["PWONum"] || "";// $("#PWONumText").val();   //2013/12/4 邱嘉楠新增
            param.ObjectID = WONum;
            param.ContainerId = containerId;
            param.PWONum = PWONum;
            param.OrderType = _self.defaultFaultObj["OrderType"];

            if (_self.PageParam) {
                var imgInfos = _self.PageParam["ImgInfos"] || [];
                param.InitAttList = imgInfos;
            }


            _self.PhotoBox = new PhotoBox(param);
            _self.PhotoBox.initBox(_self.PhotoBox);
        }

    },

    funInitVideoBox: function (containerId) {
        var _self = this;
        if (_self.VideoBox == null) {
            var param = new Object();
            //拍照的类型，ObjectType为:A,B,C,D 其中：A,工单、B,工序、C,工具、D.故障
            param.ObjectType = "WORKORDER";
            //赋值主键：工单编号
            var WONum = _self.defaultFaultObj["WONum"] || "";//$("#WONumText").val();
            var PWONum = _self.defaultFaultObj["PWONum"] || "";// $("#PWONumText").val();   //2013/12/4 邱嘉楠新增
            param.ObjectID = WONum;
            param.ContainerId = containerId;
            param.PWONum = PWONum;
            if (_self.PageParam) {
                var videoInfos = _self.PageParam["VideoInfos"] || [];
                param.InitAttList = videoInfos;
            }

            _self.VideoBox = new VideoBox(param);
            _self.VideoBox.initBox(_self.VideoBox);


        }
    },

    funInitAudioBox: function (containerId) {
        var _self = this;
        if (_self.AudioBox == null) {
            var param = new Object();
            param.ObjectType = "WORKORDER";
            var WONum = _self.defaultFaultObj["WONum"] || "";//$("#WONumText").val();
            var PWONum = _self.defaultFaultObj["PWONum"] || "";// $("#PWONumText").val();   //2013/12/4 邱嘉楠新增
            param.ObjectID = WONum;
            param.ContainerId = containerId;
            param.PWONum = PWONum;
            if (_self.PageParam) {
                var audioInfos = _self.PageParam["AudioInfos"] || [];
                param.InitAttList = audioInfos;
            }
            _self.AudioBox = new AudioBox(param);
            _self.AudioBox.initBox(_self.AudioBox);

        }

    },


    funSaveFault: function () {
        var _self = this;
        //确认是否必填已经填写完毕
        var msg = _self.funCheckRequired();

        if (msg !== "") {
            app.alert(msg);
            return;
        }
        var faultObj = _self.funGetPageData();
        var sqlList = new Array();


        var delFaultSql = "Delete FROM FaultsOrder WHERE WONum='" + faultObj.WONum + "'";
        sqlList.push(delFaultSql);

        var inertFaultsText = SqlTextHelper.funGetInsertText("FaultsOrder", [faultObj]);
        sqlList = sqlList.concat(inertFaultsText);
        if (faultObj.WONum.substr(0, 1) != "-") {
            //p-选择 s-扫描 暂时没有扫描的数据都是p
            var updOrdersText = "UPDATE OPOrders set SelfFormIsFinished = '1',SelfFormUserName='" + faultObj.RecUserName + "',SelfFormFinishTime='" + faultObj.FaultRecTime + "',SelfFormUserCode ='" + _self.CurrentUserInfo.UserCode + "',RecWay ='p',RecTime='" + faultObj.RecordTime + "' where WONum='" + faultObj.WONum + "'";
            sqlList.push(updOrdersText);
        }
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(db, sqlList, function () {
            app.alert("保存成功", function () {
                var tempFaultWoNum = "";
                app.getGlobalVariable("TempFaultWoNum", function (res) {
                    if (res) {
                        tempFaultWoNum = res;
                    }
                });
                app.setGlobalVariable("TempFaultWoNum", "");
                app.setGlobalVariable(tempFaultWoNum, "");
                Common.funGoBack();
            });
        });
    },
    funCheckRequired: function ()
    {
        var _self = this;
        var IsYesAndNo = $("#radioBtnIsOutSourceYes").hasClass("BTCheck_ON") ? "1" : "0";
        var msg = "";
        if ($("#LocationName").val() === "") {
            msg = "请选择位置"
        }

        else if ($("#SubSystemList").btselect("val").value === "请选择" || $("#SubSystemList").btselect("val").value === "") {
            msg = "请选择子系统"
        }
        else if ($("#FaultClassify").btselect("val").value === "请选择" || $("#FaultClassify").btselect("val").value === "") {
            msg = "请选择故障分级"
        }
        //else if ($("#FaultCategory").btselect("val").value === "请选择" || $("#FaultCategory").btselect("val").value === "") {
        //    msg = "请选择故障影响类别"
        //}
        else if (_self.funGetDatepicker("ActualFaultDate", "ActualFaultTime") === "") {
            msg = "请填写故障实际发生时间"
        }
        else if (_self.funGetDatepicker("ResponseDate", "ResponseTime") === "") {
            msg = "请填写故障响应时间"
        }
        else if (_self.funGetDatepicker("FaultCompleteDate", "FaultCompleteTime") === "") {
            msg = "请填写完全修复时间"
        }
        else if ($("#FaultDescription").val() === "") {
            msg = "请填写故障现象"
        }
        else if ($("#FaultReason").val() === "") {
            msg = "请填写故障原因"
        }
        else if ($("#FaultMemo").val() === "") {
            msg = "请填写故障措施"
        }

        else if ($("#Supplier").val() === "" && IsYesAndNo ==="1")
        {
            msg = "请填写供应商";
        }
        else if ($("#SupplierTel").val() === "" && IsYesAndNo ==="1")
        {
            msg = "联系方式";
        }
        return msg;
    },

    funGetPageData: function () {
        var _self = this;
        var faultObject = _self.defaultFaultObj;
        //故障处理人
        faultObject.RecUserName = $("#RecUserName").val() ? $("#RecUserName").val() : _self.CurrentUserInfo.UserName;
        //故障处理时间
        faultObject.FaultRecTime = $("#FaultRecTime").val() ? $("#FaultRecTime").val() : Common.funGetNowDate();
        //是否申报施工计划
        faultObject.IsApplySGPlan = $("#radioBtnIsApplySGPlanYes").hasClass("BTCheck_ON") ? "1" : "0";
        //是否属设备故障
        faultObject.IsEquipmentFailure = $("#radioBtnIsEquipmentFailureYes").hasClass("BTCheck_ON") ? "1" : "0";
        //是否委外
        faultObject.IsOutSource = $("#radioBtnIsOutSourceYes").hasClass("BTCheck_ON") ? "1" : "0";
        //是否启动抢修
        faultObject.IsRepair = $("#radioBtnIsRepairYes").hasClass("BTCheck_ON") ? "1" : "0";
        //故障分级
        faultObject.FaultClassify = ($("#FaultClassify").btselect("val").value === "请选择") ? "": $("#FaultClassify").btselect("val").value ;
        //故障影响类别
        faultObject.FaultCategory = ($("#FaultCategory").btselect("val").value === "请选择") ? "":$("#FaultCategory").btselect("val").value;
        //细化选项
        faultObject.RefinePptions = ($("#RefinePptions").btselect("val").value === "请选择") ? "":$("#RefinePptions").btselect("val").value;
        //子系统
        faultObject.SubSystemID = ($("#SubSystemList").btselect("val").value === "请选择") ? "":$("#SubSystemList").btselect("val").value;

        //故障实际发生时间
        faultObject.FaultCriminalTime = _self.funGetDatepicker("FaultCriminalDate", "FaultCriminalTime");
        //故障实际发生时间
        faultObject.ActualFaultTime = _self.funGetDatepicker("ActualFaultDate", "ActualFaultTime");
        //故障响应时间
        faultObject.ResponseTime = _self.funGetDatepicker("ResponseDate", "ResponseTime");
        //故障临时修复时间
        faultObject.ActualEndTime = _self.funGetDatepicker("ActualEndDate", "ActualEndTime");
        //故障完全修复时间
        faultObject.FaultCompleteTime = _self.funGetDatepicker("FaultCompleteDate", "FaultCompleteTime");
        //设备停机开始时间
        faultObject.EquipmentStopStartTime = _self.funGetDatepicker("EquipmentStopStartDate", "EquipmentStopStartTime");
        //设备停机结束时间
        faultObject.EquipmentStopEndTime = _self.funGetDatepicker("EquipmentStopEndDate", "EquipmentStopEndTime");

        //故障现象
        faultObject.FaultDescription = $("#FaultDescription").val();
        //故障原因
        faultObject.FaultReason = $("#FaultReason").val();
        //故障措施
        faultObject.FaultMemo = $("#FaultMemo").val();
        //备注
        faultObject.OrderDesc = $("#OrderDesc").val();

        //备注
        faultObject.OrderDesc = $("#OrderDesc").val();

        //车体
        faultObject.TrainBody = $("#TrainBody").val();

        //车次
        faultObject.TrainNumber = $("#TrainNumber").val();


        //合同名称
        faultObject.ContractName = $("#ContractName").val();

        //供应商
        faultObject.Supplier = $("#Supplier").val();

        //合同号
        faultObject.ContractCode = $("#ContractCode").val();

        //联系方式
        faultObject.SupplierTel = $("#SupplierTel").val();

        //原对调设备
        faultObject.FormerEquipmentName = $("#FormerEquipmentName").val();
        //原对调设备位置
        faultObject.FormerEquipmentLocationName = $("#FormerEquipmentLocationName").val();

        //新对调设备
        faultObject.NewEquipmentName = $("#NewEquipmentName").val();
        //新对调设备位置
        faultObject.NewEquipmentLocationName = $("#NewEquipmentLocationName").val();

        return faultObject;

    },

    funEditMeasurement: function () {
        var _self = this;
        var deviceNum = $("#deviceList").btselect("val").value;
        if ((deviceNum == "请选择") || deviceNum == "") {
            app.alert("请先选择故障设备");
        } else {
            _self.funSaveFault("measurePoint");
        }
    },


    funSetDatepicker: function (dateId, timeId, date) {
        ///<summary>设置日期</summary>
        ///<param name="dateId">日期主键</param>
        ///<param name="timeId">时间主键</param>
        ///<param name="date">日期，为空则清除</param>
        if (!date || date == "") {
            $("#" + dateId).attr("value", "");
            $("#" + dateId + " span")[0].innerHTML = "日期";
            $("#" + timeId).attr("value", "");
            $("#" + timeId + " span")[0].innerHTML = "时间";
            return;
        }
        var dates = date.split(" ");
        $("#" + dateId).attr("value", dates[0].replace(/\//g, "-"));
        $("#" + dateId + " span")[0].innerHTML = dates[0].replace(/\//g, "-");
        var timeValue = dates[1].length > 5 ? dates[1].substring(0, dates[1].lastIndexOf(":")) : dates[1];
        $("#" + timeId).attr("value", timeValue);
        $("#" + timeId + " span")[0].innerHTML = timeValue;
    },

    funGetDatepicker: function (dateId, timeId) {
        ///<summary>获取日期</summary>
        ///<param name="dateId">日期主键</param>
        ///<param name="timeId">时间主键</param>
        var dateTimeValue = '';
        var dateValue = $("#" + dateId).btselect("val").value;
        var timeValue = $("#" + timeId).btselect("val").value;
        if (dateValue != "" && timeValue != "") {
            dateTimeValue = dateValue + " " + timeValue + ":0";
        }

        return dateTimeValue;
    },

    funGetSubSystemInfo: function (containerId) {
        var _self = this;
        ///<summary>获取子系统列表方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        ///<param name="_self" >类本身</param>
        var param = new Object();
        var divContainer = $("#" + containerId);
        if (!divContainer) {
            return;
        }
        param.SpecialtyNum = (_self.defaultFaultObj.SpecialtyNum == '') ? _self.defaultFaultObj["SpecialtyNum"] : _self.defaultFaultObj.SpecialtyNum;
        var defaultValue = _self.defaultFaultObj["SubSystemID"];
        _self.funGetFaultInfo("SubSystem", containerId, "SubSystemID", "SubSystemName", param, "", SqlHelper.WEIXIUBASEDB, defaultValue || "");
    },
    funGetLineInfo: function (containerId) {
        var _self = this;
        ///<summary>获取线路列表方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        ///<param name="_self" >类本身</param>
        var param = new Object();
        var divContainer = $("#" + containerId);
        if (!divContainer) {
            return;
        }
        var defaultValue = _self.defaultFaultObj["LineNum"];
        _self.funGetFaultInfo("Line", containerId, "LineNum", "LineName", param, "", SqlHelper.WEIXIUBASEDB, defaultValue || "");
    },

    funGetSpecialtyInfo: function (containerId) {
        var _self = this;
        ///<summary>获取专业列表方法</summary>
        ///<param name="containerId" >DIV容器ID</param>
        ///<param name="_self" >类本身</param>
        var param = new Object();
        var divContainer = $("#" + containerId);
        if (!divContainer) {
            return;
        }
        var defaultValue = _self.defaultFaultObj["SpecialtyNum"];
        _self.funGetFaultInfo("Specialty", containerId, "SpecialtyNum", "SpecialtyName", param, "", SqlHelper.WEIXIUBASEDB, defaultValue || "");
    },
    funGetFaultInfo: function (tableName, CId, colum1, colum2, relColumParam, whereCondition, database, value, emptyMsg) {
        var _self = this;
        ///<summary>获取故障设备信息公用方法</summary>
        ///<param name="tableName" >表名</param>
        ///<param name="CId" >容器ID</param>
        ///<param name="colum1" >表字段1，作为Key</param>
        ///<param name="colum2" >表字段2，作为Value</param>
        ///<param name="relColumParam" >需要查询的关联字段参数对象</param>
        ///<param name="whereCondition">直接使用的查询条件 如：and 字段名1='' and 字段名2 in('') and 字段名3 like '%%'</param>
        ///<param name="database" >需要查询的数据库名</param>
        ///<param name="value" >默认选中项的值selectedValue 如果默认第一个使用@first 如果默认[请选择]使用""或者null</param>
        ///<param name="emptyMsg" >没有查询到数据时的提示</param>
        SqlHelper.funGetDataByWhere(tableName, function (rows) {
            var deviceList = new Array();
            if (rows.length == 0) {
                if (emptyMsg) {
                    app.alert(emptyMsg);
                }
                //app.alert("查询不到相关设备");
            } else {
                var isContain = false;
                var isNeedCheck = !!value ? (value != "@first" && value != 'undefined') : false;//是否有指定初始值，如果默认第一个则没有，为空也没有，不为空且不系于@first则有
                for (var i = 0; i < rows.length; i++) {
                    var deviceItem = new Object();
                    deviceItem.key = rows[i][colum1];
                    deviceItem.value = rows[i][colum2];
                    deviceList.push(deviceItem);
                    if (isNeedCheck && value == rows[i][colum1]) {
                        isContain = true;
                    }
                }
                if (value == "@first") {
                    isContain = true;
                    value = rows[0][colum1];
                }
                var html = '<div id="' + CId + '" data-role="BTSelect" value="' + (isContain ? value : "") + '" callback="' + CId + 'Callback" data=\'[{"key":"","value":"请选择"}]\' ><span>请选择</span></div>';
                $("#" + CId).parent().html(html);
                $("#" + CId).attr("data", JSON.stringify(deviceList));
                $("#" + CId).uiwidget();
            }
        }, relColumParam, whereCondition, database);
    },
    setRefinePptions: function (isDriving,value1,label1) {
        if (isDriving) {
            $("#LiRefinePptions").css("display", "");
        } else {
            $("#LiRefinePptions").css("display", "none");
        }
        if(!value1){
            value1 = ""
        }
        if(!label1){
            label1 = "请选择"
        }
        $("#RefinePptions").btselect("val", {value: value1, label: label1}, function (obj, data) {
            return true;
        });
    },

    funBackRefresh: function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                retParamStr = retParamStr.replace(/\n/g, "\\n");
                var retParam = JSON.parse(retParamStr);
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.defaultFaultObj = backParam.pageData;
                }
            }
        } catch (ex) {
            app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funBindPageData()
        }, 100);
    }
};


