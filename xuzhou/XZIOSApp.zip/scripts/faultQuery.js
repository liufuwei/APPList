﻿var FaultQuery = function () {

    this.FaultOrderPath = localStorage.getItem("FaultOrderPath") || "";

    this.FaultDataList = new Array();

};


FaultQuery.prototype = {

    funBindEvent: function (rows) {
        var _self = this;
        _self.FaultDataList = rows;
        var rowlen = rows.length;
        for (var i = 0; i < rowlen; i++) {
            var ctrId = "btnDetail" + i;
            $("#" + ctrId).click(function () {
                var index = $(this).attr("index");
                var param = _self.FaultDataList[index];// param
                Common.funLoad("faultQueryDetail.html", param);
                var event = event || window.event;  //用于IE
                if (event.preventDefault) event.preventDefault();  //标准技术
                if (event.returnValue) event.returnValue = false;  //IE
                return false;

            });
        }
    },

    funInitFaultData: function (containerId) {
        var _self = this;
        var filePath = _self.FaultOrderPath;
        if (filePath) {
            app.progress.start("提示", "正在处理中...");
            app.file.readAsString(filePath, function (res) {
                var planOrder = JSON.parse(res);
                app.progress.stop();
                if (planOrder.ResStatus == true) {
                    var lihtml = "";
                    var planList = planOrder.PayLoad.CMList;
                    if (planList.length > 0) {
                        var pLen = planList.length;
                        for (var i = 0; i < pLen; i++) {
                            var item = planList[i];
                            var ctrId = "btnDetail" + i;
                            lihtml += '<li>';
                            lihtml += '   <div data-role="BTButton" data-icon="icon-chevron-down" data-iconpos="right">';
                            lihtml += '       <div class="row-box">';
                            lihtml += '           <div class="span1">';
                            lihtml += '               <div class="thumbnail-text">';
                            lihtml += '                   <h3>' + (item["WONUM"] || "") + '</h3>';
                            lihtml += '                   <p>时间：' + (item["STATUSDATE"] || "") + ' | 状态：' + (item["STATUS"] || "") + '</p>';
                            lihtml += '               </div>';
                            lihtml += '           </div>';
                            lihtml += '           <div  id="' + ctrId + '"  index="' + i + '" class="faultDetail" data-role="BTButton" >详&nbsp;&nbsp;情</div>';
                            lihtml += '       </div>';
                            lihtml += '   </div>';
                            lihtml += '   <div class="collapse-content">';
                            lihtml += '       <div>' + item["DESCRIPTION"] + '</div>';
                            lihtml += '   </div>';
                            lihtml += '</li>';
                        }
                        var cnt = document.getElementById(containerId);
                        if (cnt) {
                            if (lihtml) {
                                cnt.innerHTML = lihtml;
                                ui.init();
                                _self.funBindEvent(planList);
                            }
                        }
                    }
                }
            }, function (res) {
                app.alert(res, function () {
                    app.progress.stop();
                });
            });
        }

    },
    funBackRefresh: function () {
        var _self = this;
        _self.funInitFaultData("faultList");
    }
};

