﻿var MultiProcess = function () {
    this.PageParam = null;

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });

    })(this);

    this.OrdinaryProcessDic = new Dictionary(); //普通工序
    this.KeyProcessDic = new Dictionary();//关键工序
};

MultiProcess.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);


        $("#tabSelect").click(function () {
            var isHas = $("#tabSelect").hasClass("btn-active");
            if (isHas == false) {
                $("#divInput").css("display", "none");
                $("#divSelect").css("display", "");
            }
        });

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#tabInput").click(function () {
            var isHas = $("#tabInput").hasClass("btn-active");
            if (isHas == false) {
                $("#divSelect").css("display", "none");
                $("#divInput").css("display", "");
            }
        });


        $("#btnSaveProcess").click(function () {
            _self.funSaveProcess();
        });
    },
    funInitUi: function () {
        var _self = this;
        var title = _self.PageParam["PageHeader"];
        if (title) {
            $("#pageTitle").text(title);
        }

        var actStarts = _self.PageParam["ActStart"].split(" ");
        $("#time_ActStartDate").btdatepicker("val", actStarts[0]);
        $("#time_ActStartTime").btdatepicker("val", actStarts[1].substring(0, actStarts[1].lastIndexOf(":")));
    },

    funInitProcessData: function (cntSelectId, cntInputId) {
        var _self = this;
        var deviceList = _self.PageParam["Devices"];
        var wONumList = new Array();
        var devicelen = deviceList.length;
        for (var j = 0; j < devicelen; j++) {
            var wONumItem = deviceList[j].key;
            wONumList.push("WONum='" + wONumItem + "'");
        }
        var sqlWhere = " (" + wONumList.join(" or ") + ") ";
        var sql = "SELECT * FROM OrderProcedure WHERE " + sqlWhere + " and UppLayerProcedureNum='' Order by WONum,SortNum  asc";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sql, function (tx, results) {

            var rows = Common.funConvertRowsJson(results);
            var rowslen = rows.length;
            if (rowslen > 0) {
                var funCacheData = function (processDic, rowItem) {
                    var jobTaskNum = rowItem["JobTaskNum"];
                    var cacheItem = processDic.Item(jobTaskNum);
                    if (cacheItem == null) {
                        cacheItem = new Object();
                        cacheItem.IsKeyTask = rowItem["IsKeyTask"];
                        cacheItem.FormWay = rowItem["FormWay"];
                        cacheItem.OptionsValue = rowItem["OptionsValue"];
                        cacheItem.MaxValue = rowItem["MaxValue"];
                        cacheItem.MinValue = rowItem["MinValue"];
                        cacheItem.HasChildProcedure = rowItem["HasChildProcedure"];
                        cacheItem.JobTaskNum = jobTaskNum;
                        cacheItem.ProcedureDesc = rowItem["ProcedureDesc"];
                        cacheItem.PointName = rowItem["PointName"];
                        cacheItem.ProcessItems = new Array();

                        processDic.Add(jobTaskNum, cacheItem);
                    }
                    var procItem = new Object();
                    procItem.JobTaskNum = jobTaskNum;
                    procItem.WONum = rowItem["WONum"];
                    procItem.ProcedureNum = rowItem["ProcedureNum"];
                    procItem.ResultValue = rowItem["ResultValue"];
                    cacheItem.ProcessItems.push(procItem);
                };
                for (var i = 0; i < rowslen; i++) {
                    var row = rows[i];
                    var formWay = row["FormWay"].toLowerCase();
                    var isPhotoGraph = row["IsPhotoGraph"];

                    if (formWay != "b" || formWay != "c") {
                        if (isPhotoGraph == "1") {
                            formWay = "D";
                            row["FormWay"] = "D";
                        }
                    }

                    if (formWay != "a") { //关键工序
                        funCacheData(_self.KeyProcessDic, row);
                    } else {  //进行分类 通普工序，
                        funCacheData(_self.OrdinaryProcessDic, row);
                    }
                }
                _self.funDrawList(cntSelectId, cntInputId);
            }
        });
    },

    funDrawList: function (cntSelectId, cntInputId) {
        var _self = this;
        var liSelectHtml = "";
        var liInputHtml = "";
        var funDrawOrdinaryProc = function () {
            var ordinaryProcessDic = _self.OrdinaryProcessDic; //普通工序
            var ordinaryVals = ordinaryProcessDic.Values();
            var ordinaryLen = ordinaryVals.length;
            for (var i = 0; i < ordinaryLen; i++) {
                var item = ordinaryVals[i];
                var jobTaskNum = item["JobTaskNum"];
                var optionsValue = item["OptionsValue"].split(';');
                var optionslen = optionsValue.length;
                var pointName = item["PointName"];
                var techStandard = item["TechStandard"] || "";
                liSelectHtml += '<li>';
                liSelectHtml += '<div id="Item' + jobTaskNum + '" data-role="BTButton" mousedown="false" mouseup="false">';
                liSelectHtml += '<div class="row-box">';
                liSelectHtml += '<div class="span1 label">';
                liSelectHtml += ' <div class="procDesc"  handler="TechStandardMsg" ordNum="' + (i + 1) + '" TechStandard="' + techStandard + '" >';
                liSelectHtml += (i + 1) + '、' + item["ProcedureDesc"];
                if (pointName) {
                    liSelectHtml += '[单位:' + pointName + ']';
                }
                liSelectHtml += ' </div>';
                liSelectHtml += ' </div>';
                liSelectHtml += '<div class="sinPromh">';
                var resultValue = item.ProcessItems[0]["ResultValue"];
                if (resultValue != "") {
                    for (var j = 0; j < item.ProcessItems; j++) {
                        if (item.ProcessItems[j]["ResultValue"] == "") {
                            resultValue = "";
                            break;
                        }
                    }
                }
                for (var l = 0; l < optionslen; l++) {
                    var optionVal = optionsValue[l];
                    if (optionVal == resultValue) {
                        liSelectHtml += '<div  id=' + jobTaskNum + "_" + l + '  name="' + jobTaskNum + '" data-role="BTRadio" value="' + optionsValue[l] + '" class="BTCheck_ON"  > ' + optionsValue[l] + '</div>';
                    } else {
                        liSelectHtml += '<div  id=' + jobTaskNum + "_" + l + '  name="' + jobTaskNum + '" data-role="BTRadio" value="' + optionsValue[l] + '" > ' + optionsValue[l] + '</div>';
                    }
                }
                liSelectHtml += '</div>';
                liSelectHtml += '</div>';
                liSelectHtml += '</div>';
                liSelectHtml += '</li>';
            }
            if (liSelectHtml) {
                var cntSelect = document.getElementById(cntSelectId);
                if (cntSelect) {
                    cntSelect.innerHTML = '<ul class="list-view list-check" data-corner="all">' + liSelectHtml + '</ul>';
                }
            }
        };
        var funDrawKeyProc = function () {
            var keyProcessVals = _self.KeyProcessDic.Values();
            var keyProcesslen = keyProcessVals.length;
            if (keyProcesslen > 0) {
                var devicelen = _self.PageParam["Devices"].length;
                for (var i = 0; i < devicelen; i++) {
                    var deviceItem = _self.PageParam["Devices"][i];
                    var woNum = deviceItem["key"];
                    var keyProcItemHtml = "";
                    for (var k = 0; k < keyProcesslen; k++) {
                        var keyProcessItem = keyProcessVals[k];
                        var procItem = _self.funGetProcItem(keyProcessItem.ProcessItems, woNum);
                        if (procItem) {
                            var formWay = keyProcessItem["FormWay"].toLowerCase();
                            var keyJobTaskNum = keyProcessItem["JobTaskNum"];
                            var keyCrtId = keyJobTaskNum + "_" + woNum;
                            var resultValue = procItem["ResultValue"] || "";
                            var procedureNum = procItem["ProcedureNum"];
                            var pointName = procItem["PointName"];
                            var techStandard = procItem["TechStandard"] || "";

                            keyProcItemHtml += '<li>';
                            keyProcItemHtml += '<div id="Item' + keyCrtId + '" data-role="BTButton" mousedown="false" mouseup="false" >';
                            keyProcItemHtml += '<div class="row-box">';

                            keyProcItemHtml += '<div class="span1 label">';
                            keyProcItemHtml += ' <div class="procDesc"  handler="TechStandardMsg" ordNum="' + (i + 1) + '.' + (k + 1) + '" TechStandard="' + techStandard + '" >';

                            keyProcItemHtml += (i + 1) + '.' + (k + 1) + '、' + keyProcessItem["ProcedureDesc"];
                            if (pointName) {
                                keyProcItemHtml += '[单位:' + pointName + ']';
                            }
                            switch (formWay) {
                                case "d": {
                                    keyProcItemHtml += '<img src="bingoTouch/css/images/camera.png"/> ';
                                }
                                    break;
                                case "e": {
                                    keyProcItemHtml += '<img src="bingoTouch/css/images/camera.png"/> ';
                                }
                                    break;
                                case "f": {
                                    keyProcItemHtml += '<img src="bingoTouch/css/images/camera.png"/> ';
                                }
                                    break;
                            }
                            keyProcItemHtml += '</div>';
                            liSelectHtml += ' </div>';
                            keyProcItemHtml += ' <div class="sinPromh">';
                            switch (formWay) {
                                case "b": {
                                    if (resultValue) {
                                        keyProcItemHtml += '<input id=' + keyCrtId + ' value=' + resultValue + '  type="number" class="singInput" />';
                                    } else {
                                        keyProcItemHtml += '<input id=' + keyCrtId + '  type="number" class="singInput" />';
                                    }
                                }
                                    break;
                                case "c": {
                                    if (resultValue) {
                                        keyProcItemHtml += '<input id=' + keyCrtId + '  value=' + resultValue + ' type="text" class="singInput" />';
                                    } else {
                                        keyProcItemHtml += '<input id=' + keyCrtId + '  type="text" class="singInput" />';
                                    }
                                }
                                    break;
                                default: {
                                    var optionsValue = item["OptionsValue"].split(';');
                                    var optionslen = optionsValue.length;
                                    for (var l = 0; l < optionslen; l++) {
                                        var optionVal = optionsValue[l];
                                        if (optionVal == resultValue) {
                                            keyProcItemHtml += '<div id=' + keyCrtId + "_" + l + '  name=' + procedureNum + ' data-role="BTRadio" value="' + optionsValue[l] + '" class="BTCheck_ON" >' + optionsValue[l] + '</div>';
                                        } else {
                                            keyProcItemHtml += '<div id=' + keyCrtId + "_" + l + '  name=' + procedureNum + ' data-role="BTRadio" value="' + optionsValue[l] + '" >' + optionsValue[l] + '</div>';
                                        }
                                    }
                                }
                                    break;
                            }
                            keyProcItemHtml += '<div id="errorMsg' + keyCrtId + '" class="inputEro"></div>';
                            keyProcItemHtml += '</div>';
                            //end todo

                            keyProcItemHtml += '</div>';
                            keyProcItemHtml += '</div>';
                            keyProcItemHtml += '</li>';
                        }
                    }
                    if (keyProcItemHtml) {
                        liInputHtml += '<ul class="list-view list-view-head list-check" data-corner="all">';
                        liInputHtml += '<li>';
                        liInputHtml += '<div data-role="BTButton" mousedown="false">';
                        liInputHtml += '<span class="btn-text">';
                        liInputHtml += (i + 1) + '、' + deviceItem["value"];
                        liInputHtml += '</span>';
                        liInputHtml += ' </div>';
                        liInputHtml += ' </li>';
                        liInputHtml += keyProcItemHtml;
                        liInputHtml += "</ul>";
                        keyProcItemHtml = "";
                    }
                }

                if (liInputHtml) {
                    var cntInput = document.getElementById(cntInputId);
                    if (cntInput) {
                        //liwch 添加换行，最后一行看不见问题
                        cntInput.innerHTML = liInputHtml + "<br/><br/><br/><br/><br/><br/><br/>";
                    }
                }
            }
        };

        funDrawOrdinaryProc();
        funDrawKeyProc();
        if (liSelectHtml || liInputHtml) {
            ui.init();
            _self.funBindOrdinaryEvent();
            _self.funBindeKeyEvent();
            _self.funTechStandardMsgEvent();
        }
    },

    funTechStandardMsgEvent: function () {
        $("div[handler='TechStandardMsg']").click(function () {
            var desc = $(this).attr("TechStandard") || "暂无工序技术标准描述";
            var ordNum = $(this).attr("ordNum");

            app.alert(desc, function () {
            }, ordNum + "工序技术标准", "关闭");
        });
    },

    funGetProcItem: function (procItems, woNum) {
        var procItem = null;
        var proclen = procItems.length;
        for (var i = 0; i < proclen; i++) {
            var item = procItems[i];
            if (item.WONum == woNum) {
                procItem = item;
                break;
            }
        }
        return procItem;
    },

    funBindOrdinaryEvent: function () {
        var _self = this;
        var ordinaryProcessDic = _self.OrdinaryProcessDic; //普通工序
        var arrVals = ordinaryProcessDic.Values();
        var valsLen = arrVals.length;
        for (var i = 0; i < valsLen; i++) {
            var item = arrVals[i];
            var ctrId = item["JobTaskNum"];
            var optionslen = item["OptionsValue"].split(";").length;
            for (var j = 0; j < optionslen; j++) {
                $("#" + ctrId + "_" + j).click(function () {
                    var ctr = $(this);
                    var jobTaskNumAndposition = ctr.attr("id").split("_");
                    var jobTaskNum = jobTaskNumAndposition[0];
                    var positionNum = jobTaskNumAndposition[1];
                    var resultValue = ctr.btcheck("val").value;
                    _self.funOrdinaryRadioItem(jobTaskNum, resultValue, positionNum);

                });
            }
        }
    },

    funOrdinaryRadioItem: function (jobTaskNum, resultValue, positionNum) {
        var _self = this;
        var item = _self.OrdinaryProcessDic.Item(jobTaskNum);
        var optionslen = item["OptionsValue"].split(";").length;
        var hasChildProcedure = item["HasChildProcedure"];
        var updItem = new Object();
        updItem.ResultValue = resultValue;
        updItem.JobTaskNum = jobTaskNum;
        if (((positionNum - 0 + 1) == optionslen) && hasChildProcedure == "1") { //说明是最后个按钮
            app.wheelSelect.oneSelect(_self.PageParam["Devices"],
                function (res) {
                    updItem.ResultValue = item.OptionsValue.split(";")[0];
                    _self.funBatchUpadte([updItem], function () {
                        var woNum = res["key"];
                        var procItem = _self.funGetProcItem(item.ProcessItems, woNum);
                        var url = "nextProcess.html";
                        var pageParam = new Object();
                        pageParam["UppLayerProcedureNum"] = procItem["ProcedureNum"];
                        pageParam["WONum"] = woNum;
                        pageParam["ResultValue"] = resultValue;
                        //Common.funSetPageParam(url, pageParam);
                        //app.load({ "url": url });
                        Common.funLoad(url, pageParam);
                    });
                }, "", "请选择设备");
            $("#" + jobTaskNum + "_" + positionNum).removeClass("BTCheck_ON");
        } else {
            _self.funBatchUpadte([updItem]);
        }
    },

    funBindeKeyEvent: function () {
        var _self = this;
        var keyProcessDic = _self.KeyProcessDic;
        var arrVals = keyProcessDic.Values();
        var valsLen = arrVals.length;
        var devicelen = _self.PageParam["Devices"].length;
        for (var i = 0; i < devicelen; i++) {
            var deviceItem = _self.PageParam["Devices"][i];
            for (var k = 0; k < valsLen; k++) {
                var item = arrVals[k];
                var jobTaskNum = item["JobTaskNum"];
                var formWay = item["FormWay"].toLocaleLowerCase();
                var ctrId = jobTaskNum + "_" + deviceItem["key"];
                if (formWay == "b" || formWay == "c") {
                    $("#" + ctrId).on("blur", function () {
                        var ctr = $(this);
                        var jobTaskWoNum = ctr.attr("id").split("_");
                        var jobTask = jobTaskWoNum[0];
                        var wONum = jobTaskWoNum[1];
                        var resultValue = ctr.val();
                        _self.funKeyTextItem(jobTask, resultValue, wONum);
                    });
                } else {
                    var optionslen = item["OptionsValue"].split(";").length;
                    for (var j = 0; j < optionslen; j++) {
                        $("#" + ctrId + "_" + j).click(function () {
                            var ctr = $(this);
                            var jobTaskWoNumPosition = ctr.attr("id").split("_");
                            var jobTask = jobTaskWoNumPosition[0];
                            var wONum = jobTaskWoNumPosition[1];
                            var positionNum = jobTaskWoNumPosition[2];
                            var resultValue = ctr.btcheck("val").value;
                            var procedureNum = ctr.attr("ProcedureNum");
                            _self.funKeyRadioItem(jobTask, resultValue, positionNum, wONum, procedureNum);
                        });
                    }
                }
            }
        }
    },

    funBatchUpadte: function (updateItemList, successfun) {
        var _self = this;
        var deviceList = _self.PageParam["Devices"];
        var wONumList = new Array();
        var devicelen = deviceList.length;
        for (var j = 0; j < devicelen; j++) {
            var wONumItem = deviceList[j].key;
            wONumList.push("WONum='" + wONumItem + "'");
        }
        var sqlWhere = " and (" + wONumList.join(" or ") + ") ";
        var userName = "";
        var userCode = "";
        var selfFormTime = Common.funGetNowDate();
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                userName = res;
            }
        });
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                userCode = res;
            }
        });
        var sqlList = new Array();
        var len = updateItemList.length;
        for (var i = 0; i < len; i++) {
            var updItem = updateItemList[i];
            var sql = "update OrderProcedure ";
            sql += " set ResultValue='" + updItem["ResultValue"] + "' ,SelfFormUserName='" + userName + "' ,SelfFormUserCode='" + userCode + "',SelfFormTime='" + selfFormTime + "'";
            sql += " where ResultValue=''  and JobTaskNum='" + updItem["JobTaskNum"] + "' ";
            sql += sqlWhere;
            sqlList.push(sql);
        }

        if (sqlList.length > 0) {
            var dbName = app.database.open(Common.WEIXIUDB);
            app.database.executeNonQuery(dbName, sqlList, successfun);
        }
    },

    funSingleUpdate: function (jobTaskNum, resultValue, wONum, successfun) {
        var userName = "";
        var userCode = "";
        var selfFormTime = Common.funGetNowDate();
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                userName = res;
            }
        });
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                userCode = res;
            }
        });
        var sql = "update OrderProcedure ";
        sql += " set ResultValue='" + resultValue + "' ,SelfFormUserName='" + userName + "' ,SelfFormUserCode='" + userCode + "',SelfFormTime='" + selfFormTime + "'";
        sql += " where JobTaskNum='" + jobTaskNum + "' and WONum='" + wONum + "' ";
        var dbName = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(dbName, [sql], successfun);
    },

    funKeyRadioItem: function (jobTaskNum, resultValue, positionNum, wONum, procedureNum) {
        var _self = this;
        var item = _self.KeyProcessDic.Item(jobTaskNum);
        var optionsValue = item["OptionsValue"];
        var optionslen = optionsValue.split(";").length;
        var hasChildProced = item["HasChildProced"];

        var url = "nextProcess.html";
        var pageParam = new Object();
        pageParam["UppLayerProcedureNum"] = procedureNum;
        pageParam["ResultValue"] = resultValue;
        pageParam["WONum"] = wONum;
        if (((positionNum - 0 + 1) == optionslen) && hasChildProced == "1") { //说明是最后个按钮
            Common.funLoad(url, pageParam);
        } else {

            var formWay = item["FormWay"].toLowerCase();
            switch (formWay) {
                case "d": //D: 单选 + 拍照
                {
                    if ((positionNum - 0) == 0) {
                        url = "processphoto.html";
                        Common.funLoad(url, pageParam);
                    } else {
                        _self.funSingleUpdate(jobTaskNum, resultValue, wONum);
                    }
                }
                    break;
                case "e"://E: 单选 + 录音
                {
                    if ((positionNum - 0) == 0) {
                        url = "processpAudio.html";
                        Common.funLoad(url, pageParam);
                    } else {
                        _self.funSingleUpdate(jobTaskNum, resultValue, wONum);
                    }
                }
                    break;
                case "f"://F:单选+录像
                {
                    if ((positionNum - 0) == 0) {
                        url = "processpVideo.html";
                        Common.funLoad(url, pageParam);
                    } else {
                        _self.funSingleUpdate(jobTaskNum, resultValue, wONum);
                    }
                }
                    break;
            }

        }
    },

    funKeyTextItem: function (jobTaskNum, resultValue, wONum) {
        var _self = this;
        var item = _self.KeyProcessDic.Item(jobTaskNum);
        var formWay = item["FormWay"].toLowerCase();
        var isSave = true;
        //B: 测量值，C: 文本框
        if (formWay == "b") {
            var keyCrtId = jobTaskNum + "_" + wONum;
            $("#errorMsg" + keyCrtId).text("");
            if (isNaN(resultValue)) {
                $("#errorMsg" + keyCrtId).text("数值格式填写有误");
                isSave = false;
            } else {
                var minValue = item["MinValue"] - 0;
                var maxValue = item["MaxValue"] - 0;
                if (!(minValue == 0 && maxValue == 0)) {
                    var resultVal = resultValue - 0;
                    if (resultVal < minValue || resultVal > maxValue) {
                        $("#errorMsg" + keyCrtId).text("填入数据范围有误,已超出最小值与最大值的范围[" + minValue + "至" + maxValue + "]");
                    }
                }
            }
        }
        if (isSave) {
            _self.funSingleUpdate(jobTaskNum, resultValue, wONum);
        }
    },

    funSaveProcess: function () {
        var _self = this;
        app.progress.start("提示", "正在处理中...");
        setTimeout(function () {
            var keyIsSubmit = _self.funIsSubmitKey();
            var ordinaryItemObj = _self.funIsSubmitOrdinary();
            app.progress.stop();
            if (ordinaryItemObj.isSubmit == false) { //是否允许提交
                app.confirm("存在工序未填报结果,未填报的是否通过一次性提交", function (index) {
                    if (index == 2) {
                        _self.funSetDefaultOption(ordinaryItemObj.Items, function () {
                            if (keyIsSubmit == true) { //说明关键工序已全部填写完成.
                                _self.funChangeStatus();
                            } else {
                                app.alert("存在关键工序未填报完，请手工输入完成后再提交");
                            }
                        });
                    }
                }, "提示", "取消,确定");

            } else if (keyIsSubmit == false) {
                app.alert("存关键工序未填报完，请手工输入完成后再提交");
            } else {
                _self.funChangeStatus();
            }
        }, 1500);
    },

    funIsSubmitOrdinary: function () {
        var _self = this;
        var retObj = new Object();
        retObj.isSubmit = true;
        retObj.Items = new Array();
        var ordinaryProcessDic = _self.OrdinaryProcessDic; //普通工序
        var arrVals = ordinaryProcessDic.Values();
        var valsLen = arrVals.length;
        for (var i = 0; i < valsLen; i++) {
            var item = arrVals[i];
            var ctrId = item["JobTaskNum"];
            var optionslen = item["OptionsValue"].split(";").length;
            var isCheck = false;
            for (var j = 0; j < optionslen; j++) {
                if ($("#" + ctrId + "_" + j).hasClass('BTCheck_ON')) {
                    isCheck = true;
                    break;
                }
            }
            if (isCheck == false) { //说明没有选中
                $("#Item" + ctrId).addClass("unfih");
                retObj.isSubmit = false;
                retObj.Items.push(ctrId);
            } else {
                $("#Item" + ctrId).removeClass("unfih");
            }
        }
        return retObj;
    },

    funIsSubmitKey: function () {
        var _self = this;
        var isSubmit = true;
        var keyProcessDic = _self.KeyProcessDic;
        var arrVals = keyProcessDic.Values();
        var valsLen = arrVals.length;
        var devicelen = _self.PageParam["Devices"].length;
        for (var i = 0; i < devicelen; i++) {
            var deviceItem = _self.PageParam["Devices"][i];
            for (var k = 0; k < valsLen; k++) {
                var item = arrVals[k];
                var woNum = deviceItem["key"];
                var procItem = _self.funGetProcItem(item.ProcessItems, woNum);
                if (procItem) {
                    var jobTaskNum = item["JobTaskNum"];
                    var formWay = item["FormWay"].toLowerCase();
                    var ctrId = jobTaskNum + "_" + deviceItem["key"];
                    var isfill = true;
                    if (formWay == "b" || formWay == "c") {
                        var ctr = $("#" + ctrId);
                        var txtVal = ctr.val().trim();
                        if (txtVal == "") {
                            isfill = false;
                        } else if (formWay == "b") {
                            if (isNaN(txtVal)) {
                                isfill = false;
                                ctr.val(''); //数据不填写不对，清空
                            }
                        }
                    } else {
                        var optionslen = item["OptionsValue"].split(";").length;
                        var isCheck = false;
                        for (var j = 0; j < optionslen; j++) {
                            if ($("#" + ctrId + "_" + j).hasClass('BTCheck_ON')) {
                                isCheck = true;
                                break;
                            }
                        }
                        if (isCheck == false) {
                            isfill = false;
                        }
                    }

                    if (isfill == false) {
                        $("#Item" + ctrId).addClass("unfih");
                        if (isSubmit) {
                            isSubmit = false;
                        }
                    } else {
                        $("#Item" + ctrId).removeClass("unfih");
                    }

                }
            }
        }
        return isSubmit;
    },

    funSetDefaultOption: function (defItemList, successfun) {
        var _self = this;
        var itemlen = defItemList.length;
        var updItemList = new Array();
        for (var i = 0; i < itemlen; i++) {
            var ctrId = defItemList[i];
            var cnt = $("#" + ctrId + "_" + 0);
            cnt.removeClass('BTCheck_OFF').addClass('BTCheck_ON');

            $("#Item" + ctrId).removeClass("unfih");

            var updItem = new Object();
            updItem.ResultValue = cnt.attr("value");
            updItem.JobTaskNum = ctrId;
            updItemList.push(updItem);
        }
        _self.funBatchUpadte(updItemList, successfun);
    },

    funGetDatepicker: function (dateId, timeId) {
        ///<summary>获取日期</summary>
        ///<param name="dateId">日期主键</param>
        ///<param name="timeId">时间主键</param>
        var dateTimeValue = '';
        var dateValue = $("#" + dateId).btselect("val").value;
        var timeValue = $("#" + timeId).btselect("val").value;
        if (dateValue != "" && timeValue != "") {
            dateTimeValue = dateValue + " " + timeValue + ":0";
        }
        return dateTimeValue;
    },

    funChangeStatus: function () {
        var _self = this;
        var dtNow = new Date();
        var now = new Date(dtNow.getTime() + 60 * 1000);
        var curDate = now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + " " + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
        var actStart = _self.funGetDatepicker("time_ActStartDate", "time_ActStartTime");
        var actFinish = _self.funGetDatepicker("time_ActFinishDate", "time_ActFinishTime") || curDate;
        var retVal = Common.funCompareDate(actFinish, actStart);
        if (retVal) {
            var deviceList = _self.PageParam["Devices"];
            var wONumList = new Array();
            var devicelen = deviceList.length;
            for (var j = 0; j < devicelen; j++) {
                var wONumItem = deviceList[j].key;
                wONumList.push("WONum='" + wONumItem + "'");
            }
            var userName = "";
            var usercode = "";
            app.getGlobalVariable("UserName", function (res) {
                if (res) {
                    userName = res;
                }
            });
            app.getGlobalVariable("UserCode", function (res) {
                if (res) {
                    usercode = res;
                }
            });
            var sqlWhere = " (" + wONumList.join(" or ") + ") ";
            var selfChkFinishTime = Common.funGetNowDate();

            var sql = "update OPOrders ";
            sql += " set  ActStart='" + actStart + "', ActFinish='" + actFinish + "', SelfFormIsFinished='1',SelfFormUserName='" + userName + "',SelfFormUserCode='" + usercode + "' ,SelfFormFinishTime='" + selfChkFinishTime + "'";
            sql += " where " + sqlWhere;
            var dbName = app.database.open(Common.WEIXIUDB);
            app.database.executeNonQuery(dbName, sql, function () {
                Common.funGoBack();
            });
        } else {
            app.alert("实际完成时间需大于实际开始时间");
        }
    },
    funBackRefresh: function (retParamStr) {
        var _self = this;
        try {
            if (retParamStr) {
                var retParam = JSON.parse(retParamStr);
                var backParam = retParam["backParam"];
                if (backParam) {
                    _self.PageParam = backParam;
                }
            }
        } catch (ex) {
            app.alert("multiProcess.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
        }
        setTimeout(function () {
            _self.funInitProcessData("divSelect", "divInput");
        },100)
    }
};

