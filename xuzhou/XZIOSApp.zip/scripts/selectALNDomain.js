﻿var SelALNDomain = function () {
    this.PageParam = null;
    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);
};

SelALNDomain.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            var faultObj = _self.PageParam;
            faultObj.manualSelect = "0"; //手选页面传回一个“1”回去上一个填报故障信息页面
            Common.funGoBack(faultObj, "selectALNDomain.html");
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });

        _self.funSelectALNDomain("txtALNDomainName", "alndomainlist");
        $("#btnSelectALNDomain").click(function () {
            _self.funSelectALNDomain("txtALNDomainName", "alndomainlist");
        });
    },

    funSelectALNDomain: function (inputCntId, containerId) {
        var _self = this;
        var inputCtr = $("#" + inputCntId); 
        var alndomainName = inputCtr.val().trim();
        //var LineNum = $("#LineList").val().trim();
        var sql = 'select * from ALNDomain ';
        if (alndomainName) {
            sql += ' where VALUE like "%' + alndomainName + '%"  ';
        }
        else {
            sql += '  where 1=1';
        }
        var db = app.database.open(Common.WEIXIUBASEDB);
        app.database.executeQuery(db, sql, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowlen = rows.length;
            var liHtml = "";
            if (rowlen > 0) {
                inputCtr.val("");
                for (var i = 0; i < rowlen; i++) {
                    var row = rows[i];
                    var LineNum = row.LineNum;
                    var VALUE = row.VALUE;
                    var ALNDomainID = row.ALNDomainID;
                    liHtml += '<li  id="li' + ALNDomainID + '"  VALUE="' + VALUE + '"  VALUE="' + VALUE + '"  ALNDomainID="' + ALNDomainID + '">';
                    liHtml += '<div class="row-fluid">';
                    liHtml += '<div class="span6">' + VALUE + '</div>';
                    liHtml += '<div class="span5">' + LineNum + '</div>';
                    liHtml += '</div>';
                    liHtml += '</li>';
                }
            }
            var cnt = document.getElementById(containerId);
            if (cnt) {
                var childItems = cnt.children;
                var childlen = childItems.length;
                for (var j = 1; j < childlen; j++) {
                    cnt.removeChild(childItems[1]);
                }
                if (liHtml) {
                    cnt.innerHTML += liHtml;
                    _self.funBindEvent(rows);
                } else {
                    liHtml += '<li>';
                    liHtml += '<div class="row-fluid">';
                    liHtml += '<div class="span10" align="center">***暂无数据***</div>';
                    liHtml += '</div>';
                    liHtml += '</li>';
                    cnt.innerHTML += liHtml;
                }
            }
        });
    },

    funBindEvent: function (rows) {
        var _self = this;
        var rowlen = rows.length;
        for (var i = 0; i < rowlen; i++) {
            var item = rows[i];
            var ALNDomainID = item["ALNDomainID"];
            $("#li" + ALNDomainID).click(function () {
                var ctr = $(this);
                var VALUE = ctr.attr("VALUE");
                var faultObj = _self.PageParam;
                faultObj.pageData.FaultLocation = VALUE;
                Common.funGoBack(faultObj, "selectALNDomain.html");
            });
        }
    }
};
