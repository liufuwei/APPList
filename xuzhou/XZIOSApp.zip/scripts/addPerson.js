﻿var AddPerson = function () {

};

AddPerson.prototype = {
    funInitEvent: function () {
        var _self = this;

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnAddPerson").click(function () {
            var userCode = $("#txtUserCode").val().trim();
            var password = $("#txtPassword").val().trim();
            _self.funAddPerson(userCode, password, "personlist");
        });
    },
    funAddPerson: function (usercode, password, containerId) {
        var _self = this;
        ///<summary>添加作业人员方法:void</summary>
        ///<param name="username" >作业人员的用户名</param>
        ///<param name="password">作业人员的密码</param>
        if (usercode && password) {
            var getSqlParam = new Object();
            getSqlParam.UserCode = usercode;
            getSqlParam.Password = b64_md5(password);
            SqlHelper.funGetData("User", function (rows1) {
                if (rows1.length == 0) {
                    app.alert("请输入正确的账号和密码");
                } else {
                    var insertSqlParamList = new Array();
                    var userObj = new Object();
                    userObj.UserNum = rows1[0].UserNum;
                    userObj.UserName = rows1[0].UserName;
                    userObj.UserCode = rows1[0].UserCode;
                    userObj.LoginTime = Common.funGetNowDate();
                    userObj.isAdd = "1";
                    insertSqlParamList.push(userObj);

                    //判断业务Users表里是否存在了
                    var newusersObjParam = new Object();
                    newusersObjParam.UserCode = usercode;
                    SqlHelper.funGetData("OPUsers", function (rows4) {
                        if (rows4.length >= 1) {
                            app.alert("已存在，无需再添加作业人员");
                        } else {
                            //插入业务Users表
                            SqlHelper.funInsertData("OPUsers", insertSqlParamList, function (rows2) {
                                app.alert("添加人员成功", function () {
                                    $("#txtUserCode").val("");
                                    $("#txtPassword").val("");
                                });

                                var liHtml = "";
                                liHtml += '<li id="li' + userObj.UserCode + '" >';
                                liHtml += '<div class="row-fluid">';
                                liHtml += '<div class="span4"> ' + userObj.UserCode + '</div>';
                                liHtml += '<div class="span6">' + userObj.UserName + '</div>';
                                liHtml += '<div class="span2" align="right">';
                                liHtml += '<a  UserCode="' + userObj.UserCode + '"  id="btnDel' + userObj.UserCode + '" href="javascript:void(0)" class="delN"></a>';
                                liHtml += '</div>';
                                liHtml += '</div>';
                                liHtml += '</li>';
                                $(liHtml).appendTo("#" + containerId);
                                $("#btnDel" + userObj.UserCode).click(function () {
                                    var ctr = $(this);
                                    var ucode = ctr.attr("UserCode");
                                    _self.funDelPerson(ucode);
                                });
                            });
                        }
                    }, newusersObjParam);
                }
            }, getSqlParam);
        } else {
            app.alert("账号或密码不能为空！");
        }


    },

    funDelPerson: function (userCode) {
        var _self = this;
        app.confirm("确认要删除所选作业人员?", function (index) {
            if (index == 2) {
                var delList = new Array();
                var userObj = new Object();
                userObj.UserCode = userCode;
                userObj.TableName = "OPUsers";
                delList.push(userObj);
                SqlHelper.funDeleteData(delList, function (rows) {
                    app.hint("成功删除！");
                    var ctr = $("#btnDel" + userCode);
                    ctr.unbind("tap");
                    ctr.remove();
                    var liCtr = $("#li" + userCode);
                    liCtr.remove();

                });
            }
        }, "删除作业人员确认", "取消,确定");
    },

    funInitNewAddPerson: function (containerId) {
        var _self = this;
        SqlHelper.funGetData("OPUsers", function (rows) {
            var liHtml = "";
            var rowlen = rows.length;
            for (var i = 0; i < rowlen; i++) {
                var item = rows[i];
                var userCode = item["UserCode"];
                var userName = item["UserName"];
                liHtml += '<li id="li' + userCode + '" >';
                liHtml += '<div class="row-fluid">';
                liHtml += '<div class="span4"> ' + userCode + '</div>';
                liHtml += '<div class="span6">' + userName + '</div>';
                liHtml += '<div class="span2" align="right">';
                liHtml += '<a  UserCode="' + userCode + '"  id="btnDel' + userCode + '" href="javascript:void(0)" class="delN"></a>';
                liHtml += '</div>';
                liHtml += '</div>';
                liHtml += '</li>';
            }
            var cnt = document.getElementById(containerId);
            if (cnt) {
                cnt.innerHTML += liHtml;
                if (rowlen > 0) {
                    _self.funBindEvent(rows);
                }
            }
        });
    },

    funBindEvent: function (rows) {
        var _self = this;
        var rowlen = rows.length;
        for (var i = 0; i < rowlen; i++) {
            var item = rows[i];
            var userCode = item["UserCode"];
            $("#btnDel" + userCode).click(function () {
                var ctr = $(this);
                var ucode = ctr.attr("UserCode");
                _self.funDelPerson(ucode);
            });
        }
    },

    funBackRefresh: function () {
        this.funInitNewAddPerson("personlist");
    }

};

