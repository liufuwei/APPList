﻿var DataFileList = function () {
};

DataFileList.prototype = {
    funInitData: function (containerId) {
        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fileSystem) {
            fileSystem.root.getDirectory("Download", { create: true, exclusive: false },
                function (dirEntry) {
                    var directoryReader = dirEntry.createReader();
                    directoryReader.readEntries(function (entries) {
                        var liHtml = "";
                        for (var i = 0; i < entries.length; i++) {
                            var entry = entries[i];
                            if (!entry.name.match(".txt")) {
                                liHtml += '<li filePath="' + entry.fullPath + '" >';
                                liHtml += '<div class="row-fluid">';
                                liHtml += '<div class="span12">' + entry.name + '</div>';
                                liHtml += '</div>';
                                liHtml += '</li>';
                            }
                        }

                        var cnt = document.getElementById(containerId);
                        if (cnt) {
                            if (liHtml) {
                                cnt.innerHTML += liHtml;
                                $("#" + containerId + " li").each(function () {
                                    $(this).click(function () {
                                        var filePath = $(this).attr("filePath");
                                        if (filePath) {
                                            app.openFile(filePath);
                                        }
                                    });
                                });
                            } else {
                                liHtml = '<li>';
                                liHtml += '<div class="row-fluid">';
                                liHtml += '<div class="span12" align="center">***暂无技术资料数据***</div>';
                                liHtml += '</div>';
                                liHtml += '</li>';
                                cnt.innerHTML += liHtml;
                            }
                        }
                    }, function (error) {
                        app.alert("Failed to list directory contents:" + error.code);
                    });
                }, function () {
                    app.alert("创建目录失败", function () { app.progress.stop(); });
                });
        });
    }
};



