﻿/// <reference path="../bingoTouch/plugins.js" />


var UpdateApp = function () {

};

UpdateApp.prototype = {

    funUpdateApp: function () {
        var networkState = navigator.network.connection.type;
        if (networkState == Connection.NONE) {
            app.alert("您当前没有用网络");
        } else {
            //app.progress.start("更新程序提示", "正在处理中...");
            var savePath = "";
            var platform = "";
            if (window.devicePlatform == "android") {
                platform = "android";
            } else if (window.devicePlatform == "iOS") {
                platform = "ios";
            }
            if (platform =="android") {
                app.getAppDirectoryEntry(function (res) {
                    //区分平台，并将相应的目录保存到全局,方便下面下载的时候使用
                    if (window.devicePlatform == "android") {
                        savePath = res.sdcard;
                    } else if (window.devicePlatform == "iOS") {
                        savePath = res.documents;
                    }
                });
                var uri = "";
                var recNote = "";
                var retIsNewApk = true;
                var localVersion = app.version;
                localVersion = localVersion.replace("v", "");
                localVersion = localVersion - 0;
                var reqVersionParam = new Object();
                reqVersionParam.orgin = "stream";
                reqVersionParam.CallMethod = "Misc_CheckVersion";
                var dlDataParam = new Object();
                dlDataParam.DataType = "CheckVersion";
                dlDataParam.Platform = platform;
                reqVersionParam.AuthBlock = new Object();
                reqVersionParam.AuthBlock.UserCode = "admin";
                reqVersionParam.AuthBlock.Password = "112233";
                reqVersionParam.PayLoad = dlDataParam;
                app.ajax({
                    "url": MobileConfig.DownBaseDataUrl, "data": reqVersionParam,
                    "contentType": "application/json",
                    "method": "POST", "async": false,
                    "success": function (res) {
                        var responseData = JSON.parse(res.returnValue);
                        var serverVersion = responseData.PayLoad.VersionName;
                        var recNote = responseData.PayLoad.RecNote ? responseData.PayLoad.RecNote : "是否下载新版本?";
                        serverVersion = serverVersion - 0;
                        if (localVersion < serverVersion) {
                            app.alert(recNote);
                            if (index == 1) {
                                app.progress.stop();
                            } else {
                                uri = encodeURI(responseData.PayLoad.FileID); //软件包服务器下载地址
                                if (uri) {
                                    //android系统的时候
                                    recNote = responseData.PayLoad.RecNote;
                                    if (window.devicePlatform == "android") {
                                        uri = encodeURI(responseData.PayLoad.FileID); //软件包服务器下载地址
                                        retIsNewApk = false;
                                        if (retIsNewApk == false) {
                                            var fileTransfer = new FileTransfer();
                                            var filePath = savePath + "/xzdt.apk";
                                            fileTransfer.download(uri, filePath, function (entry) {
                                                app.progress.stop();
                                                if (recNote) {
                                                    app.alert(recNote, function () {
                                                        app.install(filePath); //安装
                                                    });
                                                } else {
                                                    app.install(filePath);
                                                }
                                            }, function (error) {
                                                app.alert(JSON.stringify(error), function () {
                                                    app.progress.stop();
                                                });
                                            });
                                        }

                                    } else if (window.devicePlatform == "iOS") {
                                        //平果系统时
                                        app.alert(recNote, function () {
                                            app.run(uri);
                                            app.progress.stop();
                                        });
                                    }

                                } else {
                                    app.alert("软件包服务器下载地址为空");
                                }
                            }
                        } else {
                            //app.alert("当前版本[" + localVersion + "]已最新，无需更新", function () {
                            //    app.progress.stop();
                            //});
                            app.progress.stop();
                        }
                    },
                    "fail": function (failRes) {
                        app.alert("ERROR:" + JSON.stringify(failRes), function () {
                            app.progress.stop();
                        });
                    }
                });
            }
        }
    }
}