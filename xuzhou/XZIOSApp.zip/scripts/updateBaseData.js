﻿var UpdateBaseData = function () {
    this.Lines = new Array();
    this.Specialtys = new Array();
    this.page = 1;
    this.size = 4000;
};

UpdateBaseData.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);


        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnUpdateFault").click(function () {
            _self.funGetServerBaseData("Fault");
        });


        $("#btnUpdateDevice").click(function () {
            //var ret = _self.funChkWhere("LineList", "SpecialtyList");
            //if (ret) {
            //    _self.funGetServerBaseData("Device");
            //} else {
            //    app.alert("请选择线路和专业");
            //}
            _self.funGetServerBaseData("Device");
        });


        $("#btnUpdateLocation").click(function () {
            //var ret = _self.funChkWhere("LineList", "SpecialtyList");
            //if (ret) {
            //    _self.funGetServerBaseData("Location");
            //} else {
            //    app.alert("请选择线路和专业");
            //}
            _self.funGetServerBaseData("Location");
        });

        $("#btnUpdateTool").click(function () {
            _self.funGetServerBaseData("ActualTools");
        });

        $("#btnUpdateMeasurePoint").click(function () {
            _self.funGetServerBaseData("MeasurePoint");
        });

        $("#btnUpdateMaterial").click(function () {
            _self.funGetServerBaseData("Material");
        });

        $("#btnUpdateElse").click(function () {
            _self.funGetServerBaseData("Other");
        });

        $("#btnUpdateAll").click(function () {
            // var ret = _self.funChkWhere("LineList", "SpecialtyList");
            // if (ret) {
                _self.funGetServerBaseData("All");
            // } else {
            //     app.alert("请选择线路和专业");
            // }
                _self.funGetServerBaseData("Location");
                _self.funGetServerBaseData("Device");
        });

        $("#LineList").click(function () {
            var lines = _self.Lines;
            if (lines.length > 0) {
                var lineCtr = $("#LineList");
                var defkey = "";
                app.wheelSelect.oneSelect(lines,
                    function (res) {
                        var key = res["key"];
                        var value = res["value"];
                        lineCtr.text(value);
                        lineCtr.attr("key", key);
                    }, defkey, "请选择线路");
            } else {
                app.alert("暂无线路基础数据");
            }
        });

        $("#SpecialtyList").click(function () {
            var specialtys = _self.Specialtys;
            if (specialtys.length > 0) {
                var specialtyCtr = $("#SpecialtyList");
                var defkey = "";
                app.wheelSelect.oneSelect(specialtys,
                    function (res) {
                        var key = res["key"];
                        var value = res["value"];
                        specialtyCtr.text(value);
                        specialtyCtr.attr("key", key);

                    }, defkey, "请选择专业");
            } else {
                app.alert("暂无专业基础数据");
            }
        });
        $("#btnCleanAll").click(function () {
            app.confirm("是否清理所有基础数据?", function (index) {
                if (index == 2) {
                    _self.funCleanAllData();
                } else {
                    app.progress.stop();
                }
            }, "清理数据", "取消,确定");
        });

        // var db = app.database.open(Common.WEIXIUDB);
        // app.database.executeQuery(db, "select count(*) from Location", function (tx, results) {
        //     var rows = Common.funConvertRowsJson(results);
        //     alert(JSON.stringify(rows))
        // });
    },
    //清理基础数据
    funCleanAllData: function () {
        var sqlList = new Array();
        sqlList.push("DELETE FROM Line");
        sqlList.push("DELETE FROM Device");
        sqlList.push("DELETE FROM FaultPhenomenon");
        sqlList.push("DELETE FROM FaultReason");
        sqlList.push("DELETE FROM FaultSolution");
        sqlList.push("DELETE FROM FaultClass");
        sqlList.push("DELETE FROM Specialty");
        sqlList.push("DELETE FROM Area");
        sqlList.push("DELETE FROM Tool");
        sqlList.push("DELETE FROM Location");
        sqlList.push("DELETE FROM MeasurePoint");
        sqlList.push("DELETE FROM Material");
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(db, sqlList, function () {
            app.refresh();
            app.hint("清理数据完成");
        });
    },

    funCheckNetwork: function () {
        var retNetworkState = false;
        var networkState = navigator.network.connection.type;
        if (networkState == Connection.NONE) { //未连接
            retNetworkState = false;
        } else {
            retNetworkState = true;
        }
        return retNetworkState;
    },

    funChkWhere: function (lineCrtId, specialtyCrtId) {
        var ret = true;
        var line = $("#" + lineCrtId).attr("key") || "NA";
        var specialty = $("#" + specialtyCrtId).attr("key") || "NA";
        if (line != "NA" && specialty != "NA") {
            ret = true;
        } else {
            ret = false;
        }
        return ret;
    },

    funGetServerBaseData: function (dataType) {
        var _self = this;
        app.progress.start("下载提示", "正在处理中...");
        var specialtyNum = $("#SpecialtyList").attr("key"); //参数2
        var lineNum = $("#LineList").attr("key"); //参数3
        var dlDataParam = new Object();
        dlDataParam.IsCheck = "1";
        dlDataParam.DataType = new Array();
        if (lineNum != "NA") {
            dlDataParam.LineID = lineNum;
        }
        if (specialtyNum != "NA") {
            dlDataParam.SpecialtyID = specialtyNum;
        }
        app.getGlobalVariable("UnitOrgNum", function (res) {
            if (res) {
                dlDataParam.UnitOrgNum = res;
            }
        });
        switch (dataType) {
            case "Device":
                dlDataParam.DataType.push("Device");
                break;
            case "ActualTools":
                dlDataParam.DataType.push("ActualTools");
                break;
            case "Location":
                dlDataParam.DataType.push("Location");
                break;
            case "MeasurePoint":
                dlDataParam.DataType.push("MeasurePoint");
                break;
            case "Material":
                dlDataParam.DataType.push("Material");
                break;
            case "Other":
                dlDataParam.DataType.push("Line");
                dlDataParam.DataType.push("Area");
                dlDataParam.DataType.push("Specialty");
                dlDataParam.DataType.push("SubSystem");
                dlDataParam.DataType.push("ALNDomain");
                break;
            default:
                dlDataParam.DataType.push("ActualTools");
                //dlDataParam.DataType.push("Device");
                // dlDataParam.DataType.push("Location");
                dlDataParam.DataType.push("Material");
                dlDataParam.DataType.push("Line");
                dlDataParam.DataType.push("Area");
                dlDataParam.DataType.push("Specialty");
                dlDataParam.DataType.push("SubSystem");
                dlDataParam.DataType.push("ALNDomain");
                break;
        }

        dlDataParam.page = 1;
        dlDataParam.size = _self.size;
        var requestParam = new Object();
        requestParam.orgin = "stream";
        requestParam.CallMethod = "Com_DownloadBaseData";
        requestParam.AuthBlock = new Object();
        requestParam.AuthBlock.ClientNumber = device.uuid;
        requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                requestParam.AuthBlock.UserCode = res;
            }
        });
        app.getGlobalVariable("Password", function (res) {
            if (res) {
                requestParam.AuthBlock.Password = res;
            }
        });
        requestParam.PayLoad = dlDataParam;
        app.ajax({
            "url": MobileConfig.DownBaseDataUrl, "data": requestParam,
            "contentType": "application/json",
            "method": "POST", "async": true,
            "fail": function (res) {
                app.alert("连接超时，请稍后重试" + JSON.stringify(res), function () {
                    app.progress.stop();
                });
            },
            "timeout": 600000,
            "success": function (res) {
                var filePathObj = JSON.parse(res.returnValue);
                if (filePathObj.ResStatus == true) {
                    _self.funUpdServerBaseData(dataType, filePathObj);
                } else {
                    app.alert(filePathObj.ResMsg, function () {
                        app.progress.stop();
                    });
                }
            }
        });

    },
    funUpdateLocationOrDevice: function (page, size, dataType) {
        var _self = this;
        app.progress.start("下载提示", "大批量分页下载正在处理中...");
        var specialtyNum = $("#SpecialtyList").attr("key"); //参数2
        var lineNum = $("#LineList").attr("key"); //参数3
        var dlDataParam = new Object();
        dlDataParam.IsCheck = "1";
        dlDataParam.DataType = new Array();
        if (lineNum != "NA") {
            dlDataParam.LineID = lineNum;
        }
        if (specialtyNum != "NA") {
            dlDataParam.SpecialtyID = specialtyNum;
        }
        app.getGlobalVariable("UnitOrgNum", function (res) {
            if (res) {
                dlDataParam.UnitOrgNum = res;
            }
        });
        dlDataParam.DataType.push(dataType);

        dlDataParam.page = page;
        dlDataParam.size = size;
        var requestParam = new Object();
        requestParam.orgin = "stream";
        requestParam.CallMethod = "Com_DownloadBaseData";
        requestParam.AuthBlock = new Object();
        requestParam.AuthBlock.ClientNumber = device.uuid;
        requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                requestParam.AuthBlock.UserCode = res;
            }
        });
        app.getGlobalVariable("Password", function (res) {
            if (res) {
                requestParam.AuthBlock.Password = res;
            }
        });
        requestParam.PayLoad = dlDataParam;
        app.ajax({
            "url": MobileConfig.DownBaseDataUrl, "data": requestParam,
            "contentType": "application/json",
            "method": "POST", "async": true,
            "fail": function (res) {
                app.alert("连接超时，请稍后重试" + JSON.stringify(res), function () {
                    app.progress.stop();
                });
            },
            "timeout": 600000,
            "success": function (res) {
                var filePathObj = JSON.parse(res.returnValue);
                if (filePathObj.ResStatus == true) {
                    _self.funUpdServerBaseData(dataType, filePathObj);
                } else {
                    app.alert(filePathObj.ResMsg, function () {
                        app.progress.stop();
                    });
                }
            }
        });
    },
    funUpdteBaseData: function (sqlList, msgTitle) {
        if (sqlList.length > 0) {
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeNonQuery(db, sqlList, function () {

            });
        }
    },
    funGetLineData: function (dataList, sqlList) {
        ///<summary>获取服务器Line的基础数据</summary>
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {
                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    var delSql = "DELETE FROM Line where LineNum='" + item.LineNum + "'";
                    sqlList.push(delSql);
                }
                var list = SqlTextHelper.funGetInsertText("Line", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }
    },
    funGetFaultPheData: function (dataList, sqlList) {
        ///<summary>获取服务器FaultPhenomenon的基础数据</summary>
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {
                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    var delSql = "DELETE FROM FaultPhenomenon where FaultPhenomenonNum='" + item.FaultPhenomenonNum + "'";
                    sqlList.push(delSql);
                }

                var list = SqlTextHelper.funGetInsertText("FaultPhenomenon", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }
    },
    funGetFaultRsnData: function (dataList, sqlList) {
        ///<summary>获取服务器FaultReason的基础数据</summary>
        if (dataList) {
            var datalen = dataList.length;
            var data = new Array();
            if (datalen > 0) {
                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    if(item.FaultPhenomenonNum=="PGCL0016"){
                        data.push(item);
                    }
                    var delSql = "DELETE FROM FaultReason where FaultReasonNum='" + item.FaultReasonNum + "'";
                    sqlList.push(delSql);
                }

                var list = SqlTextHelper.funGetInsertText("FaultReason", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }
    },
    funGetFaultSlnData: function (dataList, sqlList) {
        ///<summary>获取服务器FaultSolution的基础数据</summary>
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {
                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    var delSql = "DELETE FROM FaultSolution where FaultSolutionNum='" + item.FaultSolutionNum + "'";
                    sqlList.push(delSql);
                }

                var list = SqlTextHelper.funGetInsertText("FaultSolution", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }
    },
    funGetFaultClass: function (dataList, sqlList) {
        ///<summary>获取服务器FaultSolution的基础数据</summary>
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {
                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    var delSql = "DELETE FROM FaultClass where 1=1";
                    sqlList.push(delSql);
                }

                var list = SqlTextHelper.funGetInsertText("FaultClass", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }
    },
    funGetALNDomainData: function (dataList, sqlList) {
        ///<summary>获取服务器Specialty的基础数据</summary>
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {

                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    var delSql = "DELETE FROM ALNDomain where ALNDomainID='" + item.ALNDomainID + "'";
                    sqlList.push(delSql);
                }

                var list = SqlTextHelper.funGetInsertText("ALNDomain", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }
    },
    funGetSubSystemData: function (dataList, sqlList) {
        ///<summary>获取服务器Specialty的基础数据</summary>
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {

                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    var delSql = "DELETE FROM SubSystem where SubSystemNum='" + item.SubSystemNum + "'";
                    sqlList.push(delSql);
                }

                var list = SqlTextHelper.funGetInsertText("SubSystem", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }
    },
    funGetSpecialtyData: function (dataList, sqlList) {
        ///<summary>获取服务器Specialty的基础数据</summary>
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {

                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    var delSql = "DELETE FROM Specialty where SpecialtyNum='" + item.SpecialtyNum + "'";
                    sqlList.push(delSql);
                }

                var list = SqlTextHelper.funGetInsertText("Specialty", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }
    },
    funGetAreaData: function (dataList, sqlList) {
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {
                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    var delSql = "DELETE FROM Area where AreaNum='" + item.AreaNum + "'";
                    sqlList.push(delSql);
                }
                var list = SqlTextHelper.funGetInsertText("Area", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }

    },
    funGetToolData: function (dataList, sqlList) {
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {
                var delSql = "DELETE FROM Tool";
                sqlList.push(delSql);
                var list = SqlTextHelper.funGetInsertText("Tool", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }

    },
    funGetDeviceData: function (dataList, sqlList) {
        var _self = this;
        ///<summary>获取服务器Device的基础数据</summary>
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {
                if (_self.page === 1) {
                    var delSql = "DELETE FROM Device";
                    sqlList.push(delSql);
                }
                var list = SqlTextHelper.funGetInsertText("Device", dataList);
                Common.funConcatArray(sqlList, list);
            }
            if (datalen === _self.size) {
                _self.page++;
                _self.funUpdateLocationOrDevice(_self.page, _self.size, "Device");
            } else {
                //app.alert("设备更新成功", function () {
                //    app.progress.stop();
                //});
                app.progress.stop();
            }
            dataList = null;
        }
    },
    funGetLocationData: function (dataList, sqlList) {
        var _self = this;
        ///<summary>获取服务器Location的基础数据</summary>
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {
                if(_self.page ===1){
                    var delSql = "DELETE FROM Location";
                    sqlList.push(delSql);
                }
                var list = SqlTextHelper.funGetInsertText("Location", dataList);
                Common.funConcatArray(sqlList, list);
            }
            if(datalen === _self.size){
                _self.page++;
                _self.funUpdateLocationOrDevice(_self.page, _self.size, "Location");
            } else {
                //app.alert("位置更新成功", function () {
                //    app.progress.stop();
                //});
                app.progress.stop();
            }
            dataList = null;
        }
    },

    funGetMeasurePointData: function (dataList, sqlList) {
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {
                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    var delSql = "DELETE FROM MeasurePoint where PointNum='" + item.PointNum + "'";
                    sqlList.push(delSql);
                }
                var list = SqlTextHelper.funGetInsertText("MeasurePoint", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }
    },

    funGetMaterialData: function (dataList, sqlList) {
        if (dataList) {
            var delSql = "DELETE FROM Material";
            sqlList.push(delSql);
            var datalen = dataList.length;
            if (datalen > 0) {
                var list = SqlTextHelper.funGetInsertText("Material", dataList);
                Common.funConcatArray(sqlList, list);
            }
            dataList = null;
        }
    },

    funUpdServerBaseData: function (dataType, responseData) {
        var _self = this;
        if (responseData.ResStatus == true) {
            var baseData = responseData.PayLoad;
            var sqlList = new Array();
            var msgTitle = "";
            var isFinish = true;
            switch (dataType) {
                case "Fault":
                    _self.funGetFaultPheData(baseData.FaultPhenomenon, sqlList);
                    _self.funGetFaultRsnData(baseData.FaultReason, sqlList);
                    _self.funGetFaultSlnData(baseData.FaultSolution, sqlList);
                    _self.funGetFaultClass(baseData.FaultClass, sqlList);
                    _self.funUpdteBaseData(sqlList);
                    break;
                case "Device":
                    _self.funGetDeviceData(baseData.Device, sqlList);
                    msgTitle = "设备数据";
                    _self.funUpdteBaseData(sqlList);
                    isFinish = false;
                    break;
                case "Location":
                    _self.funGetLocationData(baseData.Location, sqlList);
                    msgTitle = "位置数据";
                    _self.funUpdteBaseData(sqlList);
                    isFinish =false;
                    break;
                case "ActualTools":
                    _self.funGetToolData(baseData.ActualTools, sqlList);
                    msgTitle = "工具数据";
                    _self.funUpdteBaseData(sqlList);
                    break;
                case "MeasurePoint":
                    _self.funGetMeasurePointData(baseData.MeasurePoint, sqlList);
                    msgTitle = "测点数据";
                    _self.funUpdteBaseData(sqlList);
                    break;
                case "Material":
                    _self.funGetMaterialData(baseData.Material, sqlList);
                    msgTitle = "物料数据";
                    _self.funUpdteBaseData(sqlList);
                    break;
                case "Other":
                    _self.funGetLineData(baseData.Line, sqlList);
                    _self.funGetSpecialtyData(baseData.Specialty, sqlList);
                    _self.funGetSubSystemData(baseData.SubSystem, sqlList);
                    _self.funGetALNDomainData(baseData.ALNDomain, sqlList);
                    _self.funGetAreaData(baseData.Area, sqlList);
                    msgTitle = "其他数据";
                    _self.funUpdteBaseData(sqlList);
                    _self.funInitData();
                    break;
                default:
                    _self.funGetDeviceData(baseData.Device, sqlList);
                    _self.funGetLocationData(baseData.Location, sqlList);

                    _self.funGetFaultPheData(baseData.FaultPhenomenon, sqlList);
                    _self.funGetFaultRsnData(baseData.FaultReason, sqlList);
                    _self.funGetFaultSlnData(baseData.FaultSolution, sqlList);
                    _self.funGetFaultClass(baseData.FaultClass, sqlList);
                    _self.funGetLineData(baseData.Line, sqlList);
                    _self.funGetSpecialtyData(baseData.Specialty, sqlList);
                    _self.funGetSubSystemData(baseData.SubSystem, sqlList);
                    _self.funGetALNDomainData(baseData.ALNDomain, sqlList);
                    _self.funGetAreaData(baseData.Area, sqlList);
                    _self.funGetToolData(baseData.ActualTools, sqlList);
                    
                    if (baseData.MeasurePoint) {
                        _self.funGetMeasurePointData(baseData.MeasurePoint, sqlList);
                    }
                    _self.funGetMaterialData(baseData.Material, sqlList);
                    msgTitle = "全部数据";
                    isFinish =true;
                    _self.funUpdteBaseData(sqlList);
                    _self.funInitData();
                    break;
            }
            if(isFinish){
                app.alert(msgTitle + "更新成功", function () {
                    app.progress.stop();
                });
            }
        } else {
            app.alert(responseData.ResMsg, function () {
                app.progress.stop();
            });
        }
    },

    funInitData: function () {
        var _self = this;
        var userCode = "";
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                userCode = res;
            }
        });
        if (userCode) {
            var db = app.database.open(Common.WEIXIUDB);
            var userRows = new Array();
            db.transaction(function (tx) {
                tx.executeSql("SELECT LineNum as 'key' ,LineName as value from Line", [], function (tx1, results) {
                    _self.Lines = Common.funConvertRowsJson(results);
                    _self.Lines.unshift({"key": "NA", "value": "--请选择线路--"});
                });
                tx.executeSql("SELECT SpecialtyNum as 'key',SpecialtyName as value  from Specialty", [], function (tx1, results) {
                    _self.Specialtys = Common.funConvertRowsJson(results);
                    _self.Specialtys.unshift({"key": "NA", "value": "--请选择专业--"});
                });
                tx.executeSql("SELECT * FROM User WHERE UserCode='" + userCode + "'", [], function (tx1, results) {
                    userRows = Common.funConvertRowsJson(results);
                });
            }, function (error) {
                app.alert(error);
            }, function () {
                if (userRows.length != 0) {
                    var row = userRows[0];
                    var specialtyNum = row["SpecialtyNum"];
                    var specialtyName = row["SpecialtyName"];
                    if (specialtyNum && specialtyName) {
                        var specialtyCtr = $("#SpecialtyList");
                        specialtyCtr.text(specialtyName);
                        specialtyCtr.attr("key", specialtyNum);
                    }
                    var lineNum = row["LineNum"];
                    var lineName = "";
                    var linelen = _self.Lines.length;
                    for (var i = 0; i < linelen; i++) {
                        var line = _self.Lines[i];
                        if (line["key"] == lineNum) {
                            lineName = line["value"];
                            break;
                        }
                    }
                    if (lineNum && lineName) {
                        var lineCtr = $("#LineList");
                        lineCtr.text(lineName);
                        lineCtr.attr("key", lineNum);
                    }
                }
            });
        }
    }
};

