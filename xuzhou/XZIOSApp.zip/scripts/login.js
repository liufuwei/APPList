﻿﻿var Login = function () {
};

Login.prototype = {
    //登录
    funLogin: function (userCode, password) {
        ///<summary>用户登录方法:void</summary>
        ///<param name="username" >用户名</param>
        ///<param name="password">密码</param>
        if (userCode && password) {
            var _self = this;
          
            //var sql = "SELECT * FROM  User WHERE UserCode='" + userCode + "' and Password='" + pwd + "'";001743   qweasd.123
            var sql = "SELECT * FROM  User WHERE UserCode='" + userCode + "' ";
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeQuery(db, sql, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if (rows.length > 0) {
                   
                    var CheckPassword = false;//在有网的情况下，验证RSA密码正确性
                    try {
                        var requestParam = new Object();
                        requestParam.CallMethod = "Misc_CheckPassword";
                        requestParam.AuthBlock = new Object();
                        requestParam.AuthBlock.UserCode = "admin";
                        requestParam.AuthBlock.Password = "112233";
                        var dlDataParam = new Object();
                        dlDataParam.IsCheck = "0";
                        dlDataParam.UserCode = userCode;
                        dlDataParam.Password = password;
                        requestParam.PayLoad = dlDataParam;
                        app.ajax({
                            "url": MobileConfig.DownBaseDataUrl, "data": requestParam,
                            "contentType": "application/json",
                            "method": "POST", "async": false,
                            "success": function (res) {
                                var da = JSON.parse(res.returnValue);
                                if (da.ResStatus == true) {
                                    var list = da.PayLoad;
                                    CheckPassword = list.CheckPassword;
                                } else {
                                    CheckPassword = false;
                                }
                            },
                            "timeout": 600000
                        });
                    }catch(e)
                    {
                        app.alert("请检查网络是否通畅！");
                    }
                    var row = rows[0];
                    var pwd = b64_md5(password);
                    if (pwd == row.Password || CheckPassword) {//md5和RSA两种密码都进行验证
                        app.setGlobalVariable("UserName", row.UserName);
                        app.setGlobalVariable("UserCode", row.UserCode);
                        app.setGlobalVariable("Password", row.Password);
                        app.setGlobalVariable("OrgNum", row.OrgNum);
                        app.setGlobalVariable("OrgName", row.OrgName);
                        app.setGlobalVariable("UnitOrgNum", row.UnitOrgNum);
                        app.setGlobalVariable("UnitName", row.UnitName);
                        app.setGlobalVariable("IsOutSourceUser", row.IsOutSourceUser);
                        app.setGlobalVariable("SpecialtyNum", (row.SpecialtyNum || "").toLowerCase());
                        var loginTime = Common.funGetNowDate();
                        var sqlList = new Array();
                        sqlList.push("delete from OPUsers ");
                        var addUserSql = "insert into OPUsers (UserNum,UserName,UserCode,LoginTime,isAdd) VALUES('" + row.UserNum + "','" + row.UserName + "','" + row.UserCode + "','" + loginTime + "','1')";
                        sqlList.push(addUserSql);
                        var db2 = app.database.open(Common.WEIXIUDB);
                        app.database.executeNonQuery(db2, sqlList, function () {
                            app.load({ url: "main.html" });
                        });
                    } else {
                        app.alert("您输入的密码有误！");
                    }

                } else {
                    app.alert("您输入的账号不存在！");
                }
            });

        } else {
            app.alert("账号或密码不能为空！");
        }
    },


    //初始化数据库
    funInitDb: function (apkVersion) {
        var vInfo = "";
        app.setting.get("recordVersion", "", function (res) {
            vInfo = res;
        });
        if (apkVersion != vInfo) {
            //app.progress.start("检查提示", "正在检查应用数据库信息...");
            var db = app.database.open(Common.WEIXIUDB);
            // 更新本地表结构 2018年8月15日 报障数据更改
            var oldtempTable = "temp20";
            var newtempTable = "temp21";
            db.transaction(function (tx) {
                tx.executeSql('select * from ' + newtempTable, [], function () {
                    app.progress.stop();
                });
            }, function (error) {
                funCrtDb();
            }, function () {
                app.setting.set("recordVersion", apkVersion);
                setTimeout(function () {
                    app.progress.stop();
                }, 100);
            });

            var funCrtDb = function () {
                var db2 = app.database.open(Common.WEIXIUDB);
                db2.transaction(function (tx) {
                    var sqlList = new Array();
                    sqlList.push("DROP TABLE IF  EXISTS " + oldtempTable);
                    sqlList.push("DROP TABLE IF  EXISTS " + newtempTable);
                    sqlList.push("CREATE TABLE IF NOT EXISTS " + newtempTable + " (id)");
                    for (var tableItem in WEIXIUDB) {
                        var delSql = "DROP TABLE IF  EXISTS " + tableItem;
                        sqlList.push(delSql);
                        var cteSql = "CREATE TABLE IF NOT EXISTS " + tableItem;
                        var clms = WEIXIUDB[tableItem];
                        if (clms.length > 0) {
                            cteSql += " (" + clms.join(",") + ")";
                            sqlList.push(cteSql);
                        }
                        var sqllen = sqlList.length;
                        if (sqllen > 0) {
                            for (var i = 0; i < sqllen; i++) {
                                tx.executeSql(sqlList[i]);
                            }
                        } else {
                            app.progress.stop();
                        }
                    }
                }, function (error) {
                    app.alert("初始化数据库失败", function () {
                        app.progress.stop();
                    });
                }, function () {
                    app.setting.set("recordVersion", apkVersion);
                    setTimeout(function () {
                        app.progress.stop();
                    }, 100);
                });
            };
        }
    },

    funUpdateUserData: function (dataList) {
        if (dataList) {
            var datalen = dataList.length;
            if (datalen > 0) {
                var sqlList = new Array();
                for (var i = 0; i < datalen; i++) {
                    var item = dataList[i];
                    var delSql = "DELETE FROM User where UserNum='" + item.UserNum + "'";
                    sqlList.push(delSql);
                }

                var list = SqlTextHelper.funGetInsertText("User", dataList);
                Common.funConcatArray(sqlList, list);

                var db = app.database.open(Common.WEIXIUDB);
                app.database.executeNonQuery(db, sqlList, function () {
                    //app.alert("数据更新成功", function () {
                    //    app.progress.stop();
                    //});
                    app.progress.stop();
                });
            } else {
                //app.alert("用户数据更新0条", function () {
                //    app.progress.stop();
                //});
                app.progress.stop();
            }
        } else {
            app.progress.stop();
        }
    },
    //下载用户数据
    funDownUser: function () {
        var _self = this;
        var dlDataParam = new Object();
        dlDataParam.IsCheck = "0";
        dlDataParam.DataType = new Array();
        app.setting.get("UpdateUserDate", '1990-1-1', function (res1) {
            dlDataParam.AfterTime = res1;
            dlDataParam.DataType.push("User");
            var requestParam = new Object();
            requestParam.orgin = "stream";
            requestParam.CallMethod = "Com_DownloadBaseData";
            requestParam.AuthBlock = new Object();
            requestParam.AuthBlock.ClientNumber = device.uuid;
            requestParam.AuthBlock.UserCode = "admin";
            requestParam.AuthBlock.Password = "112233";
            requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
            requestParam.PayLoad = dlDataParam;
            app.ajax({
                "url": MobileConfig.DownBaseDataUrl,
                "data": requestParam,
                "contentType": "application/json",
                "method": "POST", "async": true,
                "success": function (res) {
                    var filePathObj = JSON.parse(res.returnValue);
                    if (filePathObj.ResStatus == true) {
                        var planList = filePathObj.PayLoad;
                        if (planList.User) {
                            _self.funUpdateUserData(planList.User);
                            _self.funUpdateLineAndSpecialty();
                        } else {
                            app.alert("用户数据更新失败", function () {
                                app.progress.stop();
                            });
                        }
                    } else {
                        app.alert(filePathObj.ResMsg, function () {
                            app.progress.stop();
                        });
                    }
                },
                "fail": function (res) {
                    app.alert("用户数据更新失败" + res, function () {
                        app.progress.stop();
                    });
                },
                "timeout": 50000
            });
        });
       
    },
    funUpdateLineAndSpecialty: function () {
        var _self = this;
        //app.progress.start("检查提示", "正在检查更新线路与专业数据...");
        var lines = new Array();
        var dlDataParam = new Object();
        dlDataParam.IsCheck = "0";
        dlDataParam.LineID = "";
        dlDataParam.DataType = new Array();
        dlDataParam.DataType.push("Line");
        dlDataParam.DataType.push("Specialty");
        dlDataParam.DataType.push("SubSystem");
        var requestParam = new Object();
        requestParam.orgin = "stream";
        requestParam.CallMethod = "Com_DownloadBaseData";
        requestParam.AuthBlock = new Object();
        requestParam.AuthBlock.ClientNumber = device.uuid;
        requestParam.AuthBlock.UserCode = "admin";
        requestParam.AuthBlock.Password = "112233";
        requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                requestParam.AuthBlock.UserCode = res;
            }
        });
        app.getGlobalVariable("Password", function (res) {
            if (res) {
                requestParam.AuthBlock.Password = res;
            }
        });
        requestParam.PayLoad = dlDataParam;
        app.ajax({
            "url": MobileConfig.DownBaseDataUrl, "data": requestParam,
            "contentType": "application/json",
            "method": "POST", "async": true,
            "fail": function (res) {
                app.alert("连接超时，请稍后重试" + JSON.stringify(res), function () {
                    app.progress.stop();
                });
            },
            "timeout": 600000,
            "success": function (res) {
                var filePathObj = JSON.parse(res.returnValue);
                if (filePathObj.ResStatus == true) {
                    _self.funUpdServerBaseData(filePathObj);
                } else {
                    app.alert(filePathObj.ResMsg, function () {
                        app.progress.stop();
                    });
                }
            }
        });
    },
    funUpdServerBaseData: function (responseData) {
        if (responseData.ResStatus == true) {
            var baseData = responseData.PayLoad;
            var sqlList = new Array();
            ///<summary>获取服务器Line的基础数据</summary>
            if (baseData.Line) {
                var datalen = baseData.Line.length;
                if (datalen > 0) {
                    for (var i = 0; i < datalen; i++) {
                        var item = baseData.Line[i];
                        var delSql = "DELETE FROM Line where LineNum='" + item.LineNum + "'";
                        sqlList.push(delSql);
                    }
                    var list = SqlTextHelper.funGetInsertText("Line", baseData.Line);
                    Common.funConcatArray(sqlList, list);
                }
                baseData.Line = null;
            }
            ///<summary>获取服务器SubSystem的基础数据</summary>
            if (baseData.SubSystem) {
                var datalen = baseData.SubSystem.length;
                if (datalen > 0) {
                    for (var i = 0; i < datalen; i++) {
                        var item = baseData.SubSystem[i];
                        var delSql = "DELETE FROM SubSystem where SubSystemNum='" + item.SubSystemNum + "'";
                        sqlList.push(delSql);
                    }
                    var list = SqlTextHelper.funGetInsertText("SubSystem", baseData.SubSystem);
                    Common.funConcatArray(sqlList, list);
                }
                baseData.SubSystem = null;
            }
            ///<summary>获取服务器Specialty的基础数据</summary>
            if (baseData.Specialty) {
                var datalen = baseData.Specialty.length;
                if (datalen > 0) {
                    for (var i = 0; i < datalen; i++) {
                        var item = baseData.Specialty[i];
                        var delSql = "DELETE FROM Specialty where SpecialtyNum='" + item.SpecialtyNum + "'";
                        sqlList.push(delSql);
                    }
                    var list = SqlTextHelper.funGetInsertText("Specialty", baseData.Specialty);
                    Common.funConcatArray(sqlList, list);
                }
                baseData.Specialty = null;
            }
            if (sqlList.length > 0) {
                var db = app.database.open(Common.WEIXIUDB);
                app.database.executeNonQuery(db, sqlList, function () {
                    app.progress.stop();
                });
            }


        } else {
            app.progress.stop();
        }
    }

};