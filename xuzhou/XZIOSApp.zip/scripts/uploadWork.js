﻿﻿var UploadWork = function () {
    this.UploadList = new Array();
    this.UpdRecordFilePath = "";
    this.UpdManifestList = new Array();
    this.NotScanWkList = new Array();
    this.FaultOrderIdList = new Array();

    (function (self) {
        if (self.UpdRecordFilePath == "") {
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fileSystem) {
                fileSystem.root.getDirectory("LmisUpdRecordFile", {create: true, exclusive: false},
                    function (fileEntry) {
                        self.UpdRecordFilePath = fileEntry.fullPath;
                        var uri = fileEntry.fullPath + "/LMIS_UploadOrder.txt";
                        app.file.readAsString(uri, function (res) {
                            if (res) {
                                self.UpdManifestList = JSON.parse(res);
                            }
                        });

                    }, function () {
                        app.alert("创建目录失败");
                    });
            });
        }
    })(this);
};

UploadWork.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);


        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnUploadWork").click(function () {
            var funUpwk = function () {
                var networkState = navigator.network.connection.type;
                if (networkState == Connection.NONE) { //未连接
                    _self.funUploadWork();
                } else {
                    _self.funChkRepeatOrder();
                }
            };
            var isAllScan = true;
            if (_self.NotScanWkList.length > 0) {
                //检查需要上传的数据
                var chkObj = _self.funGetChkList();
                var planList = chkObj.PlanList;
                var chkListCount = planList.length;
                for (var i = 0; i < chkListCount; i++) {
                    var planId = planList[i];
                    if (_self.NotScanWkList.indexOf(planId) >= 0) {
                        isAllScan = false;
                        break;
                    }
                }
            }
            if (isAllScan == false) {
                app.confirm("存在未扫描的工单,是否继续上传?", function (index) {
                    if (index == 1) {
                        funUpwk();
                    }
                }, "提示", "确定,取消");
            } else {
                funUpwk();
            }
        });

        $("#btnClearWork").click(function () {
            _self.funClearWork();
        });

        $("#btnUploadRecord").click(function () {

            Common.funLoad("uploadRecord.html");
        });
    },
    funInitUiData: function () {
        app.getGlobalVariable("UserName", function (res) {
            if (res) {
                $("#username").html(res);
            }
        });

        app.getGlobalVariable("UserCode", function (res) {
            if (res) {
                $("#usercode").html("（" + res + "）");
            }
        });
    },

    funInitPlanData: function (containerId) {
        var _self = this;
        _self.UploadList.length = 0;
        var sqlText = "";
        sqlText += " SELECT * from (  ";
        sqlText += " SELECT c.PWONum as Id,( c.PWONum || '_' || c.OPName) as ItemDesc,'Plan' as DataType,WorkStatus as Status,( select count(*) from OPOrders where RecWay='s' and PWONum=c.PWONum ) as ScanNum,( select count(*) from OPOrders where PWONum=c.PWONum ) as OrderNum FROM OPPlan c where c.WorkStatus in ('3','4') ";
        sqlText += " UNION  ";
        sqlText += " SELECT a.WONum  as Id,(a.DeviceName || '_' || a.FaultDesc ) as ItemDesc,'Fault' as DataType,'3' as Status,'0' as ScanNum,1 as OrderNum FROM FaultsOrder a ";
        sqlText += " ) ORDER BY DataType DESC,Status ASC ";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sqlText, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var leng = rows.length;
            var lihtml = "";
            if (leng == 0) {
                lihtml = ' <li>';
                lihtml += '<div class="row-fluid">';
                lihtml += '<div class="span10" align="center">***暂无上传数据***</div>';
                lihtml += '</div>';
                lihtml += '</li>';
            } else {
                var funGetStatus = function (statusVal) {
                    var statusText = "";
                    switch (statusVal) {
                        case "3":
                            statusText = "【已完成未上传】";
                            break;
                        case "4":
                            statusText = "【已发送到电脑】";
                            break;
                        default:
                            statusText = "【N/A】";
                            break;
                    }
                    return statusText;
                };


                var funGetScanDesc = function (scanNumVal, orderNumVal) {
                    var scanDesc = "";
                    if (scanNumVal == orderNumVal) {
                        scanDesc = "【已完全扫描】";
                    } else if (scanNumVal > 0) {
                        scanDesc = "【未完成扫描】";
                    } else {
                        scanDesc = "【未扫描】";
                    }
                    return scanDesc;
                };

                for (var i = 0; i < leng; i++) {
                    var row = rows[i];
                    var dataType = row["DataType"];
                    var itemDesc = row["ItemDesc"];
                    var status = row["Status"];
                    var scanNum = row["ScanNum"] || 0;
                    var orderNum = row["OrderNum"] || 0;
                    var id = row["Id"];
                    var clsName = (status == "3") ? "BTCheck_ON" : "BTCheck_OFF";
                    if (dataType == "Plan" && (scanNum != orderNum)) {
                        _self.NotScanWkList.push(id);
                    }
                    if(dataType === "Fault" && id.slice(0,1) !== "-"){
                        _self.FaultOrderIdList.push(id);
                        continue
                    }

                    _self.UploadList.push({"Id": id, "DataType": dataType});
                    lihtml += '<li>';
                    lihtml += '<div data-role="BTButton" data-status="1">';
                    lihtml += '<span class="btn-text">';
                    lihtml += '<div class="row-box">';
                    lihtml += '<div class="span1">';
                    if (dataType === "Plan") {
                        lihtml += '<div id="li' + id + '" WOType = "PM" data-role="BTCheck" class="' + clsName + '" data-inline="false">' + itemDesc + funGetStatus(status) + funGetScanDesc(scanNum, orderNum) + '</div>';
                    } else if (dataType === "Fault") {
                        lihtml += '<div id="li' + id + '" WOType = "CM"data-role="BTCheck" class="' + clsName + '" data-inline="false">【故障】' + itemDesc + funGetStatus(status) + '</div>';
                    }
                    lihtml += '</div>';
                    lihtml += '</div>';
                    lihtml += '</span>';
                    lihtml += '</div>';
                    lihtml += ' </li>';
                }
            }
            var cnt = document.getElementById(containerId);
            if (cnt) {
                cnt.innerHTML = lihtml;
                ui.init();
                if (leng > 0) {
                    _self.funBindEvent();
                }
            }
        });
    },

    funBindEvent: function () {
        var _self = this;
        $("#btnAllChk").click(function () {
            var chkBox = $(this);
            var result = chkBox.btcheck("val");
            var length = _self.UploadList.length;
            if (length > 0) {
                var isAllchked = false;
                if (result != null && result.value != "") {
                    isAllchked = true;
                }
                for (var i = 0; i < length; i++) {
                    var chkBoxItem = $("#li" + _self.UploadList[i].Id);
                    if (isAllchked) {
                        chkBoxItem.removeClass('BTCheck_OFF').addClass('BTCheck_ON');
                    } else {
                        chkBoxItem.removeClass('BTCheck_ON').addClass('BTCheck_OFF');
                    }
                }
            }
        });
    },

    //检查选择的工单
    funGetChkList: function () {
        var _self = this;
        var planList = new Array();
        var faultList = new Array();
        var length = _self.UploadList.length;
        if (length > 0) {
            for (var i = 0; i < length; i++) {
                var updItem = _self.UploadList[i];
                var id = updItem["Id"];
                var chkBoxItem = $("#li" + id);
                var result = chkBoxItem.btcheck("val");
                if (result != null && result.value != "") {
                    var dataType = updItem["DataType"];
                    if (dataType == "Plan") {
                        if(_self.FaultOrderIdList.indexOf(id) > -1){
                            faultList.push(id);
                        } else {
                            planList.push(id);
                        }
                    } else if (dataType == "Fault") {
                        faultList.push(id);
                    }
                }
            }
        }
        return {"PlanList": planList, "FaultList": faultList};
    },

    funClearWork: function () {
        var _self = this;
        var chkObj = _self.funGetChkList();
        var planList = chkObj.PlanList;
        var faultList = chkObj.FaultList;
        var chkListCount = planList.length + faultList.length;
        if (chkListCount > 0) {
            app.confirm("确认要删除所选作业?", function (index) {
                if (index == 2) {
                    app.progress.start("删除提示", "正在处理中...");
                    _self.funDelWK(planList, faultList, true, []);
                }
            }, "删除作业确认", "取消,确定");
        }
    },

    funDelWK: function (planList, faultList, isDelAttFile, attFileList) {
        var _self = this;
        var sqlList = new Array();
        var planLeng = planList.length;
        for (var i = 0; i < planLeng; i++) {
            var pwoNum = planList[i];
            sqlList.push("delete from TagRecords where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPMaterial where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPTools where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPAreasTags where PWONum='" + pwoNum + "'");
            if (isDelAttFile) {
                sqlList.push("delete from AttFile where PWONum='" + pwoNum + "'");
            }
            sqlList.push("delete from OrderProcedure where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPOrders where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPPlan where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPSafety where PWONum='" + pwoNum + "'");
            sqlList.push("delete from OPSafetyMain where PWONum='" + pwoNum + "'");
        }

        var faultLeng = faultList.length;
        for (var k = 0; k < faultLeng; k++) {
            var faultNum = faultList[k];
            sqlList.push("delete from TagRecords where PWONum='" + faultNum + "'");
            sqlList.push("delete from OPMaterial where PWONum='" + faultNum + "'");
            sqlList.push("delete from OPTools where PWONum='" + faultNum + "'");
            sqlList.push("delete from OPAreasTags where PWONum='" + faultNum + "'");
            if (isDelAttFile) {
                sqlList.push("DELETE FROM AttFile where ObjectID='" + faultNum + "'");
            }
            sqlList.push("DELETE FROM FaultsOrder where WONum='" + faultNum + "'");
            sqlList.push("delete from OPOrders where PWONum='" + faultNum + "'");
            sqlList.push("delete from OPPlan where PWONum='" + faultNum + "'");
            sqlList.push("delete FROM Measurement where WONum='" + faultNum + "'");
            sqlList.push("delete from OPSafety where PWONum='" + faultNum + "'");
            sqlList.push("delete from OPSafetyMain where PWONum='" + faultNum + "'");
        }

        var attLeng = attFileList.length;
        for (var g = 0; g < attLeng; g++) {
            var attNum = attFileList[g];
            sqlList.push("DELETE FROM AttFile where AttNum='" + attNum + "'");
        }

        var sqlCount = sqlList.length;
        if (sqlCount > 0) {
            var db = app.database.open(Common.WEIXIUDB);
            db.transaction(function (tx) {
                for (var j = 0; j < sqlCount; j++) {
                    tx.executeSql(sqlList[j]);
                }
            }, function (error) {
                app.alert(error, function () {
                    app.progress.stop();
                });
            }, function () {
                app.progress.stop();
                _self.funInitPlanData("planList");
            });
        } else {
            app.progress.stop();
        }
    },

    //上传
    funUploadWork: function () {
        var _self = this;
        var chkObj = _self.funGetChkList();
        var planList = chkObj.PlanList;
        var faultList = chkObj.FaultList;
        var chkListCount = planList.length + faultList.length;
        if (chkListCount > 0) {
            app.progress.start("上传提示", "正在处理中...");
            var pwoNums = planList.join("','");
            var faultNums = faultList.join("','");

            var sqlPlanText = "SELECT PWONum,OPCode,OPName FROM OPPlan where PWONum IN('" + pwoNums + "') order by PWONum ";
            var sqlOPUsersText = "SELECT UserCode,LoginTime,isAdd FROM OPUsers";
            var sqlActualToolsText = "SELECT a.PWONum,a.OPToolNum,a.OPToolName,a.OPToolUnit,a.OPToolCount FROM OPTools a inner join OPPlan b on a.PWONum=b.PWOnum where b.PWONum IN('" + pwoNums + "') or b.PWONum IN ('" + faultNums + "') order by a.PWONum ";
            var sqlActualMaterialText = "SELECT a.PWONum,a.WONum,a.OPMateriaID,a.OPMaterialNum,a.FinishChkCount,a.IsOut FROM OPMaterial a inner join OPPlan b on a.PWONum=b.PWOnum where  a.WONum NOT LIKE '-%' and b.PWONum IN('" + pwoNums + "') order by a.PWONum ";
            var sqlTagRecordsText = "SELECT a.PWONum,a.TagCode,a.TagType,a.ScanTime,a.EnterOrExit FROM TagRecords a inner join OPPlan b on a.PWONum=b.PWOnum where b.PWONum IN('" + pwoNums + "') order by a.PWONum ";

            var sqlOrderResultText = "SELECT a.PWONum,a.WONum,a.RecWay,a.RecTime,a.TagCode,a.SelfFormIsFinished,a.SelfFormFinishTime,a.SelfFormUserCode,a.MutFormIsFinished,a.MutFormFinishTime,a.MutFormUserCode,a.DeviceNote,a.HasFollowUpWork,a.IsOtherCheck,a.IsConfirm,a.ConfirmUserCode,a.ConfirmTime,a.ActStart,a.ActFinish,a.IsRemove,a.RemoveUserCode,a.RemoveUserName,a.RemoveFinishTime,a.CancelFlag,a.CancelReason,a.CancelMemo FROM OPOrders a where ";
            sqlOrderResultText += " ( EXISTS ( select WONum FROM OrderProcedure b where b.WONum=a.WONum and  b.ResultValue!='' ) or  a.SelfFormIsFinished='1' or a.IsRemove='1' or a.CancelFlag='1') ";
            sqlOrderResultText += " and PWONum IN('" + pwoNums + "') ";
            sqlOrderResultText += " order by PWONum ";

            var sqlActualProceduresText = "SELECT a.PWONum,a.WONum,a.ProcedureNum,a.ResultValue,a.SelfFormUserCode,a.SelfFormTime,a.MutFormUserCode,a.MutFormTime FROM OrderProcedure a inner join OPPlan b on a.PWONum=b.PWOnum where  a.ResultValue!='' and b.PWONum IN('" + pwoNums + "') order by a.PWONum ";
            var sqlFaultsOrderText = "SELECT a.* FROM FaultsOrder a where a.WONum IN('" + faultNums + "') ORDER BY a.WONum";
            var sqlAttachmentText = "SELECT a.PWONum,a.AttNum,a.AttType,a.ObjectType,a.ObjectID,a.AttDesc,a.AttPath,a.IsUpLoad FROM AttFile a where a.ObjectID in (select ProcedureNum from  OrderProcedure where PWONum in ('" + pwoNums + "')) or a.ObjectID in (select WONum from  OPOrders where PWONum in ('" + pwoNums + "')) or a.ObjectID IN ('" + faultNums + "')";

            var sqlActualSafetyMainText = "SELECT a.PWONum,a.IsTakeover,a.IsConfirm,a.ConfirmTime,a.SafetyMainNum FROM OPSafetyMain a inner join OPPlan b on a.PWONum=b.PWOnum where b.PWONum IN('" + pwoNums + "') order by a.PWONum";
            var sqlActualSafetyText = "SELECT a.PWONum,a.OPSafetyNum,a.IsConfirm,a.SafetyMainNum FROM OPSafety a inner join OPPlan b on a.PWONum=b.PWOnum where b.PWONum IN('" + pwoNums + "') order by a.PWONum";

            var sqlMeasurementText = "SELECT c.WONum,c.PointNum,c.MeasurementValue,c.MeasurementType,c.MeasureDate FROM FaultsOrder a LEFT JOIN OPPlan b on a.PWONum=b.PWONum INNER JOIN Measurement c on a.WONum=c.WONum where (b.PWONum IN('" + pwoNums + "') or c.WONum IN('" + faultList + "') ) ORDER BY a.WONum";
            var sqlFaultMaterialText = "SELECT a.PWONum,a.WONum,a.OPMateriaID,a.OPMaterialNum,a.FinishChkCount,a.isOut FROM OPMaterial a INNER JOIN FaultsOrder c on a.WONum=c.WONum  where c.WONum IN('" + faultList + "')  ORDER BY c.WONum";


            var userCode = "";
            var userName = "";
            var password = "";
            app.getGlobalVariable("UserCode", function (res) {
                if (res) {
                    userCode = res;
                }
            });
            app.getGlobalVariable("Password", function (res) {
                if (res) {
                    password = res;
                }
            });
            app.getGlobalVariable("UserName", function (res) {
                if (res) {
                    userName = res;
                }
            });

            var uploadWks = new Array();
            var users = new Array();
            var tools = new Array();
            var materials = new Array();
            var tagRecords = new Array();
            var orders = new Array();
            var procedures = new Array();
            var faultsOrders = new Array();

            var safetyMains = new Array();
            var safetys = new Array();

            var measurements = new Array();
            var faultMaterials = new Array();
            var attachments = new Array();


            var upPlanOkList = new Array();
            var upPlanErrorList = new Array();
            var upPlanIdList = new Array();

            var upFaultIdList = new Array();
            var upFaultErrorList = new Array();
            var upfaultAllOk = true;

            var upAttFileIdList = new Array();
            var upattAllOk = true;

            var db = app.database.open(Common.WEIXIUDB);
            db.transaction(function (tx) {
                tx.executeSql(sqlPlanText, [], function (tx1, results) {
                    uploadWks = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlOPUsersText, [], function (tx1, results) {
                    users = Common.funConvertRowsJson(results);
                    //作业人员为空，添加上传人进去
                    if (users.length == 0) {
                        app.getGlobalVariable("UserCode", function (res) {
                            if (res) {
                                var userItem = new Object();
                                userItem.UserCode = res;
                                users.push(userItem);
                            }
                        });
                    }
                });
                tx.executeSql(sqlActualToolsText, [], function (tx1, results) {
                    tools = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlActualMaterialText, [], function (tx1, results) {
                    materials = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlTagRecordsText, [], function (tx1, results) {
                    tagRecords = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlOrderResultText, [], function (tx1, results) {
                    orders = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlActualProceduresText, [], function (tx1, results) {
                    procedures = Common.funConvertRowsJson(results);
                });

                tx.executeSql(sqlFaultsOrderText, [], function (tx1, results)
                {
                    faultsOrders = Common.funConvertRowsJson(results);
                });


                tx.executeSql(sqlMeasurementText, [], function (tx1, results) {
                    measurements = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlFaultMaterialText, [], function (tx1, results) {
                    faultMaterials = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlAttachmentText, [], function (tx1, results) {
                    attachments = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlActualSafetyMainText, [], function (tx1, results) {
                    safetyMains = Common.funConvertRowsJson(results);
                });
                tx.executeSql(sqlActualSafetyText, [], function (tx1, results) {
                    safetys = Common.funConvertRowsJson(results);
                });
            }, function (error) {
                app.alert(error);
            }, function () {
                funConvertWkStruct();
                funConvertFaultStruct();
                var wklen = uploadWks.length;
                var fltOrderlen = faultsOrders.length;
                var attachlen = attachments.length;

                if (wklen > 0 || fltOrderlen > 0 || attachlen > 0) {
                    //上传数据

                    funUpWk();
                    //funUpAttach();
                } else {
                    app.alert("当前没有需要上传的数据", function () {
                        app.progress.stop();
                    });
                }
            });


            var funConvertWkStruct = function () {
                var wklen = uploadWks.length;
                if (wklen > 0) {
                    for (var i = 0; i < wklen; i++) {
                        var wkItem = uploadWks[i];
                        wkItem.OPUsers = users;
                        funGetTools(wkItem); //工具
                        funGetMaterials(wkItem); //物料
                        funGetTagRecords(wkItem); //标签记录
                        funGetOrders(wkItem); //工单
                        funGetProcedures(wkItem); //工单工序
                        funGetSafetyMain(wkItem); //安全交底主表
                        funGetSafety(wkItem); //安全交底细项
                        funGetSafetyUsers(wkItem); //安全交底确认人员
                    }
                }
            };
            var funConvertFaultStruct = function () {
                var fltOrderlen = faultsOrders.length;
                if (fltOrderlen > 0) {
                    for (var i = 0; i < fltOrderlen; i++) {
                        var fltItem = faultsOrders[i];
                        funGetMeasurements(fltItem); //测点
                        funGetFaultMaterial(fltItem); //故障物料
                        funGetTools(fltItem); //工具
                    }
                }
            };

            var funGetSafetyUsers = function (wkItem) {
                var safetyMainlen = wkItem.ActualSafetyMain.length;
                var userlen = users.length;
                wkItem.SafetyUsers = new Array();
                if (safetyMainlen > 0 && userlen > 0) {
                    var safetyMainNum = wkItem.ActualSafetyMain[0]["SafetyMainNum"];
                    for (var i = 0; i < userlen; i++) {
                        var user = users[i];
                        wkItem.SafetyUsers.push({
                            "UserCode": user["UserCode"],
                            "LoginTime": user["LoginTime"],
                            "SafetyMainNum": safetyMainNum
                        });
                    }
                }
            };

            var toolStartIndex = 0;
            var funGetTools = function (wkItem) {
                var toollen = tools.length;
                if (toollen > 0) {
                    var actTools = new Array();
                    var pWoNum = wkItem.PWONum;
                    var isbreak = false;
                    for (var i = toolStartIndex; i < toollen; i++) {
                        var toolTem = tools[i];
                        if (pWoNum == toolTem.PWONum) {
                            isbreak = true;
                            actTools.push(toolTem);
                        } else {
                            if (isbreak) {
                                toolStartIndex = i;
                                break;
                            }
                        }
                    }
                    wkItem.ActualTools = actTools;
                } else {
                    wkItem.ActualTools = new Array();
                }
            };
            var materialStartIndex = 0;
            var funGetMaterials = function (wkItem) {
                var materiallen = materials.length;
                if (materiallen > 0) {
                    var actmaterials = new Array();
                    var actOutmaterials = new Array();
                    var pWoNum = wkItem.PWONum;
                    var isbreak = false;
                    for (var i = materialStartIndex; i < materiallen; i++) {
                        var materiaTem = materials[i];
                        if (pWoNum == materiaTem.PWONum) {
                            isbreak = true;
                            var isOut = materiaTem["IsOut"] || "0";
                            if (isOut == "0") {
                                actmaterials.push(materiaTem);
                            } else {
                                actOutmaterials.push(materiaTem);
                            }
                        } else {
                            if (isbreak) {
                                materialStartIndex = i;
                                break;
                            }
                        }
                    }
                    wkItem.ActualMaterial = actmaterials;
                    wkItem.ActualOutMaterial = actOutmaterials;
                } else {
                    wkItem.ActualMaterial = new Array();
                    wkItem.ActualOutMaterial = new Array();
                }
            };

            var tagStartIndex = 0;
            var funGetTagRecords = function (wkItem) {
                var tagRecordlen = tagRecords.length;
                if (tagRecordlen > 0) {
                    var actTags = new Array();
                    var pWoNum = wkItem.PWONum;
                    var isbreak = false;
                    for (var i = tagStartIndex; i < tagRecordlen; i++) {
                        var tagRecordItem = tagRecords[i];
                        if (pWoNum == tagRecordItem.PWONum) {
                            isbreak = true;
                            actTags.push(tagRecordItem);
                        } else {
                            if (isbreak) {
                                tagStartIndex = i;
                                break;
                            }
                        }
                    }
                    wkItem.TagRecords = actTags;
                } else {
                    wkItem.TagRecords = new Array();
                }
            };
            var orderStartIndex = 0;
            var funGetOrders = function (wkItem) {
                var orderslen = orders.length;
                if (orderslen > 0) {
                    var actOrders = new Array();
                    var pWoNum = wkItem.PWONum;
                    var isbreak = false;
                    for (var i = orderStartIndex; i < orderslen; i++) {
                        var orderItem = orders[i];
                        if (pWoNum == orderItem.PWONum) {
                            isbreak = true;
                            actOrders.push(orderItem);
                        } else {
                            if (isbreak) {
                                orderStartIndex = i;
                                break;
                            }
                        }
                    }
                    wkItem.OrderResult = actOrders;
                } else {
                    wkItem.OrderResult = new Array();
                }
            };
            var procedurceStartIndex = 0;
            var funGetProcedures = function (wkItem) {
                var procelen = procedures.length;
                if (procelen > 0) {
                    var actProcedures = new Array();
                    var pWoNum = wkItem.PWONum;
                    var isbreak = false;
                    for (var i = procedurceStartIndex; i < procelen; i++) {
                        var actProceItem = procedures[i];
                        if (pWoNum == actProceItem.PWONum) {
                            isbreak = true;
                            actProcedures.push(actProceItem);
                        } else {
                            if (isbreak) {
                                procedurceStartIndex = i;
                                break;
                            }
                        }
                    }
                    wkItem.ActualProcedures = actProcedures;
                } else {
                    wkItem.ActualProcedures = new Array();
                }
            };

            var safetyMainIndex = 0;
            var funGetSafetyMain = function (wkItem) {
                var safetyMainlen = safetyMains.length;
                if (safetyMainlen > 0) {
                    var actSafetyMains = new Array();
                    var pWoNum = wkItem.PWONum;
                    var isbreak = false;
                    for (var i = safetyMainIndex; i < safetyMainlen; i++) {
                        var safetyMainItem = safetyMains[i];
                        if (pWoNum == safetyMainItem.PWONum) {
                            isbreak = true;
                            actSafetyMains.push(safetyMainItem);
                        } else {
                            if (isbreak) {
                                safetyMainIndex = i;
                                break;
                            }
                        }
                    }
                    wkItem.ActualSafetyMain = actSafetyMains;
                } else {
                    wkItem.ActualSafetyMain = new Array();
                }
            };

            var safetyIndex = 0;
            var funGetSafety = function (wkItem) {
                var safetylen = safetys.length;
                if (safetylen > 0) {
                    var actualSafetys = new Array();
                    var pWoNum = wkItem.PWONum;
                    var isbreak = false;
                    for (var i = safetyIndex; i < safetylen; i++) {
                        var acSafetyItem = safetys[i];
                        if (pWoNum == acSafetyItem.PWONum) {
                            isbreak = true;
                            actualSafetys.push(acSafetyItem);
                        } else {
                            if (isbreak) {
                                safetyIndex = i;
                                break;
                            }
                        }
                    }
                    wkItem.ActualSafety = actualSafetys;
                } else {
                    wkItem.ActualSafety = new Array();
                }
            };

            var measurementStartIndex = 0;
            var funGetMeasurements = function (fltItem) {
                var measurementlen = measurements.length;
                if (measurementlen > 0) {
                    var actMeasurement = new Array();
                    var woNum = fltItem.WONum;
                    var isbreak = false;
                    for (var i = measurementStartIndex; i < measurementlen; i++) {
                        var measurementItem = measurements[i];
                        if (woNum == measurementItem.WONum) {
                            isbreak = true;
                            actMeasurement.push(measurementItem);
                        } else {
                            if (isbreak) {
                                measurementStartIndex = i;
                                break;
                            }
                        }
                    }
                    fltItem.Measurement = actMeasurement;
                } else {
                    fltItem.Measurement = new Array();
                }
            };

            var faultMaterialStartIndex = 0;
            var funGetFaultMaterial = function (fltItem) {
                var faultMateriallen = faultMaterials.length;
                if (faultMateriallen > 0) {
                    var actmaterials = new Array();
                    var actOutmaterials = new Array();
                    var wONum = fltItem.WONum;
                    var isbreak = false;
                    for (var i = faultMaterialStartIndex; i < faultMateriallen; i++) {
                        var materiaTem = faultMaterials[i];
                        if (wONum == materiaTem.WONum) {
                            isbreak = true;
                            var isOut = materiaTem["IsOut"] || "0";
                            if (isOut == "0") {
                                actmaterials.push(materiaTem);
                            } else {
                                actOutmaterials.push(materiaTem);
                            }
                        } else {
                            if (isbreak) {
                                faultMaterialStartIndex = i;
                                break;
                            }
                        }
                    }
                    fltItem.ActualMaterial = actmaterials;
                    fltItem.ActualOutMaterial = actOutmaterials;
                } else {
                    fltItem.ActualMaterial = new Array();
                    fltItem.ActualOutMaterial = new Array();
                }
            };
            //上传信息,
            //1.全部上传完成（包括成功和失败） 或者 2.无上传列表数据 --->开始上传故障
            //递归单条上传工单  lsw/2017-11-09：因为iphone不能异步上传改成同步的递归上传数据，异步导致多选上传的时候上传是同一条记录
            var funUpWk = function (i) {
                var wklen = uploadWks.length;
                if (!i) {
                    i = 0;
                }
                if (i < wklen) {
                    var wkItem = uploadWks[i];
                    app.progress.start("上传提示", "正在上传数据[" + wkItem["PWONum"] + "]...(" + (i + 1) + "/" + wklen + ")");
                    var requestParam = new Object();
                    requestParam.orgin = "stream";
                    requestParam.AuthBlock = new Object();
                    requestParam.AuthBlock.ClientNumber = device.uuid;
                    requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
                    requestParam.AuthBlock.Password = password;
                    requestParam.AuthBlock.UserCode = userCode;
                    requestParam.CallMethod = "Biz_SubmitOrderResult";
                    requestParam.PayLoad = wkItem;
                    app.ajax({
                        "url": MobileConfig.UploadWorkUrl,
                        "data": requestParam,
                        "contentType": "application/json",
                        "method": "POST",
                        "async": false,
                        "timeout": 6000,
                        // "timeout": 600000,
                        "success": function (res) {
                            var item = uploadWks[i];
                            try {
                                var responseData = JSON.parse(res.returnValue);
                                if (responseData.ResStatus == true) {
                                    upPlanIdList.push(item["PWONum"]);
                                    var description = item["PWONum"] + "_" + item["OPCode"] + item["OPName"];
                                    upPlanOkList.push(description);
                                    _self.funSaveUpdRecord("Plan", userCode, requestParam, item["PWONum"], description);
                                } else {
                                    upPlanErrorList.push(item["PWONum"] + "_" + item["OPCode"] + item["OPName"] + "[" + responseData.ResMsg + "]");
                                }

                            } catch (e) {
                                upPlanErrorList.push(item["PWONum"] + "_" + item["OPCode"] + item["OPName"] + "[" + e.message + "]");
                            }
                            //判断上传了多少条，上传完成作业，开始上传故障，改成同步上传
                            i++;
                            if (i < wklen) {
                                funUpWk(i);
                            } else {
                                //上传故障
                                funUpFault();
                            }

                        },
                        "fail": function (res) {
                            upPlanErrorList.push(wkItem["PWONum"] + "_" + wkItem["OPCode"] + wkItem["OPName"] + "[上传超时]");
                            //判断上传了多少条，上传完成作业，开始上传故障，改成同步上传
                            i++;
                            if (i < wklen) {
                                funUpWk(i);
                            } else {
                                //上传故障
                                funUpFault();
                            }
                        }
                    });
                } else {
                    funUpFault();
                }
            };

            //上传故障
            //1.全部上传完成（包括成功和失败） 或者 2.无上传列表数据 ，开始判断是否要删除本地
            //递归单条上传故障  lsw/2017-11-09：因为iphone不能异步上传改成同步的递归上传数据，异步导致多选上传的时候上传是同一条记录
            var funUpFault = function (i) {
                if (!i) {
                    i = 0;
                }
                var fltOrderlen = faultsOrders.length;
                if (i < fltOrderlen) {
                    var faultItem = funGetFault(faultsOrders[i]);
                    app.progress.start("上传提示", "正在上传故障数据[" + faultItem["PWONum"] + "]...(" + (i + 1) + "/" + fltOrderlen + ")");
                    var requestParam = new Object();
                    requestParam.orgin = "stream";
                    requestParam.AuthBlock = new Object();
                    requestParam.AuthBlock.ClientNumber = device.uuid;
                    requestParam.AuthBlock.RequestTime = Common.funGetNowDate();
                    faultItem.UserCode = userCode;
                    faultItem.UserName = userName;
                    requestParam.AuthBlock.UserCode = userCode;
                    requestParam.AuthBlock.Password = password;
                    requestParam.CallMethod = "Biz_SubmitFaultOrder";
                    requestParam.PayLoad = faultItem;
                    // alert("测试了")
                    // $("#input").val(JSON.stringify(requestParam));
                    // if(true){
                    //     return;
                    // }
                    app.ajax({
                        "url": MobileConfig.UploadFaultUrl,
                        "data": requestParam,
                        "contentType": "application/json",
                        "method": "POST",
                        "async": false,
                        "timeout": 6000,
                        // "timeout": 600000,
                        "success": function (res) {
                            var item = faultsOrders[i];
                            try {
                                var responseData = JSON.parse(res.returnValue);
                                if (responseData.ResStatus == true) {
                                    upFaultIdList.push(item["WONum"]);
                                    var description = item["WONum"] + "_" + item["DeviceName"] + "_" + item["FaultDesc"];
                                    _self.funSaveUpdRecord("Fault", userCode, requestParam, item["WONum"], description);
                                } else {
                                    upfaultAllOk = false;
                                    upFaultErrorList.push(item["DeviceName"] + "_" + item["FaultDesc"] + "[" + responseData.ResMsg + "]");
                                    // 故障上传失败，移除工单上传记录
                                    Common.funRemoveItem(upPlanIdList, item["WONum"]);
                                }
                            } catch (e) {
                                upFaultErrorList.push(item["DeviceName"] + "_" + item["FaultDesc"] + "[" + e.message + "]");
                                // 故障上传失败，移除工单上传记录
                                Common.funRemoveItem(upPlanIdList, item["WONum"]);
                            }
                            //改成同步，上传完成作业和故障后才显示成功
                            funUpFault(i + 1);

                        },
                        "fail": function (res) {
                            upFaultErrorList.push(faultItem["DeviceName"] + "_" + faultItem["FaultDesc"] + "[上传超时]");
                            // 故障上传失败，移除工单上传记录
                            Common.funRemoveItem(upPlanIdList, faultItem["WONum"]);
                            //递归上传下一条
                            funUpFault(i + 1);
                        }
                    });
                } else {
                    funUpAttach();
                }
            };
            var funGetFault = function(Object){
                var faultTemp = {};

                // if(Object.WONum.slice(0,1) === "-"){//本地新建的故障数据
                //     faultTemp.PWONum = Object.PWONum;
                //     faultTemp.WONum = Object.WONum;
                //     faultTemp.WOType = Object.WOType;
                //     faultTemp.FaultReportUserName = Object.FaultReportUserName;
                //     faultTemp.FaultRepMobilePhone = Object.FaultRepMobilePhone;
                //     faultTemp.FaultDesc = Object.FaultDesc;
                //     faultTemp.FaultLocation = Object.FaultLocation;
                //     faultTemp.FaultJournalTime = Object.FaultJournalTime;
                //     faultTemp.FaultTime = Object.FaultTime;
                //     faultTemp.OperationTimeFault = Object.OperationTimeFault;
                //     faultTemp.LineName = Object.LineName;
                //     faultTemp.LineNum = Object.LineNum;
                //     faultTemp.DeviceNum = "";
                // } else {
                // }
                faultTemp = Object;
                return faultTemp;
            };
            //上传附件
            //递归单条上传附件  lsw/2017-11-09：因为iphone不能异步上传改成同步的递归上传数据，异步导致多选上传的时候上传是同一条记录
            var funUpAttach = function (i, ft) {
                var attachlen = attachments.length;
                if (!i) {
                    i = 0;
                }
                if (!ft) {
                    ft = new FileTransfer();
                }
                if (i < attachlen) {
                    app.progress.start("上传提示", "正在上传附件...(" + (i + 1) + "/" + attachlen + ")");
                    var attachItem = attachments[i];
                    var attPath = attachItem.AttPath;
                    var attNum = attachItem.AttNum;
                    var objid = attachItem.ObjectID;
                    var attDesc = attachItem.AttDesc;
                    var type = attachItem.AttType;
                    var objname = attachItem.ObjectType;
                    var isUpLoad = attachItem.IsUpLoad;
                    if (isUpLoad == "0") {
                        upAttFileIdList.push(attNum);
                        funUpAttach(i + 1, ft);

                    } else {
                        var options = new FileUploadOptions();
                        options.fileName = (new Date()).getTime() + attPath.substr(attPath.lastIndexOf('/') + 1);
                        if (options.fileName.indexOf(".jpg") < 0) {
                            options.fileName += ".jpg";
                        }
                        options.chunkedMode = false;
                        options.params = attachItem;
                        var url = MobileConfig.UploadAttachUrl + "?userid=" + userCode + "&password=" + encodeURIComponent(password) + "&attnum=" + attNum + "&id=" + objid + "&attpath=" + attPath + "&description=" + attDesc + "&type=" + type + "&objname=" + objname;
                        ft.upload(attPath, url, function (res) {
                            console.log(res);
                            var responseData = JSON.parse(res.response);
                            
                            if (responseData.ResStatus) {
                                var payLoad = responseData.PayLoad;
                                upAttFileIdList.push(payLoad.AttNum);
                            } else {
                                upattAllOk = false;
                            }
                            funUpAttach(i + 1, ft);
                            console.log(res);
                        }, function (error) {
                            console.log(error);
                            if (JSON.stringify(error).indexOf("500") > 0) {
                                app.alert("上传附件不得大于400M" + error);
                            } else {

                            }
                            upattAllOk = false;
                            funUpAttach(i + 1, ft);
                        }, options);
                    }
                } else {
                    //上传成功，删除本地数据
                    funUpEndMsg(true);
                }
            };

            var funUpEndMsg = function (isDelAttFile) {
                app.progress.stop();
                var titleMsg = "";
                if (upPlanOkList.length > 0) {
                    titleMsg += "上传成功的工单如下\n" + upPlanOkList.join("\n") + "\n\n";
                }
                if (upPlanErrorList.length > 0) {
                    titleMsg += "上传失败的工单如下\n" + upPlanErrorList.join("\n") + "\n\n";
                }
                if (upfaultAllOk == false) {
                    titleMsg += "上传故障失败\n" + upFaultErrorList.join("\n") + "\n\n";
                } else if (faultsOrders.length > 0 && upfaultAllOk) {
                    titleMsg += "上传故障成功\n";
                }
                if (upattAllOk == false) {
                    titleMsg += "上传附件失败,请检查网络或文件是否有超于400M";
                }
                if (titleMsg) {
                    app.alert(titleMsg, function () {
                        _self.funDelWK(upPlanIdList, upFaultIdList, isDelAttFile, upAttFileIdList);
                    });
                } else {
                    app.alert("上传成功", function () {
                        _self.funDelWK(upPlanIdList, upFaultIdList, isDelAttFile, upAttFileIdList);
                    });
                }
            };

        } else {
            app.alert("请选择要上传的作业");
        }
    },

    funChkRepeatOrder: function () {
        var _self = this;
        var chkObj = _self.funGetChkList();
        var planList = chkObj.PlanList;
        var faultList = chkObj.FaultList;
        var chkListCount = planList.length + faultList.length;
        if (chkListCount > 0) {
            _self.funUploadWork();
        } else {
            app.alert("请选择要上传的作业");
        }
    },
    funSaveUpdRecord: function (type, userCode, requestParam, wONum, description) {
        var _self = this;
        var date = Common.funGetNowDate();
        var now = new Date();
        var nowDate = now.getFullYear() + "_" + (now.getMonth() + 1) + "_" + now.getDate() + "_" + now.getHours() + "_" + now.getMinutes() + "_" + now.getSeconds();
        var fileName = _self.UpdRecordFilePath + "/" + type + "_" + wONum + "_userCode" + userCode + "_time" + nowDate + ".txt";
        var item = {
            "Date": date,
            "DataType": type,
            "FilePath": fileName,
            "UserCode": userCode,
            "Description": description
        };
        _self.UpdManifestList.push(item);
        var content = JSON.stringify(requestParam);
        var manifestPath = _self.UpdRecordFilePath + "/LMIS_UploadOrder.txt";
        var manifestCnt = JSON.stringify(_self.UpdManifestList);

        app.file.writeAsString(fileName, content, function (res) {
            app.file.remove(manifestPath);
            app.file.writeAsString(manifestPath, manifestCnt, function (manifestres) {
            }, function (manifestres) {
            });
        }, function (res) {
        });
    },
    funBackRefresh: function () {
        var _self = this;
        setTimeout(function () {
            _self.funInitUiData();
            _self.funInitPlanData("planList");
        }, 100);
    }
};