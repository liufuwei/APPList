﻿var AddMaterial = function () {
    this.PageParam = null;
    this.StartWkList = new Array();

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
        app.getGlobalVariable("startWkList", function (res) {
            if (res) {
                _this.StartWkList = JSON.parse(res);
            }
        });
    })(this);

    this.SelectMaterial = null;
    this.OrdersList = new Array();
    this.OrdersList.push({"key": "NA", "value": "--请选择--", "PWONum": ""});
};

AddMaterial.prototype = {
    funInitProcessData: function () {
        var _self = this;
        var param = _self.PageParam;
        if (param) {
            var pageName = param["GoPageName"];
            switch (pageName) {
                case "outCheck": {
                    var pWoNumList = new Array();
                    var wklist = _self.StartWkList;
                    var wklen = wklist.length;
                    for (var k = 0; k < wklen; k++) {
                        var pWoNum = wklist[k]["PWONum"];
                        pWoNumList.push("PWONum='" + pWoNum + "'");
                    }
                    if (pWoNumList.length > 0) {
                        var sqlWhere = " (" + pWoNumList.join(" or ") + ") ";
                        var selSql = " SELECT  PWONum, WONum,DeviceLocation FROM OPOrders where" + sqlWhere;
                        var db = app.database.open(Common.WEIXIUDB);
                        app.database.executeQuery(db, selSql, function (tx, results) {
                            var rows = Common.funConvertRowsJson(results);
                            var rowlen = rows.length;
                            if (rowlen > 0) {
                                for (var i = 0; i < rowlen; i++) {
                                    var row = rows[i];
                                    _self.OrdersList.push({
                                        "key": row["PWONum"],
                                        "value": row["WONum"] + "_" + row["DeviceLocation"],
                                        "PWONum": row["PWONum"]
                                    });
                                }
                                $("#btnWONumSelect").attr("PWONum", rows[0]["PWONum"]);
                                $("#btnWONumSelect").attr("WONum", rows[0]["PWONum"].split('_')[0]);
                                $("#btnWONumSelect").text(rows[0]["PWONum"])
                            }

                        });
                    }
                }
                    break;
                case "faultReport": {
                    $("#divOrderRow").css("display", "none");
                    var wONumSelectCtr = $("#btnWONumSelect");
                    wONumSelectCtr.attr("WONum", (PageParam["WONum"] || ""));
                    wONumSelectCtr.attr("PWONum", (PageParam["PWONum"] || ""));
                }
                    break;
            }
        }
        _self.funSelectMaterial("materiallist");

    },

    funInitEvent: function () {
        var _self = this;
        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSelectMaterial").click(function () {
            _self.SelectMaterial = null;
            _self.funSelectMaterial("materiallist");
        });


        $("#btnSaveMaterial").click(function () {
            _self.funSaveMaterial();
        });

        $("#btnWONumSelect").click(function () {
            _self.funSwitchWONum();
        });
    },
    funSelectMaterial: function (containerId) {
        var _self = this;
        var materialCtr = $("#txtMaterialName");
        var materialName = materialCtr.val();
        materialCtr.val("");

        var sqlText = "";
        var isOut = "0";
        app.getGlobalVariable("IsOutSourceUser", function (res) {
            isOut = res || "0";
        });

        //if (isOut == "0") {
        //    sqlText = "SELECT * from Material";
        //} else {
        //    sqlText = "select * from OutMaterial";
        //}
        sqlText = "SELECT * from Material";
        sqlText += "  where ItemNum like '%" + materialName + "%' or Description like '%" + materialName + "%'  limit 100";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sqlText, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowslen = rows.length;
            var liHtml = "";
            for (var i = 0; i < rowslen; i++) {
                var row = rows[i];
                var itemNum = row["ItemNum"] || "";
                var description = row["Description"] || "";
                var itemUnit = row["ItemUnit"] || "";
                var descText = itemNum + "  " + description;
                if (itemUnit) {
                    descText += "(" + itemUnit + ")";
                }
                liHtml += '<li id="li' + itemNum + '" itemNum=' + itemNum + ' description=' + description + ' itemUnit=' + itemUnit + ' >';
                liHtml += '<div class="row-fluid">';
                liHtml += '<div class="span10">' + descText + '</div>';
                liHtml += '</div>';
                liHtml += ' </li>';
            }

            var cnt = document.getElementById(containerId);
            if (cnt) {
                var childItems = cnt.children;
                var childlen = childItems.length;
                for (var j = 1; j < childlen; j++) {
                    cnt.removeChild(childItems[1]);
                }
                if (liHtml) {
                    cnt.innerHTML += liHtml;
                    _self.funBindEvent(rows);
                } else {
                    liHtml += '<li>';
                    liHtml += '<div class="row-fluid">';
                    liHtml += '<div class="span10" align="center">***暂无数据***</div>';
                    liHtml += '</div>';
                    liHtml += ' </li>';
                    cnt.innerHTML += liHtml;
                }
            }
        });

    },

    funBindEvent: function (rows) {
        var _self = this;
        var rowlen = rows.length;
        for (var i = 0; i < rowlen; i++) {
            var row = rows[i];
            var itemNumId = row["ItemNum"] || "";
            if (itemNumId) {
                $("#li" + itemNumId).click(function () {
                    var liItem = $(this);
                    var itemNum = liItem.attr("itemNum");
                    var description = liItem.attr("description");
                    var itemUnit = liItem.attr("itemUnit");
                    var descText = itemNum + "  " + description;
                    if (itemUnit) {
                        descText += "(" + itemUnit + ")";
                    }
                    var materialName = $("#txtMaterialName");
                    materialName.val(descText);

                    if (_self.SelectMaterial == null) {
                        _self.SelectMaterial = new Object();
                    }
                    _self.SelectMaterial.ItemNum = itemNum;
                    _self.SelectMaterial.Description = description || "";
                    _self.SelectMaterial.ItemUnit = itemUnit || "";
                });
            }
        }
    },

    funSwitchWONum: function () {
        var _self = this;
        var ordersList = _self.OrdersList;
        if (ordersList.length > 1) {
            var wONumSelectCtr = $("#btnWONumSelect");
            var defkey = wONumSelectCtr.attr("key") || "NA";
            app.wheelSelect.oneSelect(ordersList,
                function (res) {
                    var key = res["key"];
                    var value = res["value"];
                    if (key == "NA") {
                        wONumSelectCtr.attr("WONum", "");
                    } else {
                        wONumSelectCtr.attr("PWONum", key);
                        wONumSelectCtr.attr("WONum", value.split('_')[0]);
                    }
                    wONumSelectCtr.text(value);
                }, defkey, "工单编号");
        }
    },

    funSaveMaterial: function () {
        var _self = this;
        var materialItem = _self.SelectMaterial;
        var param = _self.PageParam;
        if (materialItem != null) {
            var wONumSelectCtr = $("#btnWONumSelect");
            var wONum;
            if (param["GoPageName"] == "faultReport") {
                app.getGlobalVariable("TempFaultWoNum", function (res) {
                    if (res) {
                        wONum = res;
                    }
                });
            } else {
                wONum = wONumSelectCtr.attr("WONum") || "NA";
            }
            if (wONum == "NA") {
                app.alert("请选择工单编号");

            } else {
                var materialCount = $("#txtCount").val();
                if (materialCount && !isNaN(materialCount)) {
                    var oPMaterialNum = materialItem.ItemNum;
                    var sqlText = "SELECT * from OPMaterial where WONum='" + wONum + "' and OPMaterialNum='" + oPMaterialNum + "'";
                    var db = app.database.open(Common.WEIXIUDB);
                    app.database.executeQuery(db, sqlText, function (tx, results) {
                        var rows = Common.funConvertRowsJson(results);
                        var rowslen = rows.length;
                        if (rowslen > 0) {
                            app.alert("该物料已存在该工单");
                        } else {
                            var pageName = param["GoPageName"];
                            switch (pageName) {
                                case "outCheck": {
                                    _self.funSaveOPMaterial();
                                }
                                    break;
                                case "faultReport": {
                                    _self.funSaveFaultMaterial();
                                }
                                    break;
                            }
                        }
                    });
                } else {
                    app.alert("数量不能为空");
                }
            }
        } else {
            app.alert("请选择需要添加的物料");
        }
    },

    funSaveFaultMaterial: function () {
        var _self = this;
        var tempFaultWoNum = _self.PageParam.TempFaultWoNum;
        var tempMaterialList = new Array();
        app.getGlobalVariable(tempFaultWoNum, function (res) {
            if (res) {
                tempMaterialList = JSON.parse(res);
            }
        });
        var materialDataItem = _self.funGetMaterialData();
        var tempMaterialLen = tempMaterialList.length;
        var isExist = false;
        for (var i = 0; i < tempMaterialLen; i++) {
            if (tempMaterialList[i].OPMaterialNum == materialDataItem.OPMaterialNum) {
                isExist = true;
                break;
            }
        }
        if (isExist) {
            app.alert("该物料已存于在该故障工单中");
        } else {
            tempMaterialList.push(materialDataItem);
            app.setGlobalVariable(tempFaultWoNum, JSON.stringify(tempMaterialList));
            var faultObj = _self.PageParam;
            faultObj.addMaterial = "addMaterial";
            Common.funGoBack(faultObj, "addMaterial.html");
        }
    },

    funSaveOPMaterial: function () {
        var _self = this;
        var materialDataItem = _self.funGetMaterialData();
        var intSqlText = 'INSERT into OPMaterial (PWONum,WONum,OPMaterialNum,OPMaterialName,OPMaterialUnit,FinishChkTime,FinishChkCount,IsOut) ' +
            'VALUES ' +
            '("' + materialDataItem.PWONum + '","' + materialDataItem.WONum + '","' + materialDataItem.OPMaterialNum + '","'
            + materialDataItem.OPMaterialName.replace(/"/g, "&quot;") + '","' + materialDataItem.OPMaterialUnit + '","'
            + materialDataItem.FinishChkTime + '","' + materialDataItem.FinishChkCount + '","0")';
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(db, [intSqlText], function () {
            Common.funGoBack();
        });
    },

    funGetMaterialData: function () {
        var _self = this;
        var materialItem = _self.SelectMaterial;
        var wONumSelectCtr = $("#btnWONumSelect");
        var materialDataItem = new Object();
        materialDataItem.PWONum = wONumSelectCtr.attr("PWONum") || "";
        materialDataItem.WONum = wONumSelectCtr.attr("WONum");
        materialDataItem.OPMaterialNum = materialItem.ItemNum;
        materialDataItem.OPMaterialName = materialItem.Description;
        materialDataItem.OPMaterialUnit = materialItem.ItemUnit;
        materialDataItem.OPMaterialCount = "0";
        materialDataItem.FinishChkTime = Common.funGetNowDate();
        materialDataItem.FinishChkCount = $("#txtCount").val();
        app.getGlobalVariable("IsOutSourceUser", function (res) {
            var isOut = res || "0";
            materialDataItem.IsOut = isOut;
        });
        return materialDataItem;
    }
};

funBackRefresh = function (retParamStr) {
    var _self = this;
    try {
        if (retParamStr) {
            var retParam = JSON.parse(retParamStr);
            var pageName = retParam["pageName"];
            var backParam = retParam["backParam"];
            if (backParam) {
                _self.PageParam = backParam;
            }
        }
    } catch (ex) {
        app.alert("addMaterial.funBackRefresh方法运行出错,请与管理员联系!\n" + ex.message);
    }
    setTimeout(function () {
        _self.funInitProcessData();
    }, 100);
};
