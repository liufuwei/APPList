﻿var ConsumeMaterial = function () {

    this.StartWkList = null;

    (function (_this) {
        app.getGlobalVariable("startWkList", function (res) {
            if (res) {
                _this.StartWkList = JSON.parse(res);
            } else {
                _this.StartWkList = new Array();
            }
        });
    })(this);

    this.OPMaterialList = new Array();

    this.MaterialCount = 0;
};

ConsumeMaterial.prototype = {
    funInitEvent: function () {
        var _self = this;

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSave").click(function () {
            _self.funSave();
        });

        $("#btnSkip").click(function () {
            Common.funLoad("choice.html");
        });


        $("#btnBatchUpdate").click(function () {
            _self.funBatchUpdate();
        });

        $("#btnAddMaterial").click(function () {
            var db = app.database.open(Common.WEIXIUDB);
            var sql2 = "SELECT count(*) FROM Material";
            app.database.executeQuery(db, sql2, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                if(rows && rows[0]["count(*)"]>0){
                    _self.funAddMaterial();
                } else {
                    app.alert("请在主界面更新基础数据--物料");
                }
            });
        });

    },

    funInitMaterialData: function (containerId) {
        var _self = this;
        var sqlWhere = "";
        var wk = _self.StartWkList;
        var wklen = wk.length;
        for (var k = 0; k < wklen; k++) {
            if ((k + 1) == wklen) {
                sqlWhere += " b.PWONum='" + _self.StartWkList[k].PWONum + "' ";
            } else {
                sqlWhere += " b.PWONum='" + _self.StartWkList[k].PWONum + "' or";
            }
        }
        if (wklen > 0) {
            var sql = "SELECT a.*,c.DeviceLocation FROM  OPMaterial a  inner JOIN OPPlan b on a.PWONum=b.PWONum INNER JOIN OPOrders c on c.WONum=a.WONum  where " + sqlWhere + "ORDER BY OPMaterialNum,WONum";
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeQuery(db, sql, function (tx, results) {
                var liHtml = "";
                var rows = Common.funConvertRowsJson(results);
                var rowlen = rows.length;
                var materIndex = 0;
                if (rowlen > 0) {
                    _self.MaterialCount = rowlen;
                    var crtMaterialName = "NA";
                    for (var i = 0; i < rowlen; i++) {
                        var row = rows[i];
                        var materCount = (row["FinishChkCount"] || "0") - 0;
                        if (materCount == 0) {
                            materCount = row["OPMaterialCount"] || "0";
                        }
                        var materialName = row["OPMaterialName"];
                        var deviceLocation = row["DeviceLocation"];
                        var wONum = row["WONum"];
                        var oPMaterialNum = row["OPMaterialNum"];
                        var materialUnit = row["OPMaterialUnit"] || "";
                        var material = new Object();
                        material.WONum = wONum;
                        material.OPMaterialNum = oPMaterialNum;
                        _self.OPMaterialList.push(material);
                        var txtId = "txtMater" + wONum + oPMaterialNum;
                        var chkId = "chkMater" + wONum + oPMaterialNum;
                        if (materialName != crtMaterialName || i == 0) {
                            crtMaterialName = materialName;
                            materIndex++;
                            if (i != 0) {
                                liHtml += '</ul>';
                            }
                            liHtml += '<ul class="list-view list-view-head list-liStyle" data-corner="all" style="padding-bottom:0;" >';
                            liHtml += '<li>';
                            liHtml += '<div data-role="BTButton" mousedown="false" data-status="1">';
                            if (materialUnit) {
                                liHtml += '<span class="btn-text">' + materIndex + '、' + materialName + '[' + materialUnit + ']</span>';
                            } else {
                                liHtml += '<span class="btn-text">' + materIndex + '、' + materialName + '</span>';
                            }
                            liHtml += '</div>';
                            liHtml += '</li>';
                        }
                        liHtml += '<li>';
                        liHtml += '<div class="row-fluid">';
                        liHtml += '<div class="span5">';
                        liHtml += '<div data-role="BTCheck" id="' + chkId + '"  >' + deviceLocation + "【" + wONum + '】</div>';
                        liHtml += '</div>';
                        liHtml += '<div class="span2" align="center"><input id="' + txtId + '" type="number" value="' + materCount + '" class="toolNum"/></div>';
                        liHtml += '<div  align="center">';
                        liHtml += '  <a CntId="' + txtId + '" id="btnAddMater' + wONum + oPMaterialNum + '" href="javascript:void(0)" class="addN"></a>';
                        liHtml += '  <a CntId="' + txtId + '" id="btnMinusMater' + wONum + oPMaterialNum + '" href="javascript:void(0)" class="minusN"></a>';
                        liHtml += '  <a CntId="' + oPMaterialNum + '"  wONum="' + wONum + '" id="Del' + wONum + oPMaterialNum + '" href="javascript:void(0)" class="delN"></a>';
                        liHtml += '</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                        if ((i + 1) == rowlen) {
                            liHtml += '</ul>';
                        }
                    }
                }
                if (liHtml) {
                    var cnt = document.getElementById(containerId);
                    if (cnt) {
                        cnt.innerHTML = liHtml;
                        ui.init();
                        _self.funBindMaterEvent();
                    }
                } else {
                    _self.funMaterialNoDataMsg(containerId);
                }
            });
        }
    },

    funBindMaterEvent: function () {
        var _self = this;
        var materialList = _self.OPMaterialList;
        var materiallen = materialList.length;
        for (var i = 0; i < materiallen; i++) {
            var item = materialList[i];

            var wONum = item["WONum"];
            var oPMaterialNum = item["OPMaterialNum"];
            var ctrId = wONum + oPMaterialNum;

            $("#btnAddMater" + ctrId).click(function () {
                var ctr = $(this);
                var cntId = ctr.attr("CntId");
                _self.funUpCount(cntId);
            });

            $("#btnMinusMater" + ctrId).click(function () {
                var ctr = $(this);
                var cntId = ctr.attr("CntId");
                _self.funDownCount(cntId);
            });
            $("#Del" + ctrId).click(function () {
                var ctr = $(this);
                var wONum = ctr.attr("wONum");
                var CntId = ctr.attr("CntId");
                app.confirm("确认删除该物料?", function (index) {
                    if (index == 2) {
                        _self.funDelOPMaterial(CntId, wONum);
                    }
                }, "删除物料确认", "取消,确定");
               
            });
        }
    },
    funDelOPMaterial: function (CntId, wONum) {
        var _self = this;
        var sql = "delete from OPMaterial WHERE WONum='" + wONum + "' and  OPMaterialNum='" + CntId + "' ";
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeNonQuery(db, sql, function () {
            _self.funBackRefresh();
        });
    },
    funUpCount: function (cntId) {
        if (cntId) {
            var cnt = $("#" + cntId);
            var count = parseInt(cnt.val()) || 0;
            count += 1;
            if (count < 0) {
                count = 0;
            }
            cnt.val(count);
            cnt.attr("value", count);
        }
    },

    funDownCount: function (cntId) {
        if (cntId) {
            var cnt = $("#" + cntId);
            var count = parseInt(cnt.val()) || 0;
            count -= 1;
            if (count < 0) {
                count = 0;
            }
            cnt.val(count);
            cnt.attr("value", count);
        }
    },

    funGetSaveMaterialSql: function () {
        var _self = this;
        var sqlList = new Array();
        var opMaterialLength = _self.OPMaterialList.length;
        if (opMaterialLength > 0) {
            var finishChkTime = Common.funGetNowDate();
            for (var i = 0; i < opMaterialLength; i++) {
                var item = _self.OPMaterialList[i];
                var wONum = item["WONum"];
                var oPMaterialNum = item["OPMaterialNum"];
                var finishChkCount = Number($("#txtMater" + wONum + oPMaterialNum).val()) || "0";
                var sql = " UPDATE OPMaterial set FinishChkTime='" + finishChkTime + "' ,FinishChkCount='" + finishChkCount + "' where  WONum='" + wONum + "' and OPMaterialNum='" + oPMaterialNum + "'";
                sqlList.push(sql);
            }
        }
        return sqlList;
    },

    funSave: function () {
        var _self = this;
        var sqlList = new Array();
        var materialSqlList = _self.funGetSaveMaterialSql();

        if (materialSqlList.length > 0) {

            sqlList = sqlList.concat(materialSqlList);
        }
        if (sqlList.length > 0) {
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeNonQuery(db, sqlList, function () {
                Common.funLoad("choice.html");
            });
        } else {
            Common.funLoad("choice.html");
        }
    },

    funAddMaterial: function () {
        var _self = this;
        var sqlList = new Array();

        var materialSqlList = _self.funGetSaveMaterialSql();
        if (materialSqlList.length > 0) {
            sqlList = sqlList.concat(materialSqlList);
        }

        var pageParam = new Object();
        pageParam.GoPageName = "outCheck";

        if (sqlList.length > 0) {
            var db = app.database.open(Common.WEIXIUDB);
            app.database.executeNonQuery(db, sqlList, function () {
                Common.funLoad("addMaterial.html", pageParam);
            });
        } else {
            Common.funLoad("addMaterial.html", pageParam);
        }
    },

    funBatchUpdate: function () {
        var _self = this;
        var opMaterialLength = _self.OPMaterialList.length;
        if (opMaterialLength > 0) {
            var chkTxtIdList = new Array();
            for (var i = 0; i < opMaterialLength; i++) {
                var item = _self.OPMaterialList[i];
                var wONum = item["WONum"];
                var oPMaterialNum = item["OPMaterialNum"];
                var chkCnt = $("#chkMater" + wONum + oPMaterialNum);
                var isCheck = chkCnt.hasClass('BTCheck_ON');
                if (isCheck) {
                    var txtId = $("#txtMater" + wONum + oPMaterialNum);
                    chkTxtIdList.push(txtId);
                }
            }

            var chkTxtlen = chkTxtIdList.length;
            if (chkTxtlen > 0) {
                var materCount = window.prompt("物料数量输入");
                if (materCount != null) {
                    if (isNaN(materCount)) {
                        app.alert("数值格式填写有误");
                    } else {
                        for (var j = 0; j < chkTxtlen; j++) {
                            var txtCnt = $(chkTxtIdList[j]);
                            txtCnt.val(materCount);
                            txtCnt.attr("value", materCount);
                        }
                    }
                }
            } else {
                app.alert("请勾选要批量修改的物料");
            }
        }
    },

    funMaterialNoDataMsg: function (containerId) {
        var _self = this;
        var total = _self.OPMaterialList.length;
        if (total > 0) {
            var cntDataMsg = $("#liMaterDataMsg");
            if (cntDataMsg) {
                $("#liMaterDataMsg").remove();
            }
        } else {
            var cnt = document.getElementById(containerId);
            if (cnt) {
                var liHtml = "";
                liHtml += '<ul id="liMaterDataMsg" class="list-view list-view-head list-liStyle" data-corner="all" style="padding-bottom:0;" >';
                liHtml += '<li>';
                liHtml += '<div class="row-fluid">';
                liHtml += '<div align="center">***暂无数据***</div>';
                liHtml += '</div>';
                liHtml += '</li>';
                liHtml += '</ul>';
                cnt.innerHTML += liHtml;
            }
        }
    },
    funBackRefresh: function () {
        app.refresh();
        this.funInitMaterialData("materiellist");
    }
};

