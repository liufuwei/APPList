﻿var SelDevice = function () {
    this.PageParam = null;
    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.PageParam = result;
            }
        });
    })(this);
};

SelDevice.prototype = {
    funInitEvent: function () {
        var _self = this;
        document.addEventListener("backbutton", function () {

            var faultObj = _self.PageParam;
            faultObj.manualSelect = "0"; //手选页面传回一个“1”回去上一个填报故障信息页面
            Common.funGoBack(faultObj, "selectNewEquipment.html");
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnSelectDevice").click(function () {
            _self.funSelectDevice("txtDeviceName", "devicelist");
        });
    },

    funSelectDevice: function (inputCntId, containerId) {

        var _self = this;
        var inputCtr = $("#" + inputCntId);
        var deviceName = inputCtr.val().trim();
        if (deviceName) {
            var sql = 'select * from Device where DeviceName like "%' + deviceName + '%" or DeviceNum like "%' + deviceName + '%"';
            var db = app.database.open(Common.WEIXIUBASEDB);
            app.database.executeQuery(db, sql, function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                var rowlen = rows.length;
                var liHtml = "";
                if (rowlen > 0) {
                    inputCtr.val("");
                    var row1 = rows[0];
                    for (var i = 0; i < rowlen; i++) {
                        var row = rows[i];
                        var NewEquipment = row.DeviceNum;
                        var NewEquipmentName = row.DeviceName;
                        var NewEquipmentLocation = row.LocationNum;
                        var NewEquipmentLocationName = row.LocationName;
                        var locationName = row.LocationName;
                        liHtml += '<li  id="li' + NewEquipment + '"  NewEquipment="' + NewEquipment + '"  NewEquipmentName="' + NewEquipmentName + '"  NewEquipmentLocation="' + NewEquipmentLocation + '"  NewEquipmentLocationName="' + NewEquipmentLocationName + '">';
                        liHtml += '<div class="row-fluid">';
                        liHtml += '<div class="span6">' + NewEquipment + '<br/>' + NewEquipmentName + '</div>';
                        liHtml += '<div class="span5">' + locationName + '</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                    }
                }
                var cnt = document.getElementById(containerId);
                if (cnt) {
                    var childItems = cnt.children;
                    var childlen = childItems.length;
                    for (var j = 1; j < childlen; j++) {
                        cnt.removeChild(childItems[1]);
                    }
                    if (liHtml) {
                        cnt.innerHTML += liHtml;

                        _self.funBindEvent(rows);
                    } else {
                        liHtml += '<li>';
                        liHtml += '<div class="row-fluid">';
                        liHtml += '<div class="span10" align="center">***暂无数据***</div>';
                        liHtml += '</div>';
                        liHtml += '</li>';
                        cnt.innerHTML += liHtml;
                    }
                }
            });
        } else {
            app.alert("请输入设备名称");
        }
    },

    funBindEvent: function (rows) {
        var _self = this;
        for (var i = 0; i < rows.length; i++)
        {
            var deviceNum = rows[i]["DeviceNum"];
           
            $("#li" + deviceNum).click(function () {
                var ctr = $(this);
                var NewEquipment = ctr.attr("NewEquipment");
                var NewEquipmentName = ctr.attr("NewEquipmentName");
                var NewEquipmentLocation = ctr.attr("NewEquipmentLocation");
                var NewEquipmentLocationName = ctr.attr("NewEquipmentLocationName");
                var faultObj = _self.PageParam;
                faultObj.pageData.NewEquipment = NewEquipment;
                faultObj.pageData.NewEquipmentName = NewEquipment + "_" + NewEquipmentName;
                faultObj.pageData.NewEquipmentLocation = NewEquipmentLocation;
                faultObj.pageData.NewEquipmentLocationName = NewEquipmentLocationName;
                // faultObj.pageData.RecordWay = "p"; //p-选择 s-扫描
                // faultObj.pageData.RecordTime = Common.funGetNowDate();
                faultObj.manualSelect = "1"; //手选页面传回一个“1”回去上一个填报故障信息页面
                Common.funGoBack(faultObj, "selectNewEquipment.html");
            });
        }
    }
};
