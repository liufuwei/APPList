﻿var Navigation = function (divContainerID) {
    ///<summary></summary>
    ///<param name="startWkList">父工单列表</param>
    ///<param name="divContainerID">绘区域点容器</param>
    this.StartWkList = new Array();

    (function (_this) {

        app.getGlobalVariable("startWkList", function (res) {
            if (res) {
                _this.StartWkList = JSON.parse(res);
            }
        });

    })(this);

    this.ContainerId = divContainerID;

    this.CurrentTagCode = "";

    this.TagType = "";

};

Navigation.prototype = {
    funInitEvent: function () {
        var _self = this;
        var funCode = function (res) {
            if (res) {
                switch (res["TagType"]) {
                    case "L"://设备的位置标签               
                        _self.TagType = res["TagType"];
                        _self.funGoOpPlan("L"+res["TagCode"], res["TagType"]);
                        break;
                    default:
                        _self.TagType = "L";
                        _self.funGoOpPlan(res["TagCode"], "L");
                        break;
                }
            } else {
                navigator.notification.vibrate(2000);
                app.alert("未知标签！类型：" + res["TagType"] + ",识别编码：" + res["TagCode"]);
            }
        };

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnBarCode").click(function () {
            Common.getBarcode(function (res) {
                funCode(res);
            }, function () {
                navigator.notification.vibrate(2000);
                app.alert("app扫描二维码，无法获取数据！");
            });
        });

        app.setting.get("bluetooth_key", "", function (rest) {
            if (rest) {
                setInterval(function () {
                    app.getGlobalVariable("bluetoothIsConnected", function (isCon) {
                        if (isCon == "F") {   //F ==失
                            app.bluetooth.connect(rest);
                        } else if (isCon == "S") { //成功
                            var res = window.bluetoothValue;
                            if (res) {
                                window.bluetoothValue = "";
                                var convertCode = Common.funConvertCode(res);
                                funCode(convertCode);
                            }
                        } else if (isCon == "H") { //正在连接请等待

                        }
                    });
                }, 1000);
            }
        });
    },

    funSqlTags: function (sql, successfun, params) {
        var _self = this;
        ///<summary>运行查询脚本</summary>
        ///<param name="sql">sql语句</param>
        ///<param name="successfun">回调函数</param>
        ///<param name="params">传递给回调函数的参数</param>
        ///<param name="_self"></param>
        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sql, function (tx, results) {
            var len = results.rows.length;
            var rows = results.rows;
            var dataTable = new Array();
            for (var i = 0; i < len; i++) {
                var row = new Object();
                for (var clmField in rows.item(i)) {
                    row[clmField] = rows.item(i)[clmField];
                }
                dataTable.push(row);
            }
            successfun(dataTable, params);
        });
    },

    funInitTags: function () {
        var _self = this;
        ///<summary>初始化导航标签</summary>
        ///<param name="containerId">容器id</param>
        if (!_self.StartWkList || _self.StartWkList.length <= 0) {
            return;
        }
        var pwoNums = new Array();
        for (var i = 0; i < _self.StartWkList.length; i++) {
            pwoNums.push(_self.StartWkList[i].PWONum);
        }
        var sqlOPPlan = "SELECT * FROM OPPlan WHERE PWONum IN ('" + pwoNums.join("','") + "')";
        _self.funSqlTags(sqlOPPlan, function (rows) {
            //根据父工单的线路名称显示线路图
            var imgList = "";
            if (rows && rows.length > 0) {
                for (var i = 0; i < rows.length; i++) {
                    if (imgList.indexOf(rows[i].LineNum, 0) < 0) {
                        imgList = imgList + rows[i].LineNum;
                        var img = document.createElement("img");
                        img.src = "img/" + rows[i].LineNum + ".png";
                        img.style.maxWidth = "none";
                        img.style.maxHeight = "none";
                        var navBox = document.getElementById(_self.ContainerId);
                        if (navBox) {
                            navBox.appendChild(img);
                        }
                    }
                }
            }
            //查询要描绘的点 已扫描的IsScan为1，未扫描的为0 或者null
            var sql = "SELECT * FROM OPAreasTags WHERE PWONum in ('" + pwoNums.join("','") + "') ";
            _self.funSqlTags(sql, _self.funSetTag, false);
        }, null);
    },

    funScanTags: function (tagCode) {
        var _self = this;
        ///<summary>扫描区域标签</summary>
        ///<param name="tagCode">标签编码</param>
        var pwoNums = new Array();
        var tagCodeArr = new Array();
        tagCodeArr = tagCode.split(";");
        for (var i = 0; i < _self.StartWkList.length; i++) {
            pwoNums.push(_self.StartWkList[i].PWONum);
        }
        _self.CurrentTagCode = tagCode;
        //已扫描的IsScan为1，未扫描的为0 或者null
        var sql = "UPDATE OPAreasTags SET IsScan='1' WHERE PWONum in ('" + pwoNums.join("','") + "') AND TagCode in ('" + tagCodeArr.join("','") + "') ";
        EqlistHelper.funSqlSave(sql, function () {
            var sqlSelect = "SELECT TagCode,AreaID,AreaName,CoordX,CoordY,IsScan FROM OPPlan P INNER JOIN OPAreasTags A ON P.PWONum=A.PWONum WHERE P.PWONum in ('" + pwoNums.join("','") + "') AND A.TagCode in ('" + tagCodeArr.join("','") + "') GROUP BY TagCode,AreaID,AreaName,CoordX,CoordY,IsScan ";
            _self.funSqlTags(sqlSelect, _self.funSetTag, true);
        });

    },

    funGoOpPlan: function (tagCode, type) {
        var _self = this;
        ///<summary>扫描设备/位置工单二维码标签</summary>
        ///<param name="tagCode">标签编码</param>
        ///<param name="type">标签类型</param>
        var pwoNums = new Array();
        for (var i = 0; i < _self.StartWkList.length; i++) {
            pwoNums.push(_self.StartWkList[i].PWONum);
        }
        var tagCodeArr = new Array();
        tagCodeArr = tagCode.split(";");
        var tagWhereCondition = new Array();
        for (var tagi = 0; tagi < tagCodeArr.length; tagi++) {
            tagWhereCondition.push(" LocationCode like '%" + tagCodeArr[tagi] + "%' ");
        }
        _self.CurrentTagCode = tagCode;
        var sqlOPOrders = "SELECT * FROM  OPOrders  WHERE PWONum IN('" + pwoNums.join("','") + "')  AND ( " + tagWhereCondition.join(" OR ") + " )";
        EqlistHelper.funSqlSelect(sqlOPOrders, function (OPOrdersList) {//查询标签对应本次作业内的设备
            if (!OPOrdersList || OPOrdersList.length <= 0) {
                app.alert("本次作业任务无此设备！");
                return;
            }
            var len = OPOrdersList.length;
            var Orders0 = OPOrdersList[0];
            var sql = "INSERT INTO TagRecords(PWONum,TagCode,ScanTime,TagType,EnterOrExit) ";
            var value = "";
            var nowDate = Common.funGetNowDate();
            //for (var tagRecordsi = 0; tagRecordsi < tagCodeArr.length; tagRecordsi++) {
            //    value += " select '" + Orders0.PWONum + "','" + tagCodeArr[tagRecordsi] + "','" + nowDate + "','" + type + "','1'  union all ";
            //}
            // Eidt By Number，对于扫描出的子工单，都记录扫描日志
            for (var i = 0; i < tagCodeArr.length; i++) {
                for (var j = 0; j < OPOrdersList.length; j++) {
                    value += " select '" + OPOrdersList[j].PWONum + "','" + tagCodeArr[i] + "','" + nowDate + "','" + type + "','1'  union all ";
                }
            }

            // 记录子工单的扫描时间
            for (var i = 0; i < OPOrdersList.length; i++) {
                var sqlText = "";
                sqlText = "UPDATE OPOrders SET ActStart=ifnull(nullif(ActStart,''),'" + nowDate + "'), RecWay='s' , RecTime='" + nowDate + "' WHERE  WONum='" + OPOrdersList[i].WONum + "' ";
                EqlistHelper.funSqlSave(sqlText);
            }

            if (value.length > 0) {
                sql = sql + value.substring(0, value.length - 10);
            }

            EqlistHelper.funSqlSave(sql, function () {//保存扫描记录
                if (len == 1) {
                    EqlistHelper.funSingleOrder(Orders0, true);
                }
                else if (len > 1) {
                    var url = "scansEqlist.html";
                    var pageParam = new Object();
                    pageParam.CurrentTagCode = tagCode;
                    //Common.funSetPageParam(url, pageParam);
                    //app.load({ url: url });
                    Common.funLoad(url, pageParam);
                }
            });
        });
    },

    funSetTag: function (OPAreasTags, isShowMessage) {
        var _self = this;
        ///<summary>描绘区域标签</summary>
        ///<param name="OPAreasTags">计划区域标签</param>
        ///<param name="isShowMessage">是否显示提示信息</param>
        ///<param name="isNoticeArea">是否提示区域信息</param>
        if (isShowMessage && (!OPAreasTags || OPAreasTags.length <= 0)) {
            navigator.notification.vibrate(2000);
            navigator.notification.beep(3);
            app.alert("你已超出区域！", null, "温馨提示", "OK");
            return;
        }
        var scrollToTag = new Object();
        //描点 已扫描的IsScan为1，未扫描的为0 或者null
        for (var i = 0; i < OPAreasTags.length; i++) {
            if (OPAreasTags[i].IsScan == "1") {
                _self.funSetScannedDot(OPAreasTags[i].CoordX, OPAreasTags[i].CoordY, _self.ContainerId);

            }
            else {
                _self.funSetTagDot(OPAreasTags[i].CoordX, OPAreasTags[i].CoordY, _self.ContainerId);
            }
            scrollToTag = OPAreasTags[i];
        }
        if (scrollToTag) {// && scrollToTag.IsScan == 1
            var scrollHeight = scrollToTag.CoordY - 0 - (window.screen.height - 0) / 3;
            window.scrollTo(0, (scrollHeight > 0 ? scrollHeight : scrollToTag.CoordY));

        }
        //提示信息
        if (isShowMessage) {//如果不是初始化时 会进行提示信息 (扫描时进入此方法)
            var pwoNums = new Array();
            for (var i = 0; i < _self.StartWkList.length; i++) {
                pwoNums.push(_self.StartWkList[i].PWONum);
            }
            var sql = "SELECT PO.* FROM OPAreasTags A INNER JOIN OPOrders PO ON A.PWONum=PO.PWONum AND A.AreaID=PO.DeviceOfAreaNum WHERE A.PWONum IN('" + pwoNums.join("','") + "')  AND A.TagCode='" + OPAreasTags[0].TagCode + "' AND (PO.SelfFormIsFinished='0' or PO.SelfFormIsFinished is NULL)  ORDER BY PO.DeviceOfAreaNum";
            _self.funSqlTags(sql, _self.funShowGoingArea, OPAreasTags);
        }
    },

    funSetTagDot: function (x, y, navBoxId) {
        ///<summary>描绘当前任务计划未扫描的区域标签</summary>
        ///<param name="x">x坐标</param>
        ///<param name="y">y坐标</param>
        ///<param name="navBoxId">标签容器div的ID</param>
        var img = document.createElement("img");
        img.src = "img/dot.png";
        img.style.position = 'absolute';
        img.style.top = (y - 0 + 258) + "px";
        img.style.left = (x - 0 + 7) + "px";
        var navBox = document.getElementById(navBoxId);
        if (navBox) {
            navBox.appendChild(img);
        }
    },

    funSetScannedDot: function (x, y, navBoxId) {
        ///<summary>描绘当前任务已扫描的区域标签</summary>
        ///<param name="x">x坐标</param>
        ///<param name="y">y坐标</param>
        ///<param name="navBoxId">标签容器div的ID</param>
        var img = document.createElement("img");
        img.src = "img/dot_g.png";
        img.style.position = 'absolute';
        img.style.top = (y - 0 + 258) + "px";
        img.style.left = (x - 0 + 7) + "px";
        var navBox = document.getElementById(navBoxId);
        if (navBox) {
            navBox.appendChild(img);
        }
        //test
        //var MyiScroll = new iScroll(document.getElementById(navBoxId).parentElement.parentElement, null);
        //MyiScroll.scrollTo(0, y, 10, true);
    },

    funShowGoingArea: function (OPOrders, OPAreasTags) {
        var _self = this;
        ///<summary>提示进入区域</summary>
        ///<param name="OPOrders">工单集合</param>
        ///<param name="OPAreasTags">区域数组</param>
        if (!OPAreasTags || OPAreasTags.length <= 0) {
            return;
        }
        var messageList = new Array();
        for (var j = 0; j < OPAreasTags.length; j++) {
            var deviceOfAreaString = "【" + OPAreasTags[j].AreaName + "】区域计划检修设备如下：\r\n";
            var oporder = new Array();
            for (var i = 0; i < OPOrders.length; i++) {
                oporder.push(">>" + OPOrders[i].WONum + OPOrders[i].DeviceLocation);
            }
            messageList.push(deviceOfAreaString + oporder.join("\r\n"));
        }
        var message = messageList.join("\r\n");
        app.confirm("你当前所在作业区域：\n" + message, function (index) {
            var date = Common.funGetNowDate();
            var sql = "INSERT INTO TagRecords(PWONum,TagCode,ScanTime,TagType,EnterOrExit) ";
            var values = "";
            var planlen = _self.StartWkList.length;
            //可能存在多个父工单对应一个区域
            if (OPAreasTags && OPAreasTags.length > 0) {
                for (var i = 0; i < OPAreasTags.length; i++) {
                    var obj = OPAreasTags[i];
                    for (var j = 0; j < planlen; j++) {
                        var planItem = _self.StartWkList[j];
                        values += " select '" + planItem.PWONum + "','" + obj.TagCode + "','" + date + "','" + (_self["TagType"] || "P") + "','" + (index == 1 ? 1 : 0) + "' union all ";
                    }
                }
            }
            if (values.length > 0) {
                sql = sql + values.substring(0, values.length - 10);
                EqlistHelper.funSqlSave(sql, null);
            }
        }, "提示", "进入,退出");
    },
    funBackRefresh: function () {
        this.funInitTags();
    }
};