﻿var ScansEqlist = function () {
    this.StartWkList = new Array();
    this.CurrentTagCode = null;

    (function (_this) {
        app.getPageParams(function (result) {
            if (result) {
                _this.CurrentTagCode = result["CurrentTagCode"];
            }
        });
        app.getGlobalVariable("startWkList", function (res) {
            if (res) {
                _this.StartWkList = JSON.parse(res);
            }
        });
    })(this);

    this.OPOrdersDic = new Dictionary();


};

ScansEqlist.prototype = {
    funInitEvent: function () {
        document.addEventListener("backbutton", function () {
            Common.funGoBack();
        }, false);

        $("#imback").click(function () {
            Common.funGoBack();
        });
        $("#btnUnchecked").click(function () {
            var isHas = $("#btnUnchecked").hasClass("btn-active");
            if (isHas == false) {

                $("#divChecked").css("display", "none");
                $("#divUnChecked").css("display", "");
            }
        });

        $("#btnChecked").click(function () {
            var isHas = $("#btnChecked").hasClass("btn-active");
            if (isHas == false) {

                $("#divUnChecked").css("display", "none");
                $("#divChecked").css("display", "");

            }
        });
    },

    funInitOrdersData: function (uncheckedContainerId, checkedContainerId) {
        var _self = this;
        var unChkDataList = new Array();
        var chkedDataList = new Array();
        var sqlParam = new Object();
        app.getGlobalVariable("CurrentPWONum", function (res) {
            if (res) {
                sqlParam.PWONum = res;
            }
        });

        var pwoNums = new Array();
        for (var g = 0; g < _self.StartWkList.length; g++) {
            pwoNums.push(_self.StartWkList[g].PWONum);
        }
        var tagCodeArr = new Array();
        tagCodeArr = _self.CurrentTagCode.split(";");
        var tagWhereCondition = new Array();
        for (var tagi = 0; tagi < tagCodeArr.length; tagi++) {
            tagWhereCondition.push(" TagCode like '%" + tagCodeArr[tagi] + "%' ");
            tagWhereCondition.push(" AssetTagCode like '%" + tagCodeArr[tagi] + "%' ");
            tagWhereCondition.push(" LocationCode like '%" + tagCodeArr[tagi] + "%' ");
        }
        var sql = "SELECT * FROM  OPOrders  WHERE PWONum IN('" + pwoNums.join("','") + "')  AND (" + tagWhereCondition.join(" OR ") + " )  ORDER BY JobPlanNum asc ";

        var db = app.database.open(Common.WEIXIUDB);
        app.database.executeQuery(db, sql, function (tx, results) {
            var rows = Common.funConvertRowsJson(results);
            var rowslen = rows.length;
            if (rowslen > 0) {
                var funCacheData = function (row) {
                    var cacheItem = new Object();
                    cacheItem.WONum = row["WONum"];
                    cacheItem.DeviceNum = row["DeviceNum"];
                    cacheItem.DeviceName = row["DeviceName"];
                    cacheItem.JobPlanNum = row["JobPlanNum"];
                    cacheItem.DeviceTypeName = row["DeviceTypeName"];
                    cacheItem.DeviceLocation = row["DeviceLocation"];
                    cacheItem.WOType = row["WOType"];
                    cacheItem.RecWay = row["RecWay"];
                    cacheItem.OrderDesc = row["OrderDesc"] || "";
                    cacheItem.IsAllowedBatchSubmit = row["IsAllowedBatchSubmit"];
                    cacheItem.MutFormIsFinished = row["MutFormIsFinished"];
                    cacheItem.MutFormFinishTime = row["MutFormFinishTime"];
                    // cacheItem.IsRemove = row["IsRemove"]; //没有用到isRemove；
                    cacheItem.CancelFlag = row["CancelFlag"];
                    _self.OPOrdersDic.Add(cacheItem.WONum, cacheItem);
                };


                var funGetCancelText = function (cacheItem) {
                    var titleText = "";
                    if (cacheItem["CancelFlag"] == 1) {
                        titleText = "<font color='red' >[已取消]</font>"
                    }
                    return titleText;
                };

                var uncheckedliHtml = "";
                var checkedliHtml = "";
                var crtUnChkType = "NA"; //当前未选中的类型
                var crtChkedType = "NA"; //当前选中的类型

                ////构造数组结构
                for (var i = 0; i < rowslen; i++) {
                    funCacheData(rows[i]);
                    var selfFormIsFinished = rows[i]["SelfFormIsFinished"] || "0";
                    var jobPlanNum = rows[i]["JobPlanNum"];
                    if (selfFormIsFinished == "0") {
                        if (crtUnChkType != jobPlanNum) {
                            var unChkDataItem = new Object();
                            unChkDataItem.Items = new Array();
                            unChkDataItem.WONums = new Array();
                            unChkDataList.push(unChkDataItem);
                            crtUnChkType = jobPlanNum;
                        }
                        unChkDataList[unChkDataList.length - 1].Items.push(rows[i]);
                        unChkDataList[unChkDataList.length - 1].WONums.push(rows[i]["WONum"]);
                    } else {
                        if (crtChkedType != jobPlanNum) {
                            var chkDataItem = new Object();
                            chkDataItem.Items = new Array();
                            chkDataItem.WONums = new Array();
                            chkedDataList.push(chkDataItem);
                            crtChkedType = jobPlanNum;
                        }
                        chkedDataList[chkedDataList.length - 1].Items.push(rows[i]);
                        chkedDataList[chkedDataList.length - 1].WONums.push(rows[i]["WONum"]);
                    }
                }


                var unChkOrderCount = 0;
                var chkedOrderCount = 0;


                var unChkedLen = unChkDataList.length;
                for (var j = 0; j < unChkedLen; j++) {
                    var unItems = unChkDataList[j].Items;
                    var items = unChkDataList[j].WONums.join(',');
                    uncheckedliHtml += '<ul class="list-view list-equipC" data-theme="c" data-corner="all">';
                    uncheckedliHtml += '<li>';
                    uncheckedliHtml += '<span id="bntStart' + unItems[0]["JobPlanNum"] + '" Items=' + items + ' class="beginTb">开始填报</span>';
                    uncheckedliHtml += '<div  data-role="BTButton" data-icon=" icon-list-down"  data-iconpos="right" >';
                    uncheckedliHtml += '<div  id="btnUnChkAll' + unItems[0]["JobPlanNum"] + '" Items=' + items + ' data-role="BTCheck">' + unItems[0]["DeviceTypeName"] + '</div>';
                    uncheckedliHtml += '</div>';
                    uncheckedliHtml += '<div class="collapse-content"><ul class="list-view">';
                    var unItemslen = unItems.length;
                    for (var k = 0; k < unItemslen; k++) {
                        uncheckedliHtml += '<li>';
                        uncheckedliHtml += '<div data-role="BTButton" >';
                        uncheckedliHtml += '<div class="row-box">';
                        uncheckedliHtml += '<div class="span1">';
                        if (unItems[k]["OrderDesc"].lastIndexOf("他检") > 0) {
                            uncheckedliHtml += '<div id=chk' + unItems[k]["WONum"] + ' data-role="BTCheck">' + unItems[k]["WONum"] + "_" + unItems[k]["OrderDesc"] + funGetCancelText(unItems[k]) + '</div>';
                        } else {
                            uncheckedliHtml += '<div id=chk' + unItems[k]["WONum"] + ' data-role="BTCheck">' + unItems[k]["WONum"] + "_" + unItems[k]["DeviceLocation"] + funGetCancelText(unItems[k]) + '</div>';
                        }
                        uncheckedliHtml += '</div>';
                        uncheckedliHtml += '<div id=' + unItems[k]["WONum"] + ' class="moreFill" align="right">填报</div>';
                        uncheckedliHtml += '</div>';
                        uncheckedliHtml += '</div>';
                        uncheckedliHtml += '</li>';
                        unChkOrderCount++;
                    }
                    uncheckedliHtml += '</ul>';
                    uncheckedliHtml += '</div>';
                    uncheckedliHtml += '</li>';
                    uncheckedliHtml += '</ul>';
                }

                var chkedLen = chkedDataList.length;
                for (var l = 0; l < chkedLen; l++) {
                    var chkedItems = chkedDataList[l].Items;
                    var itemsChked = chkedDataList[l].WONums.join(',');
                    checkedliHtml += '<ul class="list-view list-equipC" data-theme="c" data-corner="all">';
                    checkedliHtml += '<li>';
                    checkedliHtml += '<span id="btnMutualInspection' + chkedItems[0]["JobPlanNum"] + '" Items=' + itemsChked + ' class="beginTb">开始互检</span>';
                    checkedliHtml += '<div  data-role="BTButton" data-icon=" icon-list-down"  data-iconpos="right" >';
                    checkedliHtml += '<div  id="btnChkedAll' + chkedItems[0]["JobPlanNum"] + '" Items=' + itemsChked + ' data-role="BTCheck">' + chkedItems[0]["DeviceTypeName"] + '</div>';
                    checkedliHtml += '</div>';
                    checkedliHtml += '<div class="collapse-content"><ul class="list-view">';
                    var chkItemslen = chkedItems.length;
                    for (var m = 0; m < chkItemslen; m++) {
                        var mutFormIsFinished = chkedItems[m]["MutFormIsFinished"];
                        var mutFormIsFinishTime = chkedItems[m]["MutFormFinishTime"];
                        var mutualFinishTxt = "【已填报】";
                        if (mutFormIsFinished == "1") {
                            mutualFinishTxt = "【已完成互检】";
                        } else if (mutFormIsFinished == "0" && mutFormIsFinishTime) {
                            mutualFinishTxt = "【完成部分互检】";
                        }

                        checkedliHtml += '<li>';
                        checkedliHtml += '<div data-role="BTButton" >';
                        checkedliHtml += '<div class="row-box">';
                        checkedliHtml += '<div class="span1">';

                        if (chkedItems[m]["OrderDesc"].lastIndexOf("他检") > 0) {
                            checkedliHtml += '<div  id=chked' + chkedItems[m]["WONum"] + ' data-role="BTCheck">' + chkedItems[m]["WONum"] + "_" + chkedItems[m]["OrderDesc"] + mutualFinishTxt + funGetCancelText(chkedItems[m]) + '</div>';
                        } else {
                            checkedliHtml += '<div  id=chked' + chkedItems[m]["WONum"] + ' data-role="BTCheck">' + chkedItems[m]["WONum"] + "_" + chkedItems[m]["DeviceLocation"] + mutualFinishTxt + funGetCancelText(chkedItems[m]) + '</div>';
                        }
                        checkedliHtml += '</div>';
                        checkedliHtml += '<div id=' + chkedItems[m]["WONum"] + ' class="moreFill" align="right">修改</div>';
                        checkedliHtml += '</div>';
                        checkedliHtml += '</div>';
                        checkedliHtml += '</li>';
                        chkedOrderCount++;
                    }
                    checkedliHtml += '</ul>';
                    checkedliHtml += '</div>';
                    checkedliHtml += '</li>';
                    checkedliHtml += '</ul>';

                }


                $("#lblUnChkCount").text("未检查(" + unChkOrderCount + ")");
                $("#lblChkCount").text("已检查(" + chkedOrderCount + ")");

                var uncheckedCnt = document.getElementById(uncheckedContainerId);
                if (uncheckedCnt) {
                    if (uncheckedliHtml) {
                        uncheckedCnt.innerHTML = uncheckedliHtml;
                    } else {
                        uncheckedCnt.innerHTML = "";
                    }
                }

                var checkedCnt = document.getElementById(checkedContainerId);
                if (checkedCnt) {
                    if (checkedliHtml) {
                        checkedCnt.innerHTML = checkedliHtml;
                    } else {
                        checkedCnt.innerHTML = "";
                    }
                }

                if (uncheckedliHtml || checkedliHtml) {
                    ui.init();
                    _self.funBindEvent(unChkDataList, chkedDataList);
                }
            }
        });

    },

    funBindEvent: function (unChkDataList, chkedDataList) {
        var _self = this;
        var unChkedLen = unChkDataList.length;
        for (var i = 0; i < unChkedLen; i++) {
            var unItems = unChkDataList[i].Items;
            var unItemslen = unItems.length;
            var jobPlanNum = unItems[0]["JobPlanNum"];

            $("#bntStart" + jobPlanNum).click(function () {

                var btnStart = $(this);
                var items = btnStart.attr("Items").split(',');
                var itemlen = items.length;
                var woNumList = new Array();
                for (var j = 0; j < itemlen; j++) {
                    var wONum = items[j];
                    if ($("#chk" + wONum).hasClass('BTCheck_ON')) {
                        woNumList.push(wONum);
                    }
                }

                if (woNumList.length == 1) {
                    EqlistHelper.funSingleOrder(_self.OPOrdersDic.Item(woNumList[0]), true);
                } else if (woNumList.length > 1) {
                    EqlistHelper.funMultiOrder(woNumList, _self.OPOrdersDic, true);
                } else {
                    app.alert("请先选择需要填报的工单");
                }
            });

            $("#btnUnChkAll" + jobPlanNum).click(function () {
                var unChkAll = $(this);
                var isCheckAll = unChkAll.hasClass('BTCheck_ON');
                var items = unChkAll.attr("Items").split(',');
                var itemlen = items.length;
                for (var j = 0; j < itemlen; j++) {
                    if (isCheckAll) {
                        $("#chk" + items[j]).removeClass("BTCheck_OFF").addClass("BTCheck_ON");
                    } else {
                        $("#chk" + items[j]).removeClass("BTCheck_ON").addClass("BTCheck_OFF");
                    }
                }
            });

            for (var k = 0; k < unItemslen; k++) {
                var unWoNum = unItems[k]["WONum"];
                $("#" + unWoNum).click(function () {
                    var unChkedCtr = $(this);
                    EqlistHelper.funSingleOrder(_self.OPOrdersDic.Item(unChkedCtr.attr("id")), true);
                });
            }
        }

        var chkedLen = chkedDataList.length;
        for (var l = 0; l < chkedLen; l++) {
            var chkedItems = chkedDataList[l].Items;
            var chkItemslen = chkedItems.length;

            var _jobPlanNum = chkedItems[0]["JobPlanNum"];

            $("#btnMutualInspection" + _jobPlanNum).click(function () {
                var btnMutualInspection = $(this);
                var itemsChked = btnMutualInspection.attr("Items").split(',');
                var itemlen = itemsChked.length;
                var woNumList = new Array();
                for (var j = 0; j < itemlen; j++) {
                    var wONum = itemsChked[j];
                    if ($("#chked" + wONum).hasClass('BTCheck_ON')) {
                        woNumList.push(wONum);
                    }
                }
                if (woNumList.length > 0) {
                    var url = "mutualInspection.html";
                    var sql = "SELECT * FROM OPOrders WHERE WONum IN ('" + woNumList.join("','") + "')";
                    EqlistHelper.funSqlSelect(sql, function (rowsOrder) {
                        if (rowsOrder && rowsOrder.length > 0) {
                            var rowsLenOrder = rowsOrder.length;
                            var pageParam = new Object();
                            pageParam.Devices = new Array();
                            for (var orderNum = 0; orderNum < rowsLenOrder; orderNum++) {
                                var objDevice = new Object();
                                objDevice.key = rowsOrder[orderNum]["WONum"];
                                objDevice.value = rowsOrder[orderNum]["DeviceNum"] + rowsOrder[orderNum]["DeviceName"];
                                pageParam.Devices.push(objDevice);
                            }
                            if (pageParam.Devices && pageParam.Devices.length > 1) {
                                pageParam.PageHeader = "工序互检-" + rowsOrder[0]["DeviceTypeName"] + "(" + pageParam.Devices.length + ")";
                            } else {
                                pageParam.PageHeader = "工序互检-" + rowsOrder[0]["DeviceLocation"];
                            }
                            Common.funLoad(url, pageParam);
                        }
                        else {
                            app.alert("请先,选择要开始互检的工单!");
                        }
                    });
                } else {
                    app.alert("请先,选择要开始互检的工单");
                }
            });

            $("#btnChkedAll" + _jobPlanNum).click(function () {
                var ChkedAll = $(this);
                var isCheckAll = ChkedAll.hasClass('BTCheck_ON');
                var itemsChked = ChkedAll.attr("Items").split(',');
                var itemlen = itemsChked.length;
                for (var j = 0; j < itemlen; j++) {
                    if (isCheckAll) {
                        $("#chked" + itemsChked[j]).removeClass("BTCheck_OFF").addClass("BTCheck_ON");
                    } else {
                        $("#chked" + itemsChked[j]).removeClass("BTCheck_ON").addClass("BTCheck_OFF");
                    }
                }
            });

            for (var m = 0; m < chkItemslen; m++) {
                var chkWoNum = chkedItems[m]["WONum"];
                $("#" + chkWoNum).click(function () {
                    var chkedCtr = $(this);
                    EqlistHelper.funSingleOrder(_self.OPOrdersDic.Item(chkedCtr.attr("id")), false);
                });
            }
        }
    },
    funBackRefresh : function () {
        var _self = this;
        app.getGlobalVariable("startWkList", function (res) {
            if (res) {
                _self.StartWkList = JSON.parse(res);
            }
        });
        setTimeout(function () {
            _self.funInitOrdersData("divUnChecked", "divChecked");
        }, 100);
    }
};




