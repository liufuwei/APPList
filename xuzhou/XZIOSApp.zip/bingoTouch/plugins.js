/*
 * version:v2.0
 * author:pa_dev
 * date:2013-9-25
 * */

/**/
; (function (window) {

    app.ajaxStream = function (url, data, success, fail) {
        var opts = { "orgin": "stream" };
        $.extend(data, opts); //combine data 
        app.ajax({
            "url": url,
            "data": data,
            "method": "POST",
            "success": success,
            "fail": fail
        });
    }
    //set runtime variable
    app.setGlobalVariable = function (key, value) {
        key = app.id + "_" + key;
        localStorage.setItem(key, value);
        // Cordova.exec(null, null, "ExtendApp", "setVariable", [key, value]);
    }
    //get runtime variable
    app.getGlobalVariable = function (key, callback) {
        key = app.id + "_" + key;
        callback(localStorage.getItem(key));
        // Cordova.exec(callback, null, "ExtendApp", "getVariable", [key]);
    }

    app.setting.get = function (key,defaultValue, success, fail) {
        NativeStorage.getItem(key, success, function () {
            success(defaultValue);
        });
    };


})(window);

$(function () {
    //应用标志|版本|应用名称|页面uri|页面参数|应用目录|应用size
    //isDebug 用于ios的测试版本判断
    var isDebug = true;
    var defaultId = ""
    window.devicePlatform = "iOS";
    if (window.devicePlatform == "iOS") {
        if (isDebug) {
            defaultId = "lmistest"
        } else {
            defaultId = "lmis"
        }
    }
    app.id = defaultId;
    app.version = "";
    app.name = "";
    app.pageUri = "";
    app.pageParams = {};
    app.directory = {};
    app.size = {};

    //页面初始化的时候先把这些常用数据拿到
    document.addEventListener("deviceready", function () {
        //获取当前页面要接收的参数
        app.getPageParams(function (result) {
            if (result != null) {
                app.pageParams = result;
            }
        });
        //获取应用相关信息
        app.getInfo(function (result) {
            //android 使用获取值，ios 使用默认值（因为ios获取异步可能会拿到空值
            if (window.devicePlatform == "android") {
                app.id = result.id;
            }
            app.version = result.versionName;
            app.name = result.appName;
        });
        //获取应用高度宽度
        app.getSize(function (result) {
            app.size = result;
        });
        //获取当前页面uri
        app.getCurrentUri(function (result) {
            app.pageUri = result;
        });
        //获取应用相关目录
        app.getAppDirectoryEntry(function (result) {
            app.directory = result;
        });
    }, false);
});
