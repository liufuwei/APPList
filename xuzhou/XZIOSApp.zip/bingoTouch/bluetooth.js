
;
(function (window) {
    window.app.bluetooth = window.app.bluetooth || {};
    app.bluetooth.init = function (success, error) {
        Cordova.exec(success, error, "BluetoothPlugin", "init", []);
    };

    app.bluetooth.search = function (method) {
        Cordova.exec(null, null, "BluetoothPlugin", "search", [method]);
    };

    app.bluetooth.connect = function (address) {
        Cordova.exec(null, null, "BluetoothPlugin", "connect", [address]);
    };
})(window);
