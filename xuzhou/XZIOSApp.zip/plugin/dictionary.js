﻿var Dictionary = function () {
    this.arrKeys = new Array();	//关键字数组
    this.arrValues = new Array();	//值数组
};

Dictionary.prototype = {
    Item: function (key) {
        var retItem = null;
        var itemIndex = this.GetElementIndex(key);
        if (itemIndex > -1) {
            retItem= this.arrValues[itemIndex];
        }
        return retItem;
    },
    
    Add: function (key, value) {
        var itemIndex = this.GetElementIndex(key);
        if (itemIndex == -1) {
            this.arrKeys.push(key);
            this.arrValues.push(value);
        } else {
            this.arrValues[itemIndex] = value;
        }
    },

    Keys: function () {
        return this.arrKeys;
    },

    Values: function () {
        return this.arrValues;
    },
    
    GetElementIndex: function (key) {
        var len = this.arrKeys.length;
        var retIndex = -1;
        for (var i = 0; i < len; i++) {
            if (this.arrKeys[i] == key) {
                retIndex = i;
                break;
            }
        }
        return retIndex;
    }
};

