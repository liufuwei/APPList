﻿var VideoBox = function (param) {
    ///<summary>构建函数</summary>
    ///<param name="param">param为Object对象，结构{ContainerId:容器ID,ObjectType:附件关联实体类型,ObjectID:附件关联实体编号}
    ///注其中,ObjectType为:WORKORDER,UDWOTASK,UDTOOLCK 其中：WORKORDER,工单、UDWOTASK,工序、UDTOOLCK,工具、WORKORDER,故障
    ///</param>
    this.ObjectType = param.ObjectType;
    this.ObjectID = param.ObjectID;
    this.ContainerId = param.ContainerId;
    this.PWONum = param["PWONum"] || "";
    this.InitAttList = param["InitAttList"] || new Array();
};

VideoBox.prototype = {
    addVideo: function (scopeVideoBox) {
        ///<summary>添加视频</summary>
        ///<param name="scopeVideoBox">scopeVideoBox作用域</param>
        navigator.device.capture.captureVideo(function (mediaFiles) {
            var len = mediaFiles.length;
            for (var i = 0; i < len; i += 1) {
                var path = mediaFiles[i].fullPath;
                window.resolveLocalFileSystemURI(path, function (fileEntry) {
                    fileEntry.file(function (fileObj) {
                        var fileSize = fileObj.size;
                        if (fileSize <= 52428800) {
                            scopeVideoBox.createVideo(path, scopeVideoBox);
                        } else {
                            app.alert("视频时间过长，请控制到20秒以内");
                        }
                    });
                }, null);
            }
        }, function (error) {
            if (error.code != 3) {
                app.alert("视频异常:" + JSON.stringify(error));
            }
        }, { limit: 1 });
    },

    initBox: function (scopeVideoBox) {
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            tx.executeSql('SELECT * from AttFile where AttType="Videos" and ObjectType=? and ObjectID=?', [scopeVideoBox.ObjectType, scopeVideoBox.ObjectID], function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                var cntIdList = new Array();
                var liHtml = scopeVideoBox.initAttch(scopeVideoBox, cntIdList);
                var rowslen = rows.length;
                for (var j = 0; j < rowslen; j++) {
                    var row = rows[j];
                    var attNum = row["AttNum"];
                    var attDesc = row["AttDesc"];
                    var attPath = row["AttPath"];
                    liHtml += '<div class="photoList">';
                    liHtml += '<div class="photoFih">';
                    liHtml += '<img id="video' + attNum + '" src="img/selvideo.png" attPath="' + attPath + '"  />';
                    liHtml += '<a href="###" class="delImg" attPath="' + attPath + '" attNum="' + attNum + '"  id="delFile' + attNum + '"></a>';
                    liHtml += '<a href="###" class="addAttDesc"  attNum="' + attNum + '"  attDesc="' + attDesc + '"  id="addAttDesc' + attNum + '"></a>';
                    liHtml += '</div>';
                    liHtml += '</div>';
                    cntIdList.push(attNum);
                }

                liHtml += '<div id="addVideo_VideoBox" class="photoList">';
                liHtml += '<div class="photoFih">';
                liHtml += '<img src="img/addvideo.png" />';
                liHtml += '</div>';
                liHtml += '</div>';
                var cnt = document.getElementById(scopeVideoBox.ContainerId);
                if (cnt) {
                    cnt.innerHTML = liHtml;
                    scopeVideoBox.bindEvent(cntIdList, scopeVideoBox);
                }
            });
        }, function (error) {
            app.alert(error);
        });

    },

    initAttch: function (scopePhotoBox, cntIdList) {
        var liHtml = "";
        var attList = scopePhotoBox.InitAttList;
        var attLen = attList.length;
        for (var i = 0; i < attLen; i++) {
            var row = attList[i];
            var attNum = Common.funGetPkId();
            var attPath = row["path"];
            liHtml += '<div class="photoList">';
            liHtml += '<div class="photoFih">';
            liHtml += '<img id="video' + attNum + '" src="img/selvideo.png" attPath="' + attPath + '"  />';
            liHtml += '</div>';
            liHtml += '</div>';
            if (cntIdList) {
                cntIdList.push(attNum);
            }

        }
        return liHtml;
    },

    bindEvent: function (cntIdList, scopeVideoBox) {
        var cntIdlen = cntIdList.length;
        for (var i = 0; i < cntIdlen; i++) {
            var attNum = cntIdList[i];
            $("#video" + attNum).click(function () {
                var cnt = $(this);
                var src = cnt.attr("attPath");
                if (src) {
                    app.openFile(src);
                }
            });

            $("#delFile" + attNum).click(function () {
                var cnt = $(this);
                var attNumId = cnt.attr("attNum");
                var attPath = cnt.attr("attPath");
                app.confirm("确认要删除此视频", function (index) {
                    if (index == 2) {
                        var db = app.database.open(Common.WEIXIUDB);
                        db.transaction(function (tx) {
                            tx.executeSql('DELETE from  AttFile where AttNum=?', [attNumId]);
                        }, function (error) {
                            app.alert(error);
                        }, function () {
                            if (attPath) {
                                window.resolveLocalFileSystemURI(attPath, function (fileEntry) {
                                    fileEntry.remove();
                                }, null);
                            }
                            scopeVideoBox.initBox(scopeVideoBox);
                        });
                    }
                }, "删除视频确认", "取消,确定");
            });

            $("#addAttDesc" + attNum).click(function () {
                var cnt = $(this);
                var attDesc = cnt.attr("attDesc");
                var attNote = window.prompt("添加视频备注", attDesc);
                if (attNote != null) {
                    var attNumId = cnt.attr("attNum");
                    var db = app.database.open(Common.WEIXIUDB);
                    db.transaction(function (tx) {
                        tx.executeSql('UPDATE AttFile set AttDesc=? where AttNum=?', [attNote, attNumId]);
                        cnt.attr("attDesc", attNote);
                    }, function (error) {
                        app.alert(error);
                    });
                }
            });
        }

        $("#addVideo_VideoBox").click(function () {
            //lsw 2017年12月5日 苹果暂时不支持视频和音频的录制，等迁入浅海需要双平台适配
            if (window.devicePlatform == "iOS") {
                app.alert("苹果暂时不支持视频录制");
            } else {
                scopeVideoBox.addVideo(scopeVideoBox);
            }
        });
    },

    createVideo: function (attPath, scopeVideoBox) {
        ///<summary>创建图片</summary>
        ///<param name="attPath">图片路径</param>
        ///<param name="scopePhotoBox">PhotoBox作用域</param>
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            var attNum = Common.funGetPkId();
            tx.executeSql('INSERT INTO AttFile(AttNum,AttType,ObjectType,ObjectID,AttPath,PWONum) VALUES ("' + attNum + '",?,?,?,?,?)', ["Videos", scopeVideoBox.ObjectType, scopeVideoBox.ObjectID, attPath, scopeVideoBox.PWONum]);
        }, function (error) {
            app.alert(error);
        }, function () {
            scopeVideoBox.initBox(scopeVideoBox);
        });
    },


    getVideoInfo: function () {
        var _self = this;
        var attPaths = $("#" + _self.ContainerId).find("a[class='delImg']");
        var attDecs = $("#" + _self.ContainerId).find("a[class='addAttDesc']");

        var paths = attPaths.map(function () {
            return $(this).attr("attPath");
        });
        var decs = attDecs.map(function () {
            return $(this).attr("attDesc");
        });

        var ret = new Array();
        var pathlen = paths.length;
        for (var i = 0; i < pathlen; i++) {
            ret.push({ "path": paths[i], "desc": decs[i] });
        }
        return ret;
    }

};