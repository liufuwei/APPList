﻿var PhotoBox = function (param) {
    ///<summary>构建函数</summary>
    ///<param name="param">param为Object对象，结构{ContainerId:容器ID,ObjectType:附件关联实体类型,ObjectID:附件关联实体编号}
    ///注其中,ObjectType为:WORKORDER,UDWOTASK,UDTOOLCK 其中：WORKORDER,工单、UDWOTASK,工序、UDTOOLCK,工具、WORKORDER,故障
    ///</param>
    this.ObjectType = param.ObjectType;
    this.ObjectID = param.ObjectID;
    this.ContainerId = param.ContainerId;
    this.PWONum = param["PWONum"] || "";
    this.OrderType = param.OrderType;
    this.InitAttList = param["InitAttList"] || new Array();
};

PhotoBox.prototype = {
    addImg: function (scopePhotoBox) {
        ///<summary>添加图片</summary>
        ///<param name="scopePhotoBox">PhotoBox作用域</param>
        navigator.camera.getPicture(function (mediaFiles) {
            var imgPath = mediaFiles;
            var opts = { "source": imgPath, "savePath": imgPath };
            app.file.imageCompress(opts, function (res) { }, function (res) { });
            scopePhotoBox.createImg(imgPath, scopePhotoBox);

            //var len = mediaFiles.length;
            //for (var i = 0; i < len; i += 1) {
            //    var imgPath = mediaFiles[i].fullPath;
            //    var opts = { "source": imgPath, "savePath": imgPath };
            //    app.file.imageCompress(opts, function (res) { }, function (res) { });
            //    scopePhotoBox.createImg(imgPath, scopePhotoBox);
            //}
        }, function (error) {
            if (error.code != 3) {
                app.alert("拍照异常:" + JSON.stringify(error));
            }
        }, { limit: 1 });
    },

    initBox: function (scopePhotoBox) {
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            tx.executeSql('SELECT * from AttFile where (AttType="Images" or AttType="RepImages") and ObjectType=? and ObjectID=?', [scopePhotoBox.ObjectType, scopePhotoBox.ObjectID], function (tx, results) {
                var rows = Common.funConvertRowsJson(results);
                var cntIdList = new Array();
                var liHtml = scopePhotoBox.initAttch(scopePhotoBox, cntIdList);
                var rowslen = rows.length;
                for (var j = 0; j < rowslen; j++) {
                    var row = rows[j];
                    var attNum = row["AttNum"];
                    var attDesc = row["AttDesc"];
                    var attPath = row["AttPath"];
                    var attType = row['AttType'];
                    liHtml += '<div class="photoList">';
                    liHtml += '<div class="photoFih">';
                    liHtml += '<img id="Img' + attNum + '" src="' + attPath + '" atttype="' +  attType  + '" />';
                    if(scopePhotoBox.OrderType == "CM" || scopePhotoBox.OrderType == "CBM"){
                        if(attType == 'RepImages'){
                            liHtml += '<a href="###" class="delImg"   attPath="' + attPath + '"  attNum="' + attNum + '"  id="delFile' + attNum + '"></a>';
                            liHtml += '<a href="###" class="addAttDesc"  attNum="' + attNum + '"  attDesc="' + attDesc + '"  id="addAttDesc' + attNum + '"></a>';
                        }
                    }else{
                        liHtml += '<a href="###" class="delImg"   attPath="' + attPath + '"  attNum="' + attNum + '"  id="delFile' + attNum + '"></a>';
                        liHtml += '<a href="###" class="addAttDesc"  attNum="' + attNum + '"  attDesc="' + attDesc + '"  id="addAttDesc' + attNum + '"></a>';
                    }
                    
                    liHtml += '</div>';
                    liHtml += '</div>';
                    cntIdList.push(attNum);
                }

                liHtml += '<div id="addImg_PhotoBox" class="photoList">';
                liHtml += '<div class="photoFih">';
                liHtml += '<img src="img/add.png" />';
                liHtml += '</div>';
                liHtml += '</div>';
                var cnt = document.getElementById(scopePhotoBox.ContainerId);
                if (cnt) {
                    cnt.innerHTML = liHtml;
                    scopePhotoBox.bindEvent(cntIdList, scopePhotoBox);
                }
            });
        }, function (error) {
            app.alert(error);
        });
    },

    initAttch: function (scopePhotoBox, cntIdList) {
        var liHtml = "";
        var attList = scopePhotoBox.InitAttList;
        var attLen = attList.length;
        for (var i = 0; i < attLen; i++) {
            var row = attList[i];
            var attNum = Common.funGetPkId();
            var attPath = row["path"];
            liHtml += '<div class="photoList">';
            liHtml += '<div class="photoFih">';
            liHtml += '<img id="Img' + attNum + '" src="' + attPath + '" />';
            liHtml += '</div>';
            liHtml += '</div>';
            if (cntIdList) {
                cntIdList.push(attNum);
            }

        }
        return liHtml;
    },
    
    bindEvent: function (cntIdList, scopePhotoBox) {
        var cntIdlen = cntIdList.length;
        for (var i = 0; i < cntIdlen; i++) {
            var attNum = cntIdList[i];

            $("#Img" + attNum).click(function () {
                var cnt = $(this);
                var src = cnt.attr("src");
                if (src) {
                    app.openFile(src);
                }

            });

            $("#delFile" + attNum).click(function () {
                var cnt = $(this);
                var attNumId = cnt.attr("attNum");
                var attPath = cnt.attr("attPath");
                app.confirm("确认要删除此图片", function (index) {
                    if (index == 2) {
                        var db = app.database.open(Common.WEIXIUDB);
                        db.transaction(function (tx) {
                            tx.executeSql('DELETE from  AttFile where AttNum=?', [attNumId]);
                        }, function (error) {
                            app.alert(error);
                        }, function () {
                            if (attPath) {
                                window.resolveLocalFileSystemURI(attPath, function (fileEntry) {
                                    fileEntry.remove();
                                }, null);
                            }
                            scopePhotoBox.initBox(scopePhotoBox);
                        });
                    }
                }, "删除图片确认", "取消,确定");
            });

            $("#addAttDesc" + attNum).click(function () {
                var cnt = $(this);
                var attDesc = cnt.attr("attDesc");
                var attNote = window.prompt("添加图片备注", attDesc);
                if (attNote != null) {
                    var attNumId = cnt.attr("attNum");
                    var db = app.database.open(Common.WEIXIUDB);
                    db.transaction(function (tx) {
                        tx.executeSql('UPDATE AttFile set AttDesc=? where AttNum=?', [attNote, attNumId]);
                        cnt.attr("attDesc", attNote);
                    }, function (error) {
                        app.alert(error);
                    });
                }
            });
        }

        $("#addImg_PhotoBox").click(function () {
            scopePhotoBox.addImg(scopePhotoBox);
        });
    },

    createImg: function (attPath, scopePhotoBox) {
        ///<summary>创建图片</summary>
        ///<param name="attPath">图片路径</param>
        ///<param name="scopePhotoBox">PhotoBox作用域</param>
        //alert(JSON.stringify(attPath));
        var db = app.database.open(Common.WEIXIUDB);
        db.transaction(function (tx) {
            var attNum = Common.funGetPkId();
            var typeimg = 'Images';
            if(scopePhotoBox.OrderType == "CM" || scopePhotoBox.OrderType == "CBM"){
                typeimg = 'RepImages'
            }
            tx.executeSql('INSERT INTO AttFile(AttNum,AttType,ObjectType,ObjectID,AttPath,PWONum) VALUES ("' + attNum + '",?,?,?,?,?)', [typeimg , scopePhotoBox.ObjectType, scopePhotoBox.ObjectID, attPath, scopePhotoBox.PWONum]);
        }, function (error) {
            app.alert(error);
        }, function () {
            scopePhotoBox.initBox(scopePhotoBox);
        });
    },

    getImgInfo: function () {
        var _self = this;
        var attPaths = $("#" + _self.ContainerId).find("a[class='delImg']");
        var attDecs = $("#" + _self.ContainerId).find("a[class='addAttDesc']");

        var paths = attPaths.map(function () {
            return $(this).attr("attPath");
        });
        var decs = attDecs.map(function () {
            return $(this).attr("attDesc");
        });

        var ret = new Array();
        var pathlen = paths.length;
        for (var i = 0; i < pathlen; i++) {
            ret.push({ "path": paths[i], "desc": decs[i] });
        }
        return ret;
    }
};