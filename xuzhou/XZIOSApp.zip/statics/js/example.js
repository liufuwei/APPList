
$(document).bind("pagebeforecreate",function(){
	//动态插入查看代码
	example();
})
function example(){

	$('.example').each(function(){
		var showHtml = $.trim($(this).find('.example-show').html());
			//替换字符串
		var newHtml = showHtml.replace(/(<)/img,"&lt;");
			//全局查找匹配的属性 data 开头
		//var arr = newHtml.match(/data\S*?="\S*?"/img);
		
		var arr = newHtml.match(/="\S*?"/img);
		for(var i=0;i<arr.length;i++){
			//找到引号里面的内容
			 var key=arr[i].match(/"\S*?"/img)[0];	
			
				 //查找全局的
				 var reg=new RegExp(key,"img");
				 newHtml=newHtml.replace(reg,"<span class='blue'>"+key+"</span>");
			
		}
		
		var html = '';
			html +='<ul class="list-view list-collapse" data-theme="a" data-corner="all">';
			html +='		<li><div data-role="BTButton" class="subtitle" data-icon="icon-list-down" data-iconpos="right">查看代码</div>';
			html +='			<div class="collapse-content">';
			html +='			<pre>'+ newHtml +'</pre>';
			html +='			</div>';
			html +='		</li>';
			html +='</ul>';
		//动态添加查看代码按钮	
			$(this).append(html);
	})
	
}