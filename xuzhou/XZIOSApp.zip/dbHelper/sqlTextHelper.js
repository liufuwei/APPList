﻿var SqlTextHelper = {};
SqlTextHelper.funGetInsertText = function (tableName, paramEntityList) {
    ///<summary>插入数据</summary>
    ///<param name="tableName">表名</param>
    ///<param name="paramEntityList">参数条件[{字段名:值，字段名:值}]</param>
    var sqlList = new Array();
    var _paramEntityList = paramEntityList || new Array();
    var _listLength = _paramEntityList.length;
    if (_listLength > 0) {
        var sql = "insert into " + tableName;
        var clmNameList = new Array();
        for (var clnNameItem in _paramEntityList[0]) {
            clmNameList.push(clnNameItem);
        }
        var clmlen = clmNameList.length;
        sql += " (" + clmNameList.join(",") + ")";
        var count = 0;
        var sqlVal = "";
        for (var i = 0; i < _listLength; i++) {
            count++;
            var clmValList = new Array();
            var item = _paramEntityList[i];
            for (var j = 0; j < clmlen; j++) {
                var clmName = clmNameList[j];
                var clmVal = item[clmName] || "";
                if (clmVal) {
                    clmVal += "";
                    clmVal = clmVal.replace(/'/g, "");
                }
                clmValList.push("'" + clmVal + "'");
            }
            if (count == 400 || (i + 1) == _listLength) {
                sqlVal += " select " + clmValList.join(",");
            } else {
                sqlVal += " select " + clmValList.join(",") + " union all";
            }
            if (count == 400 || (i + 1) == _listLength) {
                sqlList.push(sql + sqlVal);
                sqlVal = "";
                count = 0;
            }
        }
    }
    return sqlList;
};

SqlTextHelper.funUpdateDataText = function (tableName, paramEntity) {
    ///<summary>修改数据</summary>
    ///<param name="tableName">表名</param>
    ///<param name="paramEntity">参数条件[{字段名:set值，字段名:set值,WhereParam:{字段名:where值,字段名:where值}]</param>
    var updSetList = new Array();
    var updWhereList = new Array();
    for (var setParamItem in paramEntity) {
        if (setParamItem == "WhereParam") {
            for (var whereParamItem in paramEntity["WhereParam"]) {
                updWhereList.push(whereParamItem + "=" + "'" + paramEntity["WhereParam"][whereParamItem] + "'");
            }
        } else {
            updSetList.push(setParamItem + "=" + "'" + paramEntity[setParamItem] + "'");
        }
    }
    var sql = "";
    if (updSetList.length > 0) {
        sql += "update " + tableName + " set " + updSetList.join(" , ");
        if (updWhereList.length > 0) {
            sql += " where " + updWhereList.join(" and ");
        }
    }
    return sql;
};

