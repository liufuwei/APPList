﻿var SqlHelper = {};

///<summary>业务数据库名称</summary>
SqlHelper.WEIXIUDB = "WEIXIUDB";

/////<summary>基础数据库名称</summary>
SqlHelper.WEIXIUBASEDB = "WEIXIUDB";

SqlHelper.funGetData = function (tableName, successfun, paramEntity, dataBaseName) {
    ///<summary>获取数据</summary>
    ///<param name="tableName">查询的表名</param>
    ///<param name="successfun">查询成功回调函数function(rows)参数rows:Json对象数组</param>
    ///<param name="paramEntity">查询条件为Json对象[OrderParam为排序条件]{字段名:值，字段名:值,"OrderParam":"列1 asc,列2 desc,....."}</param>
    ///<param name="dataBaseName">数据库名,默认：WEIXIUDB</param>
    var sql = "SELECT * FROM " + tableName;
    var _paramEntity = paramEntity || {};
    var _dataBaseName = dataBaseName || SqlHelper.WEIXIUDB;
    var paramList = new Array();
    var orderParam = "";
    for (var paramItem in _paramEntity) {
        if (paramItem == "OrderParam") {
            orderParam = _paramEntity["OrderParam"];
        } else {
            paramList.push(paramItem + "=" + "'" + _paramEntity[paramItem] + "'");
        }
    }
    if (paramList.length > 0) {
        sql += " WHERE " + paramList.join(" and ");
    }
    if (orderParam.length > 0) {
        sql += " Order by " + orderParam;
    }
    var db = app.database.open(_dataBaseName);
    app.database.executeQuery(db, sql, function (tx, results) {
        var len = results.rows.length;
        var rows = results.rows;
        var dataTable = new Array();
        for (var i = 0; i < len; i++) {
            var row = new Object();
            for (var clmField in rows.item(i)) {
                row[clmField] = rows.item(i)[clmField];
            }
            dataTable.push(row);
        }
        successfun(dataTable);
    });
};

SqlHelper.funGetDataByWhere = function (tableName, successfun, paramEntity, whereCondition, dataBaseName) {
    ///<summary>获取数据,可直接提供查询条件</summary>
    ///<param name="tableName">查询的表名</param>
    ///<param name="successfun">查询成功回调函数function(rows)参数rows:Json对象数组</param>
    ///<param name="paramEntity">查询条件为Json对象[OrderParam为排序条件]{字段名:值，字段名:值,"OrderParam":"列1 asc,列2 desc,....."}</param>
    ///<param name="whereCondition">直接使用的查询条件 如：and 字段名1='' and 字段名2 in('') and 字段名3 like '%%'</param>
    ///<param name="dataBaseName">数据库名,默认：WEIXIUDB</param>
    var sql = "SELECT * FROM " + tableName + " WHERE 1=1 ";
    var _paramEntity = paramEntity || {};
    var _dataBaseName = dataBaseName || SqlHelper.WEIXIUDB;
    var paramList = new Array();
    var orderParam = "";
    for (var paramItem in _paramEntity) {
        if (paramItem == "OrderParam") {
            orderParam = _paramEntity["OrderParam"];
        } else {
            paramList.push(paramItem + " IN " + "('" + _paramEntity[paramItem] + "')");
        }
    }
    if (paramList.length > 0) {
        sql += " and " + paramList.join(" and ");
    }
    if (whereCondition && whereCondition.length > 0) {
        sql += whereCondition;
    }
    if (orderParam.length > 0) {
        sql += " Order by " + orderParam;
    }
    var db = app.database.open(_dataBaseName);
    app.database.executeQuery(db, sql, function (tx, results) {
        var len = results.rows.length;
        var rows = results.rows;
        var dataTable = new Array();
        for (var i = 0; i < len; i++) {
            var row = new Object();
            for (var clmField in rows.item(i)) {
                row[clmField] = rows.item(i)[clmField];
            }
            dataTable.push(row);
        }
        successfun(dataTable);
    });
};

SqlHelper.funDeleteData = function (paramEntityList, successfun, dataBaseName) {
    ///<summary>获取数据</summary>
    ///<param name="paramEntityList">参数条件[{TableName:"表名",字段名:值，字段名:值}]</param>
    ///<param name="successfun">删除成功回调函数function(affectedCount)参数affectedCount:影响行数</param>
    ///<param name="dataBaseName">数据库名,默认：WEIXIUDB</param>
    var _paramEntityList = paramEntityList || new Array();
    var _dataBaseName = dataBaseName || SqlHelper.WEIXIUDB;
    var _listLength = _paramEntityList.length;
    if (_listLength > 0) {
        var delSqlList = new Array();
        for (var i = 0; i < _listLength; i++) {
            {
                var delWhereList = new Array();
                var sql = "";
                for (var paramItem in _paramEntityList[i]) {
                    if (paramItem == "TableName") {
                        sql += "DELETE FROM " + _paramEntityList[i]["TableName"];
                    } else {
                        delWhereList.push(paramItem + "=" + "'" + _paramEntityList[i][paramItem] + "'");
                    }
                }
                if (sql != "") {
                    if (delWhereList.length > 0) {
                        sql += " where " + delWhereList.join(" and ");
                    }
                    delSqlList.push(sql);
                }
            }
        }
        if (delSqlList.length > 0) {
            var dbName = app.database.open(_dataBaseName);
            app.database.executeNonQuery(dbName, delSqlList, successfun);
        }
    }
};

SqlHelper.funInsertData = function (tableName, paramEntityList, successfun, dataBaseName) {
    ///<summary>插入数据</summary>
    ///<param name="tableName">表名</param>
    ///<param name="paramEntityList">参数条件[{字段名:值，字段名:值}]</param>
    ///<param name="successfun">插入成功回调函数function</param>
    ///<param name="dataBaseName">数据库名,默认：WEIXIUDB</param>
    var sql = "insert into " + tableName;
    var _paramEntityList = paramEntityList || new Array();
    var _dataBaseName = dataBaseName || SqlHelper.WEIXIUDB;
    var _listLength = _paramEntityList.length;
    if (_listLength > 0) {
        var sqlList = new Array();
        var clmNameList = new Array();
        for (var clnNameItem in _paramEntityList[0]) {
            clmNameList.push(clnNameItem);
        }
        var clmlen = clmNameList.length;
        sql += " (" + clmNameList.join(",") + ")";
        var count = 0;
        var sqlVal = "";
        for (var i = 0; i < _listLength; i++) {
            count++;
            var clmValList = new Array();
            
            var item = _paramEntityList[i];
            for (var j = 0; j < clmlen; j++) {
                var clmName = clmNameList[j];
                var clmVal = item[clmName] || "";
                clmValList.push("'" + clmVal + "'");
            }
            
            if (count == 400 || (i + 1) == _listLength) {
                sqlVal += " select " + clmValList.join(",");
            } else {
                sqlVal += " select " + clmValList.join(",") + " union all";
            }

            if (count == 400 || (i + 1) == _listLength) {
                sqlList.push(sql + sqlVal);
                sqlVal = "";
                count = 0;
            }
        }
        var dbName = app.database.open(_dataBaseName);
        app.database.executeNonQuery(dbName, sqlList, successfun);
    }
};

SqlHelper.funUpdateData = function (tableName, paramEntityList, successfun, dataBaseName) {
    ///<summary>修改数据</summary>
    ///<param name="tableName">表名</param>
    ///<param name="paramEntityList">参数条件[{字段名:set值，字段名:set值,WhereParam:{字段名:where值,字段名:where值}]</param>
    ///<param name="successfun">修改成功回调函数function()</param>
    ///<param name="dataBaseName">数据库名,默认：WEIXIUDB</param>
    var _paramEntityList = paramEntityList || new Array();
    var _dataBaseName = dataBaseName || SqlHelper.WEIXIUDB;
    var _listLength = _paramEntityList.length;
    if (_listLength > 0) {
        var updSqlList = new Array();
        for (var i = 0; i < _listLength; i++) {
            {
                var updSetList = new Array();
                var updWhereList = new Array();
                for (var setParamItem in _paramEntityList[i]) {
                    if (setParamItem == "WhereParam") {
                        for (var whereParamItem in _paramEntityList[i]["WhereParam"]) {
                            updWhereList.push(whereParamItem + "=" + "'" + _paramEntityList[i]["WhereParam"][whereParamItem] + "'");
                        }
                    } else {
                        updSetList.push(setParamItem + "=" + "'" + _paramEntityList[i][setParamItem] + "'");
                    }
                }
            }
            var sql = "";
            if (updSetList.length > 0) {
                sql += "update " + tableName + " set " + updSetList.join(" , ");
                if (updWhereList.length > 0) {
                    sql += " where " + updWhereList.join(" and ");
                }
                updSqlList.push(sql);
            }
        }
        if (updSqlList.length > 0) {
            var dbName = app.database.open(_dataBaseName);
            app.database.executeNonQuery(dbName, updSqlList, successfun);
        }
    }
};
